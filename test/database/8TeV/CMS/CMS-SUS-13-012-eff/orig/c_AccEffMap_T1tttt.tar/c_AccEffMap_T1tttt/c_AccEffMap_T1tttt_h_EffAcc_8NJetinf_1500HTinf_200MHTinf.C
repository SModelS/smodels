{
//=========Macro generated from canvas: c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf/c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf
//=========  (Sat Feb 22 16:31:37 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf = new TCanvas("c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf", "c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf",125,360,500,500);
   c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf->SetFillColor(0);
   c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf->SetLogz();
   c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1500HTinf_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1500HTinf_200MHTinf","h_EffAcc_8NJetinf_1500HTinf_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(79,0.0001133017);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(81,0.0002435288);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(83,0.0005640326);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(85,0.001348573);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(87,0.001973478);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(89,0.003167706);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(91,0.004822471);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(93,0.00677018);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(95,0.008857961);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(97,0.0117946);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(99,0.01484367);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(101,0.01978437);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(103,0.02476824);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(105,0.02956875);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(107,0.03556431);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(109,0.04195838);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(111,0.0473492);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(113,0.05327669);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(115,0.05963532);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(117,0.06437386);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(119,0.06922804);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(141,9.275958e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(143,0.0003195434);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(145,0.0007033258);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(147,0.001120622);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(149,0.002062382);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(151,0.003133075);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(153,0.004451076);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(155,0.006436849);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(156,0.00732885);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(158,0.010268);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(160,0.0134331);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(162,0.01738558);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(164,0.02174713);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(166,0.02683387);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(168,0.03170083);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(169,0.03518673);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(171,0.04037663);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(173,0.04687996);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(175,0.0520207);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(177,0.05977115);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(179,0.06489379);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(181,0.06891418);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(265,0.0001211242);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(267,0.000232416);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(269,0.0006249843);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(271,0.001034361);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(273,0.00163836);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(275,0.002551657);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(277,0.003689987);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(279,0.005531084);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(280,0.006624475);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(282,0.008999383);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(284,0.0123699);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(286,0.01605257);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(288,0.01951568);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(290,0.02410895);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(292,0.03000145);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(293,0.03268804);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(295,0.03820398);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(297,0.04562969);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(299,0.05051883);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(301,0.05691212);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(303,0.06213499);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(305,0.06918778);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(389,8.493617e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(391,0.0002101355);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(393,0.0003823661);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(395,0.0007692226);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(397,0.001266824);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(399,0.002041619);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(401,0.003468241);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(403,0.0043996);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(404,0.005527666);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(406,0.007827344);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(408,0.01019684);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(410,0.01379748);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(412,0.01760233);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(414,0.02158575);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(416,0.02682758);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(417,0.03001891);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(419,0.03476226);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(421,0.04168448);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(423,0.04866308);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(425,0.05462557);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(427,0.06039235);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(429,0.06662403);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(513,3.641471e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(515,0.000109183);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(517,0.0003057113);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(519,0.0003925898);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(521,0.0008871556);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(523,0.001540579);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(525,0.002341837);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(527,0.003482661);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(528,0.004404682);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(530,0.006082909);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(532,0.008488829);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(534,0.0109528);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(536,0.01476093);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(538,0.0181386);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(540,0.02322427);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(541,0.0257726);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(543,0.03180609);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(545,0.03832948);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(547,0.04422686);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(549,0.05025902);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(551,0.05687013);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(553,0.0625522);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(639,5.766737e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(641,0.0001179142);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(643,0.0002929452);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(645,0.0005658529);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(647,0.001004287);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(649,0.001777348);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(651,0.002638437);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(652,0.002965264);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(654,0.004696343);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(656,0.006577018);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(658,0.008847152);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(660,0.01196587);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(662,0.01537985);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(664,0.01955243);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(665,0.02265107);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(667,0.02752002);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(669,0.03308623);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(671,0.03858295);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(673,0.04665425);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(675,0.0536334);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(677,0.05837958);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(765,7.46724e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(767,0.0001922508);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(769,0.0003324937);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(771,0.0006665475);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(773,0.001255684);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(775,0.001746696);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(776,0.002290172);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(778,0.003448339);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(780,0.004642406);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(782,0.007236528);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(784,0.008504984);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(786,0.01179424);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(788,0.0157641);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(789,0.01747824);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(791,0.02300011);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(793,0.02802919);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(795,0.03413952);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(797,0.04073264);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(799,0.04738846);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(801,0.05417897);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(891,0.0001329212);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(893,0.0001761297);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(895,0.0004531656);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(897,0.0007357139);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(899,0.001307267);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(900,0.001465072);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(902,0.002438247);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(904,0.003603391);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(906,0.00485469);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(908,0.007158396);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(910,0.009253079);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(912,0.01259682);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(913,0.01417085);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(915,0.01790584);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(917,0.02217817);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(919,0.02821958);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(921,0.03479148);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(923,0.04193591);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(925,0.04891285);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1017,4.40958e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1019,0.0002265571);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1021,0.0004597816);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1023,0.0007264981);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1024,0.0009971497);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1026,0.001589668);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1028,0.002651111);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1030,0.003828828);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1032,0.005138263);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1034,0.006900537);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1036,0.009355153);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1037,0.0106358);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1039,0.01414852);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1041,0.01860109);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1043,0.02331117);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1045,0.03000102);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1047,0.03547947);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1049,0.04115721);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1143,0.0001328725);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1145,0.0001817658);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1147,0.0004221545);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1148,0.0007026567);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1150,0.001016588);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1152,0.001399379);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1154,0.002106613);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1156,0.003487211);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1158,0.005148079);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1160,0.007299361);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1161,0.007916545);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1163,0.01048993);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1165,0.0143853);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1167,0.01886891);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1169,0.02330741);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1171,0.02917005);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1173,0.03703564);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1269,8.679739e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1271,0.0002244238);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1272,0.0002546877);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1274,0.0005803561);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1276,0.001089923);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1278,0.001570245);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1280,0.002379418);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1282,0.003702497);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1284,0.004855367);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1285,0.005774784);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1287,0.007919971);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1289,0.01068576);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1291,0.0147425);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1293,0.01936648);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1295,0.02405109);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1297,0.02955973);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1395,4.510451e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1396,0.0001286093);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1398,0.0003070476);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1400,0.0006117341);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1402,0.0009393607);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1404,0.001607477);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1406,0.002291105);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1408,0.003536215);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1409,0.003822192);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1410,0.004466695);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1411,0.005745762);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1412,0.006540742);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1413,0.008206174);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1414,0.009238397);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1415,0.01073638);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1416,0.01287091);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1417,0.01424903);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1418,0.01681625);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1419,0.01912784);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1420,0.02111559);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1421,0.02264485);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1471,0.0034303);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1472,0.004234237);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1473,0.004991647);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1474,0.005943881);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1475,0.006789271);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1476,0.007972821);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1477,0.009169249);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1478,0.01077499);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1479,0.01281899);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1480,0.01411724);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1481,0.01630798);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1482,0.01838859);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1483,0.02070211);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1520,5.015092e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1522,8.52289e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1524,0.0002553226);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1526,0.0006597557);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1528,0.0009475333);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1530,0.001623572);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1532,0.002247098);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1533,0.002725072);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1534,0.003535369);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1535,0.004101943);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1536,0.005176754);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1537,0.005589331);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1538,0.006723004);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1539,0.007717357);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1540,0.009390542);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1541,0.01066966);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1542,0.01218436);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1543,0.01453319);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1544,0.01642122);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1545,0.01870441);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1595,0.001888622);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1596,0.002827089);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1597,0.003126211);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1598,0.004043785);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1599,0.00496653);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1600,0.005398232);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1601,0.006713751);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1602,0.007667442);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1603,0.008967156);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1604,0.01066051);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1605,0.01223559);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1606,0.01355048);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1607,0.01602635);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1646,4.963329e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1648,9.137628e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1650,0.0002368231);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1652,0.0005357422);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1654,0.001100774);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1656,0.001559809);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1657,0.001659351);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1658,0.002082143);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1659,0.002851631);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1660,0.003401277);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1661,0.003738947);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1662,0.004976822);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1663,0.005710334);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1664,0.006398052);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1665,0.007767736);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1666,0.008999343);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1667,0.01064387);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1668,0.01190301);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1669,0.01367297);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1719,0.001625689);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1720,0.001929135);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1721,0.001917045);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1722,0.00251138);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1723,0.003244658);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1724,0.003815702);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1725,0.004796527);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1726,0.005507826);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1727,0.006315375);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1728,0.007601391);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1729,0.009021107);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1730,0.01034393);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1731,0.01175296);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1772,4.202473e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1774,0.0001324314);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1776,0.0001921652);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1778,0.0007095758);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1780,0.0007542957);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1781,0.001127512);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1782,0.001359357);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1783,0.001927958);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1784,0.001983394);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1785,0.002472946);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1786,0.003289586);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1787,0.003657318);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1788,0.004299734);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1789,0.005676331);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1790,0.006470656);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1791,0.007723599);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1792,0.008908657);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1793,0.01035109);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1843,0.0008269158);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1844,0.001181297);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1845,0.001433749);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1846,0.001630187);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1847,0.002254004);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1848,0.002525353);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1849,0.003177466);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1850,0.003806784);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1851,0.004235294);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1852,0.005304425);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1853,0.005985652);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1854,0.007535624);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1855,0.008679961);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1898,9.017668e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1900,0.0001090679);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1902,0.0002955073);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1904,0.0005595506);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1905,0.0006160944);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1906,0.0008796391);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1907,0.0009829684);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1908,0.001349843);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1909,0.001726084);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1910,0.002058916);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1911,0.002466742);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1912,0.002622717);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1913,0.003920243);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1914,0.004352638);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1915,0.005332997);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1916,0.006010546);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1917,0.007193005);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1967,0.0004870672);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1968,0.0006779468);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1969,0.0007607932);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1970,0.0009538011);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1971,0.001530609);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1972,0.001653297);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1973,0.001938102);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1974,0.00242265);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1975,0.002816367);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1976,0.003561572);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1977,0.004662823);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1978,0.005210725);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1979,0.00581844);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2024,1.370521e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2026,8.085177e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2028,0.000194401);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2029,0.0003520631);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2030,0.0005383212);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2031,0.0005000736);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2032,0.0008232392);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2033,0.001011762);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2034,0.001399425);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2035,0.001460603);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2036,0.001956051);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2037,0.002239655);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2038,0.003073565);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2039,0.003652345);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2040,0.004076833);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2041,0.004844707);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2091,0.0002247828);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2092,0.0002749241);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2093,0.0004746108);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2094,0.0006645214);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2095,0.0008865025);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2096,0.001100861);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2097,0.001277668);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2098,0.001543003);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2099,0.001784125);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2100,0.002401071);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2101,0.002815739);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2102,0.003383298);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2103,0.004206406);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2150,4.114867e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2152,0.0001212216);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2153,0.0001358564);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2154,0.000247135);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2155,0.0003833161);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2156,0.0004501788);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2157,0.0006924118);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2158,0.0009108928);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2159,0.0008303287);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2160,0.001253);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2161,0.001496263);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2162,0.001826574);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2163,0.00222929);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2164,0.002836082);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2165,0.003558042);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2215,2.23477e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2216,0.0001349999);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2217,0.0001957588);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2218,0.0002685271);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2219,0.000457305);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2220,0.0004762516);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2221,0.0008360257);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2222,0.001212797);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2223,0.001089227);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2224,0.001397132);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2225,0.001714963);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2226,0.002255101);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2227,0.002814709);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2276,1.992086e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2277,5.270719e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2278,8.173682e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2279,0.0001563914);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2280,0.000206969);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2281,0.0002593566);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2282,0.0004179213);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2283,0.0005012923);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2284,0.0007117913);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2285,0.0007530347);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2286,0.001012427);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2287,0.001519662);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2288,0.001509117);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2289,0.002252127);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2339,4.68148e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2340,8.206871e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2341,7.542481e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2342,0.0001281656);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2343,0.0002171285);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2344,0.0002787851);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2345,0.000387576);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2346,0.0005371999);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2347,0.0007834053);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2348,0.0009614117);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2349,0.00121853);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2350,0.001306243);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2351,0.001515348);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2402,5.931578e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2403,5.030378e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2404,1.373448e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2405,0.0002123628);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2406,0.0001935721);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2407,0.0002215607);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2408,0.0003916808);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2409,0.0005445512);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2410,0.0006342285);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2411,0.0009214514);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2412,0.001122776);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2413,0.001325962);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2465,6.620527e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2466,4.037561e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2467,7.084038e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2468,9.692447e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2469,0.0001672161);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2470,0.0001532382);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2471,0.000420283);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2472,0.0005015105);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2473,0.0007102868);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2474,0.0008558198);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2475,0.00109065);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2528,3.035155e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2529,4.051137e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2530,8.322993e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2531,0.000132177);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2532,0.0001787214);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2533,0.0002197739);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2534,0.0002895912);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2535,0.0004216532);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2536,0.0005741379);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2537,0.000829582);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2591,3.439897e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2592,3.182994e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2593,7.390769e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2594,0.0001279652);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2595,0.0001571418);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2596,0.0001855826);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2597,0.0004578213);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2598,0.0004204021);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2599,0.0005428497);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2655,6.425178e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2657,5.587416e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2659,0.0002516973);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2661,0.0005376124);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2781,1.239161e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2783,8.058332e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2785,0.0001695665);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2907,3.058733e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2909,6.691161e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3033,3.619156e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(79,2.832736e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(81,4.249422e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(83,6.573657e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(85,0.0001014063);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(87,0.000123327);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(89,0.0001568296);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(91,0.0001934737);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(93,0.000228949);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(95,0.0002614444);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(97,0.0003026);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(99,0.0003384667);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(101,0.0005540613);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(103,0.0004389666);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(105,0.0004792636);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(107,0.0005251722);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(109,0.0005693923);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(111,0.0006045241);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(113,0.0006392538);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(115,0.0006770606);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(117,0.000699365);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(119,0.0007223381);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(141,2.574231e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(143,4.885998e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(145,7.271365e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(147,9.238881e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(149,0.0001255656);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(151,0.0001546646);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(153,0.0001858042);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(155,0.0002240056);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(156,0.0002380293);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(158,0.0002821371);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(160,0.0003231893);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(162,0.0003675183);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(164,0.0004102562);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(166,0.0004551095);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(168,0.0004938106);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(169,0.0005217367);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(171,0.0005591301);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(173,0.0006020111);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(175,0.0006314903);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(177,0.0006762726);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(179,0.0007020115);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(181,0.0007199366);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(265,2.939159e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(267,4.110999e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(269,6.832673e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(271,8.8584e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(273,0.0001114938);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(275,0.0001395649);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(277,0.0001684488);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(279,0.0002068035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(280,0.0002266917);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(282,0.0002627638);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(284,0.0003096599);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(286,0.0003514937);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(288,0.000387561);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(290,0.0004310305);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(292,0.0004812715);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(293,0.0005024713);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(295,0.0005405288);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(297,0.0005915766);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(299,0.0006210297);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(301,0.0006583275);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(303,0.0006857396);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(305,0.0007229838);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(389,2.452023e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(391,3.902615e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(393,5.30747e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(395,7.590894e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(397,9.766484e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(399,0.0001246738);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(401,0.000162494);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(403,0.0001835663);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(404,0.0002053709);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(406,0.0002631617);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(408,0.0002788984);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(410,0.0003244255);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(412,0.0003661161);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(414,0.0004074459);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(416,0.0004521118);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(417,0.0004806413);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(419,0.0005137139);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(421,0.0005636552);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(423,0.0006078504);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(425,0.0006439691);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(427,0.0006751113);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(429,0.0007075826);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(513,1.630487e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(515,2.820624e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(517,4.718101e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(519,5.400517e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(521,8.14224e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(523,0.0001079304);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(525,0.0001333234);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(527,0.0001624562);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(528,0.0001824993);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(530,0.0002145275);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(532,0.0002540342);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(534,0.0002876924);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(536,0.0003348144);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(538,0.0003696986);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(540,0.0004197201);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(541,0.0004409177);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(543,0.0004909091);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(545,0.000537643);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(547,0.0005781264);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(549,0.0006145989);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(551,0.0006530801);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(553,0.0006835894);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(639,2.038921e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(641,2.949393e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(643,4.633565e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(645,6.497856e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(647,8.588436e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(649,0.0001155454);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(651,0.0001408121);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(652,0.000149096);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(654,0.0001877511);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(656,0.0002228786);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(658,0.000257588);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(660,0.0002996691);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(662,0.0003394648);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(664,0.0003814336);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(665,0.0004110529);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(667,0.0004529908);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(669,0.0004962495);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(671,0.0005372424);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(673,0.0005906253);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(675,0.0006322507);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(677,0.0006575736);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(765,2.36426e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(767,3.775055e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(769,4.959139e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(771,6.990716e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(773,9.648714e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(775,0.0001137502);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(776,0.0001303026);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(778,0.0001597787);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(780,0.0001855948);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(782,0.0002315102);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(784,0.000250032);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(786,0.0002941622);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(788,0.0003410183);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(789,0.0003585664);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(791,0.0004109998);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(793,0.0004543668);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(795,0.0005026186);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(797,0.0005477783);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(799,0.0005904031);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(801,0.0006306081);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(891,3.1345e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(893,3.595616e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(895,5.756784e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(897,7.366768e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(899,9.787483e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(900,0.0001035596);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(902,0.0001336579);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(904,0.000162193);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(906,0.0001885345);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(908,0.0002284687);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(910,0.0002590142);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(912,0.0003027654);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(913,0.0003215993);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(915,0.000360097);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(917,0.0004009334);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(919,0.0004536516);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(921,0.0005042231);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(923,0.0005534141);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(925,0.0005961104);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1017,1.800252e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1019,4.069641e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1021,5.798358e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1023,7.27098e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1024,8.498444e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1026,0.0001071658);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1028,0.0001382831);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1030,0.0001670109);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1032,0.0001923564);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1034,0.0002227027);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1036,0.0002594411);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1037,0.0002765507);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1039,0.0003175282);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1041,0.0003658146);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1043,0.0004098813);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1045,0.0004640694);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1047,0.0005056508);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1049,0.0005436555);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1143,3.133349e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1145,3.635715e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1147,5.54666e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1148,7.10147e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1150,8.541336e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1152,0.0001002121);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1154,0.0001219353);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1156,0.0001574356);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1158,0.0001913796);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1160,0.0002275999);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1161,0.0002366439);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1163,0.0002722445);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1165,0.0003191884);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1167,0.0003656385);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1169,0.0004062706);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1171,0.0004536149);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1173,0.0005130952);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1269,2.505756e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1271,4.031317e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1272,4.310834e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1274,6.411205e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1276,8.826949e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1278,0.0001054094);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1280,0.0001292396);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1282,0.0001617461);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1284,0.000183854);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1285,0.0002005247);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1287,0.0002344409);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1289,0.0002733641);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1291,0.0003208813);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1293,0.000367763);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1295,0.0004097973);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1297,0.0004546681);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1395,1.848783e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1396,3.031585e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1398,4.684898e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1400,6.561477e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1402,8.095511e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1404,0.0001057569);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1406,0.0001257374);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1408,0.0001563811);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1409,0.0001625344);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1410,0.0001782093);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1411,0.000247502);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1412,0.0002172562);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1413,0.0002426);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1414,0.0002658891);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1415,0.0002722011);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1416,0.0003029959);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1417,0.0003140697);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1418,0.0003395869);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1419,0.0003631348);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1420,0.000403276);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1421,0.0004169218);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1471,0.0001540606);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1472,0.0001730904);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1473,0.0001990095);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1474,0.0002045624);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1475,0.0002194131);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1476,0.0002675794);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1477,0.0002498486);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1478,0.0003269836);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1479,0.0002986835);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1480,0.0003100491);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1481,0.0004097372);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1482,0.0003550889);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1483,0.000376401);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1520,1.895584e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1522,2.460473e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1524,4.257748e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1526,6.772723e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1528,8.073206e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1530,0.0001051821);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1532,0.0001240859);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1533,0.0001358565);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1534,0.0001570112);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1535,0.0001667549);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1536,0.0001981104);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1537,0.0002617253);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1538,0.0002313006);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1539,0.0002297616);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1540,0.0003140095);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1541,0.0002777311);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1542,0.0002911687);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1543,0.0003644517);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1544,0.0003336213);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1545,0.0003561998);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1595,0.0001129622);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1596,0.0001387435);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1597,0.0001855649);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1598,0.0001651709);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1599,0.0001841312);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1600,0.0001971876);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1601,0.0002225147);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1602,0.0002293012);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1603,0.0002507291);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1604,0.0002675787);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1605,0.0004232992);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1606,0.0003027447);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1607,0.0003300026);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1646,1.876018e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1648,2.534462e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1650,4.062961e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1652,6.070313e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1654,8.658629e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1656,0.0001023495);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1657,0.0001056057);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1658,0.000126369);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1659,0.0001791829);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1660,0.0001613485);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1661,0.000171058);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1662,0.0003098739);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1663,0.0001949185);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1664,0.0002126341);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1665,0.0002534762);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1666,0.0002445892);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1667,0.0003680234);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1668,0.0002822061);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1669,0.0003014858);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1719,0.0001051235);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1720,0.0001269697);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1721,0.0001176631);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1722,0.0001376699);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1723,0.0001471365);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1724,0.0001639757);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1725,0.0001784172);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1726,0.000190264);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1727,0.0002058752);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1728,0.0002250414);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1729,0.0002454649);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1730,0.0002616211);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1731,0.000323956);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1772,1.715696e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1774,3.039593e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1776,3.632969e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1778,6.928718e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1780,7.102506e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1781,8.687003e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1782,0.0001014838);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1783,0.0001148516);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1784,0.0001265289);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1785,0.0001316946);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1786,0.0001618959);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1787,0.0001558513);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1788,0.0001730236);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1789,0.0002018069);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1790,0.000206577);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1791,0.0002245401);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1792,0.0002442463);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1793,0.000266372);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1843,7.432766e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1844,0.0001057721);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1845,9.753148e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1846,0.0001037673);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1847,0.0001235101);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1848,0.0001295167);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1849,0.000144451);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1850,0.0002327806);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1851,0.0001993557);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1852,0.0001866214);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1853,0.0002020226);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1854,0.0002255944);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1855,0.0002879072);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1898,2.501187e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1900,2.726877e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1902,4.455736e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1904,6.107819e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1905,6.934857e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1906,7.725746e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1907,8.949645e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1908,0.0001013524);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1909,0.0001078986);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1910,0.0001153851);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1911,0.0001266245);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1912,0.0001654954);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1913,0.0001659515);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1914,0.0001740498);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1915,0.0001856532);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1916,0.0001981987);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1917,0.0002237995);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1967,5.997842e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1968,6.751122e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1969,7.465393e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1970,7.901859e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1971,0.0001002716);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1972,0.0001035661);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1973,0.0001325767);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1974,0.0001408117);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1975,0.0001347427);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1976,0.000167356);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1977,0.0001732128);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1978,0.0001823813);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1979,0.0002064111);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2024,9.691125e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2026,2.334104e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2028,3.614046e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2029,4.839188e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2030,5.947792e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2031,6.808157e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2032,7.311309e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2033,0.0001039027);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2034,9.839385e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2035,0.0001034553);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2036,0.0001119871);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2037,0.0001312177);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2038,0.0001436719);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2039,0.0001669115);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2040,0.0001877276);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2041,0.0001794948);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2091,3.855517e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2092,4.786611e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2093,5.557076e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2094,6.550845e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2095,7.695431e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2096,8.772448e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2097,9.071142e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2098,0.0001006305);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2099,0.0001096351);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2100,0.0001237516);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2101,0.0001480787);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2102,0.0001489782);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2103,0.0001679304);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2150,1.681677e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2152,2.86198e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2153,3.039203e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2154,5.9948e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2155,5.422988e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2156,5.422726e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2157,7.697415e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2158,0.0001032335);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2159,7.380877e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2160,8.944615e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2161,9.842751e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2162,0.0001075072);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2163,0.0001176283);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2164,0.0001774897);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2165,0.0001534902);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2215,1.580242e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2216,3.60832e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2217,3.699933e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2218,4.606968e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2219,5.429861e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2220,6.208844e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2221,7.283997e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2222,8.764336e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2223,8.491591e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2224,0.000104879);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2225,0.0001031009);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2226,0.0001296944);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2227,0.0001345162);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2276,1.150145e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2277,1.86354e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2278,2.365052e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2279,3.335708e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2280,4.228181e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2281,4.101432e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2282,5.187417e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2283,5.995882e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2284,6.920494e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2285,7.533786e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2286,8.629151e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2287,0.0001050624);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2288,0.0001024103);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2289,0.0001178969);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2339,1.769483e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2340,2.595369e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2341,2.514275e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2342,3.309477e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2343,3.964728e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2344,4.255128e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2345,5.134775e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2346,5.829682e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2347,7.101079e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2348,7.93817e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2349,0.0001020178);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2350,0.0001563189);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2351,9.642484e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2402,2.242006e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2403,1.901362e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2404,1.37346e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2405,3.945e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2406,3.536227e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2407,3.745562e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2408,5.236009e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2409,6.094363e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2410,6.725972e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2411,9.133488e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2412,8.62391e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2413,9.842754e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2465,2.095113e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2466,1.648368e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2467,2.361447e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2468,2.502726e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2469,3.27971e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2470,4.424018e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2471,7.319713e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2472,5.64415e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2473,6.629805e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2474,7.372534e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2475,8.532854e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2528,1.52546e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2529,1.65391e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2530,2.308499e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2531,3.207384e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2532,3.649655e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2533,3.716149e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2534,4.470078e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2535,5.193782e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2536,5.925254e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2537,7.914826e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2591,1.719984e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2592,1.423506e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2593,2.2285e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2594,2.865748e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2595,3.430641e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2596,3.788615e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2597,5.474128e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2598,6.918174e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2599,5.961595e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2655,2.033291e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2657,1.862535e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2659,3.932177e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2661,5.70197e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2781,8.762255e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2783,2.237796e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2785,3.205688e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2907,1.367932e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2909,2.018815e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3033,1.477547e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetEntries(627767.7);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->Draw("colz");
   c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf->Modified();
   c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf->cd();
   c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf->SetSelected(c_AccEffMap_T1tttt_8NJetinf_1500HTinf_200MHTinf);
}
/*
   400     0   0.000113302
   400    25   9.27596e-05
   400    75   0.000121124
   400   125   8.49362e-05
   400   175   3.64147e-05
   450     0   0.000243529
   450    25   0.000319543
   450    75   0.000232416
   450   125   0.000210136
   450   175   0.000109183
   450   225   5.76674e-05
   500     0   0.000564033
   500    25   0.000703326
   500    75   0.000624984
   500   125   0.000382366
   500   175   0.000305711
   500   225   0.000117914
   500   275   7.46724e-05
   550     0    0.00134857
   550    25    0.00112062
   550    75    0.00103436
   550   125   0.000769223
   550   175    0.00039259
   550   225   0.000292945
   550   275   0.000192251
   550   325   0.000132921
   600     0    0.00197348
   600    25    0.00206238
   600    75    0.00163836
   600   125    0.00126682
   600   175   0.000887156
   600   225   0.000565853
   600   275   0.000332494
   600   325    0.00017613
   600   375   4.40958e-05
   650     0    0.00316771
   650    25    0.00313307
   650    75    0.00255166
   650   125    0.00204162
   650   175    0.00154058
   650   225    0.00100429
   650   275   0.000666547
   650   325   0.000453166
   650   375   0.000226557
   650   425   0.000132872
   700     0    0.00482247
   700    25    0.00445108
   700    75    0.00368999
   700   125    0.00346824
   700   175    0.00234184
   700   225    0.00177735
   700   275    0.00125568
   700   325   0.000735714
   700   375   0.000459782
   700   425   0.000181766
   700   475   8.67974e-05
   750     0    0.00677018
   750    25    0.00643685
   750    75    0.00553108
   750   125     0.0043996
   750   175    0.00348266
   750   225    0.00263844
   750   275     0.0017467
   750   325    0.00130727
   750   375   0.000726498
   750   425   0.000422155
   750   475   0.000224424
   750   525   4.51045e-05
   775    25    0.00732885
   775    75    0.00662448
   775   125    0.00552767
   775   175    0.00440468
   775   225    0.00296526
   775   275    0.00229017
   775   325    0.00146507
   775   375    0.00099715
   775   425   0.000702657
   775   475   0.000254688
   775   525   0.000128609
   775   575   5.01509e-05
   800     0    0.00885796
   825    25      0.010268
   825    75    0.00899938
   825   125    0.00782734
   825   175    0.00608291
   825   225    0.00469634
   825   275    0.00344834
   825   325    0.00243825
   825   375    0.00158967
   825   425    0.00101659
   825   475   0.000580356
   825   525   0.000307048
   825   575   8.52289e-05
   825   625   4.96333e-05
   850     0     0.0117946
   875    25     0.0134331
   875    75     0.0123699
   875   125     0.0101968
   875   175    0.00848883
   875   225    0.00657702
   875   275    0.00464241
   875   325    0.00360339
   875   375    0.00265111
   875   425    0.00139938
   875   475    0.00108992
   875   525   0.000611734
   875   575   0.000255323
   875   625   9.13763e-05
   875   675   4.20247e-05
   900     0     0.0148437
   925    25     0.0173856
   925    75     0.0160526
   925   125     0.0137975
   925   175     0.0109528
   925   225    0.00884715
   925   275    0.00723653
   925   325    0.00485469
   925   375    0.00382883
   925   425    0.00210661
   925   475    0.00157024
   925   525   0.000939361
   925   575   0.000659756
   925   625   0.000236823
   925   675   0.000132431
   925   725   9.01767e-05
   950     0     0.0197844
   975    25     0.0217471
   975    75     0.0195157
   975   125     0.0176023
   975   175     0.0147609
   975   225     0.0119659
   975   275    0.00850498
   975   325     0.0071584
   975   375    0.00513826
   975   425    0.00348721
   975   475    0.00237942
   975   525    0.00160748
   975   575   0.000947533
   975   625   0.000535742
   975   675   0.000192165
   975   725   0.000109068
   975   775   1.37052e-05
  1000     0     0.0247682
  1025    25     0.0268339
  1025    75     0.0241089
  1025   125     0.0215858
  1025   175     0.0181386
  1025   225     0.0153798
  1025   275     0.0117942
  1025   325    0.00925308
  1025   375    0.00690054
  1025   425    0.00514808
  1025   475     0.0037025
  1025   525    0.00229111
  1025   575    0.00162357
  1025   625    0.00110077
  1025   675   0.000709576
  1025   725   0.000295507
  1025   775   8.08518e-05
  1025   825   4.11487e-05
  1050     0     0.0295687
  1075    25     0.0317008
  1075    75     0.0300014
  1075   125     0.0268276
  1075   175     0.0232243
  1075   225     0.0195524
  1075   275     0.0157641
  1075   325     0.0125968
  1075   375    0.00935515
  1075   425    0.00729936
  1075   475    0.00485537
  1075   525    0.00353621
  1075   575     0.0022471
  1075   625    0.00155981
  1075   675   0.000754296
  1075   725   0.000559551
  1075   775   0.000194401
  1075   825   0.000121222
  1075   875   1.99209e-05
  1100     0     0.0355643
  1100    25     0.0351867
  1100    75      0.032688
  1100   125     0.0300189
  1100   175     0.0257726
  1100   225     0.0226511
  1100   275     0.0174782
  1100   325     0.0141709
  1100   375     0.0106358
  1100   425    0.00791654
  1100   475    0.00577478
  1100   525    0.00382219
  1100   550     0.0034303
  1100   575    0.00272507
  1100   600    0.00188862
  1100   625    0.00165935
  1100   650    0.00162569
  1100   675    0.00112751
  1100   700   0.000826916
  1100   725   0.000616094
  1100   750   0.000487067
  1100   775   0.000352063
  1100   800   0.000224783
  1100   825   0.000135856
  1100   850   2.23477e-05
  1100   875   5.27072e-05
  1100   900   4.68148e-05
  1125   525    0.00446669
  1125   550    0.00423424
  1125   575    0.00353537
  1125   600    0.00282709
  1125   625    0.00208214
  1125   650    0.00192913
  1125   675    0.00135936
  1125   700     0.0011813
  1125   725   0.000879639
  1125   750   0.000677947
  1125   775   0.000538321
  1125   800   0.000274924
  1125   825   0.000247135
  1125   850      0.000135
  1125   875   8.17368e-05
  1125   900   8.20687e-05
  1125   925   5.93158e-05
  1150     0     0.0419584
  1150    25     0.0403766
  1150    75      0.038204
  1150   125     0.0347623
  1150   175     0.0318061
  1150   225       0.02752
  1150   275     0.0230001
  1150   325     0.0179058
  1150   375     0.0141485
  1150   425     0.0104899
  1150   475    0.00791997
  1150   525    0.00574576
  1150   550    0.00499165
  1150   575    0.00410194
  1150   600    0.00312621
  1150   625    0.00285163
  1150   650    0.00191705
  1150   675    0.00192796
  1150   700    0.00143375
  1150   725   0.000982968
  1150   750   0.000760793
  1150   775   0.000500074
  1150   800   0.000474611
  1150   825   0.000383316
  1150   850   0.000195759
  1150   875   0.000156391
  1150   900   7.54248e-05
  1150   925   5.03038e-05
  1150   950   6.62053e-05
  1175   525    0.00654074
  1175   550    0.00594388
  1175   575    0.00517675
  1175   600    0.00404378
  1175   625    0.00340128
  1175   650    0.00251138
  1175   675    0.00198339
  1175   700    0.00163019
  1175   725    0.00134984
  1175   750   0.000953801
  1175   775   0.000823239
  1175   800   0.000664521
  1175   825   0.000450179
  1175   850   0.000268527
  1175   875   0.000206969
  1175   900   0.000128166
  1175   925   1.37345e-05
  1175   950   4.03756e-05
  1175   975   3.03515e-05
  1200     0     0.0473492
  1200    25       0.04688
  1200    75     0.0456297
  1200   125     0.0416845
  1200   175     0.0383295
  1200   225     0.0330862
  1200   275     0.0280292
  1200   325     0.0221782
  1200   375     0.0186011
  1200   425     0.0143853
  1200   475     0.0106858
  1200   525    0.00820617
  1200   550    0.00678927
  1200   575    0.00558933
  1200   600    0.00496653
  1200   625    0.00373895
  1200   650    0.00324466
  1200   675    0.00247295
  1200   700      0.002254
  1200   725    0.00172608
  1200   750    0.00153061
  1200   775    0.00101176
  1200   800   0.000886502
  1200   825   0.000692412
  1200   850   0.000457305
  1200   875   0.000259357
  1200   900   0.000217129
  1200   925   0.000212363
  1200   950   7.08404e-05
  1200   975   4.05114e-05
  1200  1000    3.4399e-05
  1225   525     0.0092384
  1225   550    0.00797282
  1225   575      0.006723
  1225   600    0.00539823
  1225   625    0.00497682
  1225   650     0.0038157
  1225   675    0.00328959
  1225   700    0.00252535
  1225   725    0.00205892
  1225   750     0.0016533
  1225   775    0.00139943
  1225   800    0.00110086
  1225   825   0.000910893
  1225   850   0.000476252
  1225   875   0.000417921
  1225   900   0.000278785
  1225   925   0.000193572
  1225   950   9.69245e-05
  1225   975   8.32299e-05
  1225  1000   3.18299e-05
  1250     0     0.0532767
  1250    25     0.0520207
  1250    75     0.0505188
  1250   125     0.0486631
  1250   175     0.0442269
  1250   225     0.0385829
  1250   275     0.0341395
  1250   325     0.0282196
  1250   375     0.0233112
  1250   425     0.0188689
  1250   475     0.0147425
  1250   525     0.0107364
  1250   550    0.00916925
  1250   575    0.00771736
  1250   600    0.00671375
  1250   625    0.00571033
  1250   650    0.00479653
  1250   675    0.00365732
  1250   700    0.00317747
  1250   725    0.00246674
  1250   750     0.0019381
  1250   775     0.0014606
  1250   800    0.00127767
  1250   825   0.000830329
  1250   850   0.000836026
  1250   875   0.000501292
  1250   900   0.000387576
  1250   925   0.000221561
  1250   950   0.000167216
  1250   975   0.000132177
  1250  1000   7.39077e-05
  1250  1025   6.42518e-05
  1275   525     0.0128709
  1275   550      0.010775
  1275   575    0.00939054
  1275   600    0.00766744
  1275   625    0.00639805
  1275   650    0.00550783
  1275   675    0.00429973
  1275   700    0.00380678
  1275   725    0.00262272
  1275   750    0.00242265
  1275   775    0.00195605
  1275   800      0.001543
  1275   825      0.001253
  1275   850     0.0012128
  1275   875   0.000711791
  1275   900     0.0005372
  1275   925   0.000391681
  1275   950   0.000153238
  1275   975   0.000178721
  1275  1000   0.000127965
  1300     0     0.0596353
  1300    25     0.0597711
  1300    75     0.0569121
  1300   125     0.0546256
  1300   175      0.050259
  1300   225     0.0466543
  1300   275     0.0407326
  1300   325     0.0347915
  1300   375      0.030001
  1300   425     0.0233074
  1300   475     0.0193665
  1300   525      0.014249
  1300   550      0.012819
  1300   575     0.0106697
  1300   600    0.00896716
  1300   625    0.00776774
  1300   650    0.00631537
  1300   675    0.00567633
  1300   700    0.00423529
  1300   725    0.00392024
  1300   750    0.00281637
  1300   775    0.00223966
  1300   800    0.00178412
  1300   825    0.00149626
  1300   850    0.00108923
  1300   875   0.000753035
  1300   900   0.000783405
  1300   925   0.000544551
  1300   950   0.000420283
  1300   975   0.000219774
  1300  1000   0.000157142
  1300  1025   5.58742e-05
  1300  1075   1.23916e-05
  1325   525     0.0168163
  1325   550     0.0141172
  1325   575     0.0121844
  1325   600     0.0106605
  1325   625    0.00899934
  1325   650    0.00760139
  1325   675    0.00647066
  1325   700    0.00530443
  1325   725    0.00435264
  1325   750    0.00356157
  1325   775    0.00307357
  1325   800    0.00240107
  1325   825    0.00182657
  1325   850    0.00139713
  1325   875    0.00101243
  1325   900   0.000961412
  1325   925   0.000634229
  1325   950    0.00050151
  1325   975   0.000289591
  1325  1000   0.000185583
  1350     0     0.0643739
  1350    25     0.0648938
  1350    75      0.062135
  1350   125     0.0603923
  1350   175     0.0568701
  1350   225     0.0536334
  1350   275     0.0473885
  1350   325     0.0419359
  1350   375     0.0354795
  1350   425     0.0291701
  1350   475     0.0240511
  1350   525     0.0191278
  1350   550      0.016308
  1350   575     0.0145332
  1350   600     0.0122356
  1350   625     0.0106439
  1350   650    0.00902111
  1350   675     0.0077236
  1350   700    0.00598565
  1350   725      0.005333
  1350   750    0.00466282
  1350   775    0.00365235
  1350   800    0.00281574
  1350   825    0.00222929
  1350   850    0.00171496
  1350   875    0.00151966
  1350   900    0.00121853
  1350   925   0.000921451
  1350   950   0.000710287
  1350   975   0.000421653
  1350  1000   0.000457821
  1350  1025   0.000251697
  1350  1075   8.05833e-05
  1350  1125   3.05873e-05
  1375   525     0.0211156
  1375   550     0.0183886
  1375   575     0.0164212
  1375   600     0.0135505
  1375   625      0.011903
  1375   650     0.0103439
  1375   675    0.00890866
  1375   700    0.00753562
  1375   725    0.00601055
  1375   750    0.00521072
  1375   775    0.00407683
  1375   800     0.0033833
  1375   825    0.00283608
  1375   850     0.0022551
  1375   875    0.00150912
  1375   900    0.00130624
  1375   925    0.00112278
  1375   950    0.00085582
  1375   975   0.000574138
  1375  1000   0.000420402
  1400     0      0.069228
  1400    25     0.0689142
  1400    75     0.0691878
  1400   125      0.066624
  1400   175     0.0625522
  1400   225     0.0583796
  1400   275      0.054179
  1400   325     0.0489129
  1400   375     0.0411572
  1400   425     0.0370356
  1400   475     0.0295597
  1400   525     0.0226449
  1400   550     0.0207021
  1400   575     0.0187044
  1400   600     0.0160264
  1400   625      0.013673
  1400   650      0.011753
  1400   675     0.0103511
  1400   700    0.00867996
  1400   725    0.00719301
  1400   750    0.00581844
  1400   775    0.00484471
  1400   800    0.00420641
  1400   825    0.00355804
  1400   850    0.00281471
  1400   875    0.00225213
  1400   900    0.00151535
  1400   925    0.00132596
  1400   950    0.00109065
  1400   975   0.000829582
  1400  1000    0.00054285
  1400  1025   0.000537612
  1400  1075   0.000169567
  1400  1125   6.69116e-05
  1400  1175   3.61916e-05
*/
