{
//=========Macro generated from canvas: c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf/c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf
//=========  (Sat Feb 22 16:28:31 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf = new TCanvas("c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf", "c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf",90,432,500,500);
   c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf->Range(0,0,1,1);
   c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf->SetFillColor(0);
   c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf->SetBorderMode(0);
   c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf->SetBorderSize(2);
   c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf->SetLogz();
   c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_3NJet6_1500HTinf_300MHTinf = new TH2D("h_EffAcc_3NJet6_1500HTinf_300MHTinf","h_EffAcc_3NJet6_1500HTinf_300MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(75,0.0001437492);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(77,0.0003814431);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(79,0.0007670431);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(81,0.001445516);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(83,0.00234161);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(85,0.003440249);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(87,0.005168258);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(89,0.007850165);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(91,0.0117561);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(93,0.01591306);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(95,0.020736);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(97,0.02665649);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(99,0.034925);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(101,0.04478829);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(103,0.05460864);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(199,9.835186e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(201,0.0005160047);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(203,0.0007354192);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(205,0.001434511);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(207,0.001855206);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(209,0.003594171);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(211,0.004648377);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(213,0.007718128);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(215,0.0104618);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(217,0.01612237);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(219,0.02049986);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(221,0.0250423);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(223,0.03563747);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(225,0.04075744);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(227,0.05096722);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(323,0.0001920875);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(325,0.0003246976);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(327,0.000496072);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(329,0.001066643);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(331,0.001495697);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(333,0.003150357);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(335,0.004163395);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(337,0.006461165);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(339,0.009691001);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(341,0.01510132);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(343,0.01921276);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(345,0.02479653);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(347,0.03368177);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(349,0.04126866);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(351,0.05089655);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(447,9.59178e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(449,0.0002559013);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(451,0.0006501372);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(453,0.0005924435);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(455,0.001294976);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(457,0.00292359);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(459,0.003528008);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(461,0.005793399);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(463,0.009000617);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(465,0.01230289);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(467,0.01725549);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(469,0.02149406);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(471,0.02988782);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(473,0.03651138);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(475,0.04985384);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(571,7.149091e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(573,0.000174457);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(575,0.0002078101);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(577,0.0009262103);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(579,0.0008813679);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(581,0.001920217);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(583,0.002997571);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(585,0.004046871);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(587,0.007146327);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(589,0.01016562);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(591,0.01472104);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(593,0.02001032);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(595,0.02895377);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(597,0.03531475);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(599,0.04329929);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(695,2.386973e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(697,2.490144e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(699,0.0002347043);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(701,0.0003699856);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(703,0.0006824525);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(705,0.001025601);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(707,0.002017594);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(709,0.003620446);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(711,0.005178275);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(713,0.007783153);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(715,0.01223782);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(717,0.01594037);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(719,0.02277078);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(721,0.03042389);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(723,0.03807057);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(821,2.502424e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(823,0.0001295322);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(825,0.0002372514);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(827,0.0004606859);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(829,0.0006312896);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(831,0.001249254);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(833,0.002249967);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(835,0.003608908);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(837,0.006154216);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(839,0.009321913);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(841,0.01302494);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(843,0.01983946);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(845,0.02663298);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(847,0.03264817);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(947,7.746934e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(949,7.935708e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(951,0.0002978921);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(953,0.0003070495);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(955,0.0007291862);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(957,0.001372423);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(959,0.002240928);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(961,0.004461199);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(963,0.006660068);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(965,0.009094579);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(967,0.01552104);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(969,0.02026219);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(971,0.02802848);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1073,0.0001599565);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1075,0.0001621526);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1077,0.0001402348);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1079,0.0005957298);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1081,0.001233296);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1083,0.001805329);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1085,0.003038169);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1087,0.004982114);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1089,0.00760122);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1091,0.01203909);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1093,0.01671708);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1095,0.02335355);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1199,2.706268e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1201,0.0001922041);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1203,0.0003581976);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1205,0.0007528139);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1207,0.0008082208);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1209,0.00192648);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1211,0.003117075);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1213,0.004516675);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1215,0.008129119);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1217,0.01243636);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1219,0.01639064);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1325,2.751992e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1327,0.000110532);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1329,0.0002887555);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1331,0.0006942285);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1333,0.001071354);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1335,0.001713921);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1337,0.00306239);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1339,0.005716525);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1341,0.008169565);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1343,0.01189565);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1451,0.0001389946);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1453,0.0001936962);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1455,0.0005608781);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1457,0.0007289958);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1459,0.001176343);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1461,0.00176152);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1463,0.004161433);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1465,0.005260331);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1467,0.008037512);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1577,0.0001122498);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1579,0.0001437313);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1581,0.0005924808);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1583,0.0008205744);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1585,0.001077971);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1587,0.003284311);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1589,0.003139552);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1591,0.005512952);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1703,2.798979e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1705,0.0001128523);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1707,0.0005802882);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1709,0.0007203516);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1711,0.001805768);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1713,0.002006906);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1715,0.004179316);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1829,0.0002014657);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1831,0.0003644819);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1833,0.0002246288);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1835,0.0010975);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1837,0.001439392);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1839,0.002599427);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1955,0.0001679232);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1957,0.0002819095);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1959,0.001012835);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1961,0.0008698855);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1963,0.001297332);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2081,0.0001404921);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2083,0.0004540609);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2085,0.0004780568);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2087,0.0009548181);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2207,0.0001703762);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2209,0.0001681285);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2211,0.0004466412);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2333,0.0001995304);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2335,0.0003352968);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2459,0.0001404181);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(75,5.86905e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(77,9.859665e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(79,0.0001427034);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(81,0.0002012757);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(83,0.0002612809);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(85,0.0003172628);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(87,0.0003922997);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(89,0.0004902886);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(91,0.0006203653);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(93,0.0007051524);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(95,0.0008019824);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(97,0.0009223395);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(99,0.001064913);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(101,0.001226593);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(103,0.001347478);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(199,4.924648e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(201,0.0001156607);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(203,0.0001391435);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(205,0.000199656);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(207,0.0002292224);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(209,0.0003275411);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(211,0.0003709944);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(213,0.0004808557);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(215,0.0005816859);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(217,0.0007206547);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(219,0.0008161251);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(221,0.0009062519);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(223,0.001073364);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(225,0.001171945);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(227,0.001290625);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(323,6.792116e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(325,9.007272e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(327,0.0001138845);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(329,0.0001736987);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(331,0.0002062694);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(333,0.0003033792);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(335,0.0003565499);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(337,0.0004400157);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(339,0.0005409452);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(341,0.0006861639);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(343,0.0007771176);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(345,0.0008843841);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(347,0.001045115);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(349,0.001154759);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(351,0.001301048);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(447,4.796171e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(449,8.103162e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(451,0.0001301172);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(453,0.0001265528);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(455,0.0001894631);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(457,0.0002925367);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(459,0.000327993);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(461,0.0004189576);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(463,0.0005286603);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(465,0.0006190287);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(467,0.0007341093);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(469,0.0008187425);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(471,0.0009783459);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(473,0.001086661);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(475,0.001277288);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(571,4.12771e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(573,6.594555e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(575,7.348124e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(577,0.0001592444);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(579,0.000156016);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(581,0.0002375529);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(583,0.0002996623);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(585,0.0003465324);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(587,0.0004629715);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(589,0.0005575322);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(591,0.0006854021);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(593,0.0007867947);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(595,0.0009638453);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(597,0.001067483);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(599,0.00118522);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(695,2.387008e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(697,2.490182e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(699,7.824592e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(701,9.890498e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(703,0.0001365871);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(705,0.000168986);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(707,0.0002422718);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(709,0.0003255032);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(711,0.0003928404);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(713,0.0004850017);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(715,0.0006110706);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(717,0.0007036139);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(719,0.000845726);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(721,0.0009869853);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(723,0.001111326);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(821,2.502462e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(823,5.793313e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(825,7.909519e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(827,0.0001117639);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(829,0.0001318499);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(831,0.0001889515);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(833,0.0002557692);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(835,0.000327102);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(837,0.0004306485);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(839,0.0005414603);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(841,0.0006406747);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(843,0.000789009);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(845,0.0009208259);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(847,0.001021422);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(947,4.472905e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(949,4.581903e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(951,8.983404e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(953,9.265432e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(955,0.0001431935);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(957,0.000198563);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(959,0.000254482);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(961,0.00037225);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(963,0.0004482397);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(965,0.0005263045);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(967,0.0006934601);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(969,0.0007968175);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(971,0.0009429451);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1073,6.530832e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1075,6.620501e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1077,6.27202e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1079,0.0001302859);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1081,0.0001862189);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1083,0.0002260517);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1085,0.0003021327);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1087,0.0003867564);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1089,0.0004767924);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1091,0.0006169057);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1093,0.0007325489);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1095,0.0008556238);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1199,2.706313e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1201,7.265475e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1203,9.936762e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1205,0.0001449449);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1207,0.0001528137);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1209,0.0002412867);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1211,0.0003070261);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1213,0.0003646979);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1215,0.0004951554);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1217,0.0006179162);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1219,0.0007074193);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1325,2.752038e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1327,5.526967e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1329,9.132841e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1331,0.0001417681);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1333,0.0001739428);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1335,0.0002218838);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1337,0.0002970799);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1339,0.000416022);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1341,0.0005011251);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1343,0.0006010639);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1451,6.216548e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1453,7.321884e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1455,0.0001254585);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1457,0.0001430306);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1459,0.0001839496);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1461,0.0002240283);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1463,0.0003481366);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1465,0.0003998994);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1467,0.000495804);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1577,5.612869e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1579,6.428417e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1581,0.000129336);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1583,0.0001551505);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1585,0.0001773322);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1587,0.0003070624);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1589,0.0003133407);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1591,0.0004000068);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1703,2.799026e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1705,5.642998e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1707,0.0001299075);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1709,0.0001471049);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1711,0.0002260259);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1713,0.0002404251);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1715,0.0003460225);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1829,7.61561e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1831,0.0001011113);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1833,7.942901e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1835,0.0001758566);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1837,0.0002017295);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1839,0.0002718131);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1955,6.856128e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1957,8.916274e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1959,0.0001689085);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1961,0.0001563177);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1963,0.0001914302);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2081,6.283529e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2083,0.0001135462);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2085,0.0001159791);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2087,0.0001638439);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2207,6.956291e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2209,6.864509e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2211,0.0001116903);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2333,7.542445e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2335,9.681137e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2459,6.28022e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetEntries(50008.49);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetLineColor(ci);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->Draw("colz");
   c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf->Modified();
   c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf->cd();
   c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf->SetSelected(c_AccEffMap_T2qq_3NJet6_1500HTinf_300MHTinf);
}
/*
Topology ~q ~q ; ~q ->q+LSP

mSquark(GeV) mLSP(GeV) AccXEff
   300     0   0.000143749
   300    50   9.83519e-05
   300   100   0.000192087
   300   150   9.59178e-05
   300   200   7.14909e-05
   300   250   2.38697e-05
   350     0   0.000381443
   350    50   0.000516005
   350   100   0.000324698
   350   150   0.000255901
   350   200   0.000174457
   350   250   2.49014e-05
   350   300   2.50242e-05
   400     0   0.000767043
   400    50   0.000735419
   400   100   0.000496072
   400   150   0.000650137
   400   200    0.00020781
   400   250   0.000234704
   400   300   0.000129532
   400   350   7.74693e-05
   450     0    0.00144552
   450    50    0.00143451
   450   100    0.00106664
   450   150   0.000592444
   450   200    0.00092621
   450   250   0.000369986
   450   300   0.000237251
   450   350   7.93571e-05
   450   400   0.000159957
   500     0    0.00234161
   500    50    0.00185521
   500   100     0.0014957
   500   150    0.00129498
   500   200   0.000881368
   500   250   0.000682452
   500   300   0.000460686
   500   350   0.000297892
   500   400   0.000162153
   500   450   2.70627e-05
   550     0    0.00344025
   550    50    0.00359417
   550   100    0.00315036
   550   150    0.00292359
   550   200    0.00192022
   550   250     0.0010256
   550   300    0.00063129
   550   350    0.00030705
   550   400   0.000140235
   550   450   0.000192204
   550   500   2.75199e-05
   600     0    0.00516826
   600    50    0.00464838
   600   100    0.00416339
   600   150    0.00352801
   600   200    0.00299757
   600   250    0.00201759
   600   300    0.00124925
   600   350   0.000729186
   600   400    0.00059573
   600   450   0.000358198
   600   500   0.000110532
   600   550   0.000138995
   650     0    0.00785016
   650    50    0.00771813
   650   100    0.00646117
   650   150     0.0057934
   650   200    0.00404687
   650   250    0.00362045
   650   300    0.00224997
   650   350    0.00137242
   650   400     0.0012333
   650   450   0.000752814
   650   500   0.000288755
   650   550   0.000193696
   650   600    0.00011225
   700     0     0.0117561
   700    50     0.0104618
   700   100      0.009691
   700   150    0.00900062
   700   200    0.00714633
   700   250    0.00517828
   700   300    0.00360891
   700   350    0.00224093
   700   400    0.00180533
   700   450   0.000808221
   700   500   0.000694229
   700   550   0.000560878
   700   600   0.000143731
   700   650   2.79898e-05
   750     0     0.0159131
   750    50     0.0161224
   750   100     0.0151013
   750   150     0.0123029
   750   200     0.0101656
   750   250    0.00778315
   750   300    0.00615422
   750   350     0.0044612
   750   400    0.00303817
   750   450    0.00192648
   750   500    0.00107135
   750   550   0.000728996
   750   600   0.000592481
   750   650   0.000112852
   750   700   0.000201466
   800     0      0.020736
   800    50     0.0204999
   800   100     0.0192128
   800   150     0.0172555
   800   200      0.014721
   800   250     0.0122378
   800   300    0.00932191
   800   350    0.00666007
   800   400    0.00498211
   800   450    0.00311707
   800   500    0.00171392
   800   550    0.00117634
   800   600   0.000820574
   800   650   0.000580288
   800   700   0.000364482
   800   750   0.000167923
   850     0     0.0266565
   850    50     0.0250423
   850   100     0.0247965
   850   150     0.0214941
   850   200     0.0200103
   850   250     0.0159404
   850   300     0.0130249
   850   350    0.00909458
   850   400    0.00760122
   850   450    0.00451668
   850   500    0.00306239
   850   550    0.00176152
   850   600    0.00107797
   850   650   0.000720352
   850   700   0.000224629
   850   750    0.00028191
   850   800   0.000140492
   900     0      0.034925
   900    50     0.0356375
   900   100     0.0336818
   900   150     0.0298878
   900   200     0.0289538
   900   250     0.0227708
   900   300     0.0198395
   900   350      0.015521
   900   400     0.0120391
   900   450    0.00812912
   900   500    0.00571652
   900   550    0.00416143
   900   600    0.00328431
   900   650    0.00180577
   900   700     0.0010975
   900   750    0.00101283
   900   800   0.000454061
   900   850   0.000170376
   950     0     0.0447883
   950    50     0.0407574
   950   100     0.0412687
   950   150     0.0365114
   950   200     0.0353147
   950   250     0.0304239
   950   300      0.026633
   950   350     0.0202622
   950   400     0.0167171
   950   450     0.0124364
   950   500    0.00816957
   950   550    0.00526033
   950   600    0.00313955
   950   650    0.00200691
   950   700    0.00143939
   950   750   0.000869885
   950   800   0.000478057
   950   850   0.000168128
   950   900    0.00019953
  1000     0     0.0546086
  1000    50     0.0509672
  1000   100     0.0508966
  1000   150     0.0498538
  1000   200     0.0432993
  1000   250     0.0380706
  1000   300     0.0326482
  1000   350     0.0280285
  1000   400     0.0233536
  1000   450     0.0163906
  1000   500     0.0118957
  1000   550    0.00803751
  1000   600    0.00551295
  1000   650    0.00417932
  1000   700    0.00259943
  1000   750    0.00129733
  1000   800   0.000954818
  1000   850   0.000446641
  1000   900   0.000335297
  1000   950   0.000140418
*/
