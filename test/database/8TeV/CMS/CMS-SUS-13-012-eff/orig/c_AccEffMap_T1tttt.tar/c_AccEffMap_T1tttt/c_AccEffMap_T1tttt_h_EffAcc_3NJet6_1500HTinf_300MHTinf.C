{
//=========Macro generated from canvas: c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf/c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf
//=========  (Sat Feb 22 16:31:34 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf = new TCanvas("c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf", "c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf",90,432,500,500);
   c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf->SetFillColor(0);
   c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf->SetBorderMode(0);
   c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf->SetBorderSize(2);
   c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf->SetLogz();
   c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_3NJet6_1500HTinf_300MHTinf = new TH2D("h_EffAcc_3NJet6_1500HTinf_300MHTinf","h_EffAcc_3NJet6_1500HTinf_300MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(79,1.637563e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(81,1.440466e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(83,3.398894e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(85,7.787274e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(87,0.000166637);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(89,0.0002649688);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(91,0.0003786877);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(93,0.0005857039);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(95,0.0007917332);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(97,0.00109598);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(99,0.00199771);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(101,0.002107776);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(103,0.003562465);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(105,0.005115608);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(107,0.006539062);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(109,0.008528178);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(111,0.01157482);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(113,0.01419721);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(115,0.01806643);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(117,0.02221755);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(119,0.02612365);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(141,2.120219e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(143,7.180752e-06);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(145,1.644138e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(147,0.0001074695);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(149,0.0001845001);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(151,0.0002704616);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(153,0.0003378779);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(155,0.0006353971);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(156,0.0006528483);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(158,0.001036049);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(160,0.001672984);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(162,0.002102583);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(164,0.002897227);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(166,0.00422228);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(168,0.005948994);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(169,0.006481137);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(171,0.008806562);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(173,0.01143844);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(175,0.0147513);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(177,0.01790629);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(179,0.0218935);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(181,0.02709417);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(267,3.062846e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(269,1.641097e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(271,5.626037e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(273,0.0001252837);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(275,0.0001845121);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(277,0.0003363612);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(279,0.0004365101);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(280,0.0006319268);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(282,0.0008117681);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(284,0.001395671);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(286,0.002227935);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(288,0.002757817);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(290,0.004045556);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(292,0.004875708);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(293,0.006513807);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(295,0.008062173);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(297,0.01063491);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(299,0.01370455);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(301,0.01724434);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(303,0.02144671);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(305,0.02387918);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(389,2.831206e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(391,4.347631e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(393,4.380327e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(395,3.765747e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(397,7.162906e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(399,0.0001303745);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(401,0.0001672479);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(403,0.0003580177);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(404,0.0005223309);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(406,0.0006861132);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(408,0.001134682);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(410,0.001527674);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(412,0.002320103);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(414,0.003302468);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(416,0.004427515);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(417,0.005334041);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(419,0.00711071);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(421,0.009662688);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(423,0.0117268);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(425,0.01529162);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(427,0.01906582);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(429,0.0234607);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(513,4.263186e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(515,3.609354e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(517,4.367305e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(519,2.196307e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(521,4.608601e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(523,0.0001085429);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(525,0.000183995);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(527,0.000334906);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(528,0.0004431567);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(530,0.0004143103);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(532,0.0006988883);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(534,0.001211736);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(536,0.001889529);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(538,0.002584987);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(540,0.004012444);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(541,0.004464856);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(543,0.005711004);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(545,0.007884452);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(547,0.01066445);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(549,0.0139318);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(551,0.01702811);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(553,0.02141183);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(639,6.487579e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(641,3.656255e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(643,3.650408e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(645,2.206413e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(647,8.026996e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(649,0.0001125077);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(651,0.000186497);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(652,0.0002468067);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(654,0.0004573815);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(656,0.000553244);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(658,0.0009361768);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(660,0.001463359);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(662,0.002155801);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(664,0.003012544);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(665,0.003725339);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(667,0.004722372);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(669,0.00625959);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(671,0.008631953);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(673,0.01194718);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(675,0.01515302);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(677,0.01918202);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(765,4.371067e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(767,4.577401e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(769,4.408756e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(771,3.657325e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(773,8.198155e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(775,0.0001622837);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(776,0.0001462194);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(778,0.0002350938);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(780,0.0004103469);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(782,0.0006979656);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(784,0.001020172);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(786,0.001524151);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(788,0.002359348);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(789,0.002780215);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(791,0.003630895);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(793,0.005256922);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(795,0.006914553);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(797,0.009378647);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(799,0.0128878);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(801,0.01688605);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(891,6.691897e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(893,0.0001109984);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(895,3.654562e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(897,5.099007e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(899,0.0001163819);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(900,9.153897e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(902,0.0001713075);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(904,0.0002907585);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(906,0.0004635044);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(908,0.0007175541);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(910,0.001203031);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(912,0.001637487);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(913,0.001799729);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(915,0.002930966);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(917,0.004227704);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(919,0.005665797);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(921,0.007590692);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(923,0.01041126);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(925,0.01375688);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1017,8.81916e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1019,8.76995e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1021,6.516589e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1023,7.946778e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1024,2.868206e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1026,6.555332e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1028,0.0001517929);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1030,0.0002627712);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1032,0.0005045135);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1034,0.0006822804);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1036,0.0009693231);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1037,0.001400197);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1039,0.002018905);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1041,0.003185003);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1043,0.003913664);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1045,0.005783045);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1047,0.0085691);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1049,0.01091127);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1143,8.063984e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1145,9.451822e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1147,5.785415e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1148,0.0001020419);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1150,5.857253e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1152,0.0001083165);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1154,0.0002325313);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1156,0.0002587698);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1158,0.0004940396);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1160,0.0007507129);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1161,0.0008275824);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1163,0.001375849);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1165,0.001979448);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1167,0.003119407);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1169,0.004258524);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1171,0.005940913);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1173,0.008493416);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1269,0.0001084967);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1271,9.411322e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1272,0.0001076145);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1274,7.785265e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1276,9.32084e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1278,6.911668e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1280,0.0001239948);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1282,0.0003573953);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1284,0.0005224129);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1285,0.0006156048);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1287,0.0009727273);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1289,0.001467499);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1291,0.002161052);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1293,0.00333236);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1295,0.004637096);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1297,0.006678813);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1395,6.49505e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1396,0.0001214643);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1398,7.099367e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1400,7.723472e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1402,8.288477e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1404,9.744872e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1406,0.0001167603);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1408,0.0002183412);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1409,0.0003564997);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1410,0.0005155344);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1411,0.0005383903);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1412,0.0006094889);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1413,0.000842443);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1414,0.001152083);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1415,0.00150341);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1416,0.00168969);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1417,0.002186194);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1418,0.002843242);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1419,0.003190013);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1420,0.003938369);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1421,0.004916093);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1471,0.0002714926);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1472,0.0004652261);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1473,0.0003989343);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1474,0.0005218834);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1475,0.0005653892);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1476,0.0008461919);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1477,0.00134116);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1478,0.001497127);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1479,0.001780327);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1480,0.001865523);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1481,0.002677809);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1482,0.003155964);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1483,0.003893497);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1520,0.0001146307);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1522,4.971686e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1524,8.452058e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1526,9.697196e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1528,7.69657e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1530,0.0001362438);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1532,0.0001674959);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1533,0.0002251343);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1534,0.0002971466);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1535,0.0003073713);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1536,0.0003149698);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1537,0.0006473906);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1538,0.0008331208);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1539,0.0009538801);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1540,0.001168062);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1541,0.001467238);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1542,0.001781643);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1543,0.002283536);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1544,0.002696424);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1545,0.003261141);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1595,0.0001462611);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1596,0.000211402);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1597,0.0002442664);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1598,0.0002795094);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1599,0.0004473252);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1600,0.0005571189);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1601,0.0007003084);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1602,0.0008724345);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1603,0.001190811);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1604,0.001444447);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1605,0.00157467);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1606,0.002424867);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1607,0.002610583);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1646,5.672376e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1648,6.32605e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1650,9.715821e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1652,4.094845e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1654,5.406718e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1656,8.709382e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1657,0.0001004171);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1658,0.0001458529);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1659,0.0002490986);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1660,0.0002644821);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1661,0.0002987011);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1662,0.0004419262);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1663,0.0004659886);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1664,0.0006105059);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1665,0.0009519001);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1666,0.001201894);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1667,0.001389002);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1668,0.001850175);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1669,0.002280397);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1719,0.0001071239);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1720,0.0001510246);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1721,0.0001247859);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1722,0.0001227074);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1723,0.0002520436);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1724,0.0003770591);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1725,0.0003712372);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1726,0.0005210211);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1727,0.0007017522);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1728,0.0008523362);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1729,0.0009946507);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1730,0.001443357);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1731,0.001725864);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1772,0.0001050618);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1774,9.00187e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1776,7.601202e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1778,8.764356e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1780,6.631171e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1781,9.904937e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1782,7.481841e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1783,0.0001060104);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1784,0.0001727695);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1785,0.0001732637);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1786,0.0002086103);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1787,0.0002610103);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1788,0.0003367862);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1789,0.0005305656);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1790,0.0006209313);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1791,0.000922414);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1792,0.0009382431);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1793,0.001304548);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1843,5.474067e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1844,6.58891e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1845,8.608179e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1846,9.038662e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1847,9.69065e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1848,0.0001979331);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1849,0.000220103);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1850,0.0003317644);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1851,0.0003519155);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1852,0.0005312575);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1853,0.0005959619);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1854,0.0008347456);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1855,0.001046344);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1898,6.243001e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1900,6.816743e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1902,0.0001074572);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1904,3.990851e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1905,7.007708e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1906,8.027125e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1907,5.737757e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1908,8.436517e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1909,9.421768e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1910,0.0001014596);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1911,0.0001451489);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1912,0.0002629654);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1913,0.0003199074);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1914,0.0004103916);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1915,0.0005240539);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1916,0.0006278812);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1917,0.0008434159);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1967,8.102441e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1968,9.362521e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1969,5.105383e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1970,7.792758e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1971,5.158451e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1972,0.0001015705);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1973,0.0001277023);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1974,0.000101109);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1975,0.0002638878);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1976,0.0003243372);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1977,0.0003625396);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1978,0.0005095183);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1979,0.0005417928);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2024,0.0001233469);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2026,0.0001010647);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2028,8.640045e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2029,7.264139e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2030,7.199433e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2031,5.543541e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2032,7.102456e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2033,9.541175e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2034,5.4512e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2035,8.049141e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2036,0.0001199888);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2037,0.0001453104);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2038,0.0001839825);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2039,0.0003135296);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2040,0.0003848813);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2041,0.0004471005);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2091,9.916888e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2092,5.831724e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2093,6.571534e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2094,4.510691e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2095,7.931429e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2096,6.875011e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2097,5.089995e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2098,0.0001252503);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2099,0.0001635069);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2100,0.0001710076);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2101,0.000196799);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2102,0.0002005736);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2103,0.0003063713);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2150,9.40541e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2152,0.0001203913);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2153,8.100757e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2154,0.0001017615);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2155,5.353043e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2156,2.595625e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2157,1.707024e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2158,5.801865e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2159,4.503478e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2160,0.0001395707);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2161,3.81923e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2162,0.0001363057);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2163,0.0002175659);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2164,0.0002108812);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2165,0.0002145994);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2215,8.939078e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2216,2.892856e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2217,0.000125845);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2218,3.934464e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2219,5.134652e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2220,6.369928e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2221,6.291821e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2222,8.766266e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2223,7.856183e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2224,0.0001089306);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2225,0.0001262736);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2226,0.000113802);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2227,0.0001887369);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2276,8.632371e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2277,8.564919e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2278,8.674112e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2279,9.189102e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2280,0.0001112392);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2281,7.780698e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2282,6.404924e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2283,7.821583e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2284,6.67174e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2285,7.530347e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2286,8.001218e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2287,5.003002e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2288,7.693034e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2289,0.0001305744);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2339,8.025394e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2340,6.565496e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2341,0.0001005664);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2342,4.272185e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2343,7.237618e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2344,5.801308e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2345,5.439663e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2346,0.0001071249);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2347,0.0001081107);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2348,4.541464e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2349,9.328457e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2350,0.0001112682);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2351,0.0001203552);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2402,9.321051e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2403,0.0001221663);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2404,6.867242e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2405,8.749712e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2406,0.0001151834);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2407,9.495459e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2408,7.676595e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2409,7.435299e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2410,8.539402e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2411,0.0001165118);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2412,6.549185e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2413,0.0001049192);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2465,0.0001111595);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2466,7.402195e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2467,8.658268e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2468,8.40012e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2469,8.360804e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2470,8.938897e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2471,3.806337e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2472,5.078587e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2473,6.764636e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2474,6.470929e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2475,9.283001e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2528,8.569849e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2529,0.0001147822);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2530,0.0001088391);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2531,8.490201e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2532,2.222442e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2533,9.385361e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2534,9.624395e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2535,7.608779e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2536,5.475223e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2537,8.371066e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2591,7.739768e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2592,0.0001082218);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2593,6.718881e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2594,8.215051e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2595,6.787784e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2596,7.732606e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2597,5.875781e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2598,5.605362e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2599,6.520717e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2655,6.345855e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2657,8.691536e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2659,9.18045e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2661,5.413719e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2781,9.293705e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2783,8.554817e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2785,4.220322e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2907,7.952706e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2909,7.818885e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3033,6.63512e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(79,1.158365e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(81,1.018572e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(83,1.706291e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(85,2.473713e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(87,3.745779e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(89,4.708382e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(91,5.672777e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(93,6.985368e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(95,8.081719e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(97,9.585701e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(99,0.0001285099);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(101,0.0001869805);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(103,0.0001710196);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(105,0.0002037898);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(107,0.0002294062);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(109,0.0002604721);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(111,0.0003024817);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(113,0.0003328117);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(115,0.0003751147);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(117,0.0004131058);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(119,0.0004452155);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(141,1.224125e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(143,7.180783e-06);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(145,1.169746e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(147,2.994959e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(149,3.953792e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(151,4.732969e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(153,5.30554e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(155,7.325011e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(156,7.379217e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(158,9.274692e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(160,0.0001179911);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(162,0.0001317874);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(164,0.0001540695);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(166,0.000185537);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(168,0.0002187342);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(169,0.0002283274);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(171,0.0002654862);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(173,0.0003010235);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(175,0.0003394953);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(177,0.0003717592);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(179,0.0004102496);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(181,0.0004539153);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(267,1.539378e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(269,1.167582e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(271,2.137339e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(273,3.254554e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(275,3.87142e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(277,5.283117e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(279,6.026092e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(280,7.237605e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(282,8.235707e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(284,0.0001075786);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(286,0.0001366245);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(288,0.0001507016);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(290,0.0001816313);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(292,0.0001984234);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(293,0.0002293076);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(295,0.000253017);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(297,0.0002896174);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(299,0.0003270238);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(301,0.0003653728);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(303,0.0004053759);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(305,0.0004252884);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(389,1.415627e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(391,1.77496e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(393,1.788309e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(395,1.686133e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(397,2.401817e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(399,3.27766e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(401,3.758992e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(403,5.366352e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(404,6.614075e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(406,8.074082e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(408,9.63609e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(410,0.0001124742);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(412,0.0001377753);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(414,0.0001637346);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(416,0.0001885795);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(417,0.0002072217);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(419,0.0002373082);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(421,0.0002758476);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(423,0.0003017273);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(425,0.0003435445);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(427,0.0003816803);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(429,0.0004220439);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(513,1.740483e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(515,1.614188e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(517,1.782992e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(519,1.268055e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(521,1.889014e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(523,2.914699e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(525,3.858418e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(527,5.258789e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(528,6.064483e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(530,5.886431e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(532,7.616013e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(534,9.879472e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(536,0.0001243599);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(538,0.0001444917);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(540,0.0001796277);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(541,0.0001887751);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(543,0.000212404);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(545,0.0002477715);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(547,0.0002877482);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(549,0.0003272982);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(551,0.0003602678);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(553,0.0004023218);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(639,2.162612e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(641,1.635163e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(643,1.632548e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(645,1.27389e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(647,2.420348e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(649,2.912877e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(651,3.828115e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(652,4.456715e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(654,6.143798e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(656,6.696472e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(658,8.735785e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(660,0.000108704);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(662,0.0001318327);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(664,0.0001545069);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(665,0.0001713124);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(667,0.0001925395);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(669,0.0002206298);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(671,0.0002587678);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(673,0.0003024797);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(675,0.0003389823);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(677,0.000379924);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(765,1.784528e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(767,1.876225e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(769,1.799915e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(771,1.635642e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(773,2.478052e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(775,3.560005e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(776,3.372281e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(778,4.314855e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(780,5.721946e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(782,7.480638e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(784,8.963004e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(786,0.0001099713);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(788,0.0001366666);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(789,0.0001488486);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(791,0.000167709);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(793,0.0002020899);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(795,0.0002308381);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(797,0.0002673002);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(799,0.0003117455);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(801,0.0003553384);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(891,2.232395e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(893,2.867528e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(895,1.634406e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(897,1.927303e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(899,2.911062e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(900,2.656319e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(902,3.587192e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(904,4.679423e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(906,6.018479e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(908,7.561841e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(910,9.803586e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(912,0.0001130921);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(913,0.0001189781);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(915,0.000151057);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(917,0.000180404);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(919,0.000208544);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(921,0.0002403137);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(923,0.000280595);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(925,0.0003197694);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1017,2.546008e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1019,2.531801e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1021,2.172282e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1023,2.396159e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1024,1.434128e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1026,2.19157e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1028,3.412631e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1030,4.532286e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1032,6.34096e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1034,7.313193e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1036,8.714077e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1037,0.000104045);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1039,0.0001239833);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1041,0.0001569397);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1043,0.0001726628);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1045,0.0002090135);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1047,0.000253574);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1049,0.0002846226);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1143,2.431501e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1145,2.621613e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1147,2.045525e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1148,2.732799e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1150,2.077568e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1152,2.806338e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1154,4.200807e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1156,4.396579e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1158,6.164644e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1160,7.58765e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1161,7.970991e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1163,0.0001030631);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1165,0.0001235112);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1167,0.0001535485);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1169,0.0001792251);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1171,0.0002099001);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1173,0.0002502564);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1269,2.801557e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1271,2.610379e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1272,2.778776e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1274,2.347456e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1276,2.590794e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1278,2.185753e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1280,3.022366e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1282,5.2447e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1284,6.280195e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1285,6.756573e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1287,8.545506e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1289,0.000105348);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1291,0.0001277179);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1293,0.0001576989);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1295,0.0001850244);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1297,0.0002212536);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1395,2.165102e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1396,2.946158e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1398,2.245113e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1400,2.328823e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1402,2.392797e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1404,2.609782e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1406,2.837612e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1408,4.076887e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1409,5.174932e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1410,6.335692e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1411,7.896172e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1412,6.936272e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1413,8.147254e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1414,9.789711e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1415,0.0001065407);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1416,0.0001146451);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1417,0.0001284834);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1418,0.0001447426);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1419,0.0001534838);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1420,0.0001800822);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1421,0.0002002571);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1471,4.551427e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1472,5.944391e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1473,5.792695e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1474,6.274211e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1475,6.564983e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1476,9.164362e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1477,9.963551e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1478,0.0001271475);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1479,0.0001155234);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1480,0.000116118);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1481,0.00017225);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1482,0.0001523825);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1483,0.0001688583);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1520,2.865965e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1522,1.879177e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1524,2.440024e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1526,2.591837e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1528,2.323286e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1530,3.04884e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1532,3.435206e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1533,3.931265e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1534,4.664364e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1535,4.715315e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1536,5.072009e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1537,9.209591e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1538,8.423614e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1539,8.381164e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1540,0.000115666);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1541,0.0001077687);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1542,0.0001160316);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1543,0.0001506309);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1544,0.0001403036);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1545,0.0001539479);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1595,3.204634e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1596,3.808064e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1597,5.358915e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1598,4.56005e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1599,5.71317e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1600,6.601647e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1601,7.543652e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1602,8.074613e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1603,9.520805e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1604,0.0001028966);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1605,0.0001589668);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1606,0.0001333309);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1607,0.0001382129);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1646,2.005556e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1648,2.108764e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1650,2.596815e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1652,1.671755e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1654,1.911626e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1656,2.416988e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1657,2.597785e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1658,3.355718e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1659,5.468598e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1660,4.701518e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1661,5.075983e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1662,9.473759e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1663,5.810169e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1664,6.862746e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1665,9.252698e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1666,9.271729e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1667,0.0001389201);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1668,0.0001155229);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1669,0.0001282871);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1719,2.678271e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1720,3.570384e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1721,3.036761e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1722,3.078475e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1723,4.224168e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1724,5.308688e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1725,5.128804e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1726,6.011169e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1727,7.129767e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1728,7.85653e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1729,8.454806e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1730,0.0001015904);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1731,0.0001286229);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1772,2.712857e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1774,2.496805e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1776,2.293399e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1778,2.430924e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1780,2.097044e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1781,2.557597e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1782,2.366073e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1783,2.749728e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1784,3.885938e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1785,3.632369e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1786,4.193068e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1787,4.316139e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1788,4.992659e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1789,6.377778e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1790,6.692073e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1791,8.102258e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1792,8.181937e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1793,9.903968e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1843,1.941647e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1844,2.490473e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1845,2.389937e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1846,2.415816e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1847,2.60068e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1848,3.693438e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1849,3.911741e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1850,6.950882e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1851,5.900182e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1852,6.129067e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1853,6.618905e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1854,7.82695e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1855,0.0001041339);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1898,2.081079e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1900,2.155732e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1902,2.686604e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1904,1.629297e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1905,2.336002e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1906,2.317344e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1907,2.170744e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1908,2.550105e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1909,2.523247e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1910,2.536646e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1911,3.107978e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1912,5.397957e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1913,4.84851e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1914,5.567139e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1915,6.085268e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1916,6.656049e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1917,7.976557e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1967,2.443098e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1968,2.502381e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1969,1.929713e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1970,2.249682e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1971,1.823845e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1972,2.636737e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1973,3.425394e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1974,2.929853e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1975,4.24899e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1976,5.224265e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1977,4.962377e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1978,5.957098e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1979,6.513414e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2024,2.90753e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2026,2.609639e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2028,2.396442e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2029,2.190317e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2030,2.170805e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2031,2.263217e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2032,2.141563e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2033,3.180576e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2034,1.927354e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2035,2.428556e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2036,2.757105e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2037,3.33924e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2038,3.556338e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2039,5.049672e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2040,5.975346e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2041,5.622813e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2091,2.560683e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2092,2.204262e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2093,2.079608e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2094,1.704927e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2095,2.289716e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2096,2.17416e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2097,1.799641e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2098,2.878791e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2099,3.3486e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2100,3.368758e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2101,3.949418e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2102,3.746098e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2103,4.642075e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2150,2.513845e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2152,2.839002e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2153,2.338602e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2154,3.846459e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2155,2.023326e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2156,1.297833e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2157,1.207061e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2158,2.594764e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2159,1.702201e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2160,2.977783e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2161,1.55923e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2162,2.985691e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2163,3.686632e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2164,4.996771e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2165,3.875179e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2215,3.160612e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2216,1.67022e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2217,2.96642e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2218,1.759588e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2219,1.81543e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2220,2.252196e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2221,1.989724e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2222,2.343008e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2223,2.267993e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2224,2.911484e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2225,2.834204e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2226,2.948875e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2227,3.518463e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2276,2.394314e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2277,2.375604e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2278,2.405892e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2279,2.54874e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2280,3.085427e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2281,2.2462e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2282,2.025493e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2283,2.358408e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2284,2.109875e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2285,2.381414e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2286,2.412575e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2287,1.891014e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2288,2.325363e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2289,2.858328e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2339,2.316844e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2340,2.321346e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2341,2.903279e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2342,1.910629e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2343,2.288836e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2344,1.933837e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2345,1.923275e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2346,2.598329e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2347,2.622242e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2348,1.716559e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2349,2.812795e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2350,4.542813e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2351,2.691421e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2402,2.810561e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2403,2.963187e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2404,3.071251e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2405,2.525958e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2406,2.715089e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2407,2.451858e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2408,2.314688e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2409,2.241928e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2410,2.465241e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2411,3.231684e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2412,2.071117e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2413,2.814241e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2465,2.696195e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2466,2.231946e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2467,2.610703e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2468,2.329893e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2469,2.318987e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2470,3.378769e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2471,2.19764e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2472,1.795607e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2473,2.039698e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2474,2.048799e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2475,2.483939e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2528,2.474031e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2529,2.784071e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2530,2.639911e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2531,2.560024e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2532,1.283145e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2533,2.423428e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2534,2.572378e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2535,2.196567e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2536,1.825135e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2537,2.525691e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2591,2.580043e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2592,2.624936e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2593,2.124783e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2594,2.278559e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2595,2.264384e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2596,2.44538e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2597,1.958664e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2598,2.506879e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2599,2.062113e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2655,2.006813e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2657,2.323033e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2659,2.370514e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2661,1.804632e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2781,2.39976e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2783,2.28649e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2785,1.595173e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2907,2.20579e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2909,2.168671e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3033,2.000644e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetEntries(125265.5);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetLineColor(ci);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->Draw("colz");
   c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf->Modified();
   c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf->cd();
   c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf->SetSelected(c_AccEffMap_T1tttt_3NJet6_1500HTinf_300MHTinf);
}
/*
   400     0   1.63756e-05
   400    25   2.12022e-05
   400   125   2.83121e-05
   400   175   4.26319e-05
   450     0   1.44047e-05
   450    25   7.18075e-06
   450    75   3.06285e-05
   450   125   4.34763e-05
   450   175   3.60935e-05
   450   225   6.48758e-05
   500     0   3.39889e-05
   500    25   1.64414e-05
   500    75    1.6411e-05
   500   125   4.38033e-05
   500   175    4.3673e-05
   500   225   3.65626e-05
   500   275   4.37107e-05
   550     0   7.78727e-05
   550    25   0.000107469
   550    75   5.62604e-05
   550   125   3.76575e-05
   550   175   2.19631e-05
   550   225   3.65041e-05
   550   275    4.5774e-05
   550   325    6.6919e-05
   600     0   0.000166637
   600    25     0.0001845
   600    75   0.000125284
   600   125   7.16291e-05
   600   175    4.6086e-05
   600   225   2.20641e-05
   600   275   4.40876e-05
   600   325   0.000110998
   600   375   8.81916e-05
   650     0   0.000264969
   650    25   0.000270462
   650    75   0.000184512
   650   125   0.000130375
   650   175   0.000108543
   650   225     8.027e-05
   650   275   3.65733e-05
   650   325   3.65456e-05
   650   375   8.76995e-05
   650   425   8.06398e-05
   700     0   0.000378688
   700    25   0.000337878
   700    75   0.000336361
   700   125   0.000167248
   700   175   0.000183995
   700   225   0.000112508
   700   275   8.19815e-05
   700   325   5.09901e-05
   700   375   6.51659e-05
   700   425   9.45182e-05
   700   475   0.000108497
   750     0   0.000585704
   750    25   0.000635397
   750    75    0.00043651
   750   125   0.000358018
   750   175   0.000334906
   750   225   0.000186497
   750   275   0.000162284
   750   325   0.000116382
   750   375   7.94678e-05
   750   425   5.78542e-05
   750   475   9.41132e-05
   750   525   6.49505e-05
   775    25   0.000652848
   775    75   0.000631927
   775   125   0.000522331
   775   175   0.000443157
   775   225   0.000246807
   775   275   0.000146219
   775   325    9.1539e-05
   775   375   2.86821e-05
   775   425   0.000102042
   775   475   0.000107615
   775   525   0.000121464
   775   575   0.000114631
   800     0   0.000791733
   825    25    0.00103605
   825    75   0.000811768
   825   125   0.000686113
   825   175    0.00041431
   825   225   0.000457381
   825   275   0.000235094
   825   325   0.000171308
   825   375   6.55533e-05
   825   425   5.85725e-05
   825   475   7.78526e-05
   825   525   7.09937e-05
   825   575   4.97169e-05
   825   625   5.67238e-05
   850     0    0.00109598
   875    25    0.00167298
   875    75    0.00139567
   875   125    0.00113468
   875   175   0.000698888
   875   225   0.000553244
   875   275   0.000410347
   875   325   0.000290759
   875   375   0.000151793
   875   425   0.000108316
   875   475   9.32084e-05
   875   525   7.72347e-05
   875   575   8.45206e-05
   875   625   6.32605e-05
   875   675   0.000105062
   900     0    0.00199771
   925    25    0.00210258
   925    75    0.00222793
   925   125    0.00152767
   925   175    0.00121174
   925   225   0.000936177
   925   275   0.000697966
   925   325   0.000463504
   925   375   0.000262771
   925   425   0.000232531
   925   475   6.91167e-05
   925   525   8.28848e-05
   925   575    9.6972e-05
   925   625   9.71582e-05
   925   675   9.00187e-05
   925   725     6.243e-05
   950     0    0.00210778
   975    25    0.00289723
   975    75    0.00275782
   975   125     0.0023201
   975   175    0.00188953
   975   225    0.00146336
   975   275    0.00102017
   975   325   0.000717554
   975   375   0.000504513
   975   425    0.00025877
   975   475   0.000123995
   975   525   9.74487e-05
   975   575   7.69657e-05
   975   625   4.09485e-05
   975   675    7.6012e-05
   975   725   6.81674e-05
   975   775   0.000123347
  1000     0    0.00356247
  1025    25    0.00422228
  1025    75    0.00404556
  1025   125    0.00330247
  1025   175    0.00258499
  1025   225     0.0021558
  1025   275    0.00152415
  1025   325    0.00120303
  1025   375    0.00068228
  1025   425    0.00049404
  1025   475   0.000357395
  1025   525    0.00011676
  1025   575   0.000136244
  1025   625   5.40672e-05
  1025   675   8.76436e-05
  1025   725   0.000107457
  1025   775   0.000101065
  1025   825   9.40541e-05
  1050     0    0.00511561
  1075    25    0.00594899
  1075    75    0.00487571
  1075   125    0.00442751
  1075   175    0.00401244
  1075   225    0.00301254
  1075   275    0.00235935
  1075   325    0.00163749
  1075   375   0.000969323
  1075   425   0.000750713
  1075   475   0.000522413
  1075   525   0.000218341
  1075   575   0.000167496
  1075   625   8.70938e-05
  1075   675   6.63117e-05
  1075   725   3.99085e-05
  1075   775   8.64004e-05
  1075   825   0.000120391
  1075   875   8.63237e-05
  1100     0    0.00653906
  1100    25    0.00648114
  1100    75    0.00651381
  1100   125    0.00533404
  1100   175    0.00446486
  1100   225    0.00372534
  1100   275    0.00278022
  1100   325    0.00179973
  1100   375     0.0014002
  1100   425   0.000827582
  1100   475   0.000615605
  1100   525     0.0003565
  1100   550   0.000271493
  1100   575   0.000225134
  1100   600   0.000146261
  1100   625   0.000100417
  1100   650   0.000107124
  1100   675   9.90494e-05
  1100   700   5.47407e-05
  1100   725   7.00771e-05
  1100   750   8.10244e-05
  1100   775   7.26414e-05
  1100   800   9.91689e-05
  1100   825   8.10076e-05
  1100   850   8.93908e-05
  1100   875   8.56492e-05
  1100   900   8.02539e-05
  1125   525   0.000515534
  1125   550   0.000465226
  1125   575   0.000297147
  1125   600   0.000211402
  1125   625   0.000145853
  1125   650   0.000151025
  1125   675   7.48184e-05
  1125   700   6.58891e-05
  1125   725   8.02712e-05
  1125   750   9.36252e-05
  1125   775   7.19943e-05
  1125   800   5.83172e-05
  1125   825   0.000101761
  1125   850   2.89286e-05
  1125   875   8.67411e-05
  1125   900    6.5655e-05
  1125   925   9.32105e-05
  1150     0    0.00852818
  1150    25    0.00880656
  1150    75    0.00806217
  1150   125    0.00711071
  1150   175      0.005711
  1150   225    0.00472237
  1150   275    0.00363089
  1150   325    0.00293097
  1150   375    0.00201891
  1150   425    0.00137585
  1150   475   0.000972727
  1150   525    0.00053839
  1150   550   0.000398934
  1150   575   0.000307371
  1150   600   0.000244266
  1150   625   0.000249099
  1150   650   0.000124786
  1150   675    0.00010601
  1150   700   8.60818e-05
  1150   725   5.73776e-05
  1150   750   5.10538e-05
  1150   775   5.54354e-05
  1150   800   6.57153e-05
  1150   825   5.35304e-05
  1150   850   0.000125845
  1150   875    9.1891e-05
  1150   900   0.000100566
  1150   925   0.000122166
  1150   950   0.000111159
  1175   525   0.000609489
  1175   550   0.000521883
  1175   575    0.00031497
  1175   600   0.000279509
  1175   625   0.000264482
  1175   650   0.000122707
  1175   675    0.00017277
  1175   700   9.03866e-05
  1175   725   8.43652e-05
  1175   750   7.79276e-05
  1175   775   7.10246e-05
  1175   800   4.51069e-05
  1175   825   2.59563e-05
  1175   850   3.93446e-05
  1175   875   0.000111239
  1175   900   4.27219e-05
  1175   925   6.86724e-05
  1175   950    7.4022e-05
  1175   975   8.56985e-05
  1200     0     0.0115748
  1200    25     0.0114384
  1200    75     0.0106349
  1200   125    0.00966269
  1200   175    0.00788445
  1200   225    0.00625959
  1200   275    0.00525692
  1200   325     0.0042277
  1200   375      0.003185
  1200   425    0.00197945
  1200   475     0.0014675
  1200   525   0.000842443
  1200   550   0.000565389
  1200   575   0.000647391
  1200   600   0.000447325
  1200   625   0.000298701
  1200   650   0.000252044
  1200   675   0.000173264
  1200   700   9.69065e-05
  1200   725   9.42177e-05
  1200   750   5.15845e-05
  1200   775   9.54118e-05
  1200   800   7.93143e-05
  1200   825   1.70702e-05
  1200   850   5.13465e-05
  1200   875    7.7807e-05
  1200   900   7.23762e-05
  1200   925   8.74971e-05
  1200   950   8.65827e-05
  1200   975   0.000114782
  1200  1000   7.73977e-05
  1225   525    0.00115208
  1225   550   0.000846192
  1225   575   0.000833121
  1225   600   0.000557119
  1225   625   0.000441926
  1225   650   0.000377059
  1225   675    0.00020861
  1225   700   0.000197933
  1225   725    0.00010146
  1225   750    0.00010157
  1225   775    5.4512e-05
  1225   800   6.87501e-05
  1225   825   5.80186e-05
  1225   850   6.36993e-05
  1225   875   6.40492e-05
  1225   900   5.80131e-05
  1225   925   0.000115183
  1225   950   8.40012e-05
  1225   975   0.000108839
  1225  1000   0.000108222
  1250     0     0.0141972
  1250    25     0.0147513
  1250    75     0.0137045
  1250   125     0.0117268
  1250   175     0.0106645
  1250   225    0.00863195
  1250   275    0.00691455
  1250   325     0.0056658
  1250   375    0.00391366
  1250   425    0.00311941
  1250   475    0.00216105
  1250   525    0.00150341
  1250   550    0.00134116
  1250   575    0.00095388
  1250   600   0.000700308
  1250   625   0.000465989
  1250   650   0.000371237
  1250   675    0.00026101
  1250   700   0.000220103
  1250   725   0.000145149
  1250   750   0.000127702
  1250   775   8.04914e-05
  1250   800      5.09e-05
  1250   825   4.50348e-05
  1250   850   6.29182e-05
  1250   875   7.82158e-05
  1250   900   5.43966e-05
  1250   925   9.49546e-05
  1250   950    8.3608e-05
  1250   975    8.4902e-05
  1250  1000   6.71888e-05
  1250  1025   6.34585e-05
  1275   525    0.00168969
  1275   550    0.00149713
  1275   575    0.00116806
  1275   600   0.000872435
  1275   625   0.000610506
  1275   650   0.000521021
  1275   675   0.000336786
  1275   700   0.000331764
  1275   725   0.000262965
  1275   750   0.000101109
  1275   775   0.000119989
  1275   800    0.00012525
  1275   825   0.000139571
  1275   850   8.76627e-05
  1275   875   6.67174e-05
  1275   900   0.000107125
  1275   925    7.6766e-05
  1275   950    8.9389e-05
  1275   975   2.22244e-05
  1275  1000   8.21505e-05
  1300     0     0.0180664
  1300    25     0.0179063
  1300    75     0.0172443
  1300   125     0.0152916
  1300   175     0.0139318
  1300   225     0.0119472
  1300   275    0.00937865
  1300   325    0.00759069
  1300   375    0.00578304
  1300   425    0.00425852
  1300   475    0.00333236
  1300   525    0.00218619
  1300   550    0.00178033
  1300   575    0.00146724
  1300   600    0.00119081
  1300   625     0.0009519
  1300   650   0.000701752
  1300   675   0.000530566
  1300   700   0.000351915
  1300   725   0.000319907
  1300   750   0.000263888
  1300   775    0.00014531
  1300   800   0.000163507
  1300   825   3.81923e-05
  1300   850   7.85618e-05
  1300   875   7.53035e-05
  1300   900   0.000108111
  1300   925    7.4353e-05
  1300   950   3.80634e-05
  1300   975   9.38536e-05
  1300  1000   6.78778e-05
  1300  1025   8.69154e-05
  1300  1075   9.29371e-05
  1325   525    0.00284324
  1325   550    0.00186552
  1325   575    0.00178164
  1325   600    0.00144445
  1325   625    0.00120189
  1325   650   0.000852336
  1325   675   0.000620931
  1325   700   0.000531257
  1325   725   0.000410392
  1325   750   0.000324337
  1325   775   0.000183982
  1325   800   0.000171008
  1325   825   0.000136306
  1325   850   0.000108931
  1325   875   8.00122e-05
  1325   900   4.54146e-05
  1325   925    8.5394e-05
  1325   950   5.07859e-05
  1325   975    9.6244e-05
  1325  1000   7.73261e-05
  1350     0     0.0222175
  1350    25     0.0218935
  1350    75     0.0214467
  1350   125     0.0190658
  1350   175     0.0170281
  1350   225      0.015153
  1350   275     0.0128878
  1350   325     0.0104113
  1350   375     0.0085691
  1350   425    0.00594091
  1350   475     0.0046371
  1350   525    0.00319001
  1350   550    0.00267781
  1350   575    0.00228354
  1350   600    0.00157467
  1350   625      0.001389
  1350   650   0.000994651
  1350   675   0.000922414
  1350   700   0.000595962
  1350   725   0.000524054
  1350   750    0.00036254
  1350   775    0.00031353
  1350   800   0.000196799
  1350   825   0.000217566
  1350   850   0.000126274
  1350   875     5.003e-05
  1350   900   9.32846e-05
  1350   925   0.000116512
  1350   950   6.76464e-05
  1350   975   7.60878e-05
  1350  1000   5.87578e-05
  1350  1025   9.18045e-05
  1350  1075   8.55482e-05
  1350  1125   7.95271e-05
  1375   525    0.00393837
  1375   550    0.00315596
  1375   575    0.00269642
  1375   600    0.00242487
  1375   625    0.00185018
  1375   650    0.00144336
  1375   675   0.000938243
  1375   700   0.000834746
  1375   725   0.000627881
  1375   750   0.000509518
  1375   775   0.000384881
  1375   800   0.000200574
  1375   825   0.000210881
  1375   850   0.000113802
  1375   875   7.69303e-05
  1375   900   0.000111268
  1375   925   6.54919e-05
  1375   950   6.47093e-05
  1375   975   5.47522e-05
  1375  1000   5.60536e-05
  1400     0     0.0261237
  1400    25     0.0270942
  1400    75     0.0238792
  1400   125     0.0234607
  1400   175     0.0214118
  1400   225      0.019182
  1400   275     0.0168861
  1400   325     0.0137569
  1400   375     0.0109113
  1400   425    0.00849342
  1400   475    0.00667881
  1400   525    0.00491609
  1400   550     0.0038935
  1400   575    0.00326114
  1400   600    0.00261058
  1400   625     0.0022804
  1400   650    0.00172586
  1400   675    0.00130455
  1400   700    0.00104634
  1400   725   0.000843416
  1400   750   0.000541793
  1400   775     0.0004471
  1400   800   0.000306371
  1400   825   0.000214599
  1400   850   0.000188737
  1400   875   0.000130574
  1400   900   0.000120355
  1400   925   0.000104919
  1400   950     9.283e-05
  1400   975   8.37107e-05
  1400  1000   6.52072e-05
  1400  1025   5.41372e-05
  1400  1075   4.22032e-05
  1400  1125   7.81888e-05
  1400  1175   6.63512e-05
*/
