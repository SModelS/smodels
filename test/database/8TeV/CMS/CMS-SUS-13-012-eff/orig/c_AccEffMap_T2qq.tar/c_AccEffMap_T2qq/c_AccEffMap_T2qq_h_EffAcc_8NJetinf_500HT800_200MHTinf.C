{
//=========Macro generated from canvas: c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf/c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf
//=========  (Sat Feb 22 16:28:33 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf = new TCanvas("c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf", "c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf",105,264,500,500);
   c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf->SetFillColor(0);
   c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf->SetLogz();
   c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_500HT800_200MHTinf = new TH2D("h_EffAcc_8NJetinf_500HT800_200MHTinf","h_EffAcc_8NJetinf_500HT800_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(83,3.140758e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(93,2.814602e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(331,3.038662e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(335,3.569134e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(339,2.783771e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(347,3.176194e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(461,3.514346e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(469,2.802583e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(575,2.597626e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(595,3.186986e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(599,3.504738e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(697,2.801413e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(717,2.816941e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(837,3.185046e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(949,2.645236e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(953,3.104995e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(957,3.159031e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(959,6.849231e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(963,3.181561e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1073,2.665942e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1083,6.297659e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1087,2.834773e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1207,3.427722e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1213,3.534175e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1325,2.751992e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1327,5.526598e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1331,2.892619e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1333,2.810109e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1337,3.157103e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1451,2.779892e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1455,2.80439e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1457,2.80383e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1461,2.824081e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1577,2.806245e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1581,6.348008e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1591,3.508083e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1705,3.173971e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1713,6.371129e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1833,2.80786e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1961,2.806082e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2081,2.809842e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2083,2.837881e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2459,2.808363e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(83,3.140811e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(93,2.81465e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(331,3.038712e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(335,3.569196e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(339,2.783817e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(347,3.176248e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(461,3.514405e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(469,2.80263e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(575,2.597667e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(595,3.18704e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(599,3.504797e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(697,2.801455e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(717,2.816989e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(837,3.1851e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(949,2.645278e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(953,3.105047e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(957,3.159084e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(959,4.844893e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(963,3.181615e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1073,2.665986e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1083,4.480671e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1087,2.834822e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1207,3.427782e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1213,3.534235e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1325,2.752038e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1327,3.908026e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1331,2.892669e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1333,2.810156e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1337,3.157156e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1451,2.779938e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1455,2.804438e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1457,2.803877e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1461,2.824129e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1577,2.806292e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1581,4.488872e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1591,3.508142e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1705,3.174025e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1713,4.505222e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1833,2.807907e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1961,2.80613e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2081,2.80989e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2083,2.837929e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2459,2.80841e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetEntries(47.58827);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->Draw("colz");
   c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf->Modified();
   c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf->cd();
   c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf->SetSelected(c_AccEffMap_T2qq_8NJetinf_500HT800_200MHTinf);
}
/*
Topology ~q ~q ; ~q ->q+LSP

mSquark(GeV) mLSP(GeV) AccXEff
   350   250   2.80141e-05
   400   200   2.59763e-05
   450   350   2.64524e-05
   450   400   2.66594e-05
   500     0   3.14076e-05
   500   100   3.03866e-05
   550   350     3.105e-05
   550   500   2.75199e-05
   600   100   3.56913e-05
   600   500    5.5266e-05
   600   550   2.77989e-05
   650   150   3.51435e-05
   650   350   3.15903e-05
   650   600   2.80624e-05
   700   100   2.78377e-05
   700   350   6.84923e-05
   700   400   6.29766e-05
   700   450   3.42772e-05
   700   500   2.89262e-05
   700   550   2.80439e-05
   750     0    2.8146e-05
   750   300   3.18505e-05
   750   500   2.81011e-05
   750   550   2.80383e-05
   750   600   6.34801e-05
   750   650   3.17397e-05
   800   350   3.18156e-05
   800   400   2.83477e-05
   850   150   2.80258e-05
   850   250   2.81694e-05
   850   450   3.53417e-05
   850   500    3.1571e-05
   850   550   2.82408e-05
   850   700   2.80786e-05
   850   800   2.80984e-05
   900   100   3.17619e-05
   900   200   3.18699e-05
   900   800   2.83788e-05
   950   650   6.37113e-05
   950   750   2.80608e-05
  1000   200   3.50474e-05
  1000   600   3.50808e-05
  1000   950   2.80836e-05
*/
