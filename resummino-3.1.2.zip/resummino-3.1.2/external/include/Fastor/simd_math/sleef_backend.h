#ifndef SLEEF_BACKEND_H
#define SLEEF_BACKEND_H

#include "Fastor/simd_math/sleef_backend_u10.h"
#include "Fastor/simd_math/sleef_backend_u35.h"

#endif // SLEEF_BACKEND_H
