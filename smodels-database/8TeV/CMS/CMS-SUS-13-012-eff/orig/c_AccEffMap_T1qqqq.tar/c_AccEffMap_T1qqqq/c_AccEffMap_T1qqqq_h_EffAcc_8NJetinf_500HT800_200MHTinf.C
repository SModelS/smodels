{
//=========Macro generated from canvas: c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf/c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf
//=========  (Sat Feb 22 16:30:38 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf = new TCanvas("c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf", "c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf",105,264,500,500);
   c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf->SetFillColor(0);
   c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf->SetLogz();
   c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_500HT800_200MHTinf = new TH2D("h_EffAcc_8NJetinf_500HT800_200MHTinf","h_EffAcc_8NJetinf_500HT800_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(141,6.350068e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(143,0.000133293);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(145,0.0001289576);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(147,0.0001554522);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(149,0.0001967722);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(151,8.913434e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(153,5.989953e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(155,5.316549e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(157,4.441888e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(159,2.424889e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(161,4.301458e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(163,2.437651e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(165,1.695146e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(169,8.255648e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(173,1.702422e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(175,2.556725e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(177,7.768671e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(265,0.0001197974);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(267,8.466802e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(269,5.774699e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(271,0.0001004559);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(273,0.0001048308);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(275,0.0001123379);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(277,0.000123228);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(279,6.340532e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(281,3.925041e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(283,4.280125e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(285,2.437595e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(287,2.606661e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(289,2.419551e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(291,8.346768e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(293,1.606178e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(295,2.42618e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(301,8.828046e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(389,8.955162e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(391,9.220549e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(393,0.0001508043);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(395,0.0001348887);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(397,0.0001271148);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(399,8.35468e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(401,8.541549e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(403,0.0001088846);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(405,6.972734e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(407,4.811345e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(409,6.732068e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(411,3.997383e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(413,2.341103e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(415,9.346078e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(419,6.492642e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(421,1.565815e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(423,1.557943e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(425,1.087565e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(427,8.85933e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(429,6.769875e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(513,0.0001198269);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(515,0.0001615455);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(517,0.0001398235);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(519,0.0002293787);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(521,0.0001305548);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(523,9.918916e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(525,6.12698e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(527,0.0001144964);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(529,5.082329e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(531,0.0001148521);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(533,6.445513e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(535,4.988005e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(537,1.552017e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(541,6.599195e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(543,8.121016e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(545,1.614719e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(549,9.826281e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(551,7.76365e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(637,6.996165e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(639,0.0001728573);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(641,9.769198e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(643,0.0001148722);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(645,0.0001321535);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(647,0.0001881631);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(649,0.0001488629);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(651,7.81146e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(653,6.949311e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(655,8.447462e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(657,5.420753e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(659,4.999438e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(661,3.265711e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(663,3.582438e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(665,6.633953e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(667,8.127699e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(669,7.59769e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(671,1.417988e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(675,8.544639e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(677,7.528281e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(761,2.437023e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(763,4.724571e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(765,0.0001549311);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(767,0.0002129225);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(769,0.0001181354);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(771,0.0001092296);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(773,0.0001306345);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(775,0.000133305);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(777,0.0001065233);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(779,6.683822e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(781,0.0001004554);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(783,2.484675e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(785,6.586067e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(789,8.232662e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(791,8.108893e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(793,1.816492e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(795,7.873827e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(799,9.664357e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(801,2.058521e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(887,2.322966e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(889,7.23697e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(891,0.00014753);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(893,0.0001958463);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(895,0.0001767513);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(897,0.0001388401);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(899,0.0001118151);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(901,0.0001828246);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(903,0.0001204897);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(905,4.182516e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(907,5.694223e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(909,4.211484e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(911,2.385364e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(913,2.388308e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(915,2.965008e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(917,8.015284e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(919,1.397029e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(921,7.022965e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(923,1.454411e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1011,1.528182e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1013,2.181395e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1015,9.136713e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1017,0.0001248659);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1019,0.000209632);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1021,0.000227133);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1023,0.0001466967);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1025,0.0001791576);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1027,0.0001072369);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1029,7.329609e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1031,4.789462e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1033,7.782569e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1035,4.716406e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1037,8.256193e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1039,1.549597e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1041,1.51209e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1043,1.512009e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1045,7.791584e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1137,1.548353e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1139,5.441858e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1141,0.0001020968);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1143,0.0001451545);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1145,0.0002017864);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1147,0.0001789668);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1149,0.0001349103);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1151,7.376931e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1153,0.0001224439);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1155,4.122785e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1157,3.26233e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1159,5.369506e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1161,3.879658e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1163,2.348044e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1167,8.455719e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1169,2.290507e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1171,7.656566e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1173,1.00954e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1263,7.338372e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1265,9.10493e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1267,5.569861e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1269,0.0001999326);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1271,0.0002027896);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1273,0.0001720333);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1275,0.0001568886);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1277,0.0001240846);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1279,8.884624e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1281,9.453873e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1283,7.225103e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1285,4.650455e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1287,3.209055e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1289,2.959201e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1291,9.333802e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1293,1.573742e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1297,2.308959e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1389,1.560322e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1391,3.015092e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1393,0.0001184667);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1395,0.000150646);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1397,0.0001665978);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1399,0.0001483878);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1401,0.0001466882);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1403,0.0002118318);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1405,0.0001165342);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1407,7.598646e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1409,2.474572e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1411,6.559607e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1413,5.777213e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1415,8.823151e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1417,2.347581e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1513,7.341319e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1515,7.305889e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1517,3.814657e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1519,0.0001015869);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1521,0.000172286);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1523,0.0002140176);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1525,0.0002392701);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1527,0.0001835286);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1529,0.000176318);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1531,9.535073e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1533,7.13839e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1535,5.38307e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1537,6.121139e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1539,2.390215e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1541,2.212266e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1543,9.043746e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1545,1.223446e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1641,7.249345e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1643,5.25522e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1645,0.0001597945);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1647,0.0001430315);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1649,9.659104e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1651,0.0001699936);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1653,0.000187485);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1655,9.251887e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1657,0.0001097469);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1659,7.809953e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1661,5.958989e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1663,2.919722e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1665,8.269647e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1667,4.509834e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1669,8.446463e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1765,7.251579e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1767,2.972476e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1769,6.093227e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1771,9.150603e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1773,0.0002137829);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1775,0.0001965072);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1777,0.0002076886);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1783,7.804335e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1785,7.99967e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1787,7.567159e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1789,1.58219e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1791,6.803795e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1793,1.508288e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1845,0.0001303281);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1846,9.782754e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1847,9.356895e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1848,5.299606e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1849,3.079541e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1850,6.97531e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1851,7.410558e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1852,3.092798e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1853,9.314946e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1854,5.638911e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1855,6.986612e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1893,1.431872e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1895,6.610979e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1897,0.000132245);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1899,0.0001803453);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1901,0.0002815568);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1907,8.094152e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1908,0.0001054185);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1909,9.842025e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1910,9.708726e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1911,3.69493e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1912,5.863033e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1913,5.11917e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1914,4.536328e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1915,8.80344e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1916,1.525666e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1917,2.260729e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1969,0.0001184061);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1970,9.581729e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1971,6.413428e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1972,0.0001249582);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1973,9.884072e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1974,2.981749e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1975,3.70996e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1976,5.243064e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1977,3.775302e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1978,4.987375e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1979,3.735965e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2019,7.052307e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2021,5.921452e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2023,0.0001417887);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2025,0.0002322085);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2031,9.370531e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2032,0.0001561568);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2033,0.0001094797);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2034,9.125375e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2035,7.883906e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2036,4.482335e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2037,0.0001095942);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2038,4.665074e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2039,7.408733e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2040,4.187578e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2041,4.471496e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2093,0.0001539722);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2094,6.609136e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2095,0.0001137924);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2096,0.0001047007);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2097,0.0001012576);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2098,0.0001045132);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2099,6.815149e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2100,5.939582e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2101,6.884961e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2102,3.826993e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2103,5.076411e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2145,2.179945e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2147,4.47756e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2149,0.0001000752);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2155,0.0001675011);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2156,0.0001495976);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2157,0.0001528035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2158,0.0001673054);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2159,0.0001213681);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2160,0.0001357255);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2161,7.969982e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2162,8.280258e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2163,6.849132e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2164,8.730486e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2165,5.338056e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2217,0.0002482186);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2218,0.0001077368);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2219,0.0001397254);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2220,7.354759e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2221,0.000101262);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2222,9.008725e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2223,9.870629e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2224,8.152986e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2225,7.07009e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2226,9.355402e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2227,2.667424e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2271,6.894546e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2273,7.063658e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2279,0.0001273522);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2280,0.0002170398);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2281,0.0001817495);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2282,0.0001337406);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2283,9.500278e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2284,7.047172e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2285,0.0001695914);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2286,9.940741e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2287,9.15542e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2288,7.842919e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2289,2.332236e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2341,0.0001539429);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2342,0.0002044542);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2343,0.0001873092);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2344,0.0001838592);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2345,0.000123901);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2346,0.000167667);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2347,0.0001296458);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2348,9.574578e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2349,0.0001037935);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2350,6.645099e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2351,5.763422e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2397,1.440439e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2403,0.000148464);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2404,0.0001465378);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2405,0.0002185723);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2406,0.0001670464);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2407,0.0001385211);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2408,0.0001266915);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2409,0.0001720262);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2410,0.000122275);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2411,0.0001160111);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2412,0.0001437584);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2413,0.0001078065);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2465,9.862148e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2466,0.0001615872);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2467,0.0001146264);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2468,0.0002096854);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2469,0.0001391967);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2470,0.0001847655);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2471,0.0001544275);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2472,9.13093e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2473,0.0001172197);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2474,0.0001431549);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2475,7.500694e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2527,0.0001342988);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2528,0.0001168632);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2529,0.0001990361);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2530,0.0001403632);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2531,0.0001689518);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2532,0.0001687316);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2533,0.0001554795);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2534,0.0001525373);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2535,0.0001404873);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2536,0.0001042065);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2537,0.00011008);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2589,6.732191e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2590,0.0001137635);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2591,0.0001382011);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2592,0.0001264681);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2593,0.0001350597);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2594,0.0002192751);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2595,0.0001682953);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2596,0.0001947747);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2597,0.0001621784);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2598,0.0001358224);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2599,0.0001095694);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2651,3.973196e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2653,0.0001312486);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2655,0.0001776867);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2657,0.0002101957);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2659,0.0001640432);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2661,9.82355e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2775,3.239732e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2777,3.350062e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2779,9.836649e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2781,0.0001955297);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2783,0.000150577);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2785,0.0001494002);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2901,6.402566e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2903,5.373391e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2905,5.743531e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2907,0.0001248867);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2909,0.0001779406);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3027,6.273937e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3029,7.087543e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3031,0.0001414115);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3033,0.0001054795);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3153,1.339014e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3155,2.013531e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3157,6.985236e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3279,1.342559e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3281,4.286647e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3405,1.201889e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(141,2.410774e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(143,3.341717e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(145,3.235976e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(147,3.675178e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(149,4.198489e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(151,2.828571e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(153,2.269898e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(155,2.172087e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(157,1.988205e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(159,1.406032e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(161,1.924104e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(163,1.408695e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(165,1.198659e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(169,8.255681e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(173,1.203804e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(175,1.476144e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(177,7.7687e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(265,3.100213e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(267,2.685468e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(269,2.190621e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(271,2.909574e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(273,3.029857e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(275,3.122197e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(277,3.297128e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(279,2.84483e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(281,1.766216e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(283,1.916662e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(285,1.407813e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(287,1.506895e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(289,1.710901e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(291,8.346802e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(293,1.136122e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(295,1.400772e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(301,8.828084e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(389,2.70879e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(391,2.789149e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(393,3.664384e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(395,3.382958e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(397,3.289912e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(399,2.646867e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(401,2.710957e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(403,3.028601e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(405,2.467749e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(407,1.96865e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(409,2.382552e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(411,1.789374e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(413,1.357449e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(415,9.346131e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(419,6.492668e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(421,1.107571e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(423,1.102003e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(425,1.08757e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(427,8.859368e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(429,6.769899e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(513,3.10205e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(515,3.626834e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(517,3.401028e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(519,4.424528e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(521,3.380388e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(523,2.869661e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(525,2.322259e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(527,3.187876e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(529,2.077778e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(531,3.078752e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(533,2.283898e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(535,2.04244e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(537,1.097451e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(541,6.599222e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(543,8.121048e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(545,1.148815e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(549,9.826328e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(551,7.763679e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(637,2.338116e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(639,3.700388e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(641,2.833804e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(643,3.197382e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(645,3.314252e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(647,4.018887e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(649,3.522289e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(651,2.611336e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(653,2.633052e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(655,2.674188e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(657,2.213462e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(659,2.042579e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(661,1.634396e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(663,1.609064e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(665,6.63398e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(667,8.127731e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(669,7.59772e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(671,1.008847e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(675,8.544674e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(677,7.528308e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(761,1.407499e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(763,1.932781e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(765,3.564516e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(767,4.190386e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(769,3.167259e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(771,3.040995e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(773,3.27992e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(775,3.345095e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(777,2.962337e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(779,2.366439e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(781,2.903385e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(783,1.43625e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(785,2.331338e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(789,8.232694e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(791,8.108925e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(793,1.284465e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(795,7.873857e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(799,9.664402e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(801,1.455608e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(887,1.343327e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(889,2.422702e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(891,3.490179e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(893,4.010921e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(895,3.780134e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(897,3.477523e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(899,3.10797e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(901,3.908778e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(903,3.121447e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(905,1.872951e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(907,2.154375e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(909,1.88504e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(911,1.378479e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(913,1.380546e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(915,2.097297e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(917,8.015315e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(919,9.914787e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(921,7.022992e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(923,1.029855e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1011,1.082465e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1013,1.259446e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1015,2.761629e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1017,3.236024e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1019,4.126991e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1021,4.38512e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1023,3.467051e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1025,3.82842e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1027,2.979865e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1029,2.452627e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1031,1.957004e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1033,2.597797e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1035,1.930896e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1037,8.256226e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1039,1.096139e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1041,1.075797e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1043,1.07064e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1045,7.791614e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1137,1.096753e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1139,2.066023e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1141,2.83664e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1143,3.43618e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1145,4.050618e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1147,3.826107e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1149,3.377775e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1151,2.464708e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1153,3.170363e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1155,1.846203e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1157,1.632704e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1159,2.034489e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1161,1.737425e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1163,1.357271e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1167,8.455754e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1169,1.32282e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1171,7.656595e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1173,1.009545e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1263,7.338405e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1265,2.632125e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1267,2.112052e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1269,4.016729e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1271,4.06953e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1273,3.766275e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1275,3.60791e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1277,3.110124e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1279,2.683622e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1281,2.736863e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1283,2.410978e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1285,1.90074e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1287,1.604938e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1289,1.484475e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1291,9.333847e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1293,1.112812e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1297,1.334794e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1389,1.105231e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1391,1.509648e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1393,3.072304e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1395,3.468383e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1397,3.648408e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1399,3.416941e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1401,3.466741e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1403,4.088283e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1405,3.017824e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1407,2.536096e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1409,1.428712e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1411,2.192603e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1413,2.184217e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1415,8.823188e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1417,1.357121e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1513,7.341351e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1515,7.305922e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1517,1.708903e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1519,2.825897e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1521,3.679782e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1523,4.058541e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1525,4.385528e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1527,3.838685e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1529,4.564143e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1531,2.758385e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1533,2.382041e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1535,2.040293e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1537,2.166757e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1539,1.380404e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1541,1.278445e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1543,9.043786e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1545,1.223453e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1641,7.249377e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1643,1.99342e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1645,3.498606e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1647,3.288056e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1649,2.68769e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1651,3.636282e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1653,4.107308e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1655,2.681043e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1657,2.940495e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1659,2.477255e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1661,2.111389e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1663,1.46467e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1665,2.49875e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1667,1.841702e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1669,8.446498e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1765,7.251611e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1767,1.48831e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1769,2.163003e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1771,2.646952e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1773,4.05066e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1775,3.940663e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1777,4.08562e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1783,2.474407e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1785,2.531969e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1787,2.396151e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1789,1.118786e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1791,2.270081e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1793,1.066529e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1845,3.168621e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1846,2.72375e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1847,2.827987e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1848,2.004232e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1849,1.541312e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1850,2.333329e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1851,2.471599e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1852,1.785654e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1853,9.314988e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1854,1.998692e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1855,6.986638e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1893,1.012495e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1895,2.207267e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1897,3.128401e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1899,3.69209e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1901,5.243273e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1907,2.443602e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1908,2.824873e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1909,2.738845e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1910,2.702848e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1911,1.656939e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1912,2.077927e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1913,1.940681e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1914,1.857888e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1915,2.656577e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1916,1.078817e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1917,1.305247e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1969,2.970597e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1970,2.664561e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1971,2.145622e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1972,3.230185e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1973,2.746198e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1974,1.49253e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1975,1.665174e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1976,1.983136e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1977,1.689961e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1978,1.890255e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1979,1.672196e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2019,7.052337e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2021,2.100851e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2023,3.265114e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2025,4.186878e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2031,2.83533e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2032,3.419955e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2033,2.835077e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2034,2.639484e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2035,2.495971e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2036,1.831952e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2037,2.931678e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2038,1.910699e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2039,2.472474e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2040,1.714406e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2041,2.006365e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2093,3.455186e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2094,2.345344e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2095,2.854059e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2096,2.802457e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2097,2.821923e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2098,2.796023e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2099,2.27635e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2100,2.102677e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2101,2.185345e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2102,1.713743e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2103,1.920751e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2145,1.26062e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2147,1.832563e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2149,2.679382e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2155,3.505585e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2156,3.27437e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2157,3.34497e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2158,3.49675e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2159,3.038697e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2160,3.396122e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2161,2.407201e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2162,2.499524e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2163,2.287868e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2164,2.770869e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2165,2.181049e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2217,4.267516e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2218,2.795678e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2219,3.21435e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2220,2.333501e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2221,2.712508e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2222,2.724588e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2223,2.747426e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2224,2.463669e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2225,2.358225e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2226,3.129781e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2227,1.335364e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2271,6.894574e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2273,2.240454e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2279,3.016811e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2280,4.27232e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2281,3.650017e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2282,3.159543e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2283,2.640022e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2284,2.353772e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2285,3.547394e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2286,2.66568e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2287,2.546027e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2288,2.372225e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2289,1.348133e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2341,3.288942e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2342,3.879449e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2343,3.683385e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2344,3.620736e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2345,3.107889e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2346,3.58084e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2347,3.150108e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2348,2.669226e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2349,2.779294e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2350,2.227233e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2351,2.042909e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2397,1.020313e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2403,3.251359e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2404,3.287505e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2405,3.941387e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2406,3.49252e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2407,3.185862e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2408,2.995146e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2409,3.523781e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2410,2.974041e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2411,2.908103e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2412,3.221692e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2413,2.789581e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2465,2.64131e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2466,3.383518e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2467,2.878316e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2468,3.908369e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2469,3.126696e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2470,3.78242e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2471,3.303136e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2472,3.051237e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2473,2.853141e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2474,3.206525e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2475,2.269593e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2527,3.007383e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2528,2.843386e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2529,3.775297e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2530,3.150561e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2531,3.459947e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2532,3.454704e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2533,3.324955e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2534,3.422943e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2535,3.228792e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2536,2.701224e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2537,2.950226e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2589,2.135315e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2590,2.851624e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2591,3.100869e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2592,2.98863e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2593,3.110013e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2594,4.087783e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2595,3.3773e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2596,3.693838e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2597,3.392665e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2598,3.125379e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2599,2.836618e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2651,1.623777e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2653,3.021345e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2655,3.49838e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2657,3.852509e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2659,3.359416e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2661,3.284042e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2775,1.448881e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2777,1.500768e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2779,2.54645e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2781,3.578018e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2783,3.219385e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2785,3.350303e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2901,6.402591e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2903,1.906401e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2905,1.917021e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2907,2.872366e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2909,3.501444e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3027,6.27396e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3029,2.141461e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3031,3.256193e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3033,2.646274e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3153,9.484697e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3155,1.164244e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3157,2.112534e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3279,9.509805e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3281,1.621737e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3405,8.498699e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetEntries(4769.136);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->Draw("colz");
   c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf->Modified();
   c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf->cd();
   c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf->SetSelected(c_AccEffMap_T1qqqq_8NJetinf_500HT800_200MHTinf);
}
/*
Topology ~g ~g ; ~g ->q+qbar+LSP

mGluino(GeV) mLSP(GeV) AccXEff
   400    25   6.35007e-05
   400    75   0.000119797
   400   125   8.95516e-05
   400   175   0.000119827
   400   225   6.99617e-05
   400   275   2.43702e-05
   450    25   0.000133293
   450    75    8.4668e-05
   450   125   9.22055e-05
   450   175   0.000161546
   450   225   0.000172857
   450   275   4.72457e-05
   450   325   2.32297e-05
   450   375   1.52818e-05
   500    25   0.000128958
   500    75    5.7747e-05
   500   125   0.000150804
   500   175   0.000139823
   500   225    9.7692e-05
   500   275   0.000154931
   500   325   7.23697e-05
   500   375   2.18139e-05
   500   425   1.54835e-05
   550    25   0.000155452
   550    75   0.000100456
   550   125   0.000134889
   550   175   0.000229379
   550   225   0.000114872
   550   275   0.000212923
   550   325    0.00014753
   550   375   9.13671e-05
   550   425   5.44186e-05
   550   475   7.33837e-06
   600    25   0.000196772
   600    75   0.000104831
   600   125   0.000127115
   600   175   0.000130555
   600   225   0.000132153
   600   275   0.000118135
   600   325   0.000195846
   600   375   0.000124866
   600   425   0.000102097
   600   475   9.10493e-05
   600   525   1.56032e-05
   600   575   7.34132e-06
   650    25   8.91343e-05
   650    75   0.000112338
   650   125   8.35468e-05
   650   175   9.91892e-05
   650   225   0.000188163
   650   275    0.00010923
   650   325   0.000176751
   650   375   0.000209632
   650   425   0.000145155
   650   475   5.56986e-05
   650   525   3.01509e-05
   650   575   7.30589e-06
   700    25   5.98995e-05
   700    75   0.000123228
   700   125   8.54155e-05
   700   175   6.12698e-05
   700   225   0.000148863
   700   275   0.000130634
   700   325    0.00013884
   700   375   0.000227133
   700   425   0.000201786
   700   475   0.000199933
   700   525   0.000118467
   700   575   3.81466e-05
   700   625   7.24934e-06
   700   675   7.25158e-06
   750    25   5.31655e-05
   750    75   6.34053e-05
   750   125   0.000108885
   750   175   0.000114496
   750   225   7.81146e-05
   750   275   0.000133305
   750   325   0.000111815
   750   375   0.000146697
   750   425   0.000178967
   750   475    0.00020279
   750   525   0.000150646
   750   575   0.000101587
   750   625   5.25522e-05
   750   675   2.97248e-05
   800    25   4.44189e-05
   800    75   3.92504e-05
   800   125   6.97273e-05
   800   175   5.08233e-05
   800   225   6.94931e-05
   800   275   0.000106523
   800   325   0.000182825
   800   375   0.000179158
   800   425    0.00013491
   800   475   0.000172033
   800   525   0.000166598
   800   575   0.000172286
   800   625   0.000159794
   800   675   6.09323e-05
   800   725   1.43187e-05
   850    25   2.42489e-05
   850    75   4.28013e-05
   850   125   4.81134e-05
   850   175   0.000114852
   850   225   8.44746e-05
   850   275   6.68382e-05
   850   325    0.00012049
   850   375   0.000107237
   850   425   7.37693e-05
   850   475   0.000156889
   850   525   0.000148388
   850   575   0.000214018
   850   625   0.000143031
   850   675    9.1506e-05
   850   725   6.61098e-05
   850   775   7.05231e-06
   900    25   4.30146e-05
   900    75    2.4376e-05
   900   125   6.73207e-05
   900   175   6.44551e-05
   900   225   5.42075e-05
   900   275   0.000100455
   900   325   4.18252e-05
   900   375   7.32961e-05
   900   425   0.000122444
   900   475   0.000124085
   900   525   0.000146688
   900   575    0.00023927
   900   625    9.6591e-05
   900   675   0.000213783
   900   725   0.000132245
   900   775   5.92145e-05
   900   825   2.17994e-05
   950    25   2.43765e-05
   950    75   2.60666e-05
   950   125   3.99738e-05
   950   175   4.98801e-05
   950   225   4.99944e-05
   950   275   2.48468e-05
   950   325   5.69422e-05
   950   375   4.78946e-05
   950   425   4.12279e-05
   950   475   8.88462e-05
   950   525   0.000211832
   950   575   0.000183529
   950   625   0.000169994
   950   675   0.000196507
   950   725   0.000180345
   950   775   0.000141789
   950   825   4.47756e-05
   950   875   6.89455e-06
  1000    25   1.69515e-05
  1000    75   2.41955e-05
  1000   125    2.3411e-05
  1000   175   1.55202e-05
  1000   225   3.26571e-05
  1000   275   6.58607e-05
  1000   325   4.21148e-05
  1000   375   7.78257e-05
  1000   425   3.26233e-05
  1000   475   9.45387e-05
  1000   525   0.000116534
  1000   575   0.000176318
  1000   625   0.000187485
  1000   675   0.000207689
  1000   725   0.000281557
  1000   775   0.000232208
  1000   825   0.000100075
  1000   875   7.06366e-05
  1000   925   1.44044e-05
  1050    75   8.34677e-06
  1050   125   9.34608e-06
  1050   225   3.58244e-05
  1050   325   2.38536e-05
  1050   375   4.71641e-05
  1050   425   5.36951e-05
  1050   475    7.2251e-05
  1050   525   7.59865e-05
  1050   575   9.53507e-05
  1050   625   9.25189e-05
  1100    25   8.25565e-06
  1100    75   1.60618e-05
  1100   175    6.5992e-06
  1100   225   6.63395e-06
  1100   275   8.23266e-06
  1100   325   2.38831e-05
  1100   375   8.25619e-06
  1100   425   3.87966e-05
  1100   475   4.65045e-05
  1100   525   2.47457e-05
  1100   575   7.13839e-05
  1100   625   0.000109747
  1150    75   2.42618e-05
  1150   125   6.49264e-06
  1150   175   8.12102e-06
  1150   225    8.1277e-06
  1150   275   8.10889e-06
  1150   325   2.96501e-05
  1150   375    1.5496e-05
  1150   425   2.34804e-05
  1150   475   3.20905e-05
  1150   525   6.55961e-05
  1150   575   5.38307e-05
  1150   625   7.80995e-05
  1150   675   7.80433e-05
  1150   700   0.000130328
  1150   725   8.09415e-05
  1150   750   0.000118406
  1150   775   9.37053e-05
  1150   800   0.000153972
  1150   825   0.000167501
  1150   850   0.000248219
  1150   875   0.000127352
  1150   900   0.000153943
  1150   925   0.000148464
  1150   950   9.86215e-05
  1150   975   0.000134299
  1150  1000   6.73219e-05
  1150  1025    3.9732e-05
  1150  1075   3.23973e-05
  1175   700   9.78275e-05
  1175   725   0.000105419
  1175   750   9.58173e-05
  1175   775   0.000156157
  1175   800   6.60914e-05
  1175   825   0.000149598
  1175   850   0.000107737
  1175   875    0.00021704
  1175   900   0.000204454
  1175   925   0.000146538
  1175   950   0.000161587
  1175   975   0.000116863
  1175  1000   0.000113764
  1200    25   1.70242e-05
  1200   125   1.56581e-05
  1200   175   1.61472e-05
  1200   225   7.59769e-06
  1200   275   1.81649e-05
  1200   325   8.01528e-06
  1200   375   1.51209e-05
  1200   475    2.9592e-05
  1200   525   5.77721e-05
  1200   575   6.12114e-05
  1200   625   5.95899e-05
  1200   675   7.99967e-05
  1200   700    9.3569e-05
  1200   725   9.84203e-05
  1200   750   6.41343e-05
  1200   775    0.00010948
  1200   800   0.000113792
  1200   825   0.000152804
  1200   850   0.000139725
  1200   875    0.00018175
  1200   900   0.000187309
  1200   925   0.000218572
  1200   950   0.000114626
  1200   975   0.000199036
  1200  1000   0.000138201
  1200  1025   0.000131249
  1200  1075   3.35006e-05
  1200  1125   6.40257e-06
  1225   700   5.29961e-05
  1225   725   9.70873e-05
  1225   750   0.000124958
  1225   775   9.12537e-05
  1225   800   0.000104701
  1225   825   0.000167305
  1225   850   7.35476e-05
  1225   875   0.000133741
  1225   900   0.000183859
  1225   925   0.000167046
  1225   950   0.000209685
  1225   975   0.000140363
  1225  1000   0.000126468
  1250    25   2.55673e-05
  1250   125   1.55794e-05
  1250   225   1.41799e-05
  1250   275   7.87383e-06
  1250   325   1.39703e-05
  1250   375   1.51201e-05
  1250   425   8.45572e-06
  1250   475    9.3338e-06
  1250   525   8.82315e-06
  1250   575   2.39022e-05
  1250   625   2.91972e-05
  1250   675   7.56716e-05
  1250   700   3.07954e-05
  1250   725   3.69493e-05
  1250   750   9.88407e-05
  1250   775   7.88391e-05
  1250   800   0.000101258
  1250   825   0.000121368
  1250   850   0.000101262
  1250   875   9.50028e-05
  1250   900   0.000123901
  1250   925   0.000138521
  1250   950   0.000139197
  1250   975   0.000168952
  1250  1000    0.00013506
  1250  1025   0.000177687
  1250  1075   9.83665e-05
  1250  1125   5.37339e-05
  1250  1175   6.27394e-06
  1275   700   6.97531e-05
  1275   725   5.86303e-05
  1275   750   2.98175e-05
  1275   775   4.48234e-05
  1275   800   0.000104513
  1275   825   0.000135726
  1275   850   9.00873e-05
  1275   875   7.04717e-05
  1275   900   0.000167667
  1275   925   0.000126691
  1275   950   0.000184766
  1275   975   0.000168732
  1275  1000   0.000219275
  1300    25   7.76867e-06
  1300    75   8.82805e-06
  1300   125   1.08756e-05
  1300   175   9.82628e-06
  1300   325   7.02297e-06
  1300   375   7.79158e-06
  1300   425   2.29051e-05
  1300   475   1.57374e-05
  1300   525   2.34758e-05
  1300   575   2.21227e-05
  1300   625   8.26965e-05
  1300   675   1.58219e-05
  1300   700   7.41056e-05
  1300   725   5.11917e-05
  1300   750   3.70996e-05
  1300   775   0.000109594
  1300   800   6.81515e-05
  1300   825   7.96998e-05
  1300   850   9.87063e-05
  1300   875   0.000169591
  1300   900   0.000129646
  1300   925   0.000172026
  1300   950   0.000154428
  1300   975   0.000155479
  1300  1000   0.000168295
  1300  1025   0.000210196
  1300  1075    0.00019553
  1300  1125   5.74353e-05
  1300  1175   7.08754e-05
  1300  1225   1.33901e-05
  1325   700    3.0928e-05
  1325   725   4.53633e-05
  1325   750   5.24306e-05
  1325   775   4.66507e-05
  1325   800   5.93958e-05
  1325   825   8.28026e-05
  1325   850   8.15299e-05
  1325   875   9.94074e-05
  1325   900   9.57458e-05
  1325   925   0.000122275
  1325   950   9.13093e-05
  1325   975   0.000152537
  1325  1000   0.000194775
  1350   125   8.85933e-06
  1350   175   7.76365e-06
  1350   225   8.54464e-06
  1350   275   9.66436e-06
  1350   325   1.45441e-05
  1350   425   7.65657e-06
  1350   575   9.04375e-06
  1350   625   4.50983e-05
  1350   675   6.80379e-05
  1350   700   9.31495e-06
  1350   725   8.80344e-05
  1350   750    3.7753e-05
  1350   775   7.40873e-05
  1350   800   6.88496e-05
  1350   825   6.84913e-05
  1350   850   7.07009e-05
  1350   875   9.15542e-05
  1350   900   0.000103793
  1350   925   0.000116011
  1350   950    0.00011722
  1350   975   0.000140487
  1350  1000   0.000162178
  1350  1025   0.000164043
  1350  1075   0.000150577
  1350  1125   0.000124887
  1350  1175   0.000141412
  1350  1225   2.01353e-05
  1350  1275   1.34256e-05
  1375   700   5.63891e-05
  1375   725   1.52567e-05
  1375   750   4.98738e-05
  1375   775   4.18758e-05
  1375   800   3.82699e-05
  1375   825   8.73049e-05
  1375   850    9.3554e-05
  1375   875   7.84292e-05
  1375   900    6.6451e-05
  1375   925   0.000143758
  1375   950   0.000143155
  1375   975   0.000104207
  1375  1000   0.000135822
  1400   125   6.76987e-06
  1400   225   7.52828e-06
  1400   275   2.05852e-05
  1400   425   1.00954e-05
  1400   475   2.30896e-05
  1400   575   1.22345e-05
  1400   625   8.44646e-06
  1400   675   1.50829e-05
  1400   700   6.98661e-06
  1400   725   2.26073e-05
  1400   750   3.73596e-05
  1400   775    4.4715e-05
  1400   800   5.07641e-05
  1400   825   5.33806e-05
  1400   850   2.66742e-05
  1400   875   2.33224e-05
  1400   900   5.76342e-05
  1400   925   0.000107806
  1400   950   7.50069e-05
  1400   975    0.00011008
  1400  1000   0.000109569
  1400  1025   9.82355e-05
  1400  1075     0.0001494
  1400  1125   0.000177941
  1400  1175   0.000105479
  1400  1225   6.98524e-05
  1400  1275   4.28665e-05
  1400  1325   1.20189e-05
*/
