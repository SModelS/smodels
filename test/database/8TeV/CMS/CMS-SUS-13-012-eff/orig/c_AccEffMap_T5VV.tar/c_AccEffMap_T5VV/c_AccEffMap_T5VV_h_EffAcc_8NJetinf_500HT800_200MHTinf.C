{
//=========Macro generated from canvas: c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf/c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf
//=========  (Sat Feb 22 16:32:53 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf = new TCanvas("c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf", "c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf",105,264,500,500);
   c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf->SetFillColor(0);
   c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf->SetLogz();
   c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_500HT800_200MHTinf = new TH2D("h_EffAcc_8NJetinf_500HT800_200MHTinf","h_EffAcc_8NJetinf_500HT800_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(141,0.0004984357);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(143,0.0008772195);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(145,0.001270398);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(147,0.001630036);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(149,0.001758101);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(151,0.001434889);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(153,0.001212388);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(155,0.001067919);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(157,0.000598541);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(159,0.0004062902);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(161,0.0003773914);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(163,0.000250705);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(165,0.0001248366);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(167,0.0001147722);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(169,7.342374e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(171,4.043549e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(173,2.326862e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(175,3.038879e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(177,7.391802e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(181,7.535102e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(265,0.0004010935);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(267,0.0006977071);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(269,0.001354652);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(271,0.00186815);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(273,0.001920729);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(275,0.001858319);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(277,0.001426852);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(279,0.001199219);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(281,0.0008499709);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(283,0.0008030409);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(285,0.0004346593);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(287,0.000314196);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(289,0.0001412141);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(291,0.0001327336);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(293,0.0001194956);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(295,7.300084e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(297,4.811052e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(299,7.046373e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(301,3.07266e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(303,1.490791e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(305,2.215644e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(389,0.0003013391);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(391,0.0006612897);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(393,0.001052457);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(395,0.00158398);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(397,0.002095513);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(399,0.001810064);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(401,0.001785255);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(403,0.001650604);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(405,0.0009825592);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(407,0.0007425604);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(409,0.0005190476);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(411,0.0003960666);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(413,0.000287352);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(415,0.0001367527);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(417,8.141909e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(419,5.571998e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(421,3.036376e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(423,1.57561e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(425,3.80605e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(427,1.533288e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(429,2.253568e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(513,7.852762e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(515,0.0003213571);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(517,0.000909262);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(519,0.001390618);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(521,0.001758834);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(523,0.002168261);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(525,0.00213378);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(527,0.001604867);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(529,0.001305021);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(531,0.001123517);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(533,0.0007096242);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(535,0.000441333);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(537,0.0003183634);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(539,0.0002190022);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(541,0.0001229741);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(543,0.0001330596);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(545,0.0001249169);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(547,7.4744e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(549,1.554137e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(551,7.663881e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(553,2.147997e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(639,0.0001766858);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(641,0.0004397723);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(643,0.0009940268);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(645,0.001648503);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(647,0.002001531);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(649,0.002240147);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(651,0.001997218);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(653,0.001675361);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(655,0.001244861);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(657,0.0008340426);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(659,0.000524888);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(661,0.0005501341);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(663,0.0003419938);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(665,0.0001354762);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(667,0.0001371299);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(669,0.0001334848);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(671,5.482423e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(673,2.333345e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(675,3.827896e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(677,2.259503e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(765,0.0002505713);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(767,0.000540183);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(769,0.001090292);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(771,0.001861175);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(773,0.002246074);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(775,0.00202807);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(777,0.001860328);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(779,0.00159226);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(781,0.001385132);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(783,0.0008211253);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(785,0.0005749684);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(787,0.0004647701);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(789,0.0002446462);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(791,0.0001578416);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(793,0.0001415614);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(795,6.184104e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(797,7.996689e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(799,6.08125e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(801,3.725241e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(891,0.0003144006);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(893,0.0005591936);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(895,0.001164254);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(897,0.001745928);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(899,0.002428496);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(901,0.002387611);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(903,0.002029984);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(905,0.001652249);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(907,0.00142198);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(909,0.0009514668);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(911,0.0006237366);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(913,0.0003679107);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(915,0.000253773);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(917,0.0001648269);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(919,0.0001179201);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(921,9.936735e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(923,3.813352e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(925,2.976141e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1017,0.0002604919);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1019,0.0006910752);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1021,0.001246123);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1023,0.001913963);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1025,0.002187553);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1027,0.002307704);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1029,0.001770654);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1031,0.001760637);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1033,0.001131619);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1035,0.0007214957);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1037,0.0005329365);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1039,0.0002916944);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1041,0.0002265746);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1043,0.0001383814);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1045,9.203855e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1047,7.390273e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1049,2.975363e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1143,0.000196068);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1145,0.0007008336);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1147,0.001417426);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1149,0.001923251);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1151,0.002510854);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1153,0.002364068);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1155,0.001911939);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1157,0.001481957);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1159,0.0009820992);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1161,0.0006733525);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1163,0.0003498562);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1165,0.0002991957);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1167,0.0001943774);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1169,0.0001047981);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1171,0.0001201838);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1173,5.930207e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1269,0.0003465015);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1271,0.0006636756);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1273,0.001326469);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1275,0.002112667);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1277,0.00232845);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1279,0.002385529);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1281,0.001859596);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1283,0.001449337);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1285,0.0009422296);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1287,0.0005672802);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1289,0.0004727979);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1291,0.0002703497);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1293,0.0002059752);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1295,8.972633e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1297,8.638013e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1395,0.0003703509);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1397,0.000734807);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1399,0.001554714);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1401,0.002099836);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1403,0.002530541);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1405,0.00252206);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1407,0.001919683);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1409,0.001713655);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1411,0.000875892);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1413,0.0007750804);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1415,0.0004536853);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1417,0.00026631);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1419,0.0001208922);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1421,0.0001059109);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1473,0.001071872);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1474,0.001002563);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1475,0.0008351183);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1476,0.0006789911);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1477,0.0005495592);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1478,0.0004025309);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1479,0.0004272717);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1480,0.0003290198);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1481,0.0002011637);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1482,0.0001752435);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1483,0.0001330128);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1521,0.0004597275);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1523,0.0007054565);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1525,0.001535862);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1527,0.002178995);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1529,0.002210465);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1531,0.002337226);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1533,0.001654073);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1535,0.001607836);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1536,0.001171656);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1537,0.0009929544);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1538,0.0007594902);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1539,0.0006886054);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1540,0.0005420012);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1541,0.0004045991);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1542,0.0002500633);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1543,0.0002616227);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1544,0.000233355);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1545,0.000167672);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1597,0.001550021);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1598,0.001590211);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1599,0.001208944);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1600,0.0009683463);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1601,0.001006374);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1602,0.0006811408);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1603,0.0006685208);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1604,0.0004151321);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1605,0.0002153249);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1606,0.0003145657);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1607,0.0002717905);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1647,0.0003077305);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1649,0.0008059902);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1651,0.001393903);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1653,0.002222644);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1655,0.002385728);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1657,0.002235041);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1659,0.002101882);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1660,0.001510416);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1661,0.001253251);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1662,0.0009740649);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1663,0.0009616683);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1664,0.0009025803);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1665,0.0005849471);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1666,0.0006237818);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1667,0.0003802435);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1668,0.0003416229);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1669,0.0003023921);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1721,0.002148165);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1722,0.002087955);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1723,0.001715332);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1724,0.001499642);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1725,0.001142145);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1726,0.001086341);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1727,0.0007066785);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1728,0.0005563563);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1729,0.0005519731);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1730,0.0003737467);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1731,0.0002596752);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1773,0.0003289232);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1775,0.000963777);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1777,0.001489302);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1779,0.00210948);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1781,0.002472532);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1783,0.002340865);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1784,0.002333264);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1785,0.001868384);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1786,0.001582481);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1787,0.001513682);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1788,0.001024268);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1789,0.0009243049);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1790,0.0008948964);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1791,0.0006166533);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1792,0.0004932811);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1793,0.000499534);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1845,0.002607616);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1846,0.00217079);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1847,0.001970519);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1848,0.002169099);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1849,0.00196905);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1850,0.001358286);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1851,0.001092509);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1852,0.0008832348);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1853,0.0009106226);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1854,0.0005425222);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1855,0.000584224);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1899,0.0004462511);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1901,0.0008885566);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1903,0.00166165);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1905,0.002385216);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1907,0.002651225);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1908,0.002407315);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1909,0.002087693);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1910,0.002132377);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1911,0.001783871);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1912,0.001557478);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1913,0.00122617);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1914,0.001117685);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1915,0.0008836848);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1916,0.0008129446);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1917,0.0006593044);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1969,0.002684417);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1970,0.00250461);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1971,0.002547773);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1972,0.002220245);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1973,0.002273303);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1974,0.001915387);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1975,0.002061004);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1976,0.001344895);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1977,0.001103121);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1978,0.001017225);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1979,0.0006861997);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2025,0.00041063);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2027,0.0009186119);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2029,0.001600965);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2031,0.002371291);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2032,0.002342737);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2033,0.002730732);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2034,0.002604736);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2035,0.002439531);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2036,0.002305661);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2037,0.001803197);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2038,0.001539148);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2039,0.001542844);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2040,0.001081798);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2041,0.0009615159);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2093,0.00179117);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2094,0.002296649);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2095,0.002293882);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2096,0.00244635);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2097,0.002560801);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2098,0.002500785);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2099,0.002257793);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2100,0.002120441);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2101,0.001819969);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2102,0.001157625);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2103,0.001106852);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2151,0.000338917);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2153,0.0008795026);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2155,0.001697932);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2156,0.0017684);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2157,0.002181283);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2158,0.002125975);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2159,0.002846763);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2160,0.002516097);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2161,0.0024884);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2162,0.002329235);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2163,0.001997051);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2164,0.00156673);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2165,0.001462986);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2217,0.001202489);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2218,0.001261806);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2219,0.001901135);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2220,0.002259156);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2221,0.002614548);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2222,0.002445227);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2223,0.002687688);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2224,0.002281007);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2225,0.002325098);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2226,0.002001969);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2227,0.001552941);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2277,0.0004261641);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2279,0.0007893423);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2281,0.001675372);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2283,0.002109688);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2285,0.002704758);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2287,0.002409014);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2289,0.001861045);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2403,0.000368497);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2405,0.0007152641);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2407,0.001459545);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2409,0.002029356);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2411,0.002562365);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2413,0.002226297);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2529,0.0004461153);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2531,0.0008525641);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2533,0.00141916);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2535,0.002271542);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2537,0.002406676);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2655,0.0002894054);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2657,0.0008939963);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2659,0.001559438);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2661,0.002005818);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2781,0.0002780915);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2783,0.0007017925);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2785,0.001375463);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2907,0.000328218);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2909,0.0008017766);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3033,0.0003084292);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(141,6.619729e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(143,8.669193e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(145,0.0001112943);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(147,0.0001214146);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(149,0.000124954);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(151,0.0001189586);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(153,0.0001113363);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(155,9.846678e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(157,7.435556e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(159,5.999428e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(161,5.833582e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(163,5.233268e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(165,3.611438e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(167,3.069636e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(169,2.453266e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(171,1.808366e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(173,1.345027e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(175,1.520872e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(177,7.39183e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(181,7.53513e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(265,6.000555e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(267,7.728287e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(269,0.0001087526);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(271,0.0001280697);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(273,0.000130695);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(275,0.0001347902);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(277,0.0001123533);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(279,0.0001049362);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(281,8.779264e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(283,9.287771e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(285,6.220108e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(287,5.475975e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(289,3.427313e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(291,3.319727e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(293,3.195267e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(295,2.433447e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(297,1.96415e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(299,2.349165e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(301,1.536723e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(303,1.054503e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(305,1.279584e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(389,4.905112e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(391,7.660315e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(393,9.600541e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(395,0.0001177332);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(397,0.0001379844);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(399,0.0001270832);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(401,0.0001255354);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(403,0.0001206153);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(405,9.22106e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(407,8.764176e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(409,7.207203e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(411,5.843644e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(413,5.994512e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(415,3.420058e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(417,2.879112e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(419,2.107401e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(421,1.520313e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(423,1.114133e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(425,1.703567e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(427,1.084206e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(429,1.301112e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(513,2.489741e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(515,5.525884e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(517,8.859652e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(519,0.0001096054);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(521,0.0001250821);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(523,0.0001377984);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(525,0.0001483148);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(527,0.0001195376);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(529,0.0001064304);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(531,9.98794e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(533,8.043625e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(535,6.130637e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(537,5.167836e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(539,5.165291e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(541,3.180285e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(543,3.232419e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(545,3.12565e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(547,2.492108e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(549,1.098949e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(551,7.663909e-06);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(553,1.241305e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(639,3.694805e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(641,6.066102e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(643,9.387866e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(645,0.0001203359);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(647,0.0001402174);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(649,0.0001468892);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(651,0.0001343873);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(653,0.0001205612);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(655,0.0001188792);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(657,8.803445e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(659,6.62322e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(661,6.882489e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(663,5.41901e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(665,3.38871e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(667,3.327042e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(669,3.239638e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(671,2.073652e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(673,1.347172e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(675,1.711919e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(677,1.304539e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(765,4.517487e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(767,6.672464e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(769,9.631197e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(771,0.0001267804);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(773,0.0001422229);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(775,0.00013523);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(777,0.0001331947);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(779,0.0001238176);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(781,0.0001189805);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(783,8.34873e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(785,6.930864e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(787,6.21435e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(789,4.469583e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(791,3.534606e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(793,3.340699e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(795,2.187852e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(797,2.418925e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(799,2.150408e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(801,1.666349e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(891,4.98599e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(893,6.857826e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(895,9.943756e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(897,0.0001244918);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(899,0.0001448304);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(901,0.0001575224);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(903,0.000135674);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(905,0.0001185775);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(907,0.0001095606);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(909,9.342865e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(911,7.162808e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(913,6.22544e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(915,4.493194e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(917,3.599028e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(919,3.045096e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(921,2.757939e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(923,1.705414e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(925,1.48845e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1017,4.621322e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1019,7.476943e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1021,0.0001031109);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1023,0.0001275031);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1025,0.0001385195);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1027,0.000159672);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1029,0.0001221681);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1031,0.0001214848);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1033,0.0001111616);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1035,9.030766e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1037,6.567334e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1039,4.801098e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1041,4.210697e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1043,3.264325e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1045,2.661239e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1047,2.339082e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1049,1.488061e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1143,3.930225e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1145,7.721884e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1147,0.0001085192);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1149,0.0001283695);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1151,0.0001454575);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1153,0.0001464489);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1155,0.0001897179);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1157,0.000110982);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1159,9.380528e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1161,7.946018e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1163,5.279386e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1165,4.857045e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1167,3.890126e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1169,2.806061e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1171,3.00672e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1173,2.097882e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1269,5.236441e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1271,7.584295e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1273,0.0001046377);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1275,0.0001343963);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1277,0.0001398806);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1279,0.0001704371);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1281,0.0001314965);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1283,0.000110414);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1285,8.72469e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1287,6.738135e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1289,6.110123e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1291,4.575223e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1293,3.967121e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1295,2.592237e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1297,2.609032e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1395,5.67198e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1397,7.691045e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1399,0.0001138206);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1401,0.0001376996);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1403,0.0001444259);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1405,0.0001580806);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1407,0.000124993);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1409,0.0001213894);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1411,8.325676e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1413,7.80067e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1415,5.914988e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1417,4.506419e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1419,3.02418e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1421,2.831343e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1473,9.206966e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1474,8.979005e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1475,8.281549e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1476,7.793768e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1477,6.771968e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1478,6.073196e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1479,6.04911e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1480,5.340767e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1481,4.027495e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1482,3.827047e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1483,3.327401e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1521,6.004605e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1523,7.465251e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1525,0.0001136595);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1527,0.0001333231);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1529,0.0001339877);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1531,0.0001378557);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1533,0.0001190254);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1535,0.0001130683);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1536,0.0001466428);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1537,9.318489e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1538,7.682699e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1539,7.270427e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1540,7.0047e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1541,5.563351e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1542,4.730556e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1543,4.490546e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1544,4.193633e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1545,3.580513e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1597,0.0001126414);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1598,0.0001126567);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1599,9.956791e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1600,8.894065e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1601,8.806476e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1602,7.229709e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1603,7.174665e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1604,6.410669e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1605,4.072941e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1606,5.11105e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1607,4.532411e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1647,4.816834e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1649,8.050808e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1651,0.0001057924);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1653,0.0001337553);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1655,0.0001388388);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1657,0.0001425873);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1659,0.0001289293);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1660,0.0001089584);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1661,0.0001028351);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1662,9.057065e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1663,8.721469e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1664,8.287709e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1665,6.94939e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1666,7.167032e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1667,5.55416e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1668,5.042821e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1669,5.273211e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1721,0.0001301091);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1722,0.000127856);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1723,0.0001496725);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1724,0.0001113491);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1725,9.846748e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1726,9.163073e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1727,8.277336e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1728,6.562054e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1729,6.605154e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1730,5.346008e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1731,5.002503e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1773,5.08945e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1775,8.757433e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1777,0.0001079374);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1779,0.0001325565);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1781,0.0001429585);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1783,0.0001383233);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1784,0.000140543);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1785,0.0001239772);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1786,0.0001107665);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1787,0.0001088878);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1788,9.137867e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1789,0.000100423);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1790,8.872395e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1791,7.131751e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1792,6.079794e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1793,6.158716e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1845,0.0001428889);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1846,0.0001587156);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1847,0.0001299313);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1848,0.0001493229);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1849,0.0001281875);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1850,0.0001207059);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1851,9.346706e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1852,8.510743e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1853,8.815609e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1854,6.355915e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1855,6.622348e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1899,5.878303e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1901,8.180021e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1903,0.0001216785);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1905,0.0001575328);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1907,0.0001470907);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1908,0.0001367163);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1909,0.0001269254);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1910,0.0001382685);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1911,0.0001168883);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1912,0.0001153837);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1913,0.0001019899);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1914,9.461089e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1915,0.0001008059);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1916,8.098887e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1917,7.471293e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1969,0.0001496534);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1970,0.0001404899);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1971,0.0001402465);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1972,0.0001521232);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1973,0.0001376574);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1974,0.0001209237);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1975,0.0001674756);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1976,0.0001015578);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1977,9.111975e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1978,9.894372e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1979,7.16421e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2025,5.606807e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2027,8.492909e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2029,0.0001122597);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2031,0.0001343541);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2032,0.0001359623);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2033,0.0001447789);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2034,0.0001414956);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2035,0.0001384983);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2036,0.0001347796);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2037,0.0001168864);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2038,0.0001076835);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2039,0.0001136369);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2040,9.357312e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2041,9.094116e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2093,0.0001160881);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2094,0.0001421163);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2095,0.0001398225);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2096,0.0001369391);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2097,0.0001420114);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2098,0.0001399771);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2099,0.0001320103);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2100,0.0001385907);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2101,0.0001192182);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2102,9.833114e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2103,9.575496e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2151,4.959829e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2153,8.163883e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2155,0.0001138602);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2156,0.0001153163);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2157,0.0001365488);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2158,0.0001293126);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2159,0.0001490537);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2160,0.0001482238);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2161,0.0001401277);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2162,0.0001582073);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2163,0.0001241299);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2164,0.0001093961);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2165,0.0001063317);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2217,9.632066e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2218,9.71146e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2219,0.0001446115);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2220,0.0001322289);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2221,0.0001400435);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2222,0.000135443);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2223,0.0001526082);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2224,0.0001359466);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2225,0.0001395307);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2226,0.0001218751);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2227,0.0001122545);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2277,5.716905e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2279,7.845227e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2281,0.0001109139);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2283,0.0001258152);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2285,0.0001529382);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2287,0.0001339773);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2289,0.000117012);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2403,7.889826e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2405,7.178362e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2407,0.0001216724);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2409,0.0001351494);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2411,0.0001375608);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2413,0.0001278031);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2529,6.393679e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2531,7.744618e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2533,0.0001009285);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2535,0.0001554654);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2537,0.0001318765);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2655,5.492163e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2657,7.900971e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2659,0.0001055451);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2661,0.0001200852);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2781,5.014262e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2783,6.940683e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2785,9.762523e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2907,4.656527e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2909,7.374314e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3033,4.609825e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetEntries(51075.58);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->Draw("colz");
   c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf->Modified();
   c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf->cd();
   c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf->SetSelected(c_AccEffMap_T5VV_8NJetinf_500HT800_200MHTinf);
}
/*
   400    25   0.000498436
   400    75   0.000401094
   400   125   0.000301339
   400   175   7.85276e-05
   450    25    0.00087722
   450    75   0.000697707
   450   125    0.00066129
   450   175   0.000321357
   450   225   0.000176686
   500    25     0.0012704
   500    75    0.00135465
   500   125    0.00105246
   500   175   0.000909262
   500   225   0.000439772
   500   275   0.000250571
   550    25    0.00163004
   550    75    0.00186815
   550   125    0.00158398
   550   175    0.00139062
   550   225   0.000994027
   550   275   0.000540183
   550   325   0.000314401
   600    25     0.0017581
   600    75    0.00192073
   600   125    0.00209551
   600   175    0.00175883
   600   225     0.0016485
   600   275    0.00109029
   600   325   0.000559194
   600   375   0.000260492
   650    25    0.00143489
   650    75    0.00185832
   650   125    0.00181006
   650   175    0.00216826
   650   225    0.00200153
   650   275    0.00186117
   650   325    0.00116425
   650   375   0.000691075
   650   425   0.000196068
   700    25    0.00121239
   700    75    0.00142685
   700   125    0.00178526
   700   175    0.00213378
   700   225    0.00224015
   700   275    0.00224607
   700   325    0.00174593
   700   375    0.00124612
   700   425   0.000700834
   700   475   0.000346501
   750    25    0.00106792
   750    75    0.00119922
   750   125     0.0016506
   750   175    0.00160487
   750   225    0.00199722
   750   275    0.00202807
   750   325     0.0024285
   750   375    0.00191396
   750   425    0.00141743
   750   475   0.000663676
   750   525   0.000370351
   800    25   0.000598541
   800    75   0.000849971
   800   125   0.000982559
   800   175    0.00130502
   800   225    0.00167536
   800   275    0.00186033
   800   325    0.00238761
   800   375    0.00218755
   800   425    0.00192325
   800   475    0.00132647
   800   525   0.000734807
   800   575   0.000459728
   850    25    0.00040629
   850    75   0.000803041
   850   125    0.00074256
   850   175    0.00112352
   850   225    0.00124486
   850   275    0.00159226
   850   325    0.00202998
   850   375     0.0023077
   850   425    0.00251085
   850   475    0.00211267
   850   525    0.00155471
   850   575   0.000705456
   850   625   0.000307731
   900    25   0.000377391
   900    75   0.000434659
   900   125   0.000519048
   900   175   0.000709624
   900   225   0.000834043
   900   275    0.00138513
   900   325    0.00165225
   900   375    0.00177065
   900   425    0.00236407
   900   475    0.00232845
   900   525    0.00209984
   900   575    0.00153586
   900   625    0.00080599
   900   675   0.000328923
   950    25   0.000250705
   950    75   0.000314196
   950   125   0.000396067
   950   175   0.000441333
   950   225   0.000524888
   950   275   0.000821125
   950   325    0.00142198
   950   375    0.00176064
   950   425    0.00191194
   950   475    0.00238553
   950   525    0.00253054
   950   575      0.002179
   950   625     0.0013939
   950   675   0.000963777
   950   725   0.000446251
  1000    25   0.000124837
  1000    75   0.000141214
  1000   125   0.000287352
  1000   175   0.000318363
  1000   225   0.000550134
  1000   275   0.000574968
  1000   325   0.000951467
  1000   375    0.00113162
  1000   425    0.00148196
  1000   475     0.0018596
  1000   525    0.00252206
  1000   575    0.00221047
  1000   625    0.00222264
  1000   675     0.0014893
  1000   725   0.000888557
  1000   775    0.00041063
  1050    25   0.000114772
  1050    75   0.000132734
  1050   125   0.000136753
  1050   175   0.000219002
  1050   225   0.000341994
  1050   275    0.00046477
  1050   325   0.000623737
  1050   375   0.000721496
  1050   425   0.000982099
  1050   475    0.00144934
  1050   525    0.00191968
  1050   575    0.00233723
  1050   625    0.00238573
  1050   675    0.00210948
  1050   725    0.00166165
  1050   775   0.000918612
  1050   825   0.000338917
  1100    25   7.34237e-05
  1100    75   0.000119496
  1100   125   8.14191e-05
  1100   175   0.000122974
  1100   225   0.000135476
  1100   275   0.000244646
  1100   325   0.000367911
  1100   375   0.000532937
  1100   425   0.000673353
  1100   475    0.00094223
  1100   525    0.00171365
  1100   575    0.00165407
  1100   625    0.00223504
  1100   675    0.00247253
  1100   725    0.00238522
  1100   775    0.00160097
  1100   825   0.000879503
  1100   875   0.000426164
  1150    25   4.04355e-05
  1150    75   7.30008e-05
  1150   125     5.572e-05
  1150   175    0.00013306
  1150   225    0.00013713
  1150   275   0.000157842
  1150   325   0.000253773
  1150   375   0.000291694
  1150   425   0.000349856
  1150   475    0.00056728
  1150   525   0.000875892
  1150   550    0.00107187
  1150   575    0.00160784
  1150   600    0.00155002
  1150   625    0.00210188
  1150   650    0.00214816
  1150   675    0.00234086
  1150   700    0.00260762
  1150   725    0.00265123
  1150   750    0.00268442
  1150   775    0.00237129
  1150   800    0.00179117
  1150   825    0.00169793
  1150   850    0.00120249
  1150   875   0.000789342
  1150   925   0.000368497
  1175   550    0.00100256
  1175   575    0.00117166
  1175   600    0.00159021
  1175   625    0.00151042
  1175   650    0.00208795
  1175   675    0.00233326
  1175   700    0.00217079
  1175   725    0.00240731
  1175   750    0.00250461
  1175   775    0.00234274
  1175   800    0.00229665
  1175   825     0.0017684
  1175   850    0.00126181
  1200    25   2.32686e-05
  1200    75   4.81105e-05
  1200   125   3.03638e-05
  1200   175   0.000124917
  1200   225   0.000133485
  1200   275   0.000141561
  1200   325   0.000164827
  1200   375   0.000226575
  1200   425   0.000299196
  1200   475   0.000472798
  1200   525    0.00077508
  1200   550   0.000835118
  1200   575   0.000992954
  1200   600    0.00120894
  1200   625    0.00125325
  1200   650    0.00171533
  1200   675    0.00186838
  1200   700    0.00197052
  1200   725    0.00208769
  1200   750    0.00254777
  1200   775    0.00273073
  1200   800    0.00229388
  1200   825    0.00218128
  1200   850    0.00190114
  1200   875    0.00167537
  1200   925   0.000715264
  1200   975   0.000446115
  1225   550   0.000678991
  1225   575    0.00075949
  1225   600   0.000968346
  1225   625   0.000974065
  1225   650    0.00149964
  1225   675    0.00158248
  1225   700     0.0021691
  1225   725    0.00213238
  1225   750    0.00222024
  1225   775    0.00260474
  1225   800    0.00244635
  1225   825    0.00212598
  1225   850    0.00225916
  1250    25   3.03888e-05
  1250    75   7.04637e-05
  1250   125   1.57561e-05
  1250   175    7.4744e-05
  1250   225   5.48242e-05
  1250   275    6.1841e-05
  1250   325    0.00011792
  1250   375   0.000138381
  1250   425   0.000194377
  1250   475    0.00027035
  1250   525   0.000453685
  1250   550   0.000549559
  1250   575   0.000688605
  1250   600    0.00100637
  1250   625   0.000961668
  1250   650    0.00114214
  1250   675    0.00151368
  1250   700    0.00196905
  1250   725    0.00178387
  1250   750     0.0022733
  1250   775    0.00243953
  1250   800     0.0025608
  1250   825    0.00284676
  1250   850    0.00261455
  1250   875    0.00210969
  1250   925    0.00145954
  1250   975   0.000852564
  1250  1025   0.000289405
  1275   550   0.000402531
  1275   575   0.000542001
  1275   600   0.000681141
  1275   625    0.00090258
  1275   650    0.00108634
  1275   675    0.00102427
  1275   700    0.00135829
  1275   725    0.00155748
  1275   750    0.00191539
  1275   775    0.00230566
  1275   800    0.00250078
  1275   825     0.0025161
  1275   850    0.00244523
  1300    25    7.3918e-06
  1300    75   3.07266e-05
  1300   125   3.80605e-05
  1300   175   1.55414e-05
  1300   225   2.33334e-05
  1300   275   7.99669e-05
  1300   325   9.93673e-05
  1300   375   9.20385e-05
  1300   425   0.000104798
  1300   475   0.000205975
  1300   525    0.00026631
  1300   550   0.000427272
  1300   575   0.000404599
  1300   600   0.000668521
  1300   625   0.000584947
  1300   650   0.000706678
  1300   675   0.000924305
  1300   700    0.00109251
  1300   725    0.00122617
  1300   750      0.002061
  1300   775     0.0018032
  1300   800    0.00225779
  1300   825     0.0024884
  1300   850    0.00268769
  1300   875    0.00270476
  1300   925    0.00202936
  1300   975    0.00141916
  1300  1025   0.000893996
  1300  1075   0.000278092
  1325   550    0.00032902
  1325   575   0.000250063
  1325   600   0.000415132
  1325   625   0.000623782
  1325   650   0.000556356
  1325   675   0.000894896
  1325   700   0.000883235
  1325   725    0.00111768
  1325   750     0.0013449
  1325   775    0.00153915
  1325   800    0.00212044
  1325   825    0.00232924
  1325   850    0.00228101
  1350    75   1.49079e-05
  1350   125   1.53329e-05
  1350   175   7.66388e-06
  1350   225    3.8279e-05
  1350   275   6.08125e-05
  1350   325   3.81335e-05
  1350   375   7.39027e-05
  1350   425   0.000120184
  1350   475   8.97263e-05
  1350   525   0.000120892
  1350   550   0.000201164
  1350   575   0.000261623
  1350   600   0.000215325
  1350   625   0.000380244
  1350   650   0.000551973
  1350   675   0.000616653
  1350   700   0.000910623
  1350   725   0.000883685
  1350   750    0.00110312
  1350   775    0.00154284
  1350   800    0.00181997
  1350   825    0.00199705
  1350   850     0.0023251
  1350   875    0.00240901
  1350   925    0.00256236
  1350   975    0.00227154
  1350  1025    0.00155944
  1350  1075   0.000701792
  1350  1125   0.000328218
  1375   550   0.000175243
  1375   575   0.000233355
  1375   600   0.000314566
  1375   625   0.000341623
  1375   650   0.000373747
  1375   675   0.000493281
  1375   700   0.000542522
  1375   725   0.000812945
  1375   750    0.00101723
  1375   775     0.0010818
  1375   800    0.00115762
  1375   825    0.00156673
  1375   850    0.00200197
  1400    25    7.5351e-06
  1400    75   2.21564e-05
  1400   125   2.25357e-05
  1400   175     2.148e-05
  1400   225    2.2595e-05
  1400   275   3.72524e-05
  1400   325   2.97614e-05
  1400   375   2.97536e-05
  1400   425   5.93021e-05
  1400   475   8.63801e-05
  1400   525   0.000105911
  1400   550   0.000133013
  1400   575   0.000167672
  1400   600    0.00027179
  1400   625   0.000302392
  1400   650   0.000259675
  1400   675   0.000499534
  1400   700   0.000584224
  1400   725   0.000659304
  1400   750     0.0006862
  1400   775   0.000961516
  1400   800    0.00110685
  1400   825    0.00146299
  1400   850    0.00155294
  1400   875    0.00186104
  1400   925     0.0022263
  1400   975    0.00240668
  1400  1025    0.00200582
  1400  1075    0.00137546
  1400  1125   0.000801777
  1400  1175   0.000308429
*/
