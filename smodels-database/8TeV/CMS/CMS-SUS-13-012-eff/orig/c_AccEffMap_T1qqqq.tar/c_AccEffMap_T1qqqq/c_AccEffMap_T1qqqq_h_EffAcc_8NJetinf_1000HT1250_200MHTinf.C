{
//=========Macro generated from canvas: c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf/c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf
//=========  (Sat Feb 22 16:30:38 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf = new TCanvas("c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf", "c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf",115,312,500,500);
   c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf->SetFillColor(0);
   c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf->SetLogz();
   c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1000HT1250_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1000HT1250_200MHTinf","h_EffAcc_8NJetinf_1000HT1250_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(141,0.0004583315);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(143,0.0006529099);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(145,0.001049824);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(147,0.001285631);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(149,0.001568215);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(151,0.001875071);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(153,0.00193176);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(155,0.001999563);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(157,0.002109668);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(159,0.001948288);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(161,0.001882648);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(163,0.001657175);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(165,0.001466301);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(167,0.001236206);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(169,0.001088094);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(171,0.001033617);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(173,0.0009422905);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(175,0.0008735478);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(177,0.0005597327);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(179,0.0004981017);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(181,0.0004355763);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(265,0.0003269658);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(267,0.0005894197);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(269,0.0008779421);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(271,0.001330697);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(273,0.001668097);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(275,0.001891935);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(277,0.002008026);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(279,0.001930112);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(281,0.002006677);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(283,0.001968412);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(285,0.001820361);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(287,0.001816284);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(289,0.001581177);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(291,0.001152271);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(293,0.001131326);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(295,0.001133835);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(297,0.0008383273);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(299,0.0009187366);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(301,0.0007190443);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(303,0.0004599649);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(305,0.0004775178);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(389,0.0002871052);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(391,0.0004353898);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(393,0.0006844916);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(395,0.001167816);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(397,0.001310154);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(399,0.001777766);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(401,0.001914125);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(403,0.002071518);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(405,0.002029691);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(407,0.001753713);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(409,0.002001379);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(411,0.00187791);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(413,0.001541297);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(415,0.001271651);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(417,0.001371387);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(419,0.001051402);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(421,0.001051906);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(423,0.0009299721);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(425,0.0006416632);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(427,0.0006077501);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(429,0.0005427183);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(513,0.0002513222);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(515,0.00036044);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(517,0.0006248218);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(519,0.0009063483);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(521,0.001264662);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(523,0.001459498);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(525,0.001936218);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(527,0.001856914);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(529,0.002176931);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(531,0.002179121);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(533,0.002263333);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(535,0.001795252);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(537,0.001783957);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(539,0.001511932);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(541,0.001377582);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(543,0.001218152);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(545,0.001109222);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(547,0.0008201058);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(549,0.0008254076);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(551,0.0004875572);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(553,0.0005094593);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(637,0.0001173407);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(639,0.0002432639);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(641,0.0004147212);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(643,0.0006083441);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(645,0.001112751);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(647,0.001328103);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(649,0.001693598);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(651,0.001996589);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(653,0.002317328);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(655,0.002163342);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(657,0.002090862);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(659,0.002083386);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(661,0.001875451);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(663,0.001467966);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(665,0.001352912);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(667,0.001210621);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(669,0.001073674);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(671,0.001018194);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(673,0.0008592059);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(675,0.0006848528);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(677,0.000569138);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(761,7.17814e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(763,0.0001021407);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(765,0.0003444938);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(767,0.0004714387);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(769,0.0007832794);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(771,0.001064078);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(773,0.00123377);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(775,0.001624598);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(777,0.002097484);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(779,0.001886421);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(781,0.002022155);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(783,0.002197652);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(785,0.001945688);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(787,0.001746502);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(789,0.001521807);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(791,0.001323371);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(793,0.001235668);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(795,0.001085801);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(797,0.001020536);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(799,0.0005455529);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(801,0.0006880605);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(885,2.114368e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(887,0.0001040689);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(889,0.0001929859);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(891,0.000434343);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(893,0.0005135219);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(895,0.0009038523);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(897,0.001304723);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(899,0.001478042);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(901,0.001614131);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(903,0.001795033);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(905,0.0019257);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(907,0.002272081);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(909,0.002207591);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(911,0.001968553);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(913,0.001864116);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(915,0.001414841);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(917,0.001276835);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(919,0.0009547698);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(921,0.0009395167);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(923,0.0009044142);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(925,0.0008132936);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1009,7.070517e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1011,5.034011e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1013,7.453099e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1015,0.0002713604);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1017,0.0004372592);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1019,0.0006385079);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1021,0.001006395);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1023,0.001332458);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1025,0.001488524);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1027,0.001755507);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1029,0.00201477);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1031,0.00217899);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1033,0.002023468);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1035,0.001898885);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1037,0.001717288);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1039,0.001802977);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1041,0.001466307);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1043,0.001318631);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1045,0.001307038);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1047,0.001035695);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1049,0.000962276);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1137,4.37182e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1139,0.000107008);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1141,0.0001811987);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1143,0.0004117276);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1145,0.0006489888);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1147,0.0009174308);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1149,0.001493973);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1151,0.001629551);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1153,0.001810514);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1155,0.001916666);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1157,0.002087468);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1159,0.001950641);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1161,0.001771435);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1163,0.001799088);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1165,0.001419841);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1167,0.001284424);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1169,0.001242697);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1171,0.001091061);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1173,0.0008389274);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1263,1.467674e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1265,8.829023e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1267,0.0002511003);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1269,0.0004645359);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1271,0.0006535337);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1273,0.000973522);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1275,0.001487146);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1277,0.001523724);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1279,0.0018177);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1281,0.00188098);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1283,0.001918433);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1285,0.002036323);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1287,0.00179179);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1289,0.00152865);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1291,0.00138435);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1293,0.001380958);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1295,0.001205642);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1297,0.001042743);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1389,5.965938e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1391,0.0001041577);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1393,0.0002419262);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1395,0.0004872245);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1397,0.0007259222);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1399,0.0009687038);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1401,0.001261171);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1403,0.001499151);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1405,0.001720892);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1407,0.002013419);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1409,0.001953674);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1411,0.002036718);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1413,0.00190648);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1415,0.001802128);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1417,0.001530539);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1419,0.001383226);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1421,0.0009914517);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1513,7.341319e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1515,2.191767e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1517,0.0001017242);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1519,0.0003070181);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1521,0.0005889777);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1523,0.0006460079);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1525,0.001005109);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1527,0.00137496);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1529,0.001373258);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1531,0.001774444);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1533,0.00191616);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1535,0.001773175);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1537,0.002071185);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1539,0.001932428);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1541,0.001625433);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1543,0.001341188);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1545,0.001360472);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1639,7.312444e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1641,1.449869e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1643,7.24858e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1645,0.0001718124);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1647,0.0004031287);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1649,0.0006324728);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1651,0.0009049156);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1653,0.001182746);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1655,0.001337965);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1657,0.001720219);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1659,0.001737715);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1661,0.001933672);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1663,0.001884621);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1665,0.001612187);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1667,0.001729407);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1669,0.001381419);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1765,7.251579e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1767,2.972476e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1769,0.000100516);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1771,0.0002329646);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1773,0.0005368521);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1775,0.0007365797);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1777,0.00104105);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1783,0.001742393);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1785,0.001804049);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1787,0.001831489);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1789,0.001727356);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1791,0.001712224);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1793,0.001542602);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1845,0.001656624);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1846,0.001553968);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1847,0.001974487);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1848,0.001663048);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1849,0.001765604);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1850,0.001796558);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1851,0.001948163);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1852,0.00203403);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1853,0.001760059);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1854,0.00168751);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1855,0.001562284);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1891,7.246013e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1893,2.863744e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1895,9.960541e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1897,0.0001890453);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1899,0.0003735418);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1901,0.0006034899);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1907,0.001369905);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1908,0.001371248);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1909,0.001879456);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1910,0.001681503);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1911,0.001553879);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1912,0.001787443);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1913,0.001809937);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1914,0.001615257);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1915,0.001772563);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1916,0.001795709);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1917,0.001677084);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1969,0.001323959);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1970,0.001317283);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1971,0.001546393);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1972,0.001488975);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1973,0.001548916);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1974,0.001803555);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1975,0.001699872);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1976,0.001791123);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1977,0.001756124);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1978,0.001785176);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1979,0.001603034);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2019,2.820923e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2021,0.000101013);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2023,0.0002188944);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2025,0.0004682375);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2031,0.001177804);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2032,0.001425851);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2033,0.001559487);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2034,0.001647748);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2035,0.001560598);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2036,0.001560632);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2037,0.001548525);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2038,0.001809149);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2039,0.001910854);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2040,0.001782385);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2041,0.001767213);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2093,0.001059006);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2094,0.001164017);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2095,0.00143578);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2096,0.001187536);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2097,0.001691671);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2098,0.001484633);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2099,0.001782763);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2100,0.00151575);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2101,0.001606491);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2102,0.001781944);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2103,0.001659798);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2145,2.092747e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2147,0.0001112869);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2149,0.0001984543);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2155,0.0008387195);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2156,0.001019361);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2157,0.00113219);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2158,0.001069006);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2159,0.001404286);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2160,0.001454015);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2161,0.001485889);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2162,0.00158559);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2163,0.001538299);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2164,0.001684065);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2165,0.001655274);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2217,0.0007174814);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2218,0.0009327632);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2219,0.001030925);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2220,0.001219697);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2221,0.001327481);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2222,0.001290955);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2223,0.001454162);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2224,0.00152086);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2225,0.001540958);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2226,0.001557926);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2227,0.001779934);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2271,4.826182e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2273,6.808345e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2279,0.000640411);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2280,0.0007046685);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2281,0.0007953066);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2282,0.0009477273);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2283,0.001034431);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2284,0.001145693);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2285,0.001381636);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2286,0.001453352);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2287,0.001434731);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2288,0.001759707);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2289,0.001625729);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2341,0.0004760078);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2342,0.0005248065);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2343,0.0006111562);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2344,0.0007728455);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2345,0.0009028863);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2346,0.001050337);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2347,0.001168437);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2348,0.001556172);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2349,0.001144885);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2350,0.001428286);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2351,0.001530885);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2395,6.86315e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2397,1.355707e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2403,0.0003396921);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2404,0.0004565683);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2405,0.0006073674);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2406,0.0006669782);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2407,0.0008651493);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2408,0.0008711548);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2409,0.001076814);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2410,0.00120002);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2411,0.001348929);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2412,0.001428102);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2413,0.001442007);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2465,0.0002441286);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2466,0.0003983124);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2467,0.0003778277);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2468,0.0005869573);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2469,0.0006063313);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2470,0.0008310286);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2471,0.0008532314);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2472,0.0009449702);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2473,0.001282926);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2474,0.001272403);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2475,0.001396254);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2527,0.0002238314);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2528,0.0002595169);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2529,0.0003880604);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2530,0.0004707933);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2531,0.0006190963);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2532,0.0006366494);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2533,0.0007731216);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2534,0.001117175);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2535,0.00102906);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2536,0.00111141);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2537,0.001160882);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2589,9.733288e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2590,0.0002618175);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2591,0.0002995689);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2592,0.0004013469);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2593,0.0003959615);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2594,0.0005162893);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2595,0.000546474);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2596,0.0009560965);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2597,0.0008307818);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2598,0.001023379);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2599,0.001087868);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2651,8.432906e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2653,0.0002215318);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2655,0.0002806821);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2657,0.0005208354);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2659,0.0007575051);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2661,0.0009383599);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2775,3.887678e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2777,0.0001104723);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2779,0.0002093239);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2781,0.0004426574);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2783,0.0005605448);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2785,0.0006839476);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2901,1.280513e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2903,3.239839e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2905,0.0001703656);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2907,0.0002908851);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2909,0.0004835178);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3027,1.960605e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3029,5.151056e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3031,0.0001613653);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3033,0.0003028768);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3155,7.434576e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3157,9.689198e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3279,6.317923e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3281,2.481743e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3405,6.009444e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(141,6.382811e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(143,7.151271e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(145,9.107934e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(147,0.000103066);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(149,0.0001122424);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(151,0.0001250726);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(153,0.0001257906);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(155,0.000127854);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(157,0.0001326808);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(159,0.0001250613);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(161,0.0001223311);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(163,0.0001148412);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(165,0.0001076452);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(167,9.902113e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(169,9.19491e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(171,8.992351e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(173,8.739996e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(175,8.359655e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(177,6.437769e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(179,6.445502e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(181,6.059792e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(265,5.000202e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(267,6.927628e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(269,8.48667e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(271,0.0001034105);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(273,0.0001164961);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(275,0.0001239778);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(277,0.0001275941);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(279,0.0001542996);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(281,0.0001274916);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(283,0.0001265599);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(285,0.0001210617);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(287,0.000124927);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(289,0.0001345681);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(291,9.411935e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(293,9.392238e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(295,9.32122e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(297,8.094982e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(299,9.40471e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(301,7.773411e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(303,6.053657e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(305,5.850308e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(389,4.672628e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(391,5.732954e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(393,7.452189e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(395,9.641107e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(397,0.0001024272);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(399,0.0001199004);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(401,0.0001246814);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(403,0.0001293361);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(405,0.0001284174);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(407,0.0001190456);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(409,0.000126405);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(411,0.000122757);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(413,0.0001102627);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(415,0.000117517);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(417,0.0001031547);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(419,8.950757e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(421,8.921724e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(423,8.409063e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(425,8.109233e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(427,7.134676e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(429,6.239954e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(513,4.318359e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(515,5.156354e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(517,7.011876e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(519,8.521726e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(521,0.0001014023);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(523,0.0001089657);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(525,0.0001258294);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(527,0.0001249346);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(529,0.0001321491);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(531,0.000131345);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(533,0.0001341946);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(535,0.0001196668);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(537,0.0001196382);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(539,0.0001357392);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(541,0.0001030787);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(543,9.605208e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(545,9.686463e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(547,7.842709e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(549,8.777201e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(551,5.973205e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(553,6.380581e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(637,2.939042e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(639,4.240419e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(641,5.712291e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(643,7.000173e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(645,9.411477e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(647,0.0001026205);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(649,0.0001160404);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(651,0.000131715);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(653,0.0001484785);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(655,0.0001308608);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(657,0.0001313174);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(659,0.0001284922);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(661,0.0001215943);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(663,0.0001066287);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(665,0.0001021069);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(667,9.606761e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(669,8.983736e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(671,8.755433e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(673,7.998776e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(675,7.49111e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(677,6.380049e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(761,2.271581e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(763,2.73309e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(765,5.149593e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(767,6.058891e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(769,7.782137e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(771,9.091998e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(773,9.827655e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(775,0.0001140051);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(777,0.0001291947);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(779,0.0001218303);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(781,0.000126487);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(783,0.0001307993);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(785,0.0001240851);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(787,0.0001177336);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(789,0.0001083025);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(791,0.0001001601);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(793,0.0001026601);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(795,8.95681e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(797,8.627605e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(799,7.061425e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(801,8.244509e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(885,1.220747e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(887,2.781533e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(889,3.791088e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(891,5.768905e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(893,6.29114e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(895,8.351835e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(897,0.0001026247);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(899,0.0001079691);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(901,0.0001124422);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(903,0.0001186978);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(905,0.0001223789);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(907,0.00013387);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(909,0.0001311332);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(911,0.0001230866);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(913,0.0001195619);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(915,0.0001406869);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(917,9.749436e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(919,8.468999e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(921,8.389168e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(923,8.085011e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(925,9.122695e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1009,7.070547e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1011,1.902735e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1013,2.363281e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1015,4.531459e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1017,5.753609e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1019,6.9852e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1021,8.822203e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1023,0.0001020406);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1025,0.0001073842);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1027,0.0001168605);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1029,0.0001248327);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1031,0.0001294871);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1033,0.0001288569);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1035,0.0001208881);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1037,0.0001144759);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1039,0.0001181024);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1041,0.0001068451);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1043,9.869993e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1045,9.828683e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1047,8.69212e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1049,0.0001058794);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1137,1.784835e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1139,2.8677e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1141,3.703622e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1143,5.620063e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1145,7.062926e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1147,8.441414e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1149,0.000107716);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1151,0.0001110895);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1153,0.0001181904);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1155,0.0001208296);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1157,0.0001260144);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1159,0.0001210797);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1161,0.000115811);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1163,0.0001157028);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1165,0.0001028454);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1167,0.0001006796);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1169,9.483434e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1171,8.877853e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1173,8.921312e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1263,1.037812e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1265,2.548855e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1267,4.309626e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1269,5.911291e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1271,7.027329e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1273,8.604759e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1275,0.0001058818);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1277,0.0001079797);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1279,0.0001169338);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1281,0.0001193046);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1283,0.0001202503);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1285,0.0001226824);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1287,0.000115229);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1289,0.0001067199);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1291,0.0001127248);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1293,0.0001010647);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1295,9.389098e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1297,8.975791e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1389,2.111099e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1391,2.786473e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1393,4.290569e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1395,6.111313e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1397,7.271902e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1399,8.492945e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1401,9.7129e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1403,0.0001059332);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1405,0.0001130179);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1407,0.0001259221);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1409,0.0001201436);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1411,0.0001220602);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1413,0.0001203819);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1415,0.0001209366);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1417,0.0001092022);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1419,9.971809e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1421,8.524869e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1513,7.341351e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1515,1.265434e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1517,2.71886e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1519,4.743092e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1521,6.647119e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1523,6.865214e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1525,8.655376e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1527,0.0001009878);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1529,0.0001218507);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1531,0.0001136307);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1533,0.0001189315);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1535,0.0001133766);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1537,0.0001230454);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1539,0.000119248);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1541,0.0001072004);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1543,0.0001061025);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1545,0.0001251311);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1639,7.312476e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1641,1.025221e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1643,2.292302e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1645,3.508551e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1647,5.396732e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1649,6.796761e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1651,8.15636e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1653,9.900175e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1655,9.825833e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1657,0.0001134539);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1659,0.000114604);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1661,0.0001175625);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1663,0.0001171774);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1665,0.0001079022);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1667,0.0001100778);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1669,0.0001039505);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1765,7.251611e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1767,1.48831e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1769,2.687932e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1771,4.128778e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1773,6.165191e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1775,7.279405e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1777,8.737155e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1783,0.000114152);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1785,0.0001157842);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1787,0.0001141148);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1789,0.0001117583);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1791,0.0001101173);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1793,0.0001037322);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1845,0.0001081014);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1846,0.0001042853);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1847,0.0001251941);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1848,0.0001085256);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1849,0.0001114948);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1850,0.0001157944);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1851,0.0001225667);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1852,0.000137748);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1853,0.0001219957);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1854,0.0001081105);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1855,0.0001055321);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1891,7.246044e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1893,1.431897e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1895,2.66358e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1897,3.640504e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1899,5.143034e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1901,7.336202e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1907,9.772749e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1908,9.814842e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1909,0.0001166335);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1910,0.0001094735);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1911,0.0001056883);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1912,0.0001118087);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1913,0.0001121472);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1914,0.0001086529);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1915,0.0001146977);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1916,0.0001112222);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1917,0.0001078273);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1969,9.591669e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1970,9.700259e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1971,0.0001038022);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1972,0.0001073495);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1973,0.0001058716);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1974,0.0001132485);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1975,0.0001095276);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1976,0.0001116034);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1977,0.0001129374);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1978,0.0001107874);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1979,0.0001057254);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2019,1.410485e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2021,2.703855e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2023,3.941692e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2025,5.729976e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2031,9.81866e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2032,9.972936e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2033,0.0001042135);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2034,0.0001071222);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2035,0.0001068901);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2036,0.0001036309);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2037,0.0001046286);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2038,0.0001147314);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2039,0.0001216243);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2040,0.0001108113);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2041,0.0001242921);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2093,8.981869e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2094,9.51237e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2095,9.951078e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2096,9.038538e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2097,0.0001110884);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2098,0.0001012708);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2099,0.0001130562);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2100,0.0001017188);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2101,0.0001044009);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2102,0.0001127656);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2103,0.0001062885);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2145,1.208263e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2147,2.78236e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2149,3.687458e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2155,7.590032e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2156,8.446057e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2157,8.851234e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2158,8.537696e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2159,9.924824e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2160,0.000105093);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2161,0.0001018029);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2162,0.0001059782);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2163,0.0001034492);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2164,0.000117577);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2165,0.0001193899);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2217,7.025139e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2218,8.02719e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2219,8.365348e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2220,9.073875e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2221,9.472061e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2222,9.944017e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2223,0.0001020064);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2224,0.000101419);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2225,0.0001041124);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2226,0.0001245256);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2227,0.0001096544);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2271,1.824179e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2273,2.153076e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2279,6.586974e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2280,7.54079e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2281,7.377286e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2282,7.980106e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2283,8.337716e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2284,9.123238e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2285,9.789741e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2286,9.887313e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2287,9.759952e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2288,0.0001090122);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2289,0.0001076443);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2341,5.66403e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2342,6.000908e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2343,6.389595e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2344,7.198315e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2345,8.044311e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2346,8.527925e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2347,9.051082e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2348,0.0001041954);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2349,8.870588e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2350,0.0001017197);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2351,0.0001007492);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2395,6.863179e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2397,9.586375e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2403,4.767969e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2404,5.509531e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2405,6.346202e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2406,6.723246e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2407,7.738965e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2408,7.663544e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2409,8.437827e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2410,9.034741e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2411,9.678802e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2412,9.736483e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2413,9.856603e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2465,4.019746e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2466,5.1053e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2467,4.969688e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2468,6.312321e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2469,6.340597e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2470,7.64033e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2471,7.478755e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2472,9.395654e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2473,9.229519e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2474,9.174165e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2475,9.543438e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2527,3.84155e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2528,4.107048e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2529,5.062216e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2530,5.560391e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2531,6.403644e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2532,6.488153e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2533,7.075901e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2534,9.031966e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2535,8.35743e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2536,8.507893e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2537,9.216521e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2589,2.513272e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2590,4.144073e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2591,4.423416e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2592,5.150333e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2593,5.123536e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2594,6.016701e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2595,5.942618e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2596,7.913605e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2597,7.340245e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2598,8.222111e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2599,8.528855e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2651,2.338987e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2653,3.806398e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2655,4.235387e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2657,5.762487e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2659,6.965515e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2661,9.878558e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2775,1.587175e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2777,2.682942e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2779,3.645916e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2781,5.343771e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2783,5.954576e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2785,6.828801e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2901,9.054666e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2903,1.450651e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2905,3.282505e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2907,4.296571e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2909,5.486793e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3027,1.133779e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3029,1.82529e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3031,3.367067e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3033,4.333786e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3155,2.146274e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3157,2.423532e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3279,6.317947e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3281,1.242598e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3405,6.009466e-06);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetEntries(66204.81);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->Draw("colz");
   c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf->Modified();
   c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf->cd();
   c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf->SetSelected(c_AccEffMap_T1qqqq_8NJetinf_1000HT1250_200MHTinf);
}
/*
Topology ~g ~g ; ~g ->q+qbar+LSP

mGluino(GeV) mLSP(GeV) AccXEff
   400    25   0.000458332
   400    75   0.000326966
   400   125   0.000287105
   400   175   0.000251322
   400   225   0.000117341
   400   275   7.17814e-05
   400   325   2.11437e-05
   400   375   7.07052e-06
   450    25    0.00065291
   450    75    0.00058942
   450   125    0.00043539
   450   175    0.00036044
   450   225   0.000243264
   450   275   0.000102141
   450   325   0.000104069
   450   375   5.03401e-05
   500    25    0.00104982
   500    75   0.000877942
   500   125   0.000684492
   500   175   0.000624822
   500   225   0.000414721
   500   275   0.000344494
   500   325   0.000192986
   500   375    7.4531e-05
   500   425   4.37182e-05
   550    25    0.00128563
   550    75     0.0013307
   550   125    0.00116782
   550   175   0.000906348
   550   225   0.000608344
   550   275   0.000471439
   550   325   0.000434343
   550   375    0.00027136
   550   425   0.000107008
   550   475   1.46767e-05
   600    25    0.00156821
   600    75     0.0016681
   600   125    0.00131015
   600   175    0.00126466
   600   225    0.00111275
   600   275   0.000783279
   600   325   0.000513522
   600   375   0.000437259
   600   425   0.000181199
   600   475   8.82902e-05
   600   525   5.96594e-05
   600   575   7.34132e-06
   650    25    0.00187507
   650    75    0.00189193
   650   125    0.00177777
   650   175     0.0014595
   650   225     0.0013281
   650   275    0.00106408
   650   325   0.000903852
   650   375   0.000638508
   650   425   0.000411728
   650   475     0.0002511
   650   525   0.000104158
   650   575   2.19177e-05
   650   625   7.31244e-06
   700    25    0.00193176
   700    75    0.00200803
   700   125    0.00191412
   700   175    0.00193622
   700   225     0.0016936
   700   275    0.00123377
   700   325    0.00130472
   700   375    0.00100639
   700   425   0.000648989
   700   475   0.000464536
   700   525   0.000241926
   700   575   0.000101724
   700   625   1.44987e-05
   700   675   7.25158e-06
   750    25    0.00199956
   750    75    0.00193011
   750   125    0.00207152
   750   175    0.00185691
   750   225    0.00199659
   750   275     0.0016246
   750   325    0.00147804
   750   375    0.00133246
   750   425   0.000917431
   750   475   0.000653534
   750   525   0.000487224
   750   575   0.000307018
   750   625   7.24858e-05
   750   675   2.97248e-05
   750   725   7.24601e-06
   800    25    0.00210967
   800    75    0.00200668
   800   125    0.00202969
   800   175    0.00217693
   800   225    0.00231733
   800   275    0.00209748
   800   325    0.00161413
   800   375    0.00148852
   800   425    0.00149397
   800   475   0.000973522
   800   525   0.000725922
   800   575   0.000588978
   800   625   0.000171812
   800   675   0.000100516
   800   725   2.86374e-05
   850    25    0.00194829
   850    75    0.00196841
   850   125    0.00175371
   850   175    0.00217912
   850   225    0.00216334
   850   275    0.00188642
   850   325    0.00179503
   850   375    0.00175551
   850   425    0.00162955
   850   475    0.00148715
   850   525   0.000968704
   850   575   0.000646008
   850   625   0.000403129
   850   675   0.000232965
   850   725   9.96054e-05
   850   775   2.82092e-05
   900    25    0.00188265
   900    75    0.00182036
   900   125    0.00200138
   900   175    0.00226333
   900   225    0.00209086
   900   275    0.00202215
   900   325     0.0019257
   900   375    0.00201477
   900   425    0.00181051
   900   475    0.00152372
   900   525    0.00126117
   900   575    0.00100511
   900   625   0.000632473
   900   675   0.000536852
   900   725   0.000189045
   900   775   0.000101013
   900   825   2.09275e-05
   950    25    0.00165717
   950    75    0.00181628
   950   125    0.00187791
   950   175    0.00179525
   950   225    0.00208339
   950   275    0.00219765
   950   325    0.00227208
   950   375    0.00217899
   950   425    0.00191667
   950   475     0.0018177
   950   525    0.00149915
   950   575    0.00137496
   950   625   0.000904916
   950   675    0.00073658
   950   725   0.000373542
   950   775   0.000218894
   950   825   0.000111287
   950   875   4.82618e-05
   950   925   6.86315e-06
  1000    25     0.0014663
  1000    75    0.00158118
  1000   125     0.0015413
  1000   175    0.00178396
  1000   225    0.00187545
  1000   275    0.00194569
  1000   325    0.00220759
  1000   375    0.00202347
  1000   425    0.00208747
  1000   475    0.00188098
  1000   525    0.00172089
  1000   575    0.00137326
  1000   625    0.00118275
  1000   675    0.00104105
  1000   725    0.00060349
  1000   775   0.000468238
  1000   825   0.000198454
  1000   875   6.80835e-05
  1000   925   1.35571e-05
  1050    25    0.00123621
  1050    75    0.00115227
  1050   125    0.00127165
  1050   175    0.00151193
  1050   225    0.00146797
  1050   275     0.0017465
  1050   325    0.00196855
  1050   375    0.00189888
  1050   425    0.00195064
  1050   475    0.00191843
  1050   525    0.00201342
  1050   575    0.00177444
  1050   625    0.00133797
  1100    25    0.00108809
  1100    75    0.00113133
  1100   125    0.00137139
  1100   175    0.00137758
  1100   225    0.00135291
  1100   275    0.00152181
  1100   325    0.00186412
  1100   375    0.00171729
  1100   425    0.00177144
  1100   475    0.00203632
  1100   525    0.00195367
  1100   575    0.00191616
  1100   625    0.00172022
  1150    25    0.00103362
  1150    75    0.00113383
  1150   125     0.0010514
  1150   175    0.00121815
  1150   225    0.00121062
  1150   275    0.00132337
  1150   325    0.00141484
  1150   375    0.00180298
  1150   425    0.00179909
  1150   475    0.00179179
  1150   525    0.00203672
  1150   575    0.00177318
  1150   625    0.00173771
  1150   675    0.00174239
  1150   700    0.00165662
  1150   725     0.0013699
  1150   750    0.00132396
  1150   775     0.0011778
  1150   800    0.00105901
  1150   825   0.000838719
  1150   850   0.000717481
  1150   875   0.000640411
  1150   900   0.000476008
  1150   925   0.000339692
  1150   950   0.000244129
  1150   975   0.000223831
  1150  1000   9.73329e-05
  1150  1025   8.43291e-05
  1150  1075   3.88768e-05
  1175   700    0.00155397
  1175   725    0.00137125
  1175   750    0.00131728
  1175   775    0.00142585
  1175   800    0.00116402
  1175   825    0.00101936
  1175   850   0.000932763
  1175   875   0.000704669
  1175   900   0.000524806
  1175   925   0.000456568
  1175   950   0.000398312
  1175   975   0.000259517
  1175  1000   0.000261817
  1200    25    0.00094229
  1200    75   0.000838327
  1200   125    0.00105191
  1200   175    0.00110922
  1200   225    0.00107367
  1200   275    0.00123567
  1200   325    0.00127683
  1200   375    0.00146631
  1200   425    0.00141984
  1200   475    0.00152865
  1200   525    0.00190648
  1200   575    0.00207119
  1200   625    0.00193367
  1200   675    0.00180405
  1200   700    0.00197449
  1200   725    0.00187946
  1200   750    0.00154639
  1200   775    0.00155949
  1200   800    0.00143578
  1200   825    0.00113219
  1200   850    0.00103092
  1200   875   0.000795307
  1200   900   0.000611156
  1200   925   0.000607367
  1200   950   0.000377828
  1200   975    0.00038806
  1200  1000   0.000299569
  1200  1025   0.000221532
  1200  1075   0.000110472
  1200  1125   1.28051e-05
  1225   700    0.00166305
  1225   725     0.0016815
  1225   750    0.00148898
  1225   775    0.00164775
  1225   800    0.00118754
  1225   825    0.00106901
  1225   850     0.0012197
  1225   875   0.000947727
  1225   900   0.000772846
  1225   925   0.000666978
  1225   950   0.000586957
  1225   975   0.000470793
  1225  1000   0.000401347
  1250    25   0.000873548
  1250    75   0.000918737
  1250   125   0.000929972
  1250   175   0.000820106
  1250   225    0.00101819
  1250   275     0.0010858
  1250   325    0.00095477
  1250   375    0.00131863
  1250   425    0.00128442
  1250   475    0.00138435
  1250   525    0.00180213
  1250   575    0.00193243
  1250   625    0.00188462
  1250   675    0.00183149
  1250   700     0.0017656
  1250   725    0.00155388
  1250   750    0.00154892
  1250   775     0.0015606
  1250   800    0.00169167
  1250   825    0.00140429
  1250   850    0.00132748
  1250   875    0.00103443
  1250   900   0.000902886
  1250   925   0.000865149
  1250   950   0.000606331
  1250   975   0.000619096
  1250  1000   0.000395962
  1250  1025   0.000280682
  1250  1075   0.000209324
  1250  1125   3.23984e-05
  1250  1175   1.96061e-05
  1275   700    0.00179656
  1275   725    0.00178744
  1275   750    0.00180356
  1275   775    0.00156063
  1275   800    0.00148463
  1275   825    0.00145401
  1275   850    0.00129095
  1275   875    0.00114569
  1275   900    0.00105034
  1275   925   0.000871155
  1275   950   0.000831029
  1275   975   0.000636649
  1275  1000   0.000516289
  1300    25   0.000559733
  1300    75   0.000719044
  1300   125   0.000641663
  1300   175   0.000825408
  1300   225   0.000859206
  1300   275    0.00102054
  1300   325   0.000939517
  1300   375    0.00130704
  1300   425     0.0012427
  1300   475    0.00138096
  1300   525    0.00153054
  1300   575    0.00162543
  1300   625    0.00161219
  1300   675    0.00172736
  1300   700    0.00194816
  1300   725    0.00180994
  1300   750    0.00169987
  1300   775    0.00154852
  1300   800    0.00178276
  1300   825    0.00148589
  1300   850    0.00145416
  1300   875    0.00138164
  1300   900    0.00116844
  1300   925    0.00107681
  1300   950   0.000853231
  1300   975   0.000773122
  1300  1000   0.000546474
  1300  1025   0.000520835
  1300  1075   0.000442657
  1300  1125   0.000170366
  1300  1175   5.15106e-05
  1325   700    0.00203403
  1325   725    0.00161526
  1325   750    0.00179112
  1325   775    0.00180915
  1325   800    0.00151575
  1325   825    0.00158559
  1325   850    0.00152086
  1325   875    0.00145335
  1325   900    0.00155617
  1325   925    0.00120002
  1325   950    0.00094497
  1325   975    0.00111717
  1325  1000   0.000956096
  1350    25   0.000498102
  1350    75   0.000459965
  1350   125    0.00060775
  1350   175   0.000487557
  1350   225   0.000684853
  1350   275   0.000545553
  1350   325   0.000904414
  1350   375     0.0010357
  1350   425    0.00109106
  1350   475    0.00120564
  1350   525    0.00138323
  1350   575    0.00134119
  1350   625    0.00172941
  1350   675    0.00171222
  1350   700    0.00176006
  1350   725    0.00177256
  1350   750    0.00175612
  1350   775    0.00191085
  1350   800    0.00160649
  1350   825     0.0015383
  1350   850    0.00154096
  1350   875    0.00143473
  1350   900    0.00114489
  1350   925    0.00134893
  1350   950    0.00128293
  1350   975    0.00102906
  1350  1000   0.000830782
  1350  1025   0.000757505
  1350  1075   0.000560545
  1350  1125   0.000290885
  1350  1175   0.000161365
  1350  1225   7.43458e-05
  1350  1275   6.31792e-06
  1375   700    0.00168751
  1375   725    0.00179571
  1375   750    0.00178518
  1375   775    0.00178239
  1375   800    0.00178194
  1375   825    0.00168406
  1375   850    0.00155793
  1375   875    0.00175971
  1375   900    0.00142829
  1375   925     0.0014281
  1375   950     0.0012724
  1375   975    0.00111141
  1375  1000    0.00102338
  1400    25   0.000435576
  1400    75   0.000477518
  1400   125   0.000542718
  1400   175   0.000509459
  1400   225   0.000569138
  1400   275   0.000688061
  1400   325   0.000813294
  1400   375   0.000962276
  1400   425   0.000838927
  1400   475    0.00104274
  1400   525   0.000991452
  1400   575    0.00136047
  1400   625    0.00138142
  1400   675     0.0015426
  1400   700    0.00156228
  1400   725    0.00167708
  1400   750    0.00160303
  1400   775    0.00176721
  1400   800     0.0016598
  1400   825    0.00165527
  1400   850    0.00177993
  1400   875    0.00162573
  1400   900    0.00153089
  1400   925    0.00144201
  1400   950    0.00139625
  1400   975    0.00116088
  1400  1000    0.00108787
  1400  1025    0.00093836
  1400  1075   0.000683948
  1400  1125   0.000483518
  1400  1175   0.000302877
  1400  1225    9.6892e-05
  1400  1275   2.48174e-05
  1400  1325   6.00944e-06
*/
