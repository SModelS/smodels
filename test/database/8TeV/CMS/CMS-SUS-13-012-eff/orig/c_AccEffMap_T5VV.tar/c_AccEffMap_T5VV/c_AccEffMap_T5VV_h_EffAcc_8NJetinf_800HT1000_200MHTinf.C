{
//=========Macro generated from canvas: c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf/c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf
//=========  (Sat Feb 22 16:32:53 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf = new TCanvas("c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf", "c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf",110,288,500,500);
   c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf->SetFillColor(0);
   c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf->SetLogz();
   c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_800HT1000_200MHTinf = new TH2D("h_EffAcc_8NJetinf_800HT1000_200MHTinf","h_EffAcc_8NJetinf_800HT1000_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(141,0.0008377862);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(143,0.001424579);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(145,0.002450454);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(147,0.004546134);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(149,0.005198843);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(151,0.006386012);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(153,0.006962317);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(155,0.006641473);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(157,0.006082561);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(159,0.005550215);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(161,0.00443827);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(163,0.00354204);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(165,0.002578522);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(167,0.002114312);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(169,0.00172185);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(171,0.001281805);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(173,0.0009219189);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(175,0.0006046185);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(177,0.0004427301);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(179,0.0003098719);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(181,0.0002641053);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(265,0.0005103503);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(267,0.001216538);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(269,0.002383658);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(271,0.004069915);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(273,0.005024151);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(275,0.006705737);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(277,0.007246462);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(279,0.007474627);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(281,0.007239057);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(283,0.005492647);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(285,0.004749425);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(287,0.004113775);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(289,0.002982882);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(291,0.00242019);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(293,0.001815381);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(295,0.001396749);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(297,0.0009834592);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(299,0.000721958);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(301,0.0004955151);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(303,0.0003761382);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(305,0.000262873);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(389,0.000401341);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(391,0.000965786);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(393,0.001843916);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(395,0.003313331);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(397,0.004704397);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(399,0.006175077);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(401,0.007535633);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(403,0.007791809);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(405,0.007645106);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(407,0.006616593);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(409,0.00561329);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(411,0.004593412);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(413,0.003716629);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(415,0.00280773);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(417,0.00219934);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(419,0.001729338);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(421,0.0009608531);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(423,0.0009331548);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(425,0.0005584796);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(427,0.0004519366);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(429,0.0002922126);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(513,0.0002222731);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(515,0.0005040791);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(517,0.00120529);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(519,0.002269529);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(521,0.00402066);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(523,0.005569214);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(525,0.007162721);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(527,0.007418913);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(529,0.007439736);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(531,0.007421663);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(533,0.00660122);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(535,0.005366556);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(537,0.004133192);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(539,0.003040121);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(541,0.002467456);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(543,0.001902065);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(545,0.001243582);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(547,0.0009775508);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(549,0.0006088331);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(551,0.0006169424);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(553,0.0003523469);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(639,0.0002627635);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(641,0.0005665577);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(643,0.00161114);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(645,0.002499329);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(647,0.004264176);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(649,0.00573755);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(651,0.007794828);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(653,0.008154883);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(655,0.007854648);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(657,0.007338911);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(659,0.006167756);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(661,0.004986192);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(663,0.004313705);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(665,0.00301456);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(667,0.002047212);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(669,0.001856797);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(671,0.001301375);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(673,0.0008792821);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(675,0.0006836623);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(677,0.0005407744);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(765,0.0003805493);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(767,0.0008522576);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(769,0.001557955);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(771,0.002772294);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(773,0.004382778);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(775,0.006280505);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(777,0.008146533);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(779,0.008230463);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(781,0.008338404);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(783,0.007265493);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(785,0.006027606);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(787,0.004917109);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(789,0.003822286);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(791,0.002848047);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(793,0.002228593);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(795,0.001664194);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(797,0.001067265);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(799,0.000845638);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(801,0.0006046932);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(891,0.0004843344);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(893,0.0009646327);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(895,0.00178178);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(897,0.003595468);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(899,0.004778189);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(901,0.006624129);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(903,0.008105424);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(905,0.008511309);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(907,0.008083967);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(909,0.007176658);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(911,0.006121488);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(913,0.004653429);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(915,0.003326571);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(917,0.002456041);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(919,0.001876861);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(921,0.001472655);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(923,0.001247347);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(925,0.0006566347);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1017,0.0004678782);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1019,0.0009884885);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1021,0.001994074);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1023,0.003711531);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1025,0.004981512);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1027,0.00655772);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1029,0.008090208);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1031,0.008384397);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1033,0.00810304);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1035,0.006867485);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1037,0.005810448);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1039,0.004461137);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1041,0.003442896);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1043,0.002379142);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1045,0.00187704);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1047,0.001445675);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1049,0.0009204795);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1143,0.0004995963);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1145,0.00119823);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1147,0.002099756);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1149,0.003504328);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1151,0.005232557);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1153,0.00738095);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1155,0.008369425);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1157,0.008741802);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1159,0.008315107);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1161,0.006414367);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1163,0.005763485);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1165,0.004199153);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1167,0.003072977);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1169,0.002241126);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1171,0.001836162);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1173,0.001357942);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1269,0.000607402);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1271,0.001032332);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1273,0.002084388);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1275,0.0035719);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1277,0.005146452);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1279,0.007345714);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1281,0.008786629);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1283,0.008503095);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1285,0.008008539);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1287,0.007016701);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1289,0.005399512);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1291,0.004125892);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1293,0.003088462);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1295,0.002385575);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1297,0.00156524);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1395,0.0006144344);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1397,0.001197744);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1399,0.002353335);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1401,0.003789134);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1403,0.005456762);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1405,0.007221308);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1407,0.008846034);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1409,0.008390894);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1411,0.008279574);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1413,0.006817438);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1415,0.005105929);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1417,0.003810521);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1419,0.002907152);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1421,0.001962983);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1473,0.008816451);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1474,0.007851631);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1475,0.007137227);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1476,0.006977592);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1477,0.006025206);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1478,0.005341455);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1479,0.00437899);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1480,0.003797125);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1481,0.003370511);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1482,0.002783053);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1483,0.002452738);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1521,0.0006439816);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1523,0.001334099);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1525,0.002278097);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1527,0.003700669);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1529,0.005751876);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1531,0.007310795);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1533,0.008317497);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1535,0.008681749);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1536,0.008831404);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1537,0.007957066);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1538,0.00724449);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1539,0.006306176);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1540,0.005894493);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1541,0.005113651);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1542,0.004206488);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1543,0.003861846);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1544,0.003559711);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1545,0.003090519);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1597,0.008384392);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1598,0.008631989);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1599,0.008739239);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1600,0.008136553);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1601,0.006635388);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1602,0.006726119);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1603,0.006128887);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1604,0.004852076);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1605,0.004599513);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1606,0.003812994);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1607,0.003453877);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1647,0.0004671787);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1649,0.001210553);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1651,0.00223199);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1653,0.003982238);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1655,0.005683633);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1657,0.007456093);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1659,0.00823531);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1660,0.008777985);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1661,0.008358461);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1662,0.008404973);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1663,0.007791459);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1664,0.007415056);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1665,0.006975756);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1666,0.005782351);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1667,0.004786935);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1668,0.004461952);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1669,0.003551579);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1721,0.007683618);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1722,0.008786843);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1723,0.008762844);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1724,0.008582601);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1725,0.008215502);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1726,0.008083344);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1727,0.007210375);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1728,0.006112105);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1729,0.005189028);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1730,0.005144306);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1731,0.004191275);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1773,0.0006287183);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1775,0.001160069);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1777,0.002411472);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1779,0.003984963);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1781,0.005374414);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1783,0.00748679);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1784,0.007557926);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1785,0.00843774);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1786,0.009028535);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1787,0.008833884);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1788,0.008506673);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1789,0.007783415);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1790,0.007331353);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1791,0.006717011);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1792,0.005648619);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1793,0.005030606);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1845,0.006603099);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1846,0.007369669);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1847,0.007658252);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1848,0.008092976);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1849,0.009386061);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1850,0.00831991);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1851,0.007801424);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1852,0.007689412);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1853,0.007119966);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1854,0.006805223);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1855,0.005587216);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1899,0.000604169);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1901,0.001306801);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1903,0.002006475);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1905,0.003809367);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1907,0.005471959);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1908,0.006705314);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1909,0.007314101);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1910,0.008238394);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1911,0.008763947);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1912,0.00868563);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1913,0.008856538);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1914,0.008549386);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1915,0.008222415);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1916,0.007177586);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1917,0.006453567);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1969,0.00455956);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1970,0.00575687);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1971,0.006463853);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1972,0.007401705);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1973,0.00770857);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1974,0.008550067);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1975,0.008443624);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1976,0.008672715);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1977,0.008580001);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1978,0.007553448);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1979,0.007364802);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2025,0.0006061057);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2027,0.001143453);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2029,0.002381532);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2031,0.004019514);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2032,0.004451905);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2033,0.005630437);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2034,0.006115693);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2035,0.007559179);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2036,0.007800361);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2037,0.009004725);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2038,0.008947211);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2039,0.008579716);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2040,0.008120069);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2041,0.00725697);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2093,0.002940733);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2094,0.003833309);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2095,0.004538654);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2096,0.005612426);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2097,0.006898999);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2098,0.007402935);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2099,0.007846878);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2100,0.008450851);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2101,0.008783418);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2102,0.008948416);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2103,0.008010779);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2151,0.0004702996);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2153,0.001216688);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2155,0.002232412);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2156,0.002941561);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2157,0.003617838);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2158,0.004132998);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2159,0.005776552);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2160,0.006457033);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2161,0.007284874);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2162,0.0080131);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2163,0.008553945);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2164,0.008658411);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2165,0.009168911);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2217,0.001781481);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2218,0.002226123);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2219,0.003016841);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2220,0.003906261);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2221,0.004516897);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2222,0.005745931);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2223,0.006467908);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2224,0.00765386);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2225,0.008379353);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2226,0.008499168);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2227,0.008978844);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2277,0.0004839788);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2279,0.0011496);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2281,0.002204038);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2283,0.003413765);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2285,0.005416264);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2287,0.007357922);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2289,0.008792881);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2403,0.0005151341);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2405,0.001234001);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2407,0.002502235);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2409,0.003658437);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2411,0.005517939);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2413,0.007402316);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2529,0.0004445315);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2531,0.001201358);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2533,0.002116156);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2535,0.003491403);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2537,0.005497749);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2655,0.0004883342);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2657,0.001024768);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2659,0.002084227);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2661,0.003652293);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2781,0.0004692144);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2783,0.001020581);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2785,0.002006496);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2907,0.0004777906);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2909,0.0009215909);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3033,0.0003737201);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(141,8.374025e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(143,0.0001075461);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(145,0.0001517996);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(147,0.000199263);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(149,0.0002127051);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(151,0.0002474292);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(153,0.0002655878);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(155,0.0002445695);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(157,0.0002365114);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(159,0.0002217166);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(161,0.0002000113);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(163,0.0001956039);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(165,0.0001645188);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(167,0.0001314174);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(169,0.000119646);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(171,0.0001008804);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(173,8.535407e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(175,6.852542e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(177,5.819762e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(179,4.842629e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(181,4.410224e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(265,6.618126e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(267,9.941503e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(269,0.0001411337);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(271,0.0001856542);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(273,0.0002083083);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(275,0.000253206);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(277,0.0002516446);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(279,0.0002607986);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(281,0.0002549321);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(283,0.0002419528);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(285,0.0002058816);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(287,0.0001981137);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(289,0.000157035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(291,0.0001407881);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(293,0.000124324);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(295,0.0001057363);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(297,8.77731e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(299,7.459857e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(301,6.153224e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(303,5.323525e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(305,4.388688e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(389,5.478149e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(391,9.080517e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(393,0.0001251979);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(395,0.000166289);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(397,0.0002033714);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(399,0.0002326336);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(401,0.0002555887);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(403,0.0002601415);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(405,0.0002572985);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(407,0.0002602724);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(409,0.0002369614);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(411,0.0001980249);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(413,0.000214228);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(415,0.0001540273);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(417,0.0001483022);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(419,0.0001171111);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(421,8.708484e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(423,8.495871e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(425,6.542616e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(427,5.839259e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(429,4.627658e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(513,4.069869e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(515,6.756975e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(517,9.951711e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(519,0.0001360243);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(521,0.0001855115);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(523,0.0002179106);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(525,0.0002685062);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(527,0.0002548597);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(529,0.000253019);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(531,0.0002558297);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(533,0.0002437407);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(535,0.0002143431);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(537,0.0001854984);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(539,0.0001916448);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(541,0.0001423467);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(543,0.0001227812);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(545,9.853954e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(547,8.974309e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(549,6.815815e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(551,6.820346e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(553,5.093276e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(639,4.523822e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(641,6.750291e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(643,0.0001155994);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(645,0.0001450552);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(647,0.0001999297);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(649,0.0002319743);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(651,0.0002625837);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(653,0.0002639935);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(655,0.0002962942);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(657,0.0002600775);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(659,0.0002270266);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(661,0.0002064399);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(663,0.0001926554);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(665,0.000159526);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(667,0.0001277013);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(669,0.0001203892);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(671,0.0001011491);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(673,8.210441e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(675,7.175004e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(677,6.336586e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(765,5.450595e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(767,8.229509e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(769,0.0001126179);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(771,0.0001509341);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(773,0.0001947782);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(775,0.0002340578);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(777,0.0002754245);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(779,0.0002791494);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(781,0.0002903309);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(783,0.0002469377);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(785,0.0002236296);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(787,0.0002000796);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(789,0.000176138);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(791,0.0001499358);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(793,0.0001324996);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(795,0.0001132201);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(797,9.034317e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(799,7.965757e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(801,6.687318e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(891,6.117284e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(893,8.836933e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(895,0.0001198768);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(897,0.0001743786);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(899,0.0001991024);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(901,0.0002581489);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(903,0.0002685092);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(905,0.0002669942);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(907,0.0002596336);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(909,0.0002558597);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(911,0.0002234807);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(913,0.0002211088);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(915,0.0001624122);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(917,0.0001386957);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(919,0.0001206113);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(921,0.0001059215);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(923,9.666696e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(925,6.934765e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1017,6.003595e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1019,8.806323e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1021,0.0001269538);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1023,0.0001744551);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1025,0.0002044389);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1027,0.0002642463);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1029,0.0002585837);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1031,0.0002629717);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1033,0.0002964536);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1035,0.0002774934);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1037,0.0002161658);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1039,0.0001882048);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1041,0.0001637328);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1043,0.000135209);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1045,0.0001199079);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1047,0.0001037503);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1049,8.274662e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1143,6.206057e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1145,9.888629e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1147,0.0001291397);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1149,0.0001689497);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1151,0.0002051433);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1153,0.0002537492);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1155,0.0003920726);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1157,0.0002677623);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1159,0.0002717445);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1161,0.0002448372);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1163,0.0002135777);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1165,0.0001811808);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1167,0.0001540583);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1169,0.0001305523);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1171,0.0001179809);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1173,0.0001000149);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1269,6.766065e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1271,9.008328e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1273,0.000127462);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1275,0.0001699091);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1277,0.000204631);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1279,0.0002951135);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1281,0.0002838341);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1283,0.0002660453);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1285,0.0002535706);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1287,0.0002355781);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1289,0.0002052707);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1291,0.0001789418);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1293,0.0001531347);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1295,0.0001336848);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1297,0.000110633);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1395,7.160646e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1397,9.594087e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1399,0.000135883);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1401,0.0001800259);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1403,0.0002077146);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1405,0.0002637179);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1407,0.0002657609);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1409,0.0002669083);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1411,0.0002556996);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1413,0.0002303089);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1415,0.0001980552);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1417,0.0001700856);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1419,0.0001479544);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1421,0.0001215029);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1473,0.000262824);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1474,0.0002501926);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1475,0.0002415592);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1476,0.000247519);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1477,0.0002231327);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1478,0.0002207843);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1479,0.0001929225);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1480,0.0001809729);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1481,0.0001634692);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1482,0.0001520278);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1483,0.0001422163);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1521,6.962471e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1523,0.0001003702);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1525,0.0001341589);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1527,0.0001698442);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1529,0.0002120999);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1531,0.000239692);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1533,0.0002647669);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1535,0.000260772);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1536,0.0004006693);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1537,0.0002636516);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1538,0.0002369767);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1539,0.0002202068);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1540,0.0002301096);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1541,0.0001970595);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1542,0.0001944748);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1543,0.0001712166);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1544,0.0001629794);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1545,0.0001547187);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1597,0.0002594689);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1598,0.0002615761);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1599,0.0002672133);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1600,0.000258309);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1601,0.0002256822);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1602,0.0002263395);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1603,0.0002164404);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1604,0.0002184609);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1605,0.000188744);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1606,0.00017795);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1607,0.0001606641);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1647,5.899189e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1649,9.507471e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1651,0.0001303764);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1653,0.0001746531);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1655,0.0002100741);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1657,0.0002570076);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1659,0.0002520781);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1660,0.0002610293);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1661,0.0002640211);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1662,0.0002651777);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1663,0.0002480565);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1664,0.0002376546);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1665,0.0002390983);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1666,0.0002187277);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1667,0.0001969754);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1668,0.0001820575);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1669,0.0001808343);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1721,0.0002423437);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1722,0.0002610171);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1723,0.000337026);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1724,0.0002644708);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1725,0.0002627615);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1726,0.0002495237);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1727,0.0002629279);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1728,0.0002161287);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1729,0.0002016);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1730,0.0001985107);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1731,0.0001996197);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1773,6.790236e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1775,9.351092e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1777,0.0001336328);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1779,0.0001773168);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1781,0.0002067824);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1783,0.000244282);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1784,0.0002499017);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1785,0.0002603255);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1786,0.0002634907);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1787,0.0002614294);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1788,0.0002626184);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1789,0.0002906824);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1790,0.0002533408);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1791,0.0002354082);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1792,0.0002050582);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1793,0.0001956562);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1845,0.000222973);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1846,0.0002885417);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1847,0.0002529102);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1848,0.0002855468);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1849,0.0002778676);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1850,0.0002965294);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1851,0.0002483762);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1852,0.0002505855);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1853,0.0002455214);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1854,0.0002244074);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1855,0.0002044808);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1899,6.645249e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1901,9.66505e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1903,0.0001298062);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1905,0.0001937626);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1907,0.0002069696);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1908,0.0002248333);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1909,0.0002348318);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1910,0.0002685773);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1911,0.0002572017);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1912,0.0002704806);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1913,0.0002727772);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1914,0.0002607975);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1915,0.0003059077);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1916,0.0002398651);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1917,0.0002321655);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1969,0.0001903852);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1970,0.0002086418);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1971,0.0002200983);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1972,0.0002735266);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1973,0.0002500555);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1974,0.000253329);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1975,0.0003355978);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1976,0.000256698);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1977,0.0002531159);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1978,0.0002686693);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1979,0.0002346964);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2025,6.626912e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2027,9.220821e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2029,0.0001329385);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2031,0.0001703983);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2032,0.0001832622);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2033,0.0002034323);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2034,0.0002126118);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2035,0.0002402096);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2036,0.0002444301);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2037,0.00025916);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2038,0.0002574988);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2039,0.0002665997);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2040,0.0002550086);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2041,0.0002481567);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2093,0.0001444338);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2094,0.0001791887);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2095,0.0001925862);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2096,0.0002032816);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2097,0.0002286252);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2098,0.0002370045);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2099,0.0002426766);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2100,0.0002735938);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2101,0.0002601736);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2102,0.0002720276);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2103,0.0002562148);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2151,5.717809e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2153,9.422836e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2155,0.0001264021);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2156,0.0001448205);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2157,0.0001707803);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2158,0.0001756468);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2159,0.0002074005);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2160,0.0002331961);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2161,0.0002364501);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2162,0.0002896824);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2163,0.0002545756);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2164,0.0002558027);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2165,0.0002652168);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2217,0.0001135595);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2218,0.0001256203);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2219,0.0001763012);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2220,0.0001695445);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2221,0.0001797852);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2222,0.0002034541);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2223,0.000232395);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2224,0.0002451698);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2225,0.0002609579);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2226,0.0002487761);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2227,0.0002679473);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2277,5.923941e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2279,9.173463e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2281,0.0001237689);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2283,0.000155722);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2285,0.0002120044);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2287,0.0002302534);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2289,0.000251933);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2403,9.134264e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2405,9.181468e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2407,0.0001547314);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2409,0.0001766587);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2411,0.0001972378);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2413,0.0002293357);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2529,6.236764e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2531,9.011516e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2533,0.0001198102);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2535,0.0001876741);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2537,0.0001954952);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2655,6.993963e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2657,8.204807e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2659,0.0001176104);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2661,0.0001583613);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2781,6.337847e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2783,8.093827e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2785,0.0001145003);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2907,5.533018e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2909,7.679718e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3033,4.957175e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetEntries(220569.1);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->Draw("colz");
   c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf->Modified();
   c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf->cd();
   c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf->SetSelected(c_AccEffMap_T5VV_8NJetinf_800HT1000_200MHTinf);
}
/*
   400    25   0.000837786
   400    75    0.00051035
   400   125   0.000401341
   400   175   0.000222273
   450    25    0.00142458
   450    75    0.00121654
   450   125   0.000965786
   450   175   0.000504079
   450   225   0.000262764
   500    25    0.00245045
   500    75    0.00238366
   500   125    0.00184392
   500   175    0.00120529
   500   225   0.000566558
   500   275   0.000380549
   550    25    0.00454613
   550    75    0.00406991
   550   125    0.00331333
   550   175    0.00226953
   550   225    0.00161114
   550   275   0.000852258
   550   325   0.000484334
   600    25    0.00519884
   600    75    0.00502415
   600   125     0.0047044
   600   175    0.00402066
   600   225    0.00249933
   600   275    0.00155795
   600   325   0.000964633
   600   375   0.000467878
   650    25    0.00638601
   650    75    0.00670574
   650   125    0.00617508
   650   175    0.00556921
   650   225    0.00426418
   650   275    0.00277229
   650   325    0.00178178
   650   375   0.000988488
   650   425   0.000499596
   700    25    0.00696232
   700    75    0.00724646
   700   125    0.00753563
   700   175    0.00716272
   700   225    0.00573755
   700   275    0.00438278
   700   325    0.00359547
   700   375    0.00199407
   700   425    0.00119823
   700   475   0.000607402
   750    25    0.00664147
   750    75    0.00747463
   750   125    0.00779181
   750   175    0.00741891
   750   225    0.00779483
   750   275    0.00628051
   750   325    0.00477819
   750   375    0.00371153
   750   425    0.00209976
   750   475    0.00103233
   750   525   0.000614434
   800    25    0.00608256
   800    75    0.00723906
   800   125    0.00764511
   800   175    0.00743974
   800   225    0.00815488
   800   275    0.00814653
   800   325    0.00662413
   800   375    0.00498151
   800   425    0.00350433
   800   475    0.00208439
   800   525    0.00119774
   800   575   0.000643982
   850    25    0.00555021
   850    75    0.00549265
   850   125    0.00661659
   850   175    0.00742166
   850   225    0.00785465
   850   275    0.00823046
   850   325    0.00810542
   850   375    0.00655772
   850   425    0.00523256
   850   475     0.0035719
   850   525    0.00235334
   850   575     0.0013341
   850   625   0.000467179
   900    25    0.00443827
   900    75    0.00474943
   900   125    0.00561329
   900   175    0.00660122
   900   225    0.00733891
   900   275     0.0083384
   900   325    0.00851131
   900   375    0.00809021
   900   425    0.00738095
   900   475    0.00514645
   900   525    0.00378913
   900   575     0.0022781
   900   625    0.00121055
   900   675   0.000628718
   950    25    0.00354204
   950    75    0.00411377
   950   125    0.00459341
   950   175    0.00536656
   950   225    0.00616776
   950   275    0.00726549
   950   325    0.00808397
   950   375     0.0083844
   950   425    0.00836942
   950   475    0.00734571
   950   525    0.00545676
   950   575    0.00370067
   950   625    0.00223199
   950   675    0.00116007
   950   725   0.000604169
  1000    25    0.00257852
  1000    75    0.00298288
  1000   125    0.00371663
  1000   175    0.00413319
  1000   225    0.00498619
  1000   275    0.00602761
  1000   325    0.00717666
  1000   375    0.00810304
  1000   425     0.0087418
  1000   475    0.00878663
  1000   525    0.00722131
  1000   575    0.00575188
  1000   625    0.00398224
  1000   675    0.00241147
  1000   725     0.0013068
  1000   775   0.000606106
  1050    25    0.00211431
  1050    75    0.00242019
  1050   125    0.00280773
  1050   175    0.00304012
  1050   225    0.00431371
  1050   275    0.00491711
  1050   325    0.00612149
  1050   375    0.00686748
  1050   425    0.00831511
  1050   475     0.0085031
  1050   525    0.00884603
  1050   575     0.0073108
  1050   625    0.00568363
  1050   675    0.00398496
  1050   725    0.00200648
  1050   775    0.00114345
  1050   825     0.0004703
  1100    25    0.00172185
  1100    75    0.00181538
  1100   125    0.00219934
  1100   175    0.00246746
  1100   225    0.00301456
  1100   275    0.00382229
  1100   325    0.00465343
  1100   375    0.00581045
  1100   425    0.00641437
  1100   475    0.00800854
  1100   525    0.00839089
  1100   575     0.0083175
  1100   625    0.00745609
  1100   675    0.00537441
  1100   725    0.00380937
  1100   775    0.00238153
  1100   825    0.00121669
  1100   875   0.000483979
  1150    25    0.00128181
  1150    75    0.00139675
  1150   125    0.00172934
  1150   175    0.00190206
  1150   225    0.00204721
  1150   275    0.00284805
  1150   325    0.00332657
  1150   375    0.00446114
  1150   425    0.00576349
  1150   475     0.0070167
  1150   525    0.00827957
  1150   550    0.00881645
  1150   575    0.00868175
  1150   600    0.00838439
  1150   625    0.00823531
  1150   650    0.00768362
  1150   675    0.00748679
  1150   700     0.0066031
  1150   725    0.00547196
  1150   750    0.00455956
  1150   775    0.00401951
  1150   800    0.00294073
  1150   825    0.00223241
  1150   850    0.00178148
  1150   875     0.0011496
  1150   925   0.000515134
  1175   550    0.00785163
  1175   575     0.0088314
  1175   600    0.00863199
  1175   625    0.00877799
  1175   650    0.00878684
  1175   675    0.00755793
  1175   700    0.00736967
  1175   725    0.00670531
  1175   750    0.00575687
  1175   775     0.0044519
  1175   800    0.00383331
  1175   825    0.00294156
  1175   850    0.00222612
  1200    25   0.000921919
  1200    75   0.000983459
  1200   125   0.000960853
  1200   175    0.00124358
  1200   225     0.0018568
  1200   275    0.00222859
  1200   325    0.00245604
  1200   375     0.0034429
  1200   425    0.00419915
  1200   475    0.00539951
  1200   525    0.00681744
  1200   550    0.00713723
  1200   575    0.00795707
  1200   600    0.00873924
  1200   625    0.00835846
  1200   650    0.00876284
  1200   675    0.00843774
  1200   700    0.00765825
  1200   725     0.0073141
  1200   750    0.00646385
  1200   775    0.00563044
  1200   800    0.00453865
  1200   825    0.00361784
  1200   850    0.00301684
  1200   875    0.00220404
  1200   925      0.001234
  1200   975   0.000444531
  1225   550    0.00697759
  1225   575    0.00724449
  1225   600    0.00813655
  1225   625    0.00840497
  1225   650     0.0085826
  1225   675    0.00902854
  1225   700    0.00809298
  1225   725    0.00823839
  1225   750    0.00740171
  1225   775    0.00611569
  1225   800    0.00561243
  1225   825      0.004133
  1225   850    0.00390626
  1250    25   0.000604619
  1250    75   0.000721958
  1250   125   0.000933155
  1250   175   0.000977551
  1250   225    0.00130138
  1250   275    0.00166419
  1250   325    0.00187686
  1250   375    0.00237914
  1250   425    0.00307298
  1250   475    0.00412589
  1250   525    0.00510593
  1250   550    0.00602521
  1250   575    0.00630618
  1250   600    0.00663539
  1250   625    0.00779146
  1250   650     0.0082155
  1250   675    0.00883388
  1250   700    0.00938606
  1250   725    0.00876395
  1250   750    0.00770857
  1250   775    0.00755918
  1250   800      0.006899
  1250   825    0.00577655
  1250   850     0.0045169
  1250   875    0.00341377
  1250   925    0.00250223
  1250   975    0.00120136
  1250  1025   0.000488334
  1275   550    0.00534145
  1275   575    0.00589449
  1275   600    0.00672612
  1275   625    0.00741506
  1275   650    0.00808334
  1275   675    0.00850667
  1275   700    0.00831991
  1275   725    0.00868563
  1275   750    0.00855007
  1275   775    0.00780036
  1275   800    0.00740294
  1275   825    0.00645703
  1275   850    0.00574593
  1300    25    0.00044273
  1300    75   0.000495515
  1300   125    0.00055848
  1300   175   0.000608833
  1300   225   0.000879282
  1300   275    0.00106727
  1300   325    0.00147266
  1300   375    0.00187704
  1300   425    0.00224113
  1300   475    0.00308846
  1300   525    0.00381052
  1300   550    0.00437899
  1300   575    0.00511365
  1300   600    0.00612889
  1300   625    0.00697576
  1300   650    0.00721037
  1300   675    0.00778342
  1300   700    0.00780142
  1300   725    0.00885654
  1300   750    0.00844362
  1300   775    0.00900472
  1300   800    0.00784688
  1300   825    0.00728487
  1300   850    0.00646791
  1300   875    0.00541626
  1300   925    0.00365844
  1300   975    0.00211616
  1300  1025    0.00102477
  1300  1075   0.000469214
  1325   550    0.00379713
  1325   575    0.00420649
  1325   600    0.00485208
  1325   625    0.00578235
  1325   650    0.00611211
  1325   675    0.00733135
  1325   700    0.00768941
  1325   725    0.00854939
  1325   750    0.00867272
  1325   775    0.00894721
  1325   800    0.00845085
  1325   825     0.0080131
  1325   850    0.00765386
  1350    25   0.000309872
  1350    75   0.000376138
  1350   125   0.000451937
  1350   175   0.000616942
  1350   225   0.000683662
  1350   275   0.000845638
  1350   325    0.00124735
  1350   375    0.00144567
  1350   425    0.00183616
  1350   475    0.00238558
  1350   525    0.00290715
  1350   550    0.00337051
  1350   575    0.00386185
  1350   600    0.00459951
  1350   625    0.00478694
  1350   650    0.00518903
  1350   675    0.00671701
  1350   700    0.00711997
  1350   725    0.00822242
  1350   750       0.00858
  1350   775    0.00857972
  1350   800    0.00878342
  1350   825    0.00855394
  1350   850    0.00837935
  1350   875    0.00735792
  1350   925    0.00551794
  1350   975     0.0034914
  1350  1025    0.00208423
  1350  1075    0.00102058
  1350  1125   0.000477791
  1375   550    0.00278305
  1375   575    0.00355971
  1375   600    0.00381299
  1375   625    0.00446195
  1375   650    0.00514431
  1375   675    0.00564862
  1375   700    0.00680522
  1375   725    0.00717759
  1375   750    0.00755345
  1375   775    0.00812007
  1375   800    0.00894842
  1375   825    0.00865841
  1375   850    0.00849917
  1400    25   0.000264105
  1400    75   0.000262873
  1400   125   0.000292213
  1400   175   0.000352347
  1400   225   0.000540774
  1400   275   0.000604693
  1400   325   0.000656635
  1400   375   0.000920479
  1400   425    0.00135794
  1400   475    0.00156524
  1400   525    0.00196298
  1400   550    0.00245274
  1400   575    0.00309052
  1400   600    0.00345388
  1400   625    0.00355158
  1400   650    0.00419127
  1400   675    0.00503061
  1400   700    0.00558722
  1400   725    0.00645357
  1400   750     0.0073648
  1400   775    0.00725697
  1400   800    0.00801078
  1400   825    0.00916891
  1400   850    0.00897884
  1400   875    0.00879288
  1400   925    0.00740232
  1400   975    0.00549775
  1400  1025    0.00365229
  1400  1075     0.0020065
  1400  1125   0.000921591
  1400  1175    0.00037372
*/
