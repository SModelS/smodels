{
//=========Macro generated from canvas: c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf/c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf
//=========  (Sat Feb 22 16:30:38 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf = new TCanvas("c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf", "c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf",125,360,500,500);
   c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf->SetFillColor(0);
   c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf->SetLogz();
   c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1500HTinf_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1500HTinf_200MHTinf","h_EffAcc_8NJetinf_1500HTinf_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(141,8.296057e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(143,0.0003479174);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(145,0.0005544269);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(147,0.0008071375);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(149,0.001276038);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(151,0.002040341);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(153,0.002762639);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(155,0.003398536);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(157,0.004208346);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(159,0.005153991);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(161,0.006387014);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(163,0.007723931);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(165,0.008704998);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(167,0.01028854);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(169,0.01078683);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(171,0.01220641);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(173,0.01284605);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(175,0.01421667);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(177,0.01567135);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(179,0.01684636);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(181,0.01664353);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(265,8.737102e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(267,0.0001823619);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(269,0.0004507082);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(271,0.0007898862);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(273,0.001324639);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(275,0.00160013);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(277,0.002176725);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(279,0.003096634);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(281,0.004096315);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(283,0.005134813);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(285,0.006091812);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(287,0.006995162);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(289,0.008702522);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(291,0.009637596);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(293,0.01034461);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(295,0.01119804);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(297,0.01250285);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(299,0.01414162);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(301,0.01519086);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(303,0.01630976);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(305,0.0162555);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(389,8.640156e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(391,0.000116044);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(393,0.0002790584);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(395,0.0006021978);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(397,0.0008480437);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(399,0.001361402);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(401,0.001936842);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(403,0.002756903);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(405,0.003611519);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(407,0.004545617);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(409,0.00543647);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(411,0.006560007);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(413,0.007474929);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(415,0.009384631);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(417,0.0101165);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(419,0.01083379);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(421,0.01231614);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(423,0.0135541);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(425,0.01479632);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(427,0.0152283);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(429,0.01555567);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(513,9.424584e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(515,0.0001340963);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(517,0.0002201182);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(519,0.0003796613);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(521,0.0007103853);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(523,0.001145018);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(525,0.00162388);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(527,0.002152814);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(529,0.002830947);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(531,0.003700692);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(533,0.004788842);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(535,0.006022586);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(537,0.006481827);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(539,0.007363814);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(541,0.008837972);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(543,0.01023289);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(545,0.0111595);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(547,0.01235626);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(549,0.01343204);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(551,0.01426571);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(553,0.01468837);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(637,2.125417e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(639,5.776953e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(641,0.000122115);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(643,0.000256548);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(645,0.0004928224);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(647,0.000706525);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(649,0.001152443);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(651,0.001818252);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(653,0.002560554);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(655,0.003128641);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(657,0.003563576);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(659,0.005357156);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(661,0.005856649);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(663,0.007071149);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(665,0.00855158);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(667,0.009025404);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(669,0.01079472);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(671,0.01136438);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(673,0.01276851);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(675,0.01319506);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(677,0.01484201);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(761,7.089521e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(763,8.729207e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(765,0.0001175654);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(767,0.0001696085);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(769,0.0003658981);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(771,0.0005479684);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(773,0.001030107);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(775,0.001153496);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(777,0.001883546);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(779,0.002581626);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(781,0.003161085);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(783,0.004030315);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(785,0.005453522);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(787,0.005961989);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(789,0.006808411);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(791,0.008721925);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(793,0.009176008);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(795,0.01063675);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(797,0.01185842);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(799,0.01271781);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(801,0.01370717);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(887,2.973396e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(889,8.921045e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(891,9.621521e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(893,0.0002243498);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(895,0.0004786444);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(897,0.0005656447);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(899,0.0009542762);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(901,0.001371408);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(903,0.001897493);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(905,0.0025448);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(907,0.003365199);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(909,0.00420031);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(911,0.005033119);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(913,0.006213308);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(915,0.007123623);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(917,0.008340704);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(919,0.008993277);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(921,0.01064721);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(923,0.01124604);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(925,0.01235074);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1011,1.528182e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1013,2.181395e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1015,7.30937e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1017,8.781776e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1019,0.0002297713);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1021,0.0004214932);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1023,0.0007226507);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1025,0.0009657577);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1027,0.001338475);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1029,0.001905262);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1031,0.00259235);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1033,0.003411209);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1035,0.004384133);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1037,0.005346298);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1039,0.006259114);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1041,0.007021557);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1043,0.00844616);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1045,0.009002397);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1047,0.01040158);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1049,0.01095243);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1137,7.286366e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1139,3.658392e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1141,5.88666e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1143,0.0001259832);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1145,0.000296317);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1147,0.0004451573);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1149,0.0006926603);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1151,0.000985505);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1153,0.001403965);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1155,0.001922249);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1157,0.002626388);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1159,0.00337314);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1161,0.004455003);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1163,0.005212658);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1165,0.006181191);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1167,0.007353516);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1169,0.008228743);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1171,0.008963925);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1173,0.009985861);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1263,1.467674e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1265,3.67876e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1267,7.487354e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1269,0.0001311631);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1271,0.0002691818);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1273,0.0003911869);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1275,0.0006047023);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1277,0.001115459);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1279,0.001283764);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1281,0.001977222);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1283,0.002649344);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1285,0.003284949);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1287,0.004261137);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1289,0.005238597);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1291,0.005743727);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1293,0.007164066);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1295,0.008325969);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1297,0.008639631);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1391,2.192794e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1393,0.0001098427);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1395,0.0001624082);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1397,0.0002372353);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1399,0.0004786278);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1401,0.000541618);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1403,0.0009040449);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1405,0.00149079);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1407,0.002191165);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1409,0.002492719);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1411,0.003038475);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1413,0.004275138);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1415,0.004486131);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1417,0.005764989);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1419,0.00695361);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1421,0.007716786);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1513,7.341319e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1517,5.177034e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1519,7.404555e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1521,0.0001798541);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1523,0.0002926811);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1525,0.0004645682);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1527,0.0007955771);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1529,0.0009839683);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1531,0.001664874);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1533,0.001758036);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1535,0.002112754);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1537,0.002948949);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1539,0.003751828);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1541,0.004716783);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1543,0.00551985);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1545,0.006587033);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1641,2.26542e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1643,4.349148e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1645,5.786429e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1647,0.0002121267);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1649,0.0002580172);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1651,0.0004245548);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1653,0.0005229337);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1655,0.0008849995);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1657,0.001386299);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1659,0.001811994);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1661,0.002516373);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1663,0.002926121);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1665,0.004232484);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1667,0.005067449);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1669,0.005523142);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1767,1.441201e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1769,4.269707e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1771,9.194809e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1773,0.0001253961);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1775,0.0002700362);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1777,0.0004831583);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1783,0.001344415);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1785,0.00171663);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1787,0.002251624);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1789,0.003138273);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1791,0.003775523);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1793,0.004241684);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1845,0.0009632944);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1846,0.001162658);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1847,0.001384911);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1848,0.001642087);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1849,0.001974854);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1850,0.002271128);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1851,0.002678081);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1852,0.002723724);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1853,0.003292368);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1854,0.003946481);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1855,0.004266491);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1895,2.115513e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1897,6.937444e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1899,0.0001713494);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1901,0.0001744253);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1907,0.0009802466);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1908,0.001009756);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1909,0.001317761);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1910,0.001380976);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1911,0.001762723);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1912,0.001822231);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1913,0.002293931);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1914,0.002642006);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1915,0.002889166);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1916,0.003316035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1917,0.003385442);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1969,0.0008572278);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1970,0.0009364707);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1971,0.001130516);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1972,0.001291673);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1973,0.001340115);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1974,0.001539227);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1975,0.002066527);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1976,0.002161222);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1977,0.002557057);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1978,0.002976435);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1979,0.002887748);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2021,4.87649e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2023,8.224604e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2025,0.0001222597);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2031,0.000564154);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2032,0.0006798135);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2033,0.0009469599);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2034,0.0009814759);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2035,0.001177607);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2036,0.00116073);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2037,0.001856606);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2038,0.002145934);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2039,0.002394348);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2040,0.00245925);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2041,0.002920081);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2093,0.0004319277);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2094,0.0007067729);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2095,0.0007757843);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2096,0.0007480325);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2097,0.0009744998);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2098,0.001146525);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2099,0.001539823);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2100,0.001593274);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2101,0.001795827);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2102,0.002302175);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2103,0.002455103);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2145,1.395165e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2147,3.477717e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2149,0.0001085562);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2155,0.0003540181);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2156,0.0003475826);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2157,0.0005125536);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2158,0.0006159698);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2159,0.0008288058);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2160,0.0008047211);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2161,0.001062533);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2162,0.001337182);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2163,0.001416274);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2164,0.001737826);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2165,0.002074216);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2217,0.0003037838);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2218,0.0004895266);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2219,0.0004115693);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2220,0.0004420807);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2221,0.0007238649);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2222,0.0008689204);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2223,0.0009180924);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2224,0.000922717);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2225,0.001267394);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2226,0.001599382);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2227,0.001722013);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2271,2.757818e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2273,4.765842e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2279,0.0001776441);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2280,0.0002653762);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2281,0.0003305645);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2282,0.0004127649);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2283,0.0005484251);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2284,0.0006435292);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2285,0.0006961547);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2286,0.0009378203);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2287,0.001044862);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2288,0.001142553);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2289,0.00140859);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2341,0.0002349655);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2342,0.0002154727);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2343,0.0003389976);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2344,0.0003299119);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2345,0.0003817489);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2346,0.0004933278);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2347,0.0006616404);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2348,0.000687188);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2349,0.001050958);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2350,0.001068138);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2351,0.001108988);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2403,0.000154919);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2404,0.0001517857);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2405,0.0002253653);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2406,0.0002463432);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2407,0.0003086347);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2408,0.0005091791);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2409,0.0004815181);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2410,0.0005815902);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2411,0.000690466);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2412,0.001025654);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2413,0.0009297354);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2465,8.487914e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2466,0.0001042237);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2467,0.0001988987);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2468,0.0001643481);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2469,0.0003098502);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2470,0.0002858872);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2471,0.0003379557);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2472,0.00040738);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2473,0.0005776983);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2474,0.0009217499);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2475,0.0007699462);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2527,9.197434e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2528,9.10727e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2529,0.0001617919);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2530,0.0001654139);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2531,0.0002544123);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2532,0.0002737983);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2533,0.0003187329);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2534,0.0003875737);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2535,0.0005808382);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2536,0.0005748411);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2537,0.0005978773);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2589,5.191087e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2590,6.454668e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2591,8.308043e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2592,0.0001404315);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2593,0.0001290482);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2594,0.0001757581);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2595,0.0002580788);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2596,0.0002732256);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2597,0.0003629889);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2598,0.000479304);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2599,0.0005149762);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2651,1.946055e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2653,8.272641e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2655,0.0001132163);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2657,0.0001760679);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2659,0.0003112615);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2661,0.0004411557);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2777,6.381071e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2779,9.443183e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2781,8.069478e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2783,0.0001593894);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2785,0.0002642616);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2903,2.528655e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2905,3.725534e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2907,0.0001074335);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2909,0.0001404004);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3025,6.385434e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3029,1.239352e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3031,2.776178e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3033,8.438358e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3153,1.339014e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3155,1.316539e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3157,4.807044e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3281,1.804904e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3403,6.131828e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(141,2.625373e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(143,5.086611e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(145,6.411662e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(147,7.899114e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(149,9.843139e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(151,0.000125819);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(153,0.0001454171);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(155,0.0001610104);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(157,0.0001810652);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(159,0.0001976088);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(161,0.0002193757);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(163,0.0002392369);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(165,0.0002536992);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(167,0.0002763208);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(169,0.0002795916);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(171,0.0002984095);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(173,0.0003115956);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(175,0.0003294747);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(177,0.0003303776);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(179,0.0003636922);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(181,0.0003650924);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(265,2.52379e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(267,3.729045e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(269,5.935703e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(271,7.767711e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(273,0.0001007219);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(275,0.0001102395);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(277,0.0001287788);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(279,0.0001889885);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(281,0.0001757442);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(283,0.0001979768);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(285,0.0002132819);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(287,0.0002361838);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(289,0.0003017015);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(291,0.0002657168);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(293,0.0002733239);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(295,0.0002821911);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(297,0.0003050584);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(299,0.0003582959);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(301,0.0003468892);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(303,0.0003481538);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(305,0.0003322589);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(389,2.494329e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(391,2.902609e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(393,4.661924e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(395,6.746927e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(397,7.995673e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(399,0.0001017812);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(401,0.0001214965);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(403,0.0001445509);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(405,0.0001651538);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(407,0.0001846564);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(409,0.0002008348);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(411,0.0002203533);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(413,0.0002345987);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(415,0.0003096832);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(417,0.0002702476);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(419,0.0002781463);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(421,0.0002958939);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(423,0.0003110749);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(425,0.0003801897);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(427,0.0003481447);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(429,0.0003251554);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(513,2.61548e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(515,3.165551e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(517,4.098211e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(519,5.380675e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(521,7.38215e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(523,9.314206e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(525,0.00011105);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(527,0.0001305539);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(529,0.0001461041);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(531,0.0001658449);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(533,0.0001881896);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(535,0.0002101838);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(537,0.0002197362);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(539,0.0002886405);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(541,0.0002521572);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(543,0.0002702054);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(545,0.0002973025);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(547,0.0002935078);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(549,0.0003426957);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(551,0.0003146159);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(553,0.0003311542);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(637,1.227126e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(639,2.042533e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(641,3.055624e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(643,4.472263e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(645,6.128268e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(647,7.259783e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(649,9.351129e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(651,0.0001222317);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(653,0.0001514981);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(655,0.0001518896);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(657,0.0001649491);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(659,0.0001982813);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(661,0.000206657);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(663,0.0002256428);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(665,0.0002479187);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(667,0.000252908);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(669,0.000275025);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(671,0.0002813556);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(673,0.0002970379);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(675,0.0003170714);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(677,0.000317547);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(761,7.089552e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(763,2.52151e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(765,2.940666e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(767,3.539087e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(769,5.234123e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(771,6.378995e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(773,8.79339e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(775,9.28796e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(777,0.0001181122);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(779,0.0001377665);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(781,0.0001524343);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(783,0.0001707491);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(785,0.0001997043);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(787,0.0002098409);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(789,0.0002198646);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(791,0.0002479938);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(793,0.0002698714);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(795,0.0002713469);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(797,0.0002847682);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(799,0.0003310357);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(801,0.0003552282);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(887,1.486725e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(889,2.5781e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(891,2.670135e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(893,4.100169e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(895,5.996756e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(897,6.586127e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(899,8.45686e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(901,0.0001002398);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(903,0.0001183712);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(905,0.0001355208);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(907,0.000156479);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(909,0.0001746069);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(911,0.0001893467);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(913,0.0002093345);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(915,0.0003051252);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(917,0.0002406623);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(919,0.0002506727);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(921,0.000270533);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(923,0.0002759903);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(925,0.0003464069);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1011,1.082465e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1013,1.259446e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1015,2.311528e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1017,2.535215e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1019,4.132159e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1021,5.591733e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1023,7.312178e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1025,8.389818e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1027,9.894405e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1029,0.000117907);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1031,0.0001372259);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1033,0.0001616092);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1035,0.0001779496);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1037,0.000193864);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1039,0.0002120903);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1041,0.0002255122);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1043,0.0002419981);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1045,0.0002479374);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1047,0.0002661423);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1049,0.0003439024);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1137,7.286398e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1139,1.636119e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1141,2.081323e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1143,3.060899e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1145,4.695781e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1147,5.758859e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1149,7.201006e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1151,8.468308e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1153,0.0001008569);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1155,0.0001169229);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1157,0.0001363443);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1159,0.0001543708);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1161,0.0001762441);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1163,0.0001896263);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1165,0.0002060851);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1167,0.0002323939);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1169,0.0002359451);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1171,0.0002449369);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1173,0.0002977938);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1263,1.037812e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1265,1.645228e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1267,2.374143e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1269,3.091788e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1271,4.427779e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1273,5.332635e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1275,6.566725e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1277,8.892207e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1279,9.511138e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1281,0.0001186208);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1283,0.0001362564);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1285,0.0001507723);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1287,0.0001712287);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1289,0.0001906098);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1291,0.0002197612);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1293,0.0002204491);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1295,0.0002373813);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1297,0.000250651);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1391,1.266027e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1393,2.837668e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1395,3.469609e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1397,4.134836e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1399,5.85527e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1401,6.181113e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1403,7.940905e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1405,0.0001027525);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1407,0.0001269081);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1409,0.0001309535);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1411,0.0001440536);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1413,0.0001743288);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1415,0.0001837537);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1417,0.0002036248);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1419,0.0002154743);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1421,0.0002281126);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1513,7.341351e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1517,1.958601e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1519,2.347887e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1521,3.599496e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1523,4.576681e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1525,5.722535e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1527,7.503278e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1529,0.0001005809);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1531,0.0001070892);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1533,0.0001105193);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1535,0.0001196803);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1537,0.0001405636);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1539,0.0001603742);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1541,0.0001768397);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1543,0.0002070758);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1545,0.000263685);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1641,1.310049e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1643,1.775579e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1645,2.047576e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1647,3.874346e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1649,4.305184e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1651,5.441686e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1653,6.396909e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1655,7.776092e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1657,9.851688e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1659,0.0001124578);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1661,0.0001295946);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1663,0.0001402671);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1665,0.0001679243);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1667,0.000181848);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1669,0.00020036);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1767,1.019092e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1769,1.743145e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1771,2.550323e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1773,2.955838e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1775,4.326363e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1777,5.820673e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1783,9.778653e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1785,0.0001082408);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1787,0.0001220474);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1789,0.0001443045);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1791,0.0001571297);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1793,0.0001647714);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1845,7.989027e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1846,8.788022e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1847,0.0001021303);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1848,0.0001035257);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1849,0.0001136277);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1850,0.0001257019);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1851,0.0001388871);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1852,0.0001547338);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1853,0.0001610429);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1854,0.0001589201);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1855,0.0001673456);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1895,1.221408e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1897,2.193904e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1899,3.427343e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1901,3.903347e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1907,8.104444e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1908,8.150516e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1909,9.464216e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1910,9.526551e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1911,0.0001079455);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1912,0.0001088911);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1913,0.0001218682);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1914,0.0001341947);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1915,0.0001405607);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1916,0.00014611);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1917,0.000146666);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1969,7.566805e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1970,7.930992e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1971,8.61745e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1972,9.652646e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1973,9.523717e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1974,0.0001013518);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1975,0.0001166855);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1976,0.0001181711);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1977,0.0001318869);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1978,0.0001379074);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1979,0.0001362768);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2021,1.843194e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2023,2.374357e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2025,2.881901e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2031,6.661476e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2032,6.744486e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2033,7.880729e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2034,8.032263e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2035,8.977424e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2036,8.678019e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2037,0.0001117165);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2038,0.0001207311);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2039,0.0001309487);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2040,0.0001252001);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2041,0.0001548643);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2093,5.579873e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2094,7.187646e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2095,7.125872e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2096,6.99076e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2097,8.164338e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2098,8.56413e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2099,0.0001014372);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2100,0.000100862);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2101,0.0001071395);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2102,0.0001234689);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2103,0.0001241393);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2145,9.865387e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2147,1.555315e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2149,2.714082e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2155,4.823817e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2156,4.779538e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2157,5.772841e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2158,6.332329e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2159,7.423788e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2160,7.584186e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2161,8.289056e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2162,9.364006e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2163,9.620725e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2164,0.0001152269);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2165,0.0001286229);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2217,4.485972e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2218,5.741522e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2219,5.1471e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2220,5.325678e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2221,6.853228e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2222,7.949852e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2223,7.889715e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2224,7.654061e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2225,9.171539e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2226,0.0001219955);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2227,0.0001045844);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2271,1.378932e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2273,1.801371e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2279,3.423612e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2280,4.486397e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2281,4.683161e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2282,5.166107e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2283,5.921989e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2284,6.689254e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2285,6.71305e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2286,7.729306e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2287,8.075815e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2288,8.494128e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2289,9.679313e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2341,3.918228e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2342,3.751387e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2343,4.709602e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2344,4.626369e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2345,5.109944e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2346,5.663861e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2347,6.58902e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2348,6.752772e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2349,8.251092e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2350,8.460293e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2351,8.36443e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2403,3.162567e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2404,3.170693e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2405,3.811465e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2406,3.998343e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2407,4.507442e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2408,5.774899e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2409,5.535664e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2410,6.107562e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2411,6.719111e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2412,8.003697e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2413,7.660549e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2465,2.355524e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2466,2.60693e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2467,3.573619e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2468,3.291906e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2469,4.484112e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2470,4.417504e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2471,4.602562e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2472,6.018365e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2473,6.001061e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2474,7.592158e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2475,6.842068e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2527,2.459504e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2528,2.435392e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2529,3.239957e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2530,3.244358e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2531,4.026907e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2532,4.180641e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2533,4.465312e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2534,5.18383e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2535,6.137761e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2536,5.934376e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2537,6.42374e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2589,1.835384e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2590,2.041225e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2591,2.304353e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2592,2.994265e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2593,2.886887e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2594,3.447266e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2595,4.035339e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2596,4.121305e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2597,4.728694e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2598,5.544886e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2599,5.72921e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2651,1.123569e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2653,2.294533e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2655,2.668717e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2657,3.330142e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2659,4.408044e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2661,6.58604e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2777,6.381096e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2779,2.438359e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2781,2.23818e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2783,3.126185e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2785,4.128495e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2903,1.264347e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2905,1.520977e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2907,2.609139e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2909,2.932229e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3025,6.385458e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3029,8.763606e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3031,1.388112e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3033,2.255361e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3153,9.484697e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3155,9.325502e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3157,1.699596e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3281,1.042073e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3403,6.131851e-06);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetEntries(176085.6);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->Draw("colz");
   c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf->Modified();
   c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf->cd();
   c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf->SetSelected(c_AccEffMap_T1qqqq_8NJetinf_1500HTinf_200MHTinf);
}
/*
Topology ~g ~g ; ~g ->q+qbar+LSP

mGluino(GeV) mLSP(GeV) AccXEff
   400    25   8.29606e-05
   400    75    8.7371e-05
   400   125   8.64016e-05
   400   175   9.42458e-05
   400   225   2.12542e-05
   400   275   7.08952e-06
   450    25   0.000347917
   450    75   0.000182362
   450   125   0.000116044
   450   175   0.000134096
   450   225   5.77695e-05
   450   275   8.72921e-05
   450   325    2.9734e-05
   450   375   1.52818e-05
   500    25   0.000554427
   500    75   0.000450708
   500   125   0.000279058
   500   175   0.000220118
   500   225   0.000122115
   500   275   0.000117565
   500   325   8.92105e-05
   500   375   2.18139e-05
   500   425   7.28637e-06
   550    25   0.000807138
   550    75   0.000789886
   550   125   0.000602198
   550   175   0.000379661
   550   225   0.000256548
   550   275   0.000169609
   550   325   9.62152e-05
   550   375   7.30937e-05
   550   425   3.65839e-05
   550   475   1.46767e-05
   600    25    0.00127604
   600    75    0.00132464
   600   125   0.000848044
   600   175   0.000710385
   600   225   0.000492822
   600   275   0.000365898
   600   325    0.00022435
   600   375   8.78178e-05
   600   425   5.88666e-05
   600   475   3.67876e-05
   600   575   7.34132e-06
   650    25    0.00204034
   650    75    0.00160013
   650   125     0.0013614
   650   175    0.00114502
   650   225   0.000706525
   650   275   0.000547968
   650   325   0.000478644
   650   375   0.000229771
   650   425   0.000125983
   650   475   7.48735e-05
   650   525   2.19279e-05
   700    25    0.00276264
   700    75    0.00217673
   700   125    0.00193684
   700   175    0.00162388
   700   225    0.00115244
   700   275    0.00103011
   700   325   0.000565645
   700   375   0.000421493
   700   425   0.000296317
   700   475   0.000131163
   700   525   0.000109843
   700   575   5.17703e-05
   700   625   2.26542e-05
   750    25    0.00339854
   750    75    0.00309663
   750   125     0.0027569
   750   175    0.00215281
   750   225    0.00181825
   750   275     0.0011535
   750   325   0.000954276
   750   375   0.000722651
   750   425   0.000445157
   750   475   0.000269182
   750   525   0.000162408
   750   575   7.40455e-05
   750   625   4.34915e-05
   750   675    1.4412e-05
   800    25    0.00420835
   800    75    0.00409632
   800   125    0.00361152
   800   175    0.00283095
   800   225    0.00256055
   800   275    0.00188355
   800   325    0.00137141
   800   375   0.000965758
   800   425    0.00069266
   800   475   0.000391187
   800   525   0.000237235
   800   575   0.000179854
   800   625   5.78643e-05
   800   675   4.26971e-05
   850    25    0.00515399
   850    75    0.00513481
   850   125    0.00454562
   850   175    0.00370069
   850   225    0.00312864
   850   275    0.00258163
   850   325    0.00189749
   850   375    0.00133847
   850   425   0.000985505
   850   475   0.000604702
   850   525   0.000478628
   850   575   0.000292681
   850   625   0.000212127
   850   675   9.19481e-05
   850   725   2.11551e-05
   900    25    0.00638701
   900    75    0.00609181
   900   125    0.00543647
   900   175    0.00478884
   900   225    0.00356358
   900   275    0.00316108
   900   325     0.0025448
   900   375    0.00190526
   900   425    0.00140397
   900   475    0.00111546
   900   525   0.000541618
   900   575   0.000464568
   900   625   0.000258017
   900   675   0.000125396
   900   725   6.93744e-05
   900   775   4.87649e-05
   900   825   1.39516e-05
   950    25    0.00772393
   950    75    0.00699516
   950   125    0.00656001
   950   175    0.00602259
   950   225    0.00535716
   950   275    0.00403031
   950   325     0.0033652
   950   375    0.00259235
   950   425    0.00192225
   950   475    0.00128376
   950   525   0.000904045
   950   575   0.000795577
   950   625   0.000424555
   950   675   0.000270036
   950   725   0.000171349
   950   775    8.2246e-05
   950   825   3.47772e-05
   950   875   2.75782e-05
  1000    25      0.008705
  1000    75    0.00870252
  1000   125    0.00747493
  1000   175    0.00648183
  1000   225    0.00585665
  1000   275    0.00545352
  1000   325    0.00420031
  1000   375    0.00341121
  1000   425    0.00262639
  1000   475    0.00197722
  1000   525    0.00149079
  1000   575   0.000983968
  1000   625   0.000522934
  1000   675   0.000483158
  1000   725   0.000174425
  1000   775    0.00012226
  1000   825   0.000108556
  1000   875   4.76584e-05
  1050    25     0.0102885
  1050    75     0.0096376
  1050   125    0.00938463
  1050   175    0.00736381
  1050   225    0.00707115
  1050   275    0.00596199
  1050   325    0.00503312
  1050   375    0.00438413
  1050   425    0.00337314
  1050   475    0.00264934
  1050   525    0.00219117
  1050   575    0.00166487
  1050   625   0.000884999
  1100    25     0.0107868
  1100    75     0.0103446
  1100   125     0.0101165
  1100   175    0.00883797
  1100   225    0.00855158
  1100   275    0.00680841
  1100   325    0.00621331
  1100   375     0.0053463
  1100   425      0.004455
  1100   475    0.00328495
  1100   525    0.00249272
  1100   575    0.00175804
  1100   625     0.0013863
  1150    25     0.0122064
  1150    75      0.011198
  1150   125     0.0108338
  1150   175     0.0102329
  1150   225     0.0090254
  1150   275    0.00872192
  1150   325    0.00712362
  1150   375    0.00625911
  1150   425    0.00521266
  1150   475    0.00426114
  1150   525    0.00303847
  1150   575    0.00211275
  1150   625    0.00181199
  1150   675    0.00134442
  1150   700   0.000963294
  1150   725   0.000980247
  1150   750   0.000857228
  1150   775   0.000564154
  1150   800   0.000431928
  1150   825   0.000354018
  1150   850   0.000303784
  1150   875   0.000177644
  1150   900   0.000234966
  1150   925   0.000154919
  1150   950   8.48791e-05
  1150   975   9.19743e-05
  1150  1000   5.19109e-05
  1150  1025   1.94606e-05
  1175   700    0.00116266
  1175   725    0.00100976
  1175   750   0.000936471
  1175   775   0.000679814
  1175   800   0.000706773
  1175   825   0.000347583
  1175   850   0.000489527
  1175   875   0.000265376
  1175   900   0.000215473
  1175   925   0.000151786
  1175   950   0.000104224
  1175   975   9.10727e-05
  1175  1000   6.45467e-05
  1200    25      0.012846
  1200    75     0.0125028
  1200   125     0.0123161
  1200   175     0.0111595
  1200   225     0.0107947
  1200   275    0.00917601
  1200   325     0.0083407
  1200   375    0.00702156
  1200   425    0.00618119
  1200   475     0.0052386
  1200   525    0.00427514
  1200   575    0.00294895
  1200   625    0.00251637
  1200   675    0.00171663
  1200   700    0.00138491
  1200   725    0.00131776
  1200   750    0.00113052
  1200   775    0.00094696
  1200   800   0.000775784
  1200   825   0.000512554
  1200   850   0.000411569
  1200   875   0.000330565
  1200   900   0.000338998
  1200   925   0.000225365
  1200   950   0.000198899
  1200   975   0.000161792
  1200  1000   8.30804e-05
  1200  1025   8.27264e-05
  1200  1075   6.38107e-06
  1200  1175   6.38543e-06
  1225   700    0.00164209
  1225   725    0.00138098
  1225   750    0.00129167
  1225   775   0.000981476
  1225   800   0.000748032
  1225   825    0.00061597
  1225   850   0.000442081
  1225   875   0.000412765
  1225   900   0.000329912
  1225   925   0.000246343
  1225   950   0.000164348
  1225   975   0.000165414
  1225  1000   0.000140432
  1250    25     0.0142167
  1250    75     0.0141416
  1250   125     0.0135541
  1250   175     0.0123563
  1250   225     0.0113644
  1250   275     0.0106368
  1250   325    0.00899328
  1250   375    0.00844616
  1250   425    0.00735352
  1250   475    0.00574373
  1250   525    0.00448613
  1250   575    0.00375183
  1250   625    0.00292612
  1250   675    0.00225162
  1250   700    0.00197485
  1250   725    0.00176272
  1250   750    0.00134012
  1250   775    0.00117761
  1250   800     0.0009745
  1250   825   0.000828806
  1250   850   0.000723865
  1250   875   0.000548425
  1250   900   0.000381749
  1250   925   0.000308635
  1250   950    0.00030985
  1250   975   0.000254412
  1250  1000   0.000129048
  1250  1025   0.000113216
  1250  1075   9.44318e-05
  1250  1125   2.52865e-05
  1275   700    0.00227113
  1275   725    0.00182223
  1275   750    0.00153923
  1275   775    0.00116073
  1275   800    0.00114653
  1275   825   0.000804721
  1275   850    0.00086892
  1275   875   0.000643529
  1275   900   0.000493328
  1275   925   0.000509179
  1275   950   0.000285887
  1275   975   0.000273798
  1275  1000   0.000175758
  1300    25     0.0156714
  1300    75     0.0151909
  1300   125     0.0147963
  1300   175      0.013432
  1300   225     0.0127685
  1300   275     0.0118584
  1300   325     0.0106472
  1300   375     0.0090024
  1300   425    0.00822874
  1300   475    0.00716407
  1300   525    0.00576499
  1300   575    0.00471678
  1300   625    0.00423248
  1300   675    0.00313827
  1300   700    0.00267808
  1300   725    0.00229393
  1300   750    0.00206653
  1300   775    0.00185661
  1300   800    0.00153982
  1300   825    0.00106253
  1300   850   0.000918092
  1300   875   0.000696155
  1300   900    0.00066164
  1300   925   0.000481518
  1300   950   0.000337956
  1300   975   0.000318733
  1300  1000   0.000258079
  1300  1025   0.000176068
  1300  1075   8.06948e-05
  1300  1125   3.72553e-05
  1300  1175   1.23935e-05
  1300  1225   1.33901e-05
  1325   700    0.00272372
  1325   725    0.00264201
  1325   750    0.00216122
  1325   775    0.00214593
  1325   800    0.00159327
  1325   825    0.00133718
  1325   850   0.000922717
  1325   875    0.00093782
  1325   900   0.000687188
  1325   925    0.00058159
  1325   950    0.00040738
  1325   975   0.000387574
  1325  1000   0.000273226
  1350    25     0.0168464
  1350    75     0.0163098
  1350   125     0.0152283
  1350   175     0.0142657
  1350   225     0.0131951
  1350   275     0.0127178
  1350   325      0.011246
  1350   375     0.0104016
  1350   425    0.00896392
  1350   475    0.00832597
  1350   525    0.00695361
  1350   575    0.00551985
  1350   625    0.00506745
  1350   675    0.00377552
  1350   700    0.00329237
  1350   725    0.00288917
  1350   750    0.00255706
  1350   775    0.00239435
  1350   800    0.00179583
  1350   825    0.00141627
  1350   850    0.00126739
  1350   875    0.00104486
  1350   900    0.00105096
  1350   925   0.000690466
  1350   950   0.000577698
  1350   975   0.000580838
  1350  1000   0.000362989
  1350  1025   0.000311262
  1350  1075   0.000159389
  1350  1125   0.000107434
  1350  1175   2.77618e-05
  1350  1225   1.31654e-05
  1350  1325   6.13183e-06
  1375   700    0.00394648
  1375   725    0.00331603
  1375   750    0.00297644
  1375   775    0.00245925
  1375   800    0.00230218
  1375   825    0.00173783
  1375   850    0.00159938
  1375   875    0.00114255
  1375   900    0.00106814
  1375   925    0.00102565
  1375   950    0.00092175
  1375   975   0.000574841
  1375  1000   0.000479304
  1400    25     0.0166435
  1400    75     0.0162555
  1400   125     0.0155557
  1400   175     0.0146884
  1400   225      0.014842
  1400   275     0.0137072
  1400   325     0.0123507
  1400   375     0.0109524
  1400   425    0.00998586
  1400   475    0.00863963
  1400   525    0.00771679
  1400   575    0.00658703
  1400   625    0.00552314
  1400   675    0.00424168
  1400   700    0.00426649
  1400   725    0.00338544
  1400   750    0.00288775
  1400   775    0.00292008
  1400   800     0.0024551
  1400   825    0.00207422
  1400   850    0.00172201
  1400   875    0.00140859
  1400   900    0.00110899
  1400   925   0.000929735
  1400   950   0.000769946
  1400   975   0.000597877
  1400  1000   0.000514976
  1400  1025   0.000441156
  1400  1075   0.000264262
  1400  1125     0.0001404
  1400  1175   8.43836e-05
  1400  1225   4.80704e-05
  1400  1275    1.8049e-05
*/
