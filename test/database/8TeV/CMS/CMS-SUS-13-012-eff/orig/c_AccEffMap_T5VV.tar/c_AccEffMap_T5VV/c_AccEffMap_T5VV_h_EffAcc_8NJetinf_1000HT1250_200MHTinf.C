{
//=========Macro generated from canvas: c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf/c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf
//=========  (Sat Feb 22 16:32:53 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf = new TCanvas("c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf", "c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf",115,312,500,500);
   c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf->SetFillColor(0);
   c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf->SetLogz();
   c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1000HT1250_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1000HT1250_200MHTinf","h_EffAcc_8NJetinf_1000HT1250_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(141,0.0006523437);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(143,0.00160237);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(145,0.002591325);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(147,0.004576388);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(149,0.006485326);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(151,0.008863588);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(153,0.01117264);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(155,0.01404202);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(157,0.01472894);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(159,0.01536693);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(161,0.01550027);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(163,0.01586042);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(165,0.01433792);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(167,0.01305273);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(169,0.01136243);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(171,0.009274688);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(173,0.007803815);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(175,0.006169319);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(177,0.00491088);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(179,0.003929774);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(181,0.003572015);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(265,0.0004685899);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(267,0.001230228);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(269,0.002294596);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(271,0.003419206);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(273,0.005920797);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(275,0.008051711);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(277,0.01041952);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(279,0.01226538);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(281,0.01534101);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(283,0.01591138);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(285,0.01540085);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(287,0.0164288);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(289,0.01513323);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(291,0.01382607);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(293,0.01154518);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(295,0.01016212);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(297,0.008064526);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(299,0.006800734);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(301,0.005456111);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(303,0.004219322);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(305,0.003542777);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(389,0.0003955631);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(391,0.0008206248);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(393,0.001652047);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(395,0.003027163);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(397,0.004847498);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(399,0.006649726);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(401,0.009463437);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(403,0.01196575);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(405,0.01428844);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(407,0.0166438);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(409,0.01659366);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(411,0.01712999);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(413,0.01610434);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(415,0.01411391);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(417,0.01283144);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(419,0.01103498);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(421,0.009328066);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(423,0.007358491);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(425,0.006450089);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(427,0.004992002);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(429,0.003999707);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(513,0.0002613151);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(515,0.0004642415);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(517,0.00107916);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(519,0.002146518);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(521,0.003443411);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(523,0.005432046);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(525,0.008327905);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(527,0.01042638);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(529,0.01245905);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(531,0.01531945);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(533,0.01698185);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(535,0.01695823);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(537,0.01611779);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(539,0.01515434);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(541,0.01390237);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(543,0.01188882);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(545,0.01000692);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(547,0.00845699);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(549,0.00652582);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(551,0.005235963);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(553,0.004398118);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(639,0.0002518905);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(641,0.0006053886);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(643,0.001525694);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(645,0.002330562);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(647,0.003882469);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(649,0.006111913);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(651,0.008765983);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(653,0.01122117);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(655,0.01402636);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(657,0.01552372);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(659,0.01666852);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(661,0.01719672);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(663,0.01695381);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(665,0.01478286);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(667,0.01280623);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(669,0.01106365);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(671,0.009440573);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(673,0.007480703);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(675,0.005853619);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(677,0.005240918);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(765,0.000305941);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(767,0.0008592548);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(769,0.00151335);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(771,0.003015992);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(773,0.004189386);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(775,0.006420982);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(777,0.009407008);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(779,0.01195973);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(781,0.01373099);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(783,0.01583685);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(785,0.01668173);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(787,0.01685304);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(789,0.01598576);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(791,0.01389736);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(793,0.0124946);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(795,0.01087772);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(797,0.008801429);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(799,0.006947924);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(801,0.0057745);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(891,0.0004593305);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(893,0.0007976315);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(895,0.001663938);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(897,0.002954575);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(899,0.004517012);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(901,0.007214446);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(903,0.009513679);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(905,0.01184854);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(907,0.01406291);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(909,0.01663057);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(911,0.01719731);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(913,0.01673192);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(915,0.01527293);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(917,0.01397556);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(919,0.01163425);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(921,0.009739941);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(923,0.008394712);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(925,0.006645836);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1017,0.00042576);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1019,0.001040946);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1021,0.00193232);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1023,0.002692048);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1025,0.005040226);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1027,0.007656735);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1029,0.009804933);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1031,0.01214449);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1033,0.01456792);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1035,0.01729223);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1037,0.01700993);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1039,0.01691218);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1041,0.01549802);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1043,0.01338262);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1045,0.01116162);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1047,0.009523167);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1049,0.007563825);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1143,0.000479801);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1145,0.001116284);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1147,0.001900424);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1149,0.002944779);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1151,0.00463076);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1153,0.00713512);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1155,0.009662654);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1157,0.01323185);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1159,0.01512479);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1161,0.01713617);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1163,0.01704056);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1165,0.01660115);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1167,0.01530653);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1169,0.01310015);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1171,0.01135833);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1173,0.009224851);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1269,0.0005559504);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1271,0.001008258);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1273,0.001894128);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1275,0.002883548);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1277,0.005055321);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1279,0.007445322);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1281,0.01003404);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1283,0.01257531);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1285,0.01563804);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1287,0.01661269);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1289,0.01653751);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1291,0.01618981);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1293,0.01478747);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1295,0.01295381);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1297,0.01066235);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1395,0.0005786421);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1397,0.001135246);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1399,0.001971931);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1401,0.003261913);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1403,0.00526625);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1405,0.007696145);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1407,0.009987377);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1409,0.01345766);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1411,0.0157624);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1413,0.01629503);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1415,0.01666742);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1417,0.01662558);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1419,0.0143353);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1421,0.01270777);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1473,0.01485048);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1474,0.01566063);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1475,0.01668018);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1476,0.01686379);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1477,0.01721245);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1478,0.01683269);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1479,0.01581776);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1480,0.01658453);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1481,0.01561096);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1482,0.01472088);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1483,0.01393224);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1521,0.0004724347);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1523,0.00114427);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1525,0.002020225);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1527,0.003206383);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1529,0.005458703);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1531,0.007671915);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1533,0.01047506);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1535,0.0130072);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1536,0.01383059);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1537,0.01573327);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1538,0.01617405);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1539,0.01719859);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1540,0.01694167);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1541,0.01711559);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1542,0.01618149);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1543,0.01593919);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1544,0.01522441);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1545,0.01509324);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1597,0.01173539);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1598,0.01256823);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1599,0.01391713);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1600,0.01546404);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1601,0.01614563);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1602,0.01675818);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1603,0.01723311);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1604,0.01672325);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1605,0.01644278);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1606,0.01622666);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1607,0.01543862);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1647,0.0005538256);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1649,0.001258044);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1651,0.00207493);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1653,0.003433374);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1655,0.005219381);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1657,0.007436813);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1659,0.01024156);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1660,0.01219335);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1661,0.01291142);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1662,0.01385543);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1663,0.01556994);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1664,0.01722281);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1665,0.01670475);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1666,0.01710177);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1667,0.01719031);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1668,0.01611277);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1669,0.01566467);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1721,0.008951023);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1722,0.01043897);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1723,0.01097893);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1724,0.01331429);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1725,0.01425113);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1726,0.01523644);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1727,0.01596887);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1728,0.01704857);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1729,0.01735168);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1730,0.01668618);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1731,0.01647138);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1773,0.0004920404);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1775,0.001234784);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1777,0.001987715);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1779,0.003268486);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1781,0.005290702);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1783,0.007244325);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1784,0.008997303);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1785,0.01020622);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1786,0.01207054);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1787,0.01344579);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1788,0.01423432);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1789,0.01550228);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1790,0.0164847);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1791,0.01665048);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1792,0.01669523);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1793,0.01750888);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1845,0.006270513);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1846,0.007782753);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1847,0.008781315);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1848,0.01091038);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1849,0.01152624);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1850,0.01287589);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1851,0.01451197);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1852,0.01500872);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1853,0.01622402);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1854,0.01637803);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1855,0.01674827);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1899,0.0005478332);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1901,0.0009914243);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1903,0.002072341);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1905,0.003310831);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1907,0.005437035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1908,0.006502452);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1909,0.007623906);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1910,0.008400791);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1911,0.01036683);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1912,0.01155282);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1913,0.01278193);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1914,0.01434307);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1915,0.0151085);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1916,0.01591119);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1917,0.01664134);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1969,0.004217429);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1970,0.00528031);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1971,0.005953338);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1972,0.00779753);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1973,0.009061625);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1974,0.01039883);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1975,0.01148195);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1976,0.01278649);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1977,0.01412317);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1978,0.01500248);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1979,0.01647147);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2025,0.0004740393);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2027,0.00124625);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2029,0.001875138);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2031,0.003299679);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2032,0.004049901);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2033,0.005058006);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2034,0.005675927);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2035,0.007200126);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2036,0.008569184);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2037,0.009788116);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2038,0.01215011);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2039,0.01286872);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2040,0.01433403);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2041,0.01550976);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2093,0.002473156);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2094,0.003043662);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2095,0.004155596);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2096,0.004995063);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2097,0.006016399);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2098,0.007211744);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2099,0.008883975);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2100,0.01031569);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2101,0.01173423);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2102,0.01338328);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2103,0.01386387);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2151,0.0006397581);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2153,0.001082925);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2155,0.00201139);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2156,0.00253319);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2157,0.002918326);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2158,0.003646931);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2159,0.005177553);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2160,0.006032931);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2161,0.007586228);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2162,0.008813084);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2163,0.01000183);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2164,0.01185544);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2165,0.01271393);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2217,0.001372457);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2218,0.001858803);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2219,0.002369125);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2220,0.003283187);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2221,0.003759422);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2222,0.004904529);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2223,0.005953196);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2224,0.007413688);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2225,0.008826801);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2226,0.01011417);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2227,0.01145677);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2277,0.0004607653);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2279,0.0009696887);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2281,0.00179906);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2283,0.003328382);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2285,0.004975368);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2287,0.007174232);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2289,0.01009234);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2403,0.000454194);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2405,0.0009922438);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2407,0.001932091);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2409,0.003145288);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2411,0.004912825);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2413,0.0074997);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2529,0.0004450594);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2531,0.0008910076);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2533,0.001910542);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2535,0.002843352);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2537,0.004823128);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2655,0.0004062461);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2657,0.001018152);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2659,0.001538386);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2661,0.00280134);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2781,0.0003395425);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2783,0.0007816806);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2785,0.001673838);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2907,0.0002976149);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2909,0.0008714799);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3033,0.0002916058);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(141,7.228304e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(143,0.0001118826);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(145,0.0001526834);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(147,0.0001955405);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(149,0.0002325801);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(151,0.0002858121);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(153,0.0003306482);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(155,0.0003520714);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(157,0.0003649861);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(159,0.0003659749);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(161,0.0003722499);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(163,0.000413433);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(165,0.0003882868);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(167,0.0003260487);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(169,0.0003068579);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(171,0.0002704167);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(173,0.0002477247);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(175,0.0002184399);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(177,0.0001933795);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(179,0.000171921);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(181,0.0001625152);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(265,6.172054e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(267,9.76072e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(269,0.0001349203);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(271,0.0001666125);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(273,0.0002208558);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(275,0.0002716348);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(277,0.0002957498);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(279,0.0003291536);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(281,0.0003663963);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(283,0.0004087275);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(285,0.0003670622);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(287,0.0003944205);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(289,0.0003536983);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(291,0.0003366058);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(293,0.0003125031);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(295,0.0002841792);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(297,0.0002518108);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(299,0.0002293069);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(301,0.0002037725);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(303,0.0001780987);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(305,0.0001618165);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(389,5.39582e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(391,8.193039e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(393,0.0001150217);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(395,0.0001555206);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(397,0.0002008702);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(399,0.00023525);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(401,0.0002802469);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(403,0.0003170348);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(405,0.0003465502);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(407,0.0004097815);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(409,0.0004044575);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(411,0.00038091);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(413,0.0004452458);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(415,0.0003440118);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(417,0.0003585485);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(419,0.0002954857);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(421,0.0002700896);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(423,0.0002383541);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(425,0.0002217322);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(427,0.0001938623);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(429,0.0001717304);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(513,4.36322e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(515,6.462355e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(517,9.28959e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(519,0.0001298211);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(521,0.0001680268);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(523,0.0002094272);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(525,0.0002829021);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(527,0.0002961756);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(529,0.000322128);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(531,0.0003630038);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(533,0.0003882731);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(535,0.0003787571);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(537,0.0003643504);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(539,0.0004271509);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(541,0.0003377255);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(543,0.000306587);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(545,0.0002794339);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(547,0.0002638611);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(549,0.0002229331);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(551,0.0001977827);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(553,0.000180203);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(639,4.325225e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(641,6.826526e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(643,0.0001111685);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(645,0.0001370456);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(647,0.0001862093);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(649,0.0002342057);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(651,0.0002720707);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(653,0.0003035794);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(655,0.0003899534);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(657,0.0003738604);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(659,0.0003702104);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(661,0.0003814419);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(663,0.0003812351);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(665,0.0003527908);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(667,0.0003184154);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(669,0.000294027);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(671,0.0002719258);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(673,0.000238333);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(675,0.0002094758);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(677,0.0001965177);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(765,4.84287e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(767,8.138509e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(769,0.0001082398);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(771,0.000154707);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(773,0.000185364);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(775,0.0002307219);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(777,0.0002899694);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(779,0.0003294895);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(781,0.000366691);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(783,0.0003603793);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(785,0.0003692002);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(787,0.0003695715);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(789,0.000359251);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(791,0.0003316488);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(793,0.0003124065);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(795,0.0002895653);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(797,0.0002595267);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(799,0.0002280202);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(801,0.0002059853);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(891,5.890344e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(893,7.877214e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(895,0.0001134267);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(897,0.0001546516);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(899,0.0001883903);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(901,0.0002629048);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(903,0.0002839379);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(905,0.000309097);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(907,0.0003372097);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(909,0.0003849134);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(911,0.0003713887);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(913,0.0004163132);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(915,0.000346769);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(917,0.0003302008);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(919,0.0002996022);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(921,0.0002715783);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(923,0.0002502028);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(925,0.0002213824);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1017,5.647495e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1019,8.850574e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1021,0.0001219188);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1023,0.0001439224);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1025,0.000201167);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1027,0.0002785325);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1029,0.0002782081);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1031,0.0003109482);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1033,0.0003916498);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1035,0.0004362301);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1037,0.0003666725);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1039,0.0003650709);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1041,0.0003473041);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1043,0.0003200571);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1045,0.0002918686);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1047,0.0002664515);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1049,0.0002361589);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1143,6.050039e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1145,9.357463e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1147,0.0001196792);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1149,0.0001510093);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1151,0.0001878613);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1153,0.0002429269);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1155,0.0004102036);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1157,0.0003231216);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1159,0.0003604617);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1161,0.0003960466);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1163,0.0003652649);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1165,0.0003593578);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1167,0.0003434614);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1169,0.0003152642);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1171,0.0002920359);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1173,0.0002600924);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1269,6.429281e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1271,8.826804e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1273,0.0001188122);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1275,0.000148824);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1277,0.0001973045);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1279,0.0002886507);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1281,0.0002957401);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1283,0.0003170482);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1285,0.000348864);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1287,0.0003588582);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1289,0.0003574228);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1291,0.0003524481);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1293,0.0003349006);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1295,0.0003109323);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1297,0.0002886549);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1395,6.828237e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1397,9.141775e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1399,0.0001223463);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1401,0.0001627287);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1403,0.0001989377);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1405,0.0002651879);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1407,0.0002764872);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1409,0.0003312992);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1411,0.0003478276);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1413,0.0003522752);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1415,0.0003557959);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1417,0.0003539148);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1419,0.0003271567);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1421,0.0003084049);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1473,0.0003360438);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1474,0.0003489673);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1475,0.0003640131);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1476,0.0003817777);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1477,0.0003752062);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1478,0.0003894403);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1479,0.0003658698);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1480,0.000376521);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1481,0.0003522397);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1482,0.000349605);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1483,0.0003389441);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1521,5.914143e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1523,9.126775e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1525,0.0001238607);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1527,0.0001532593);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1529,0.0002011022);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1531,0.0002391326);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1533,0.0002898647);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1535,0.0003130668);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1536,0.0004929502);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1537,0.0003649983);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1538,0.0003495122);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1539,0.0003610513);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1540,0.0003871656);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1541,0.0003588671);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1542,0.0003800864);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1543,0.0003470073);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1544,0.0003366015);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1545,0.0003409188);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1597,0.000299867);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1598,0.0003087254);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1599,0.0003310123);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1600,0.0003514433);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1601,0.0003476517);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1602,0.0003546883);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1603,0.0003600281);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1604,0.0004030317);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1605,0.0003550517);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1606,0.0003661345);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1607,0.0003394085);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1647,6.31592e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1649,9.644666e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1651,0.0001231295);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1653,0.0001585785);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1655,0.0001947098);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1657,0.0002488762);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1659,0.0002749274);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1660,0.0003006933);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1661,0.0003218883);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1662,0.00033512);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1663,0.0003453766);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1664,0.0003580867);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1665,0.0003663163);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1666,0.0003733252);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1667,0.0003709469);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1668,0.0003444917);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1669,0.0003789853);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1721,0.000254909);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1722,0.0002773981);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1723,0.0003683173);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1724,0.0003232437);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1725,0.000339669);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1726,0.0003374919);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1727,0.00038653);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1728,0.0003578238);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1729,0.0003669604);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1730,0.00035595);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1731,0.0003946095);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1773,5.973085e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1775,9.464405e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1777,0.0001185511);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1779,0.0001560273);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1781,0.0001995691);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1783,0.0002338592);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1784,0.000265453);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1785,0.0002794779);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1786,0.0002974797);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1787,0.0003168803);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1788,0.0003338321);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1789,0.0004049929);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1790,0.0003751773);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1791,0.0003671605);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1792,0.0003496124);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1793,0.0003627898);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1845,0.0002118602);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1846,0.0002881281);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1847,0.0002640781);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1848,0.0003241249);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1849,0.000301168);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1850,0.0003614204);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1851,0.000333543);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1852,0.0003450964);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1853,0.0003670196);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1854,0.0003456698);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1855,0.0003516224);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1899,6.294297e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1901,8.307389e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1903,0.0001294812);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1905,0.0001763721);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1907,0.0002008118);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1908,0.0002152731);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1909,0.0002325063);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1910,0.0002641003);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1911,0.0002729418);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1912,0.0003053736);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1913,0.0003212948);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1914,0.0003322607);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1915,0.000408636);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1916,0.000353444);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1917,0.0003707644);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1969,0.0001783022);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1970,0.0001943498);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1971,0.0002045532);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1972,0.0002723613);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1973,0.0002643473);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1974,0.0002729538);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1975,0.0003817235);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1976,0.0003055378);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1977,0.00031876);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1978,0.0003733439);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1979,0.0003472379);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2025,5.799197e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2027,9.472212e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2029,0.0001156451);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2031,0.0001504146);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2032,0.0001704783);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2033,0.0001876372);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2034,0.0001997194);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2035,0.0002278043);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2036,0.0002496912);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2037,0.0002632391);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2038,0.0002936003);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2039,0.0003195765);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2040,0.0003326025);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2041,0.0003574159);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2093,0.0001298168);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2094,0.0001548512);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2095,0.0001786933);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2096,0.0001863432);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2097,0.0002072354);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2098,0.0002273477);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2099,0.0002521487);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2100,0.0002951947);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2101,0.000294361);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2102,0.0003261263);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2103,0.0003313203);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2151,6.608315e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2153,8.685898e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2155,0.0001175434);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2156,0.0001311974);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2157,0.0001496024);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2158,0.000160055);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2159,0.0001913387);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2160,0.0002185315);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2161,0.0002344578);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2162,0.0002955349);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2163,0.0002684399);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2164,0.0002930234);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2165,0.0003055315);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2217,9.803537e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2218,0.000111866);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2219,0.0001522578);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2220,0.0001507399);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2221,0.0001599041);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2222,0.0001826903);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2223,0.0002163533);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2224,0.0002348101);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2225,0.0002612972);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2226,0.0002643937);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2227,0.0002953992);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2277,5.72166e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2279,8.331591e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2281,0.0001090341);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2283,0.0001495843);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2285,0.0001971993);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2287,0.0002214465);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2289,0.0002634249);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2403,8.448869e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2405,8.033231e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2407,0.0001331565);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2409,0.0001590239);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2411,0.0001803864);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2413,0.0002238155);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2529,6.180426e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2531,7.65645e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2533,0.0001106304);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2535,0.0001646441);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2537,0.0001772243);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2655,6.275522e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2657,8.094617e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2659,9.878725e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2661,0.0001346463);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2781,5.378403e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2783,6.974181e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2785,0.0001023873);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2907,4.300538e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2909,7.325741e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3033,4.350453e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetEntries(448272.4);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->Draw("colz");
   c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf->Modified();
   c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf->cd();
   c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf->SetSelected(c_AccEffMap_T5VV_8NJetinf_1000HT1250_200MHTinf);
}
/*
   400    25   0.000652344
   400    75    0.00046859
   400   125   0.000395563
   400   175   0.000261315
   450    25    0.00160237
   450    75    0.00123023
   450   125   0.000820625
   450   175   0.000464241
   450   225   0.000251891
   500    25    0.00259133
   500    75     0.0022946
   500   125    0.00165205
   500   175    0.00107916
   500   225   0.000605389
   500   275   0.000305941
   550    25    0.00457639
   550    75    0.00341921
   550   125    0.00302716
   550   175    0.00214652
   550   225    0.00152569
   550   275   0.000859255
   550   325    0.00045933
   600    25    0.00648533
   600    75     0.0059208
   600   125     0.0048475
   600   175    0.00344341
   600   225    0.00233056
   600   275    0.00151335
   600   325   0.000797632
   600   375    0.00042576
   650    25    0.00886359
   650    75    0.00805171
   650   125    0.00664973
   650   175    0.00543205
   650   225    0.00388247
   650   275    0.00301599
   650   325    0.00166394
   650   375    0.00104095
   650   425   0.000479801
   700    25     0.0111726
   700    75     0.0104195
   700   125    0.00946344
   700   175    0.00832791
   700   225    0.00611191
   700   275    0.00418939
   700   325    0.00295458
   700   375    0.00193232
   700   425    0.00111628
   700   475    0.00055595
   750    25      0.014042
   750    75     0.0122654
   750   125     0.0119658
   750   175     0.0104264
   750   225    0.00876598
   750   275    0.00642098
   750   325    0.00451701
   750   375    0.00269205
   750   425    0.00190042
   750   475    0.00100826
   750   525   0.000578642
   800    25     0.0147289
   800    75      0.015341
   800   125     0.0142884
   800   175      0.012459
   800   225     0.0112212
   800   275    0.00940701
   800   325    0.00721445
   800   375    0.00504023
   800   425    0.00294478
   800   475    0.00189413
   800   525    0.00113525
   800   575   0.000472435
   850    25     0.0153669
   850    75     0.0159114
   850   125     0.0166438
   850   175     0.0153194
   850   225     0.0140264
   850   275     0.0119597
   850   325    0.00951368
   850   375    0.00765673
   850   425    0.00463076
   850   475    0.00288355
   850   525    0.00197193
   850   575    0.00114427
   850   625   0.000553826
   900    25     0.0155003
   900    75     0.0154009
   900   125     0.0165937
   900   175     0.0169818
   900   225     0.0155237
   900   275      0.013731
   900   325     0.0118485
   900   375    0.00980493
   900   425    0.00713512
   900   475    0.00505532
   900   525    0.00326191
   900   575    0.00202022
   900   625    0.00125804
   900   675    0.00049204
   950    25     0.0158604
   950    75     0.0164288
   950   125       0.01713
   950   175     0.0169582
   950   225     0.0166685
   950   275     0.0158369
   950   325     0.0140629
   950   375     0.0121445
   950   425    0.00966265
   950   475    0.00744532
   950   525    0.00526625
   950   575    0.00320638
   950   625    0.00207493
   950   675    0.00123478
   950   725   0.000547833
  1000    25     0.0143379
  1000    75     0.0151332
  1000   125     0.0161043
  1000   175     0.0161178
  1000   225     0.0171967
  1000   275     0.0166817
  1000   325     0.0166306
  1000   375     0.0145679
  1000   425     0.0132318
  1000   475      0.010034
  1000   525    0.00769615
  1000   575     0.0054587
  1000   625    0.00343337
  1000   675    0.00198771
  1000   725   0.000991424
  1000   775   0.000474039
  1050    25     0.0130527
  1050    75     0.0138261
  1050   125     0.0141139
  1050   175     0.0151543
  1050   225     0.0169538
  1050   275      0.016853
  1050   325     0.0171973
  1050   375     0.0172922
  1050   425     0.0151248
  1050   475     0.0125753
  1050   525    0.00998738
  1050   575    0.00767192
  1050   625    0.00521938
  1050   675    0.00326849
  1050   725    0.00207234
  1050   775    0.00124625
  1050   825   0.000639758
  1100    25     0.0113624
  1100    75     0.0115452
  1100   125     0.0128314
  1100   175     0.0139024
  1100   225     0.0147829
  1100   275     0.0159858
  1100   325     0.0167319
  1100   375     0.0170099
  1100   425     0.0171362
  1100   475      0.015638
  1100   525     0.0134577
  1100   575     0.0104751
  1100   625    0.00743681
  1100   675     0.0052907
  1100   725    0.00331083
  1100   775    0.00187514
  1100   825    0.00108292
  1100   875   0.000460765
  1150    25    0.00927469
  1150    75     0.0101621
  1150   125      0.011035
  1150   175     0.0118888
  1150   225     0.0128062
  1150   275     0.0138974
  1150   325     0.0152729
  1150   375     0.0169122
  1150   425     0.0170406
  1150   475     0.0166127
  1150   525     0.0157624
  1150   550     0.0148505
  1150   575     0.0130072
  1150   600     0.0117354
  1150   625     0.0102416
  1150   650    0.00895102
  1150   675    0.00724433
  1150   700    0.00627051
  1150   725    0.00543703
  1150   750    0.00421743
  1150   775    0.00329968
  1150   800    0.00247316
  1150   825    0.00201139
  1150   850    0.00137246
  1150   875   0.000969689
  1150   925   0.000454194
  1175   550     0.0156606
  1175   575     0.0138306
  1175   600     0.0125682
  1175   625     0.0121933
  1175   650      0.010439
  1175   675     0.0089973
  1175   700    0.00778275
  1175   725    0.00650245
  1175   750    0.00528031
  1175   775     0.0040499
  1175   800    0.00304366
  1175   825    0.00253319
  1175   850     0.0018588
  1200    25    0.00780382
  1200    75    0.00806453
  1200   125    0.00932807
  1200   175     0.0100069
  1200   225     0.0110636
  1200   275     0.0124946
  1200   325     0.0139756
  1200   375      0.015498
  1200   425     0.0166012
  1200   475     0.0165375
  1200   525      0.016295
  1200   550     0.0166802
  1200   575     0.0157333
  1200   600     0.0139171
  1200   625     0.0129114
  1200   650     0.0109789
  1200   675     0.0102062
  1200   700    0.00878132
  1200   725    0.00762391
  1200   750    0.00595334
  1200   775    0.00505801
  1200   800     0.0041556
  1200   825    0.00291833
  1200   850    0.00236912
  1200   875    0.00179906
  1200   925   0.000992244
  1200   975   0.000445059
  1225   550     0.0168638
  1225   575      0.016174
  1225   600      0.015464
  1225   625     0.0138554
  1225   650     0.0133143
  1225   675     0.0120705
  1225   700     0.0109104
  1225   725    0.00840079
  1225   750    0.00779753
  1225   775    0.00567593
  1225   800    0.00499506
  1225   825    0.00364693
  1225   850    0.00328319
  1250    25    0.00616932
  1250    75    0.00680073
  1250   125    0.00735849
  1250   175    0.00845699
  1250   225    0.00944057
  1250   275     0.0108777
  1250   325     0.0116343
  1250   375     0.0133826
  1250   425     0.0153065
  1250   475     0.0161898
  1250   525     0.0166674
  1250   550     0.0172124
  1250   575     0.0171986
  1250   600     0.0161456
  1250   625     0.0155699
  1250   650     0.0142511
  1250   675     0.0134458
  1250   700     0.0115262
  1250   725     0.0103668
  1250   750    0.00906162
  1250   775    0.00720013
  1250   800     0.0060164
  1250   825    0.00517755
  1250   850    0.00375942
  1250   875    0.00332838
  1250   925    0.00193209
  1250   975   0.000891008
  1250  1025   0.000406246
  1275   550     0.0168327
  1275   575     0.0169417
  1275   600     0.0167582
  1275   625     0.0172228
  1275   650     0.0152364
  1275   675     0.0142343
  1275   700     0.0128759
  1275   725     0.0115528
  1275   750     0.0103988
  1275   775    0.00856918
  1275   800    0.00721174
  1275   825    0.00603293
  1275   850    0.00490453
  1300    25    0.00491088
  1300    75    0.00545611
  1300   125    0.00645009
  1300   175    0.00652582
  1300   225     0.0074807
  1300   275    0.00880143
  1300   325    0.00973994
  1300   375     0.0111616
  1300   425     0.0131001
  1300   475     0.0147875
  1300   525     0.0166256
  1300   550     0.0158178
  1300   575     0.0171156
  1300   600     0.0172331
  1300   625     0.0167047
  1300   650     0.0159689
  1300   675     0.0155023
  1300   700      0.014512
  1300   725     0.0127819
  1300   750     0.0114819
  1300   775    0.00978812
  1300   800    0.00888398
  1300   825    0.00758623
  1300   850     0.0059532
  1300   875    0.00497537
  1300   925    0.00314529
  1300   975    0.00191054
  1300  1025    0.00101815
  1300  1075   0.000339542
  1325   550     0.0165845
  1325   575     0.0161815
  1325   600     0.0167232
  1325   625     0.0171018
  1325   650     0.0170486
  1325   675     0.0164847
  1325   700     0.0150087
  1325   725     0.0143431
  1325   750     0.0127865
  1325   775     0.0121501
  1325   800     0.0103157
  1325   825    0.00881308
  1325   850    0.00741369
  1350    25    0.00392977
  1350    75    0.00421932
  1350   125      0.004992
  1350   175    0.00523596
  1350   225    0.00585362
  1350   275    0.00694792
  1350   325    0.00839471
  1350   375    0.00952317
  1350   425     0.0113583
  1350   475     0.0129538
  1350   525     0.0143353
  1350   550      0.015611
  1350   575     0.0159392
  1350   600     0.0164428
  1350   625     0.0171903
  1350   650     0.0173517
  1350   675     0.0166505
  1350   700      0.016224
  1350   725     0.0151085
  1350   750     0.0141232
  1350   775     0.0128687
  1350   800     0.0117342
  1350   825     0.0100018
  1350   850     0.0088268
  1350   875    0.00717423
  1350   925    0.00491282
  1350   975    0.00284335
  1350  1025    0.00153839
  1350  1075   0.000781681
  1350  1125   0.000297615
  1375   550     0.0147209
  1375   575     0.0152244
  1375   600     0.0162267
  1375   625     0.0161128
  1375   650     0.0166862
  1375   675     0.0166952
  1375   700      0.016378
  1375   725     0.0159112
  1375   750     0.0150025
  1375   775      0.014334
  1375   800     0.0133833
  1375   825     0.0118554
  1375   850     0.0101142
  1400    25    0.00357202
  1400    75    0.00354278
  1400   125    0.00399971
  1400   175    0.00439812
  1400   225    0.00524092
  1400   275     0.0057745
  1400   325    0.00664584
  1400   375    0.00756383
  1400   425    0.00922485
  1400   475     0.0106623
  1400   525     0.0127078
  1400   550     0.0139322
  1400   575     0.0150932
  1400   600     0.0154386
  1400   625     0.0156647
  1400   650     0.0164714
  1400   675     0.0175089
  1400   700     0.0167483
  1400   725     0.0166413
  1400   750     0.0164715
  1400   775     0.0155098
  1400   800     0.0138639
  1400   825     0.0127139
  1400   850     0.0114568
  1400   875     0.0100923
  1400   925     0.0074997
  1400   975    0.00482313
  1400  1025    0.00280134
  1400  1075    0.00167384
  1400  1125    0.00087148
  1400  1175   0.000291606
*/
