{
//=========Macro generated from canvas: c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf/c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf
//=========  (Sat Feb 22 16:28:33 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf = new TCanvas("c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf", "c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf",100,240,500,500);
   c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf->Range(0,0,1,1);
   c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf->SetFillColor(0);
   c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf->SetBorderMode(0);
   c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf->SetBorderSize(2);
   c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf->SetLogz();
   c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_6NJet8_1500HTinf_300MHTinf = new TH2D("h_EffAcc_6NJet8_1500HTinf_300MHTinf","h_EffAcc_6NJet8_1500HTinf_300MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(75,2.395819e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(77,7.503799e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(79,0.0001852604);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(81,0.0003713251);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(83,0.0003978294);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(85,0.0008900147);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(87,0.0009527301);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(89,0.000837537);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(91,0.001511019);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(93,0.002556011);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(95,0.002750072);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(97,0.003575051);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(99,0.004113906);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(101,0.005385182);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(103,0.006018182);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(199,4.768575e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(201,8.287349e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(203,0.0002591786);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(205,0.0002713493);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(207,0.0004439665);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(209,0.0006814164);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(211,0.000941794);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(213,0.001201177);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(215,0.001769714);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(217,0.00235318);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(219,0.002575231);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(221,0.003090358);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(223,0.003934941);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(225,0.004511485);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(227,0.006302324);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(323,2.401094e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(325,2.497674e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(327,0.000259384);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(329,0.0002170008);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(331,0.0002701033);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(333,0.0004817586);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(335,0.0007852095);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(337,0.001297082);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(339,0.001435382);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(341,0.002032667);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(343,0.002497042);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(345,0.003240426);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(347,0.003179723);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(349,0.004559175);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(351,0.005800339);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(447,4.79589e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(449,4.993197e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(451,0.0001326151);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(453,0.0001323896);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(455,0.000191475);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(457,0.0006531241);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(459,0.0007538326);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(461,0.001012132);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(463,0.001263625);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(465,0.002555987);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(467,0.002292971);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(469,0.002925196);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(471,0.003927701);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(473,0.004378344);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(475,0.005046297);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(573,4.984486e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(575,0.000103905);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(577,0.000185906);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(579,0.000220342);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(581,0.0004499971);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(583,0.0007235516);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(585,0.0008490185);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(587,0.001022407);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(589,0.001731777);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(591,0.002272715);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(593,0.002422165);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(595,0.003608376);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(597,0.003859506);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(599,0.005041566);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(695,2.386973e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(699,2.607825e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(701,0.0001585652);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(703,0.0001358114);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(705,0.0001898633);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(707,0.0005315816);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(709,0.0006225912);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(711,0.0009437371);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(713,0.001543377);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(715,0.001943397);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(717,0.002316934);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(719,0.002393141);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(721,0.003692023);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(723,0.005753044);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(821,2.502424e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(825,0.0001318064);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(827,8.129751e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(829,0.0001629134);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(831,0.0004775541);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(833,0.0004725799);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(835,0.0007988513);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(837,0.001072299);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(839,0.001645043);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(841,0.001989545);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(843,0.002556113);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(845,0.003315258);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(847,0.004192972);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(949,5.290472e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(951,5.41622e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(953,0.0001655998);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(955,0.0003048379);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(957,0.0002597425);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(959,0.0004882272);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(961,0.0005939522);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(963,0.001564268);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(965,0.001814667);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(967,0.002160574);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(969,0.003023996);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(971,0.003380709);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1073,2.665942e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1075,8.107629e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1077,0.0001682817);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1079,0.0001385418);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1081,0.0003404592);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1083,0.000325379);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1085,0.0008254715);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1087,0.0008114539);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1089,0.001421036);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1091,0.001761506);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1093,0.002357607);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1095,0.003575419);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1199,2.706268e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1201,2.745772e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1203,0.0001928757);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1205,0.000195174);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1207,0.0002670015);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1209,0.0005408319);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1211,0.000571857);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1213,0.0008482019);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1215,0.001343072);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1217,0.002215613);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1219,0.002883245);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1325,2.751992e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1327,0.000165798);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1329,0.0002887555);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1331,0.0001446309);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1333,0.0003407257);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1335,0.0005322082);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1337,0.0008243546);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1339,0.001320733);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1341,0.001281465);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1343,0.001861836);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1451,2.779892e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1453,5.534178e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1455,0.0001963073);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1457,0.0001962681);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1459,0.0002598276);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1461,0.0006001172);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1463,0.0009141335);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1465,0.001324609);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1467,0.001531728);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1577,2.806245e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1579,0.0001437313);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1581,0.0001410669);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1583,0.0002051436);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1585,0.0002913435);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1587,0.0004539868);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1589,0.0006528731);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1591,0.001562851);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1703,2.798979e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1705,0.0001410654);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1707,0.0002299594);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1709,0.0001500733);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1711,0.0002531944);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1713,0.0005220786);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1715,0.0007383517);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1829,2.878081e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1831,5.607414e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1833,0.0002527074);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1835,0.0002532692);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1837,0.0005644675);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1839,0.0003626296);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1955,2.79872e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1957,8.457285e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1959,0.0003657458);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1961,0.0002244866);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1963,0.0001745053);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2083,0.000141894);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2085,0.0001968469);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2087,0.0003931604);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2207,0.0001703762);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2209,0.0001120856);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2211,0.0001674905);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2333,2.850434e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2335,2.79414e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(75,2.395854e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(77,4.332518e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(79,7.009422e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(81,9.926315e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(83,0.000106562);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(85,0.0001576032);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(87,0.0001636268);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(89,0.0001561415);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(91,0.0002140938);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(93,0.0002733988);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(95,0.0002834222);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(97,0.0003222917);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(99,0.0003481708);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(101,0.0004048154);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(103,0.0004240388);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(199,3.37199e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(201,4.79683e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(203,8.197236e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(205,8.592397e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(207,0.0001111994);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(209,0.0001395502);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(211,0.0001643847);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(213,0.0001883731);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(215,0.0002353727);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(217,0.0002656347);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(219,0.000278644);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(221,0.0003056601);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(223,0.0003432686);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(225,0.000373068);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(227,0.0004306629);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(323,2.401129e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(325,2.497712e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(327,8.203736e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(329,7.679484e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(331,8.542812e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(333,0.0001172337);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(335,0.0001513274);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(337,0.0001917148);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(339,0.0002036438);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(341,0.0002457015);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(343,0.0002720176);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(345,0.0003074794);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(347,0.000305916);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(349,0.00036574);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(351,0.0004168837);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(447,3.391306e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(449,3.530831e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(451,5.938243e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(453,5.921119e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(455,7.244577e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(457,0.0001366031);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(459,0.0001481057);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(461,0.0001715494);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(463,0.0001930702);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(465,0.0002735108);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(467,0.0002608516);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(469,0.0002906203);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(471,0.0003381717);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(473,0.00035934);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(475,0.0003858934);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(573,3.524671e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(575,5.19558e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(577,7.027378e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(579,7.797738e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(581,0.0001127616);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(583,0.000144976);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(585,0.0001552409);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(587,0.0001733636);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(589,0.0002242028);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(591,0.0002616267);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(593,0.000263529);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(595,0.0003298237);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(597,0.0003361053);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(599,0.0003854249);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(695,2.387008e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(699,2.607867e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(701,6.474021e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(703,6.074171e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(705,7.176983e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(707,0.0001221768);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(709,0.0001329218);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(711,0.000164534);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(713,0.0002105993);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(715,0.0002363533);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(717,0.0002580972);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(719,0.0002636355);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(721,0.0003304362);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(723,0.0004133357);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(821,2.502462e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(825,5.89503e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(827,4.693945e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(829,6.651568e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(831,0.0001160512);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(833,0.0001146501);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(835,0.0001512321);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(837,0.0001767391);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(839,0.0002225877);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(841,0.0002438961);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(843,0.0002734251);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(845,0.0003103153);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(847,0.0003497853);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(949,3.741048e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(951,3.829971e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(953,6.761258e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(955,9.192899e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(957,8.670463e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(959,0.0001186792);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(961,0.0001366701);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(963,0.0002133937);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(965,0.0002291485);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(967,0.0002519678);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(969,0.000297645);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(971,0.0003151754);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1073,2.665986e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1075,4.681171e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1077,6.87077e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1079,6.196296e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1081,9.852672e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1083,9.841809e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1085,0.0001563481);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1087,0.000153755);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1089,0.0002012324);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1091,0.0002299185);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1093,0.0002659806);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1095,0.0003224155);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1199,2.706313e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1201,2.745818e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1203,7.290863e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1205,7.377751e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1207,8.927405e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1209,0.000127568);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1211,0.0001315705);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1213,0.0001549388);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1215,0.0001986166);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1217,0.0002531573);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1219,0.0002908638);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1325,2.752038e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1327,6.76935e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1329,9.132841e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1331,6.468656e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1333,9.843647e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1335,0.000122136);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1337,0.0001532617);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1339,0.0001997467);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1341,0.0001959243);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1343,0.0002314695);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1451,2.779938e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1453,3.913385e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1455,7.420597e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1457,7.419114e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1459,8.668754e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1461,0.0001311841);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1463,0.000161836);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1465,0.0001978141);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1467,0.0002129669);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1577,2.806292e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1579,6.428417e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1581,6.309237e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1583,7.754656e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1585,9.214704e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1587,0.0001135277);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1589,0.0001427208);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1591,0.0002111546);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1703,2.799026e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1705,6.309171e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1707,8.131417e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1709,6.712086e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1711,8.441097e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1713,0.0001233759);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1715,0.0001449939);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1829,2.878131e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1831,3.965175e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1833,8.424861e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1835,8.443593e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1837,0.0001262616);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1839,0.0001005973);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1955,2.798767e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1957,4.883065e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1959,0.0001014619);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1961,7.93787e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1963,7.141208e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2083,6.346236e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2085,7.440995e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2087,0.0001051014);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2207,6.956291e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2209,5.604659e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2211,6.838457e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2333,2.850483e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2335,2.794187e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetEntries(7675.513);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetLineColor(ci);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->Draw("colz");
   c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf->Modified();
   c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf->cd();
   c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf->SetSelected(c_AccEffMap_T2qq_6NJet8_1500HTinf_300MHTinf);
}
/*
Topology ~q ~q ; ~q ->q+LSP

mSquark(GeV) mLSP(GeV) AccXEff
   300     0   2.39582e-05
   300    50   4.76858e-05
   300   100   2.40109e-05
   300   150   4.79589e-05
   300   250   2.38697e-05
   350     0    7.5038e-05
   350    50   8.28735e-05
   350   100   2.49767e-05
   350   150    4.9932e-05
   350   200   4.98449e-05
   350   300   2.50242e-05
   400     0    0.00018526
   400    50   0.000259179
   400   100   0.000259384
   400   150   0.000132615
   400   200   0.000103905
   400   250   2.60783e-05
   450     0   0.000371325
   450    50   0.000271349
   450   100   0.000217001
   450   150    0.00013239
   450   200   0.000185906
   450   250   0.000158565
   450   300   0.000131806
   450   350   5.29047e-05
   450   400   2.66594e-05
   500     0   0.000397829
   500    50   0.000443967
   500   100   0.000270103
   500   150   0.000191475
   500   200   0.000220342
   500   250   0.000135811
   500   300   8.12975e-05
   500   350   5.41622e-05
   500   400   8.10763e-05
   500   450   2.70627e-05
   550     0   0.000890015
   550    50   0.000681416
   550   100   0.000481759
   550   150   0.000653124
   550   200   0.000449997
   550   250   0.000189863
   550   300   0.000162913
   550   350     0.0001656
   550   400   0.000168282
   550   450   2.74577e-05
   550   500   2.75199e-05
   600     0    0.00095273
   600    50   0.000941794
   600   100    0.00078521
   600   150   0.000753833
   600   200   0.000723552
   600   250   0.000531582
   600   300   0.000477554
   600   350   0.000304838
   600   400   0.000138542
   600   450   0.000192876
   600   500   0.000165798
   600   550   2.77989e-05
   650     0   0.000837537
   650    50    0.00120118
   650   100    0.00129708
   650   150    0.00101213
   650   200   0.000849019
   650   250   0.000622591
   650   300    0.00047258
   650   350   0.000259743
   650   400   0.000340459
   650   450   0.000195174
   650   500   0.000288755
   650   550   5.53418e-05
   650   600   2.80624e-05
   700     0    0.00151102
   700    50    0.00176971
   700   100    0.00143538
   700   150    0.00126362
   700   200    0.00102241
   700   250   0.000943737
   700   300   0.000798851
   700   350   0.000488227
   700   400   0.000325379
   700   450   0.000267002
   700   500   0.000144631
   700   550   0.000196307
   700   600   0.000143731
   700   650   2.79898e-05
   750     0    0.00255601
   750    50    0.00235318
   750   100    0.00203267
   750   150    0.00255599
   750   200    0.00173178
   750   250    0.00154338
   750   300     0.0010723
   750   350   0.000593952
   750   400   0.000825471
   750   450   0.000540832
   750   500   0.000340726
   750   550   0.000196268
   750   600   0.000141067
   750   650   0.000141065
   750   700   2.87808e-05
   800     0    0.00275007
   800    50    0.00257523
   800   100    0.00249704
   800   150    0.00229297
   800   200    0.00227271
   800   250     0.0019434
   800   300    0.00164504
   800   350    0.00156427
   800   400   0.000811454
   800   450   0.000571857
   800   500   0.000532208
   800   550   0.000259828
   800   600   0.000205144
   800   650   0.000229959
   800   700   5.60741e-05
   800   750   2.79872e-05
   850     0    0.00357505
   850    50    0.00309036
   850   100    0.00324043
   850   150     0.0029252
   850   200    0.00242216
   850   250    0.00231693
   850   300    0.00198955
   850   350    0.00181467
   850   400    0.00142104
   850   450   0.000848202
   850   500   0.000824355
   850   550   0.000600117
   850   600   0.000291343
   850   650   0.000150073
   850   700   0.000252707
   850   750   8.45729e-05
   900     0    0.00411391
   900    50    0.00393494
   900   100    0.00317972
   900   150     0.0039277
   900   200    0.00360838
   900   250    0.00239314
   900   300    0.00255611
   900   350    0.00216057
   900   400    0.00176151
   900   450    0.00134307
   900   500    0.00132073
   900   550   0.000914133
   900   600   0.000453987
   900   650   0.000253194
   900   700   0.000253269
   900   750   0.000365746
   900   800   0.000141894
   900   850   0.000170376
   950     0    0.00538518
   950    50    0.00451149
   950   100    0.00455917
   950   150    0.00437834
   950   200    0.00385951
   950   250    0.00369202
   950   300    0.00331526
   950   350      0.003024
   950   400    0.00235761
   950   450    0.00221561
   950   500    0.00128147
   950   550    0.00132461
   950   600   0.000652873
   950   650   0.000522079
   950   700   0.000564467
   950   750   0.000224487
   950   800   0.000196847
   950   850   0.000112086
   950   900   2.85043e-05
  1000     0    0.00601818
  1000    50    0.00630232
  1000   100    0.00580034
  1000   150     0.0050463
  1000   200    0.00504157
  1000   250    0.00575304
  1000   300    0.00419297
  1000   350    0.00338071
  1000   400    0.00357542
  1000   450    0.00288325
  1000   500    0.00186184
  1000   550    0.00153173
  1000   600    0.00156285
  1000   650   0.000738352
  1000   700    0.00036263
  1000   750   0.000174505
  1000   800    0.00039316
  1000   850    0.00016749
  1000   900   2.79414e-05
*/
