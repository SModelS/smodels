{
//=========Macro generated from canvas: c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf/c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf
//=========  (Sat Feb 22 16:28:33 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf = new TCanvas("c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf", "c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf",125,360,500,500);
   c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf->SetFillColor(0);
   c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf->SetLogz();
   c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1500HTinf_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1500HTinf_200MHTinf","h_EffAcc_8NJetinf_1500HTinf_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(75,2.395819e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(79,5.200293e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(83,0.0001203957);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(85,0.0001163865);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(87,0.0001106619);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(89,0.0001430792);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(91,0.0001566983);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(93,0.0001125841);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(95,0.0003426719);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(97,0.0003534406);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(99,0.0003174038);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(101,0.0003348859);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(103,0.0004238156);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(199,2.980359e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(201,5.003682e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(203,2.591786e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(205,2.64731e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(207,5.401874e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(209,8.238788e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(211,0.0001731239);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(213,0.0002085981);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(215,0.0002086399);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(217,0.0002610616);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(219,0.0002130849);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(221,0.0002975359);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(223,0.0003213272);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(225,0.0003045117);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(227,0.000694471);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(327,5.187681e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(329,8.012339e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(331,0.0001654383);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(333,8.602831e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(335,0.0001142123);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(337,0.0001177591);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(339,0.0001948639);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(341,0.000112828);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(343,0.000236302);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(345,0.0001121618);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(347,0.0005893605);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(349,0.0002116073);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(351,0.0003616348);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(453,5.626559e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(455,5.710658e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(457,5.499992e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(459,2.858133e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(461,5.622953e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(463,8.664854e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(465,0.0001725115);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(467,0.0002857395);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(469,0.0002872647);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(471,0.0001442326);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(473,0.000525331);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(475,0.00053036);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(571,2.680909e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(575,7.792878e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(577,7.9674e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(579,3.389876e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(581,2.748074e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(583,6.059299e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(585,8.420019e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(587,0.0001157442);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(589,0.0001441682);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(591,0.0002716392);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(593,0.0003714335);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(595,0.0003222397);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(597,0.0004247388);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(599,0.0004941681);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(701,2.642754e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(703,2.716229e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(705,0.0001084933);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(707,8.284389e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(709,0.0001430041);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(711,0.0001473493);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(713,0.0003383221);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(715,0.0001727077);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(717,0.0001971859);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(719,0.000347137);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(721,0.0003247286);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(723,0.0005342617);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(827,5.758573e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(829,3.054627e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(831,9.34345e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(833,2.779882e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(835,0.0001196517);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(837,0.0001415576);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(839,0.0002352647);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(841,8.65804e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(843,0.0002137454);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(845,0.0003662101);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(847,0.0004293265);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(951,5.41622e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(957,9.126089e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(959,8.781065e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(961,9.555698e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(963,0.0002333145);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(965,8.497952e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(967,0.0002268691);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(969,0.0001445033);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(971,0.0004022973);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1079,3.290368e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1081,0.000138963);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1085,5.780107e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1087,0.0001417387);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1089,0.0001729957);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1091,0.000249287);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1093,0.0001169665);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1095,0.0002969267);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1199,2.706268e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1203,2.755367e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1209,0.000149195);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1211,0.0001742802);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1213,8.482019e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1215,8.835999e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1217,0.0002046267);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1219,0.0002254462);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1329,5.77511e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1335,5.602192e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1337,8.418941e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1339,0.0001487639);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1341,0.0001445941);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1343,0.0002662285);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1455,2.80439e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1457,2.80383e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1459,8.542278e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1461,5.648162e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1463,0.0001133809);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1465,0.0002068568);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1467,0.0001190743);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1579,2.874627e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1581,2.821337e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1587,5.674835e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1589,6.144688e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1591,0.0001157667);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1703,2.798979e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1713,0.0001203435);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1715,8.418261e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1829,2.878081e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1835,5.628204e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1837,2.822337e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1839,8.891399e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1963,5.640575e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2083,2.837881e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2085,5.624198e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2087,5.967613e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2211,2.791508e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2335,5.58828e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(75,2.395854e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(79,3.677278e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(83,6.037238e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(85,5.849837e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(87,5.533466e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(89,6.406845e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(91,7.020298e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(93,5.629586e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(95,9.91075e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(97,0.0001023356);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(99,9.595467e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(101,0.0001014221);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(103,0.0001137046);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(199,2.980403e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(201,3.538246e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(203,2.591826e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(205,2.647353e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(207,3.819827e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(209,4.756903e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(211,7.079761e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(213,7.928867e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(215,7.88684e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(217,8.70342e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(219,8.074229e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(221,9.424894e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(223,9.722809e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(225,9.661155e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(227,0.0001421265);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(327,3.66836e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(329,4.626151e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(331,6.761679e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(333,4.975035e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(335,5.711008e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(337,5.898527e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(339,7.36603e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(341,5.641784e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(343,8.384465e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(345,5.608471e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(347,0.0001320445);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(349,8.032194e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(351,0.0001048368);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(453,3.985583e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(455,4.045156e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(457,3.889211e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(459,2.858182e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(461,3.976163e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(463,5.002917e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(465,7.050799e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(467,9.043604e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(469,9.096439e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(471,6.458494e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(473,0.0001240869);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(475,0.0001253936);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(571,2.680948e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(575,4.499433e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(577,4.600203e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(579,3.389932e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(581,2.748119e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(583,4.292125e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(585,4.861547e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(587,5.795566e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(589,6.455611e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(591,9.081375e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(593,0.0001032029);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(595,9.744655e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(597,0.0001097472);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(599,0.0001202728);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(701,2.642796e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(703,2.716273e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(705,5.425022e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(707,4.783234e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(709,6.403481e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(711,6.601414e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(713,9.774194e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(715,7.067637e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(717,7.45381e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(719,0.0001004598);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(721,9.808943e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(723,0.0001301819);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(827,4.079099e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(829,3.054677e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(831,5.394714e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(833,2.779929e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(835,6.013963e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(837,6.331188e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(839,8.32591e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(841,4.998982e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(843,8.113364e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(845,0.0001015908);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(847,0.000111088);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(951,3.829971e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(957,5.300302e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(959,5.078113e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(961,5.536339e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(963,8.261388e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(965,4.906546e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(967,8.022128e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(969,6.470616e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(971,0.0001076432);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1079,3.290423e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1081,6.215133e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1085,4.087295e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1087,6.339287e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1089,7.07059e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1091,8.860489e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1093,5.848739e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1095,9.42552e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1199,2.706313e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1203,2.755412e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1209,6.672802e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1211,7.115707e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1213,4.897346e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1215,5.109882e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1217,7.762616e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1219,7.971806e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1329,4.083762e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1335,3.961481e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1337,4.860924e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1339,6.661414e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1341,6.467006e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1343,8.909816e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1455,2.804438e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1457,2.803877e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1459,4.93214e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1461,3.993989e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1463,5.669431e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1465,7.826621e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1467,5.96232e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1579,2.874677e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1581,2.821385e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1587,4.012852e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1589,4.345111e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1591,5.796694e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1703,2.799026e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1713,6.027987e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1715,4.860531e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1829,2.878131e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1835,3.979876e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1837,2.822385e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1839,5.151441e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1963,3.988624e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2083,2.837929e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2085,3.977043e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2087,4.227176e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2211,2.791554e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2335,3.951643e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetEntries(789.9417);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->Draw("colz");
   c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf->Modified();
   c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf->cd();
   c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf->SetSelected(c_AccEffMap_T2qq_8NJetinf_1500HTinf_200MHTinf);
}
/*
Topology ~q ~q ; ~q ->q+LSP

mSquark(GeV) mLSP(GeV) AccXEff
   300     0   2.39582e-05
   300    50   2.98036e-05
   300   200   2.68091e-05
   350    50   5.00368e-05
   400     0   5.20029e-05
   400    50   2.59179e-05
   400   100   5.18768e-05
   400   200   7.79288e-05
   450    50   2.64731e-05
   450   100   8.01234e-05
   450   150   5.62656e-05
   450   200    7.9674e-05
   450   250   2.64275e-05
   500     0   0.000120396
   500    50   5.40187e-05
   500   100   0.000165438
   500   150   5.71066e-05
   500   200   3.38988e-05
   500   250   2.71623e-05
   500   300   5.75857e-05
   500   350   5.41622e-05
   500   450   2.70627e-05
   550     0   0.000116387
   550    50   8.23879e-05
   550   100   8.60283e-05
   550   150   5.49999e-05
   550   200   2.74807e-05
   550   250   0.000108493
   550   300   3.05463e-05
   600     0   0.000110662
   600    50   0.000173124
   600   100   0.000114212
   600   150   2.85813e-05
   600   200    6.0593e-05
   600   250   8.28439e-05
   600   300   9.34345e-05
   600   400   3.29037e-05
   600   450   2.75537e-05
   650     0   0.000143079
   650    50   0.000208598
   650   100   0.000117759
   650   150   5.62295e-05
   650   200   8.42002e-05
   650   250   0.000143004
   650   300   2.77988e-05
   650   350   9.12609e-05
   650   400   0.000138963
   650   500   5.77511e-05
   700     0   0.000156698
   700    50    0.00020864
   700   100   0.000194864
   700   150   8.66485e-05
   700   200   0.000115744
   700   250   0.000147349
   700   300   0.000119652
   700   350   8.78107e-05
   700   550   2.80439e-05
   700   600   2.87463e-05
   700   650   2.79898e-05
   750     0   0.000112584
   750    50   0.000261062
   750   100   0.000112828
   750   150   0.000172512
   750   200   0.000144168
   750   250   0.000338322
   750   300   0.000141558
   750   350    9.5557e-05
   750   400   5.78011e-05
   750   450   0.000149195
   750   550   2.80383e-05
   750   600   2.82134e-05
   750   700   2.87808e-05
   800     0   0.000342672
   800    50   0.000213085
   800   100   0.000236302
   800   150   0.000285739
   800   200   0.000271639
   800   250   0.000172708
   800   300   0.000235265
   800   350   0.000233314
   800   400   0.000141739
   800   450    0.00017428
   800   500   5.60219e-05
   800   550   8.54228e-05
   850     0   0.000353441
   850    50   0.000297536
   850   100   0.000112162
   850   150   0.000287265
   850   200   0.000371433
   850   250   0.000197186
   850   300   8.65804e-05
   850   350   8.49795e-05
   850   400   0.000172996
   850   450   8.48202e-05
   850   500   8.41894e-05
   850   550   5.64816e-05
   900     0   0.000317404
   900    50   0.000321327
   900   100    0.00058936
   900   150   0.000144233
   900   200    0.00032224
   900   250   0.000347137
   900   300   0.000213745
   900   350   0.000226869
   900   400   0.000249287
   900   450     8.836e-05
   900   500   0.000148764
   900   550   0.000113381
   900   600   5.67484e-05
   900   700    5.6282e-05
   900   800   2.83788e-05
   950     0   0.000334886
   950    50   0.000304512
   950   100   0.000211607
   950   150   0.000525331
   950   200   0.000424739
   950   250   0.000324729
   950   300    0.00036621
   950   350   0.000144503
   950   400   0.000116967
   950   450   0.000204627
   950   500   0.000144594
   950   550   0.000206857
   950   600   6.14469e-05
   950   650   0.000120344
   950   700   2.82234e-05
   950   800    5.6242e-05
  1000     0   0.000423816
  1000    50   0.000694471
  1000   100   0.000361635
  1000   150    0.00053036
  1000   200   0.000494168
  1000   250   0.000534262
  1000   300   0.000429327
  1000   350   0.000402297
  1000   400   0.000296927
  1000   450   0.000225446
  1000   500   0.000266228
  1000   550   0.000119074
  1000   600   0.000115767
  1000   650   8.41826e-05
  1000   700    8.8914e-05
  1000   750   5.64058e-05
  1000   800   5.96761e-05
  1000   850   2.79151e-05
  1000   900   5.58828e-05
*/
