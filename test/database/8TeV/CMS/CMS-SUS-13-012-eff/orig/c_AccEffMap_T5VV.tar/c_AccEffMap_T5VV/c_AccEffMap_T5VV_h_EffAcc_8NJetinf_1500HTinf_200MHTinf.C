{
//=========Macro generated from canvas: c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf/c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf
//=========  (Sat Feb 22 16:32:54 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf = new TCanvas("c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf", "c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf",125,360,500,500);
   c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf->SetFillColor(0);
   c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf->SetLogz();
   c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1500HTinf_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1500HTinf_200MHTinf","h_EffAcc_8NJetinf_1500HTinf_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(141,0.0001939146);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(143,0.0004995278);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(145,0.0008176686);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(147,0.001428492);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(149,0.002030029);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(151,0.003495592);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(153,0.004897272);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(155,0.007381016);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(157,0.00969608);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(159,0.01272151);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(161,0.01724651);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(163,0.02139257);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(165,0.02538811);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(167,0.03034117);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(169,0.03647547);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(171,0.04127817);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(173,0.04505287);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(175,0.05173948);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(177,0.05519692);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(179,0.06060374);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(181,0.06334798);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(265,0.0001495603);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(267,0.0003545575);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(269,0.0006353072);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(271,0.001207345);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(273,0.001844175);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(275,0.002961445);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(277,0.004419561);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(279,0.006096421);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(281,0.008883165);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(283,0.01094205);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(285,0.01514351);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(287,0.01897549);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(289,0.02355603);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(291,0.02727111);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(293,0.03337825);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(295,0.03772156);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(297,0.04281636);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(299,0.04759372);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(301,0.0534499);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(303,0.05793025);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(305,0.06041046);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(389,9.244621e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(391,0.0002165198);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(393,0.0004871963);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(395,0.0008086757);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(397,0.001572698);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(399,0.002255975);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(401,0.00349901);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(403,0.005302803);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(405,0.007256819);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(407,0.009978156);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(409,0.01335959);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(411,0.01673043);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(413,0.02019548);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(415,0.02488727);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(417,0.02962016);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(419,0.03506684);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(421,0.04037021);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(423,0.04466971);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(425,0.04858034);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(427,0.05284592);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(429,0.05684775);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(513,4.968979e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(515,0.0001529766);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(517,0.0003115587);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(519,0.0005583509);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(521,0.001125075);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(523,0.001774529);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(525,0.002787303);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(527,0.004091383);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(529,0.005894234);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(531,0.008144475);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(533,0.01093869);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(535,0.01323079);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(537,0.01801392);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(539,0.02208221);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(541,0.02645831);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(543,0.03096123);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(545,0.03647176);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(547,0.04098491);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(549,0.04622314);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(551,0.05055479);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(553,0.05346289);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(639,0.0001177905);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(641,0.0001833944);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(643,0.0003389375);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(645,0.0007892862);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(647,0.001132855);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(649,0.001965279);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(651,0.002979541);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(653,0.004213409);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(655,0.006024344);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(657,0.008545378);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(659,0.01101235);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(661,0.01417055);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(663,0.01853598);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(665,0.02225865);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(667,0.02720446);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(669,0.03118788);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(671,0.03697714);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(673,0.04240037);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(675,0.04739663);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(677,0.05038504);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(765,3.003102e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(767,0.0002845524);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(769,0.0004552465);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(771,0.0007732372);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(773,0.001540567);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(775,0.002161569);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(777,0.002893899);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(779,0.004664176);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(781,0.007044433);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(783,0.008869361);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(785,0.01197957);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(787,0.01571726);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(789,0.01842269);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(791,0.02374725);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(793,0.02739454);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(795,0.03206714);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(797,0.03751617);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(799,0.04210864);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(801,0.04686203);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(891,0.0001778054);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(893,0.0002299223);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(895,0.0006357953);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(897,0.000928755);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(899,0.001421614);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(901,0.002265569);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(903,0.003404063);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(905,0.005022645);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(907,0.006505947);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(909,0.009073984);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(911,0.01213421);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(913,0.01533835);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(915,0.0191633);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(917,0.02303865);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(919,0.02788435);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(921,0.0323627);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(923,0.0369285);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(925,0.04194739);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1017,0.0001318483);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1019,0.0003366426);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1021,0.0005617693);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1023,0.0008827057);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1025,0.001560965);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1027,0.002036075);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1029,0.003341004);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1031,0.005103658);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1033,0.006544828);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1035,0.009157801);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1037,0.01229293);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1039,0.01586566);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1041,0.02030515);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1043,0.02307364);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1045,0.02801053);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1047,0.03294729);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1049,0.03727678);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1143,9.049292e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1145,0.000343985);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1147,0.0006408406);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1149,0.0009952073);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1151,0.001574336);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1153,0.002377596);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1155,0.003486138);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1157,0.004973835);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1159,0.007062873);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1161,0.00946437);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1163,0.01233964);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1165,0.01538434);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1167,0.01894687);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1169,0.02379111);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1171,0.02823589);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1173,0.03266118);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1269,0.0001684698);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1271,0.0003124845);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1273,0.000523102);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1275,0.001075606);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1277,0.001596324);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1279,0.002414529);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1281,0.003584272);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1283,0.004840476);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1285,0.007212062);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1287,0.008972016);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1289,0.01219939);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1291,0.01565897);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1293,0.0197744);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1295,0.02401191);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1297,0.02752087);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1395,0.0001531115);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1397,0.0003535645);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1399,0.000595832);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1401,0.0009325195);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1403,0.001365915);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1405,0.002512338);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1407,0.003375879);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1409,0.004906506);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1411,0.00706193);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1413,0.009405026);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1415,0.01191042);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1417,0.01601039);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1419,0.01933396);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1421,0.02325833);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1473,0.005986304);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1474,0.006687576);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1475,0.00780281);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1476,0.00905562);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1477,0.01077263);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1478,0.01188678);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1479,0.01368924);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1480,0.01577055);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1481,0.01714493);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1482,0.01919171);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1483,0.02118607);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1521,0.0002123914);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1523,0.0003655306);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1525,0.0005903314);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1527,0.0009316368);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1529,0.001494716);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1531,0.002412215);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1533,0.003697106);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1535,0.004904693);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1536,0.005668307);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1537,0.006956053);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1538,0.008086033);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1539,0.009198476);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1540,0.0105456);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1541,0.01166147);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1542,0.0131559);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1543,0.01549435);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1544,0.01743653);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1545,0.01871236);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1597,0.003886743);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1598,0.004698202);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1599,0.005901579);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1600,0.006528542);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1601,0.007915763);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1602,0.009077443);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1603,0.01008002);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1604,0.01189878);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1605,0.01327561);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1606,0.01469162);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1607,0.01709112);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1647,8.575364e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1649,0.0003234713);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1651,0.0004188253);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1653,0.001058645);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1655,0.001615044);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1657,0.002600416);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1659,0.003075224);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1660,0.003881222);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1661,0.004549078);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1662,0.005381062);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1663,0.006601942);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1664,0.007435747);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1665,0.00936125);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1666,0.01065419);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1667,0.01196445);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1668,0.01312499);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1669,0.01461829);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1721,0.002663288);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1722,0.003416433);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1723,0.003821183);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1724,0.004738448);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1725,0.00582593);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1726,0.006402262);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1727,0.007430415);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1728,0.008752062);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1729,0.01032514);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1730,0.01128566);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1731,0.01301877);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1773,0.0001398148);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1775,0.0003059329);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1777,0.0004844154);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1779,0.0009342295);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1781,0.001545656);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1783,0.002304051);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1784,0.002689511);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1785,0.003327494);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1786,0.003833049);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1787,0.004464182);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1788,0.005157176);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1789,0.006326008);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1790,0.007477148);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1791,0.008639047);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1792,0.01035131);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1793,0.01159314);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1845,0.00165118);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1846,0.002076798);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1847,0.002917596);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1848,0.003127575);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1849,0.003752035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1850,0.004610535);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1851,0.005540289);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1852,0.006315631);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1853,0.007175116);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1854,0.008460465);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1855,0.009744842);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1899,0.0001348512);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1901,0.0003251127);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1903,0.0005550134);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1905,0.0009006878);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1907,0.001505555);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1908,0.001650719);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1909,0.002261135);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1910,0.002611262);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1911,0.002983873);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1912,0.003710281);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1913,0.004493786);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1914,0.005595388);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1915,0.005790384);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1916,0.00744802);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1917,0.008085356);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1969,0.001116752);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1970,0.001368164);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1971,0.001641569);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1972,0.001999927);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1973,0.002377876);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1974,0.002886211);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1975,0.003606757);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1976,0.004362786);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1977,0.005079257);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1978,0.006442099);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(1979,0.006851681);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2025,0.0001548062);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2027,0.000345573);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2029,0.0005856364);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2031,0.0009219216);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2032,0.001008949);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2033,0.001269894);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2034,0.001742333);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2035,0.002059787);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2036,0.00241094);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2037,0.002876962);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2038,0.003661341);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2039,0.004190223);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2040,0.005162194);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2041,0.005871588);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2093,0.0006896571);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2094,0.0007243062);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2095,0.001215695);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2096,0.001366563);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2097,0.001688771);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2098,0.001839061);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2099,0.002426751);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2100,0.002708222);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2101,0.003553749);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2102,0.004102296);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2103,0.005121086);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2151,0.0001472824);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2153,0.0002393204);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2155,0.0004034282);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2156,0.0006049049);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2157,0.0008939464);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2158,0.001036531);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2159,0.001344609);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2160,0.001473721);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2161,0.001983978);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2162,0.00244415);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2163,0.003042919);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2164,0.003610189);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2165,0.003919839);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2217,0.0003746917);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2218,0.0005412931);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2219,0.0007416644);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2220,0.0007806806);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2221,0.001018497);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2222,0.001432182);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2223,0.001584863);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2224,0.001886409);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2225,0.00250082);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2226,0.002769068);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2227,0.003548515);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2277,0.0001261411);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2279,0.000313646);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2281,0.0004867716);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2283,0.0008162836);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2285,0.001140479);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2287,0.001950555);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2289,0.00312254);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2403,0.0001675852);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2405,0.0002441584);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2407,0.0003573045);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2409,0.0006928929);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2411,0.001189191);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2413,0.001959337);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2529,0.000109813);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2531,0.0002570907);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2533,0.0004104529);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2535,0.0008902293);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2537,0.001241694);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2655,8.628236e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2657,0.000193044);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2659,0.0003575148);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2661,0.0006215855);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2781,8.332331e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2783,0.000246927);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2785,0.0004181771);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2907,5.508554e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(2909,0.000152217);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinContent(3033,8.972486e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(141,3.88394e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(143,6.118938e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(145,8.322474e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(147,0.0001050615);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(149,0.0001252335);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(151,0.000171799);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(153,0.0002087099);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(155,0.0002431344);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(157,0.0002817039);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(159,0.0003177988);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(161,0.0003756291);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(163,0.000460724);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(165,0.0004977508);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(167,0.0004819411);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(169,0.0005367285);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(171,0.0005604507);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(173,0.0005857071);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(175,0.000626599);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(177,0.000644704);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(179,0.0006745819);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(181,0.0006851865);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(265,3.433915e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(267,5.185634e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(269,6.901583e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(271,9.571885e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(273,0.0001187537);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(275,0.0001578406);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(277,0.0001838752);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(279,0.0002211468);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(281,0.0002656853);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(283,0.0003226137);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(285,0.0003477057);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(287,0.0004055281);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(289,0.0004244388);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(291,0.000455755);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(293,0.000516564);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(295,0.0005343221);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(297,0.0005692242);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(299,0.0005980673);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(301,0.0006334891);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(303,0.0006567365);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(305,0.0006663794);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(389,2.564141e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(391,4.175625e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(393,6.095675e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(395,7.798803e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(397,0.0001113095);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(399,0.0001318311);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(401,0.0001636046);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(403,0.0002016797);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(405,0.00023507);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(407,0.0003007125);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(409,0.0003453669);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(411,0.0003579718);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(413,0.0004765728);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(415,0.0004402098);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(417,0.0005269097);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(419,0.0005121013);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(421,0.0005506165);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(423,0.0005771786);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(425,0.0006017412);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(427,0.0006255263);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(429,0.0006447227);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(513,1.878154e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(515,3.606027e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(517,4.869169e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(519,6.457054e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(521,9.30215e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(523,0.0001156059);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(525,0.0001568972);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(527,0.0001774452);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(529,0.0002113584);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(531,0.000251275);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(533,0.0002953899);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(535,0.0003178919);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(537,0.0003678618);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(539,0.0004932279);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(541,0.0004490809);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(543,0.0004793278);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(545,0.0005200072);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(547,0.0005688473);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(549,0.0005850261);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(551,0.0006104932);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(553,0.0006249358);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(639,2.947409e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(641,3.75016e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(643,5.116376e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(645,7.754002e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(647,9.734718e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(649,0.0001277789);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(651,0.00015231);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(653,0.0001776752);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(655,0.000242453);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(657,0.0002628382);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(659,0.0002858565);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(661,0.000328701);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(663,0.0003802417);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(665,0.0004149309);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(667,0.0004487098);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(669,0.0004792989);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(671,0.0005257784);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(673,0.0005582899);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(675,0.0005883843);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(677,0.000604055);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(765,1.501578e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(767,4.617758e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(769,5.837806e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(771,7.594336e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(773,0.0001089326);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(775,0.0001289064);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(777,0.0001535284);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(779,0.0001965772);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(781,0.0002498993);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(783,0.0002559525);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(785,0.0002971737);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(787,0.000339562);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(789,0.0003683489);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(791,0.000415903);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(793,0.0004466219);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(795,0.0004827555);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(797,0.0005232055);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(799,0.0005518503);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(801,0.0005797864);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(891,3.629827e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(893,4.203371e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(895,6.865402e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(897,8.424437e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(899,0.0001022755);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(901,0.0001417878);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(903,0.0001631887);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(905,0.0001917019);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(907,0.0002179885);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(909,0.0002694867);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(911,0.0002962777);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(913,0.0003789658);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(915,0.0003711662);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(917,0.0004070938);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(919,0.0004484709);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(921,0.0004816924);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(923,0.000512827);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(925,0.0005468804);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1017,3.107941e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1019,4.96535e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1021,6.447578e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1023,8.073124e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1025,0.0001085272);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1027,0.0001383406);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1029,0.0001552502);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1031,0.0001916545);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1033,0.000248899);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1035,0.0003009089);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1037,0.000296014);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1039,0.0003361982);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1041,0.0003800447);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1043,0.0004042532);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1045,0.0004474881);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1047,0.0004822192);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1049,0.0005128663);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1143,2.612448e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1145,5.129752e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1147,6.838031e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1149,8.581605e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1151,0.0001066625);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1153,0.0001347679);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1155,0.0002348009);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1157,0.0001885092);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1159,0.0002336879);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1161,0.0002788496);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1163,0.0002945479);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1165,0.0003284641);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1167,0.0003647069);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1169,0.0004082463);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1171,0.0004451319);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1173,0.0004765393);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1269,3.514323e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1271,4.885463e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1273,6.12753e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1275,8.920285e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1277,0.0001068568);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1279,0.0001583319);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1281,0.0001687132);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1283,0.000187169);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1285,0.0002241179);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1287,0.0002488738);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1289,0.0002907899);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1291,0.0003297575);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1293,0.0003701292);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1295,0.0004074878);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1297,0.0004489579);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1395,3.518266e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1397,5.056462e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1399,6.588982e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1401,8.489387e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1403,9.831564e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1405,0.0001458205);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1407,0.0001531582);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1409,0.000189835);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1411,0.0002200824);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1413,0.0002531324);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1415,0.0002847139);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1417,0.0003310449);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1419,0.000363313);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1421,0.000400658);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1473,0.0002016543);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1474,0.0002155237);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1475,0.0002359921);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1476,0.0002643852);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1477,0.0002803092);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1478,0.0003098501);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1479,0.0003225191);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1480,0.0003489556);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1481,0.0003515259);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1482,0.0003813994);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1483,0.0004000537);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1521,3.946455e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1523,5.125116e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1525,6.562195e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1527,8.093867e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1529,0.0001016689);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1531,0.0001287676);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1533,0.0001638915);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1535,0.0001823588);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1536,0.000298472);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1537,0.0002295323);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1538,0.0002335633);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1539,0.0002492974);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1540,0.0002885127);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1541,0.0002803315);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1542,0.0003250215);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1543,0.000325079);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1544,0.0003431147);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1545,0.0003624562);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1597,0.0001637561);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1598,0.0001792504);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1599,0.0002035992);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1600,0.0002153444);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1601,0.0002301541);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1602,0.0002464962);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1603,0.0002591202);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1604,0.0003215295);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1605,0.0003017665);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1606,0.0003305537);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1607,0.0003398519);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1647,2.475623e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1649,4.823779e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1651,5.408379e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1653,8.543268e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1655,0.0001048952);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1657,0.0001418969);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1659,0.0001432474);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1660,0.0001613185);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1661,0.0001815061);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1662,0.0001973593);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1663,0.0002127161);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1664,0.0002219118);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1665,0.0002593051);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1666,0.0002787127);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1667,0.0002923164);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1668,0.0002950699);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1669,0.000346807);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1721,0.0001333065);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1722,0.0001515063);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1723,0.0002059464);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1724,0.0001827709);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1725,0.0002053884);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1726,0.0002060942);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1727,0.0002484886);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1728,0.0002419687);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1729,0.0002666562);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1730,0.0002766992);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1731,0.0003319694);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1773,3.214286e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1775,4.669561e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1777,5.753675e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1779,8.175218e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1781,0.0001041757);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1783,0.0001268744);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1784,0.0001393791);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1785,0.0001518108);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1786,0.0001591616);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1787,0.000172401);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1788,0.0001905437);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1789,0.0002443982);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1790,0.0002384021);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1791,0.0002490039);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1792,0.000260221);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1793,0.0002790264);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1845,0.0001046913);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1846,0.0001430373);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1847,0.0001451109);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1848,0.0001649332);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1849,0.0001632428);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1850,0.0002047771);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1851,0.0001944562);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1852,0.0002115842);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1853,0.0002297483);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1854,0.0002339364);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1855,0.0002528545);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1899,3.093952e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1901,4.693519e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1903,6.59372e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1905,8.97165e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1907,0.0001021574);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1908,0.0001037295);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1909,0.0001217481);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1910,0.0001408547);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1911,0.0001395104);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1912,0.0001641846);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1913,0.0001803309);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1914,0.0001959189);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1915,0.0002385909);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1916,0.000227626);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1917,0.0002428036);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1969,8.928798e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1970,9.54996e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1971,0.0001036623);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1972,0.0001315707);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1973,0.000129574);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1974,0.0001365096);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1975,0.0002034739);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1976,0.0001688843);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1977,0.0001807939);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1978,0.000230968);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(1979,0.0002100921);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2025,3.301892e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2027,4.941512e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2029,6.318953e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2031,7.743049e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2032,8.252096e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2033,9.087356e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2034,0.0001067352);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2035,0.000117127);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2036,0.0001263986);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2037,0.0001359531);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2038,0.0001529307);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2039,0.0001729004);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2040,0.0001887834);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2041,0.0002074359);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2093,6.705045e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2094,7.360883e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2095,9.395628e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2096,9.426805e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2097,0.000105771);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2098,0.000109946);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2099,0.0001258907);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2100,0.0001433971);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2101,0.0001537481);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2102,0.0001698791);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2103,0.0001899375);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2151,3.140352e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2153,4.045839e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2155,5.169792e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2156,6.28e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2157,8.106805e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2158,8.31485e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2159,9.407626e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2160,0.0001044448);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2161,0.0001150616);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2162,0.0001492173);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2163,0.0001408848);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2164,0.0001533357);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2165,0.0001606368);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2217,5.054853e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2218,5.948182e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2219,8.351444e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2220,7.161657e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2221,8.064191e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2222,9.568442e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2223,0.0001075689);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2224,0.0001131995);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2225,0.0001325571);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2226,0.0001317227);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2227,0.0001559452);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2277,2.9734e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2279,4.676446e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2281,5.586403e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2283,7.222296e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2285,9.148564e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2287,0.000110332);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2289,0.0001390249);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2403,5.053397e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2405,3.962144e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2407,5.656712e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2409,7.315386e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2411,8.597039e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2413,0.0001096125);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2529,3.045867e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2531,4.066362e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2533,5.05473e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2535,9.00758e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2537,8.759919e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2655,2.876229e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2657,3.467579e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2659,4.698434e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2661,6.190516e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2781,2.635048e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2783,3.90841e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2785,5.037149e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2907,1.836246e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(2909,3.046334e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetBinError(3033,2.398128e-05);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetEntries(539505.8);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1500HTinf_200MHTinf->Draw("colz");
   c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf->Modified();
   c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf->cd();
   c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf->SetSelected(c_AccEffMap_T5VV_8NJetinf_1500HTinf_200MHTinf);
}
/*
   400    25   0.000193915
   400    75    0.00014956
   400   125   9.24462e-05
   400   175   4.96898e-05
   450    25   0.000499528
   450    75   0.000354558
   450   125    0.00021652
   450   175   0.000152977
   450   225   0.000117791
   500    25   0.000817669
   500    75   0.000635307
   500   125   0.000487196
   500   175   0.000311559
   500   225   0.000183394
   500   275    3.0031e-05
   550    25    0.00142849
   550    75    0.00120735
   550   125   0.000808676
   550   175   0.000558351
   550   225   0.000338938
   550   275   0.000284552
   550   325   0.000177805
   600    25    0.00203003
   600    75    0.00184418
   600   125     0.0015727
   600   175    0.00112507
   600   225   0.000789286
   600   275   0.000455247
   600   325   0.000229922
   600   375   0.000131848
   650    25    0.00349559
   650    75    0.00296144
   650   125    0.00225598
   650   175    0.00177453
   650   225    0.00113286
   650   275   0.000773237
   650   325   0.000635795
   650   375   0.000336643
   650   425   9.04929e-05
   700    25    0.00489727
   700    75    0.00441956
   700   125    0.00349901
   700   175     0.0027873
   700   225    0.00196528
   700   275    0.00154057
   700   325   0.000928755
   700   375   0.000561769
   700   425   0.000343985
   700   475    0.00016847
   750    25    0.00738102
   750    75    0.00609642
   750   125     0.0053028
   750   175    0.00409138
   750   225    0.00297954
   750   275    0.00216157
   750   325    0.00142161
   750   375   0.000882706
   750   425   0.000640841
   750   475   0.000312485
   750   525   0.000153111
   800    25    0.00969608
   800    75    0.00888316
   800   125    0.00725682
   800   175    0.00589423
   800   225    0.00421341
   800   275     0.0028939
   800   325    0.00226557
   800   375    0.00156097
   800   425   0.000995207
   800   475   0.000523102
   800   525   0.000353564
   800   575   0.000212391
   850    25     0.0127215
   850    75      0.010942
   850   125    0.00997816
   850   175    0.00814448
   850   225    0.00602434
   850   275    0.00466418
   850   325    0.00340406
   850   375    0.00203608
   850   425    0.00157434
   850   475    0.00107561
   850   525   0.000595832
   850   575   0.000365531
   850   625   8.57536e-05
   900    25     0.0172465
   900    75     0.0151435
   900   125     0.0133596
   900   175     0.0109387
   900   225    0.00854538
   900   275    0.00704443
   900   325    0.00502265
   900   375      0.003341
   900   425     0.0023776
   900   475    0.00159632
   900   525   0.000932519
   900   575   0.000590331
   900   625   0.000323471
   900   675   0.000139815
   950    25     0.0213926
   950    75     0.0189755
   950   125     0.0167304
   950   175     0.0132308
   950   225     0.0110123
   950   275    0.00886936
   950   325    0.00650595
   950   375    0.00510366
   950   425    0.00348614
   950   475    0.00241453
   950   525    0.00136591
   950   575   0.000931637
   950   625   0.000418825
   950   675   0.000305933
   950   725   0.000134851
  1000    25     0.0253881
  1000    75      0.023556
  1000   125     0.0201955
  1000   175     0.0180139
  1000   225     0.0141705
  1000   275     0.0119796
  1000   325    0.00907398
  1000   375    0.00654483
  1000   425    0.00497384
  1000   475    0.00358427
  1000   525    0.00251234
  1000   575    0.00149472
  1000   625    0.00105864
  1000   675   0.000484415
  1000   725   0.000325113
  1000   775   0.000154806
  1050    25     0.0303412
  1050    75     0.0272711
  1050   125     0.0248873
  1050   175     0.0220822
  1050   225      0.018536
  1050   275     0.0157173
  1050   325     0.0121342
  1050   375     0.0091578
  1050   425    0.00706287
  1050   475    0.00484048
  1050   525    0.00337588
  1050   575    0.00241221
  1050   625    0.00161504
  1050   675   0.000934229
  1050   725   0.000555013
  1050   775   0.000345573
  1050   825   0.000147282
  1100    25     0.0364755
  1100    75     0.0333782
  1100   125     0.0296202
  1100   175     0.0264583
  1100   225     0.0222586
  1100   275     0.0184227
  1100   325     0.0153383
  1100   375     0.0122929
  1100   425    0.00946437
  1100   475    0.00721206
  1100   525    0.00490651
  1100   575    0.00369711
  1100   625    0.00260042
  1100   675    0.00154566
  1100   725   0.000900688
  1100   775   0.000585636
  1100   825    0.00023932
  1100   875   0.000126141
  1150    25     0.0412782
  1150    75     0.0377216
  1150   125     0.0350668
  1150   175     0.0309612
  1150   225     0.0272045
  1150   275     0.0237472
  1150   325     0.0191633
  1150   375     0.0158657
  1150   425     0.0123396
  1150   475    0.00897202
  1150   525    0.00706193
  1150   550     0.0059863
  1150   575    0.00490469
  1150   600    0.00388674
  1150   625    0.00307522
  1150   650    0.00266329
  1150   675    0.00230405
  1150   700    0.00165118
  1150   725    0.00150556
  1150   750    0.00111675
  1150   775   0.000921922
  1150   800   0.000689657
  1150   825   0.000403428
  1150   850   0.000374692
  1150   875   0.000313646
  1150   925   0.000167585
  1175   550    0.00668758
  1175   575    0.00566831
  1175   600     0.0046982
  1175   625    0.00388122
  1175   650    0.00341643
  1175   675    0.00268951
  1175   700     0.0020768
  1175   725    0.00165072
  1175   750    0.00136816
  1175   775    0.00100895
  1175   800   0.000724306
  1175   825   0.000604905
  1175   850   0.000541293
  1200    25     0.0450529
  1200    75     0.0428164
  1200   125     0.0403702
  1200   175     0.0364718
  1200   225     0.0311879
  1200   275     0.0273945
  1200   325     0.0230386
  1200   375     0.0203051
  1200   425     0.0153843
  1200   475     0.0121994
  1200   525    0.00940503
  1200   550    0.00780281
  1200   575    0.00695605
  1200   600    0.00590158
  1200   625    0.00454908
  1200   650    0.00382118
  1200   675    0.00332749
  1200   700     0.0029176
  1200   725    0.00226114
  1200   750    0.00164157
  1200   775    0.00126989
  1200   800     0.0012157
  1200   825   0.000893946
  1200   850   0.000741664
  1200   875   0.000486772
  1200   925   0.000244158
  1200   975   0.000109813
  1225   550    0.00905562
  1225   575    0.00808603
  1225   600    0.00652854
  1225   625    0.00538106
  1225   650    0.00473845
  1225   675    0.00383305
  1225   700    0.00312757
  1225   725    0.00261126
  1225   750    0.00199993
  1225   775    0.00174233
  1225   800    0.00136656
  1225   825    0.00103653
  1225   850   0.000780681
  1250    25     0.0517395
  1250    75     0.0475937
  1250   125     0.0446697
  1250   175     0.0409849
  1250   225     0.0369771
  1250   275     0.0320671
  1250   325     0.0278843
  1250   375     0.0230736
  1250   425     0.0189469
  1250   475      0.015659
  1250   525     0.0119104
  1250   550     0.0107726
  1250   575    0.00919848
  1250   600    0.00791576
  1250   625    0.00660194
  1250   650    0.00582593
  1250   675    0.00446418
  1250   700    0.00375203
  1250   725    0.00298387
  1250   750    0.00237788
  1250   775    0.00205979
  1250   800    0.00168877
  1250   825    0.00134461
  1250   850     0.0010185
  1250   875   0.000816284
  1250   925   0.000357305
  1250   975   0.000257091
  1250  1025   8.62824e-05
  1275   550     0.0118868
  1275   575     0.0105456
  1275   600    0.00907744
  1275   625    0.00743575
  1275   650    0.00640226
  1275   675    0.00515718
  1275   700    0.00461053
  1275   725    0.00371028
  1275   750    0.00288621
  1275   775    0.00241094
  1275   800    0.00183906
  1275   825    0.00147372
  1275   850    0.00143218
  1300    25     0.0551969
  1300    75     0.0534499
  1300   125     0.0485803
  1300   175     0.0462231
  1300   225     0.0424004
  1300   275     0.0375162
  1300   325     0.0323627
  1300   375     0.0280105
  1300   425     0.0237911
  1300   475     0.0197744
  1300   525     0.0160104
  1300   550     0.0136892
  1300   575     0.0116615
  1300   600       0.01008
  1300   625    0.00936125
  1300   650    0.00743042
  1300   675    0.00632601
  1300   700    0.00554029
  1300   725    0.00449379
  1300   750    0.00360676
  1300   775    0.00287696
  1300   800    0.00242675
  1300   825    0.00198398
  1300   850    0.00158486
  1300   875    0.00114048
  1300   925   0.000692893
  1300   975   0.000410453
  1300  1025   0.000193044
  1300  1075   8.33233e-05
  1325   550     0.0157705
  1325   575     0.0131559
  1325   600     0.0118988
  1325   625     0.0106542
  1325   650    0.00875206
  1325   675    0.00747715
  1325   700    0.00631563
  1325   725    0.00559539
  1325   750    0.00436279
  1325   775    0.00366134
  1325   800    0.00270822
  1325   825    0.00244415
  1325   850    0.00188641
  1350    25     0.0606037
  1350    75     0.0579302
  1350   125     0.0528459
  1350   175     0.0505548
  1350   225     0.0473966
  1350   275     0.0421086
  1350   325     0.0369285
  1350   375     0.0329473
  1350   425     0.0282359
  1350   475     0.0240119
  1350   525      0.019334
  1350   550     0.0171449
  1350   575     0.0154944
  1350   600     0.0132756
  1350   625     0.0119644
  1350   650     0.0103251
  1350   675    0.00863905
  1350   700    0.00717512
  1350   725    0.00579038
  1350   750    0.00507926
  1350   775    0.00419022
  1350   800    0.00355375
  1350   825    0.00304292
  1350   850    0.00250082
  1350   875    0.00195056
  1350   925    0.00118919
  1350   975   0.000890229
  1350  1025   0.000357515
  1350  1075   0.000246927
  1350  1125   5.50855e-05
  1375   550     0.0191917
  1375   575     0.0174365
  1375   600     0.0146916
  1375   625      0.013125
  1375   650     0.0112857
  1375   675     0.0103513
  1375   700    0.00846047
  1375   725    0.00744802
  1375   750     0.0064421
  1375   775    0.00516219
  1375   800     0.0041023
  1375   825    0.00361019
  1375   850    0.00276907
  1400    25      0.063348
  1400    75     0.0604105
  1400   125     0.0568477
  1400   175     0.0534629
  1400   225      0.050385
  1400   275      0.046862
  1400   325     0.0419474
  1400   375     0.0372768
  1400   425     0.0326612
  1400   475     0.0275209
  1400   525     0.0232583
  1400   550     0.0211861
  1400   575     0.0187124
  1400   600     0.0170911
  1400   625     0.0146183
  1400   650     0.0130188
  1400   675     0.0115931
  1400   700    0.00974484
  1400   725    0.00808536
  1400   750    0.00685168
  1400   775    0.00587159
  1400   800    0.00512109
  1400   825    0.00391984
  1400   850    0.00354852
  1400   875    0.00312254
  1400   925    0.00195934
  1400   975    0.00124169
  1400  1025   0.000621586
  1400  1075   0.000418177
  1400  1125   0.000152217
  1400  1175   8.97249e-05
*/
