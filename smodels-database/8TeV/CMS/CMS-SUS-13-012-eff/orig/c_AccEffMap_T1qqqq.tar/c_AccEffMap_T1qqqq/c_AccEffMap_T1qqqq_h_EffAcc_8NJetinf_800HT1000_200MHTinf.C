{
//=========Macro generated from canvas: c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf/c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf
//=========  (Sat Feb 22 16:30:38 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf = new TCanvas("c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf", "c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf",110,288,500,500);
   c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf->SetFillColor(0);
   c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf->SetLogz();
   c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_800HT1000_200MHTinf = new TH2D("h_EffAcc_8NJetinf_800HT1000_200MHTinf","h_EffAcc_8NJetinf_800HT1000_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(141,0.0003123824);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(143,0.0004703662);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(145,0.000692012);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(147,0.0007086378);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(149,0.0007632376);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(151,0.0008198502);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(153,0.000620777);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(155,0.0004316317);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(157,0.000530737);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(159,0.0004373618);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(161,0.0003584549);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(163,0.0002459034);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(165,0.0002025699);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(167,0.0002474964);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(169,0.0001547934);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(171,0.0001755666);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(173,0.0001442802);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(175,9.715556e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(177,4.350456e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(179,6.954299e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(181,2.47889e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(265,0.0003017453);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(267,0.0004019405);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(269,0.0005591599);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(271,0.0006054876);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(273,0.000701171);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(275,0.0006530211);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(277,0.0006202326);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(279,0.0005999643);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(281,0.0003947342);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(283,0.0005845046);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(285,0.0003438751);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(287,0.0002615971);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(289,0.0002915559);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(291,0.0001982357);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(293,0.0002697556);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(295,8.410759e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(297,3.938169e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(299,9.7272e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(301,6.885876e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(303,3.881212e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(305,3.71653e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(389,0.000220954);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(391,0.0003931102);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(393,0.0003979166);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(395,0.0006470083);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(397,0.0006924772);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(399,0.0007190504);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(401,0.000830075);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(403,0.0007274032);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(405,0.0005806142);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(407,0.0003822591);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(409,0.000475588);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(411,0.0002600448);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(413,0.0002775271);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(415,0.0003411319);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(417,0.000181864);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(419,0.000121737);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(421,0.000131689);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(423,9.986813e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(425,7.123549e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(427,8.504957e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(429,3.685821e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(513,0.0002050969);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(515,0.0003743896);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(517,0.0004665397);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(519,0.0006960458);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(521,0.0007610276);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(523,0.0007436902);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(525,0.0006380351);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(527,0.0007095948);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(529,0.000564406);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(531,0.000603631);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(533,0.0004385562);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(535,0.0003177703);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(537,0.0003211813);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(539,0.0003577456);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(541,0.0001645674);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(543,7.958596e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(545,9.239781e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(547,0.0001124941);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(549,0.0001046499);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(551,8.617651e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(553,3.902948e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(637,8.944465e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(639,0.0002829804);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(641,0.0003381645);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(643,0.0005973355);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(645,0.0006786633);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(647,0.0006695317);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(649,0.0009262079);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(651,0.0007570729);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(653,0.0005971062);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(655,0.0004729699);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(657,0.0005256764);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(659,0.0004352959);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(661,0.000319361);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(663,0.0002707656);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(665,0.0002566511);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(667,0.0001491433);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(669,0.0001699483);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(671,9.177532e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(673,8.036856e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(675,5.639462e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(677,8.506957e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(761,6.469188e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(763,9.629126e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(765,0.0002638385);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(767,0.0003989448);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(769,0.0004831142);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(771,0.0007168191);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(773,0.0007828996);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(775,0.0007830534);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(777,0.0007915705);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(779,0.0006595877);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(781,0.0005118444);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(783,0.0004896524);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(785,0.0004283096);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(787,0.0003642693);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(789,0.0002498613);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(791,0.0002752969);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(793,0.0001357828);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(795,0.0001870034);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(797,0.0001659629);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(799,5.218753e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(801,6.793118e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(885,2.951305e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(887,4.553013e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(889,0.0001638559);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(891,0.0002208368);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(893,0.0004215753);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(895,0.0006170311);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(897,0.0009045641);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(899,0.000811678);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(901,0.000683916);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(903,0.0007396485);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(905,0.000588602);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(907,0.0004374198);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(909,0.0004976426);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(911,0.0003389728);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(913,0.000316245);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(915,0.0001885441);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(917,0.0001975767);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(919,0.0001664461);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(921,9.481003e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(923,7.463426e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(925,7.294601e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1011,5.123904e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1013,8.998254e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1015,0.0001781659);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1017,0.0003448676);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1019,0.0004838014);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1021,0.0006800334);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1023,0.0007285185);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1025,0.0007228699);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1027,0.0005838451);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1029,0.0007050386);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1031,0.0005885429);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1033,0.000523966);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1035,0.0004062058);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1037,0.0003529522);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1039,0.0002684572);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1041,0.0002339539);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1043,0.0002180476);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1045,0.0002115415);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1047,0.0001183541);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1049,6.812573e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1137,1.457273e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1139,7.408244e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1141,0.0001784394);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1143,0.000302177);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1145,0.0005021937);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1147,0.0006819719);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1149,0.0007551355);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1151,0.0007535955);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1153,0.0008000248);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1155,0.000710751);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1157,0.000618148);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1159,0.0005516328);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1161,0.0003842512);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1163,0.0002692154);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1165,0.0002873298);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1167,0.0001999778);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1169,0.0001696528);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1171,0.000102598);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1173,0.0001176114);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1265,9.656744e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1267,0.0002355777);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1269,0.0004627142);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1271,0.0005090065);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1273,0.0005787788);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1275,0.0007251154);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1277,0.0008230363);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1279,0.0006545435);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1281,0.0006468663);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1283,0.0006851246);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1285,0.0004629877);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1287,0.0005524449);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1289,0.0003640223);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1291,0.0002421876);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1293,0.0002754048);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1295,0.0001691243);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1297,0.00014967);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1387,1.571093e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1389,2.202808e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1391,0.0001301972);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1393,0.0002618976);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1395,0.0004266042);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1397,0.0005055688);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1399,0.0007177215);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1401,0.0006844003);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1403,0.000792758);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1405,0.0006763219);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1407,0.0006949872);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1409,0.0005320329);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1411,0.0005867204);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1413,0.0004328723);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1415,0.0002541067);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1417,0.0002024789);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1419,0.000187006);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1421,0.0001904855);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1513,7.341319e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1515,7.305889e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1517,0.0001039948);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1519,0.0002207821);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1521,0.0003102929);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1523,0.0005853623);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1525,0.0006396545);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1527,0.0008901351);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1529,0.0008443042);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1531,0.0007703335);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1533,0.0007769224);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1535,0.0004545254);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1537,0.0005597041);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1539,0.0003751422);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1541,0.0002716818);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1543,0.0001790662);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1545,0.0001835169);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1641,1.449869e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1643,0.0001340987);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1645,0.0002741877);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1647,0.00040885);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1649,0.000505449);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1651,0.0006288906);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1653,0.0006386056);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1655,0.0007594082);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1657,0.0006503992);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1659,0.0004736906);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1661,0.0005359091);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1663,0.0005243501);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1665,0.0002973135);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1667,0.0003340335);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1669,0.0002533939);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1767,3.603001e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1769,0.0001245331);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1771,0.0002369432);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1773,0.0003470163);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1775,0.0005804919);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1777,0.0006673842);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1783,0.0006937665);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1785,0.0006960538);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1787,0.0005387659);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1789,0.0003991073);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1791,0.0003918986);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1793,0.0003076908);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1845,0.000706281);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1846,0.0006815721);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1847,0.0006250043);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1848,0.0006023358);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1849,0.0005531329);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1850,0.000678432);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1851,0.0004767602);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1852,0.0003783523);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1853,0.0002882976);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1854,0.0003311441);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1855,0.0002685964);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1893,2.147808e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1895,0.0001004869);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1897,0.0002072561);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1899,0.0003242788);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1901,0.0004796695);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1907,0.0007797231);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1908,0.0007128876);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1909,0.0006382903);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1910,0.0005474755);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1911,0.0006365723);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1912,0.0006074102);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1913,0.0005817239);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1914,0.0005313985);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1915,0.0003050494);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1916,0.0004035386);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1917,0.0002305944);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1969,0.0007753167);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1970,0.0007100307);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1971,0.0006851612);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1972,0.0006756511);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1973,0.0005893378);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1974,0.0006310025);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1975,0.0005347868);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1976,0.0003889891);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1977,0.0004558779);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1978,0.0005010218);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1979,0.0003343307);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2019,2.115692e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2021,8.011376e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2023,0.0001490709);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2025,0.0004066832);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2031,0.0006746782);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2032,0.0005951945);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2033,0.0007511749);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2034,0.0007172784);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2035,0.0006468952);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2036,0.0005772468);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2037,0.0006291516);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2038,0.0005684025);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2039,0.0005288893);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2040,0.0004522584);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2041,0.000347999);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2093,0.000746586);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2094,0.0007526322);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2095,0.0007083075);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2096,0.0006588578);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2097,0.0007213558);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2098,0.0006142099);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2099,0.0006241874);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2100,0.0005280057);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2101,0.0005251695);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2102,0.0005441505);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2103,0.0004493564);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2145,2.092747e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2147,0.0001360657);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2149,0.0002196566);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2155,0.0004863197);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2156,0.0005991969);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2157,0.000589958);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2158,0.0005130433);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2159,0.0006349426);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2160,0.0005945655);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2161,0.0006486461);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2162,0.0006397296);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2163,0.0006313797);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2164,0.0006180265);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2165,0.000539525);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2217,0.000602295);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2218,0.0006865662);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2219,0.00076909);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2220,0.0006853841);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2221,0.0005636653);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2222,0.0006829767);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2223,0.0005443301);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2224,0.0005946656);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2225,0.0006748723);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2226,0.0004890578);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2227,0.0004843279);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2271,2.757818e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2273,0.0001242523);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2279,0.0004777734);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2280,0.0003895343);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2281,0.0006899976);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2282,0.0007081087);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2283,0.000665412);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2284,0.0006093483);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2285,0.0006356711);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2286,0.0006110859);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2287,0.0006099799);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2288,0.0006601758);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2289,0.0005774294);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2341,0.0003755398);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2342,0.0004921591);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2343,0.0005335109);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2344,0.0005655064);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2345,0.0006065287);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2346,0.0006618008);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2347,0.0006909022);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2348,0.0006766843);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2349,0.0007960131);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2350,0.0006649201);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2351,0.0006543179);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2397,2.711414e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2403,0.0002473056);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2404,0.0003790607);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2405,0.0003580271);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2406,0.0004934914);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2407,0.0007177175);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2408,0.0006406969);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2409,0.0005591823);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2410,0.0005514133);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2411,0.0006744645);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2412,0.0006816198);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2413,0.0005524127);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2465,0.0002368532);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2466,0.0002823736);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2467,0.0003985962);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2468,0.0005497159);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2469,0.0006157684);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2470,0.0006720637);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2471,0.0006642711);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2472,0.0006261981);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2473,0.0006300081);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2474,0.0005299776);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2475,0.0006776877);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2527,0.0001725536);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2528,0.000309486);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2529,0.0003428067);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2530,0.0003984248);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2531,0.0004824383);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2532,0.0004964303);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2533,0.000530185);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2534,0.0007171403);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2535,0.0006288479);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2536,0.00069951);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2537,0.0004962003);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2589,9.489955e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2590,0.0002557662);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2591,0.0002604252);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2592,0.0002680965);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2593,0.0004027746);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2594,0.000494742);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2595,0.0005111048);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2596,0.0004386295);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2597,0.0006498611);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2598,0.0006441751);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2599,0.0005063672);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2651,0.0001179796);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2653,0.0001487484);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2655,0.0003439732);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2657,0.0004029396);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2659,0.0005299859);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2661,0.0004899721);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2775,1.943839e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2777,5.902491e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2779,0.0001668296);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2781,0.0002983379);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2783,0.0004226117);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2785,0.0004855506);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2899,6.489093e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2901,1.92077e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2903,0.000104307);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2905,0.0002227559);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2907,0.0003211371);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2909,0.0005199318);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3027,6.273937e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3029,6.351678e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3031,9.890133e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3033,0.0002953425);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3151,7.091293e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3153,7.088897e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3155,7.047358e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3157,0.0001659932);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3279,1.263585e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3281,6.617982e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3403,6.131828e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3405,6.009444e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(141,5.380171e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(143,6.151758e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(145,7.582721e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(147,7.807655e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(149,8.029662e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(151,8.438213e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(153,7.240726e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(155,6.058915e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(157,6.70591e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(159,6.026225e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(161,5.417163e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(163,4.499916e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(165,4.062137e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(167,4.460236e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(169,3.471822e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(171,3.746843e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(173,3.415984e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(175,2.810599e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(177,1.785145e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(179,2.458799e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(181,1.43303e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(265,4.853084e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(267,5.7646e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(269,6.861254e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(271,7.110257e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(273,7.638741e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(275,7.37613e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(277,7.237322e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(279,8.778849e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(281,5.718855e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(283,6.909584e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(285,5.320323e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(287,4.787576e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(289,5.739974e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(291,3.971698e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(293,4.574661e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(295,2.544708e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(297,1.762633e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(299,3.083279e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(301,2.437008e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(303,1.74204e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(305,1.662452e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(389,4.192837e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(391,5.581054e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(393,5.706712e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(395,7.263611e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(397,7.628372e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(399,7.779537e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(401,8.330415e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(403,7.827629e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(405,6.956608e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(407,5.596729e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(409,6.211189e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(411,4.60938e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(413,4.7045e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(415,6.139718e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(417,3.796917e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(419,3.051452e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(421,3.199568e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(423,2.775252e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(425,2.699912e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(427,2.69239e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(429,1.649752e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(513,3.959236e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(515,5.426044e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(517,6.095188e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(519,7.580372e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(521,8.011772e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(523,7.911588e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(525,7.394671e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(527,7.868348e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(529,6.865574e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(531,7.037534e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(533,6.040781e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(535,5.100092e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(537,5.094766e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(539,6.66318e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(541,3.598082e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(543,2.52154e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(545,2.795469e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(547,2.912447e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(549,3.158745e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(551,2.497788e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(553,1.751796e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(637,2.591904e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(639,4.737067e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(641,5.237373e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(643,7.117409e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(645,7.522385e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(647,7.423829e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(649,8.710696e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(651,8.244773e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(653,7.673509e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(655,6.235013e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(657,6.594858e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(659,5.991868e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(661,5.064556e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(663,4.591911e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(665,4.482921e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(667,3.42524e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(669,3.626878e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(671,2.652056e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(673,2.428162e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(675,2.13793e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(677,2.458065e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(761,2.158098e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(763,2.677314e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(765,4.535778e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(767,5.610388e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(769,6.208251e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(771,7.629909e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(773,8.023078e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(775,8.064618e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(777,8.027271e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(779,7.349741e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(781,6.417663e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(783,6.287278e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(785,5.901763e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(787,5.50163e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(789,4.426144e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(791,4.601148e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(793,3.40616e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(795,3.747876e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(797,3.541909e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(799,2.143718e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(801,2.575298e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(885,1.480109e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(887,1.860744e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(889,3.497638e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(891,4.11333e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(893,5.815301e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(895,7.01378e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(897,8.740759e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(899,8.109029e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(901,7.404388e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(903,7.697902e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(905,6.914041e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(907,5.918027e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(909,6.331555e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(911,5.181667e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(913,4.952417e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(915,5.24022e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(917,3.883669e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(919,3.555886e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(921,2.637423e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(923,2.362247e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(925,2.765175e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1011,1.9385e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1013,2.601285e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1015,3.724078e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1017,5.155478e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1019,6.21762e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1021,7.406325e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1023,7.752181e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1025,7.604923e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1027,6.818098e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1029,7.540817e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1031,6.866347e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1033,6.622499e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1035,5.704689e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1037,5.274416e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1039,4.61838e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1041,4.353194e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1043,4.060172e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1045,4.001726e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1047,2.966892e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1049,2.788848e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1137,1.030457e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1139,2.344402e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1141,3.644895e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1143,4.787371e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1145,6.306835e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1147,7.386482e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1149,7.773905e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1151,7.725752e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1153,7.948034e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1155,7.437633e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1157,6.934691e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1159,6.526992e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1161,5.448019e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1163,4.501226e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1165,4.670985e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1167,4.006627e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1169,3.545047e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1171,2.747452e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1173,3.401689e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1265,2.679911e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1267,4.240314e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1269,5.995936e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1271,6.340151e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1273,6.713229e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1275,7.553809e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1277,7.992156e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1279,7.128524e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1281,7.123799e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1283,7.323661e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1285,5.990072e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1287,6.570626e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1289,5.269239e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1291,4.760672e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1293,4.538298e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1295,3.53446e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1297,3.439317e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1387,1.112861e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1389,1.271809e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1391,3.164273e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1393,4.436097e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1395,5.662072e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1397,6.201396e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1399,7.432491e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1401,7.241485e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1403,7.841294e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1405,7.274733e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1407,7.520024e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1409,6.333605e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1411,6.624209e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1413,5.852364e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1415,4.579725e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1417,3.980716e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1419,3.67601e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1421,3.746658e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1513,7.341351e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1515,7.305922e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1517,2.783706e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1519,4.038083e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1521,4.859066e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1523,6.654763e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1525,7.051597e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1527,8.263596e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1529,9.78623e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1531,7.655031e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1533,7.646127e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1535,5.838521e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1537,6.485178e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1539,5.371598e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1541,4.420391e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1543,3.916416e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1545,4.600169e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1641,1.025221e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1643,3.167616e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1645,4.518965e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1647,5.474978e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1649,6.195401e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1651,6.889701e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1653,7.401813e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1655,7.586081e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1657,7.08097e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1659,6.036542e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1661,6.295588e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1663,6.246111e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1665,4.710287e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1667,4.8857e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1669,4.490738e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1767,1.611346e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1769,3.024596e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1771,4.271401e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1773,5.022512e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1775,6.558663e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1777,7.14025e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1783,7.379409e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1785,7.245565e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1787,6.282927e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1789,5.397855e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1791,5.397814e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1793,4.651131e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1845,7.198884e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1846,7.051903e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1847,7.198272e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1848,6.59333e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1849,6.405228e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1850,7.256511e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1851,6.176842e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1852,6.074063e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1853,5.030603e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1854,4.891628e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1855,4.427171e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1893,1.240053e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1895,2.688263e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1897,3.854301e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1899,4.791995e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1901,6.611245e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1907,7.531193e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1908,7.22696e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1909,6.947007e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1910,6.38789e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1911,6.848179e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1912,6.612077e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1913,6.445091e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1914,6.368568e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1915,4.780271e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1916,5.403784e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1917,4.084416e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1969,7.522083e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1970,7.272066e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1971,7.020094e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1972,7.315569e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1973,6.65818e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1974,6.869747e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1975,6.240019e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1976,5.258437e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1977,5.903269e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1978,5.966048e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1979,4.892521e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2019,1.221511e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2021,2.422756e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2023,3.258108e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2025,5.451896e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2031,7.52323e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2032,6.597935e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2033,7.360754e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2034,7.16448e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2035,6.961958e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2036,6.438328e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2037,6.845107e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2038,6.58246e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2039,6.44025e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2040,5.670403e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2041,5.592294e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2093,7.733157e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2094,7.757723e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2095,7.107968e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2096,6.857305e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2097,7.425287e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2098,6.574024e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2099,6.792456e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2100,6.082744e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2101,6.048668e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2102,6.388955e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2103,5.592046e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2145,1.208263e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2147,3.126871e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2149,3.95757e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2155,5.917749e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2156,6.60473e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2157,6.461636e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2158,6.030515e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2159,6.834492e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2160,6.848231e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2161,6.823233e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2162,6.84447e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2163,6.754558e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2164,7.256183e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2165,6.927106e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2217,6.523042e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2218,7.033546e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2219,7.462983e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2220,6.918009e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2221,6.327215e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2222,7.352209e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2223,6.397046e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2224,6.47037e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2225,7.061642e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2226,7.158187e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2227,5.853834e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2271,1.378932e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2273,2.933539e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2279,5.772775e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2280,5.643862e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2281,6.963845e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2282,7.036085e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2283,6.783333e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2284,6.796872e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2285,6.725266e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2286,6.538169e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2287,6.52691e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2288,6.798698e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2289,6.521384e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2341,5.078596e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2342,5.949964e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2343,6.062548e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2344,6.313036e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2345,6.723986e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2346,6.890203e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2347,7.083348e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2348,7.007462e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2349,7.548093e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2350,7.035461e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2351,6.702308e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2397,1.355729e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2403,4.07448e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2404,5.130126e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2405,4.931294e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2406,5.837219e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2407,7.095894e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2408,6.743075e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2409,6.159709e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2410,6.229728e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2411,6.947788e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2412,6.843658e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2413,6.236234e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2465,4.015239e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2466,4.423186e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2467,5.158803e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2468,6.167359e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2469,6.518379e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2470,6.995344e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2471,6.770067e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2472,7.800639e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2473,6.561159e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2474,5.989509e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2475,6.805903e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2527,3.389668e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2528,4.575267e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2529,4.86568e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2530,5.206326e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2531,5.702539e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2532,5.79054e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2533,6.030975e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2534,7.388822e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2535,6.582e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2536,6.88669e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2537,6.175872e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2589,2.54319e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2590,4.15757e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2591,4.183736e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2592,4.250956e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2593,5.260161e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2594,5.976516e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2595,5.842264e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2596,5.37644e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2597,6.621322e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2598,6.706242e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2599,5.987918e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2651,2.783513e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2653,3.104554e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2655,4.783521e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2657,5.134283e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2659,5.908348e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2661,7.331011e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2775,1.122289e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2777,1.973306e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2779,3.275323e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2781,4.411016e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2783,5.302137e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2785,5.863611e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2899,6.489118e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2901,1.10897e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2903,2.611424e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2905,3.770234e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2907,4.602674e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2909,5.798836e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3027,6.27396e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3029,2.011041e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3031,2.645844e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3033,4.269416e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3151,7.09132e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3153,7.088924e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3155,2.13084e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3157,3.198451e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3279,8.93496e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3281,1.995477e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3403,6.131851e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3405,6.009466e-06);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetEntries(24492.73);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->Draw("colz");
   c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf->Modified();
   c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf->cd();
   c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf->SetSelected(c_AccEffMap_T1qqqq_8NJetinf_800HT1000_200MHTinf);
}
/*
Topology ~g ~g ; ~g ->q+qbar+LSP

mGluino(GeV) mLSP(GeV) AccXEff
   400    25   0.000312382
   400    75   0.000301745
   400   125   0.000220954
   400   175   0.000205097
   400   225   8.94446e-05
   400   275   6.46919e-05
   400   325   2.95131e-05
   450    25   0.000470366
   450    75    0.00040194
   450   125    0.00039311
   450   175    0.00037439
   450   225    0.00028298
   450   275   9.62913e-05
   450   325   4.55301e-05
   450   375    5.1239e-05
   500    25   0.000692012
   500    75    0.00055916
   500   125   0.000397917
   500   175    0.00046654
   500   225   0.000338165
   500   275   0.000263839
   500   325   0.000163856
   500   375   8.99825e-05
   500   425   1.45727e-05
   550    25   0.000708638
   550    75   0.000605488
   550   125   0.000647008
   550   175   0.000696046
   550   225   0.000597336
   550   275   0.000398945
   550   325   0.000220837
   550   375   0.000178166
   550   425   7.40824e-05
   550   525   1.57109e-05
   600    25   0.000763238
   600    75   0.000701171
   600   125   0.000692477
   600   175   0.000761028
   600   225   0.000678663
   600   275   0.000483114
   600   325   0.000421575
   600   375   0.000344868
   600   425   0.000178439
   600   475   9.65674e-05
   600   525   2.20281e-05
   600   575   7.34132e-06
   650    25    0.00081985
   650    75   0.000653021
   650   125    0.00071905
   650   175    0.00074369
   650   225   0.000669532
   650   275   0.000716819
   650   325   0.000617031
   650   375   0.000483801
   650   425   0.000302177
   650   475   0.000235578
   650   525   0.000130197
   650   575   7.30589e-06
   700    25   0.000620777
   700    75   0.000620233
   700   125   0.000830075
   700   175   0.000638035
   700   225   0.000926208
   700   275     0.0007829
   700   325   0.000904564
   700   375   0.000680033
   700   425   0.000502194
   700   475   0.000462714
   700   525   0.000261898
   700   575   0.000103995
   700   625   1.44987e-05
   750    25   0.000431632
   750    75   0.000599964
   750   125   0.000727403
   750   175   0.000709595
   750   225   0.000757073
   750   275   0.000783053
   750   325   0.000811678
   750   375   0.000728519
   750   425   0.000681972
   750   475   0.000509007
   750   525   0.000426604
   750   575   0.000220782
   750   625   0.000134099
   750   675     3.603e-05
   800    25   0.000530737
   800    75   0.000394734
   800   125   0.000580614
   800   175   0.000564406
   800   225   0.000597106
   800   275    0.00079157
   800   325   0.000683916
   800   375    0.00072287
   800   425   0.000755136
   800   475   0.000578779
   800   525   0.000505569
   800   575   0.000310293
   800   625   0.000274188
   800   675   0.000124533
   800   725   2.14781e-05
   850    25   0.000437362
   850    75   0.000584505
   850   125   0.000382259
   850   175   0.000603631
   850   225    0.00047297
   850   275   0.000659588
   850   325   0.000739649
   850   375   0.000583845
   850   425   0.000753595
   850   475   0.000725115
   850   525   0.000717721
   850   575   0.000585362
   850   625    0.00040885
   850   675   0.000236943
   850   725   0.000100487
   850   775   2.11569e-05
   900    25   0.000358455
   900    75   0.000343875
   900   125   0.000475588
   900   175   0.000438556
   900   225   0.000525676
   900   275   0.000511844
   900   325   0.000588602
   900   375   0.000705039
   900   425   0.000800025
   900   475   0.000823036
   900   525     0.0006844
   900   575   0.000639654
   900   625   0.000505449
   900   675   0.000347016
   900   725   0.000207256
   900   775   8.01138e-05
   900   825   2.09275e-05
   950    25   0.000245903
   950    75   0.000261597
   950   125   0.000260045
   950   175    0.00031777
   950   225   0.000435296
   950   275   0.000489652
   950   325    0.00043742
   950   375   0.000588543
   950   425   0.000710751
   950   475   0.000654544
   950   525   0.000792758
   950   575   0.000890135
   950   625   0.000628891
   950   675   0.000580492
   950   725   0.000324279
   950   775   0.000149071
   950   825   0.000136066
   950   875   2.75782e-05
  1000    25    0.00020257
  1000    75   0.000291556
  1000   125   0.000277527
  1000   175   0.000321181
  1000   225   0.000319361
  1000   275    0.00042831
  1000   325   0.000497643
  1000   375   0.000523966
  1000   425   0.000618148
  1000   475   0.000646866
  1000   525   0.000676322
  1000   575   0.000844304
  1000   625   0.000638606
  1000   675   0.000667384
  1000   725   0.000479669
  1000   775   0.000406683
  1000   825   0.000219657
  1000   875   0.000124252
  1000   925   2.71141e-05
  1050    25   0.000247496
  1050    75   0.000198236
  1050   125   0.000341132
  1050   175   0.000357746
  1050   225   0.000270766
  1050   275   0.000364269
  1050   325   0.000338973
  1050   375   0.000406206
  1050   425   0.000551633
  1050   475   0.000685125
  1050   525   0.000694987
  1050   575   0.000770334
  1050   625   0.000759408
  1100    25   0.000154793
  1100    75   0.000269756
  1100   125   0.000181864
  1100   175   0.000164567
  1100   225   0.000256651
  1100   275   0.000249861
  1100   325   0.000316245
  1100   375   0.000352952
  1100   425   0.000384251
  1100   475   0.000462988
  1100   525   0.000532033
  1100   575   0.000776922
  1100   625   0.000650399
  1150    25   0.000175567
  1150    75   8.41076e-05
  1150   125   0.000121737
  1150   175    7.9586e-05
  1150   225   0.000149143
  1150   275   0.000275297
  1150   325   0.000188544
  1150   375   0.000268457
  1150   425   0.000269215
  1150   475   0.000552445
  1150   525    0.00058672
  1150   575   0.000454525
  1150   625   0.000473691
  1150   675   0.000693767
  1150   700   0.000706281
  1150   725   0.000779723
  1150   750   0.000775317
  1150   775   0.000674678
  1150   800   0.000746586
  1150   825    0.00048632
  1150   850   0.000602295
  1150   875   0.000477773
  1150   900    0.00037554
  1150   925   0.000247306
  1150   950   0.000236853
  1150   975   0.000172554
  1150  1000   9.48996e-05
  1150  1025    0.00011798
  1150  1075   1.94384e-05
  1150  1125   6.48909e-06
  1175   700   0.000681572
  1175   725   0.000712888
  1175   750   0.000710031
  1175   775   0.000595195
  1175   800   0.000752632
  1175   825   0.000599197
  1175   850   0.000686566
  1175   875   0.000389534
  1175   900   0.000492159
  1175   925   0.000379061
  1175   950   0.000282374
  1175   975   0.000309486
  1175  1000   0.000255766
  1200    25    0.00014428
  1200    75   3.93817e-05
  1200   125   0.000131689
  1200   175   9.23978e-05
  1200   225   0.000169948
  1200   275   0.000135783
  1200   325   0.000197577
  1200   375   0.000233954
  1200   425    0.00028733
  1200   475   0.000364022
  1200   525   0.000432872
  1200   575   0.000559704
  1200   625   0.000535909
  1200   675   0.000696054
  1200   700   0.000625004
  1200   725    0.00063829
  1200   750   0.000685161
  1200   775   0.000751175
  1200   800   0.000708307
  1200   825   0.000589958
  1200   850    0.00076909
  1200   875   0.000689998
  1200   900   0.000533511
  1200   925   0.000358027
  1200   950   0.000398596
  1200   975   0.000342807
  1200  1000   0.000260425
  1200  1025   0.000148748
  1200  1075   5.90249e-05
  1200  1125   1.92077e-05
  1225   700   0.000602336
  1225   725   0.000547475
  1225   750   0.000675651
  1225   775   0.000717278
  1225   800   0.000658858
  1225   825   0.000513043
  1225   850   0.000685384
  1225   875   0.000708109
  1225   900   0.000565506
  1225   925   0.000493491
  1225   950   0.000549716
  1225   975   0.000398425
  1225  1000   0.000268097
  1250    25   9.71556e-05
  1250    75    9.7272e-05
  1250   125   9.98681e-05
  1250   175   0.000112494
  1250   225   9.17753e-05
  1250   275   0.000187003
  1250   325   0.000166446
  1250   375   0.000218048
  1250   425   0.000199978
  1250   475   0.000242188
  1250   525   0.000254107
  1250   575   0.000375142
  1250   625    0.00052435
  1250   675   0.000538766
  1250   700   0.000553133
  1250   725   0.000636572
  1250   750   0.000589338
  1250   775   0.000646895
  1250   800   0.000721356
  1250   825   0.000634943
  1250   850   0.000563665
  1250   875   0.000665412
  1250   900   0.000606529
  1250   925   0.000717717
  1250   950   0.000615768
  1250   975   0.000482438
  1250  1000   0.000402775
  1250  1025   0.000343973
  1250  1075    0.00016683
  1250  1125   0.000104307
  1250  1175   6.27394e-06
  1250  1225   7.09129e-06
  1275   700   0.000678432
  1275   725    0.00060741
  1275   750   0.000631003
  1275   775   0.000577247
  1275   800    0.00061421
  1275   825   0.000594565
  1275   850   0.000682977
  1275   875   0.000609348
  1275   900   0.000661801
  1275   925   0.000640697
  1275   950   0.000672064
  1275   975    0.00049643
  1275  1000   0.000494742
  1300    25   4.35046e-05
  1300    75   6.88588e-05
  1300   125   7.12355e-05
  1300   175    0.00010465
  1300   225   8.03686e-05
  1300   275   0.000165963
  1300   325     9.481e-05
  1300   375   0.000211542
  1300   425   0.000169653
  1300   475   0.000275405
  1300   525   0.000202479
  1300   575   0.000271682
  1300   625   0.000297314
  1300   675   0.000399107
  1300   700    0.00047676
  1300   725   0.000581724
  1300   750   0.000534787
  1300   775   0.000629152
  1300   800   0.000624187
  1300   825   0.000648646
  1300   850    0.00054433
  1300   875   0.000635671
  1300   900   0.000690902
  1300   925   0.000559182
  1300   950   0.000664271
  1300   975   0.000530185
  1300  1000   0.000511105
  1300  1025    0.00040294
  1300  1075   0.000298338
  1300  1125   0.000222756
  1300  1175   6.35168e-05
  1300  1225    7.0889e-06
  1325   700   0.000378352
  1325   725   0.000531398
  1325   750   0.000388989
  1325   775   0.000568402
  1325   800   0.000528006
  1325   825    0.00063973
  1325   850   0.000594666
  1325   875   0.000611086
  1325   900   0.000676684
  1325   925   0.000551413
  1325   950   0.000626198
  1325   975    0.00071714
  1325  1000    0.00043863
  1350    25    6.9543e-05
  1350    75   3.88121e-05
  1350   125   8.50496e-05
  1350   175   8.61765e-05
  1350   225   5.63946e-05
  1350   275   5.21875e-05
  1350   325   7.46343e-05
  1350   375   0.000118354
  1350   425   0.000102598
  1350   475   0.000169124
  1350   525   0.000187006
  1350   575   0.000179066
  1350   625   0.000334034
  1350   675   0.000391899
  1350   700   0.000288298
  1350   725   0.000305049
  1350   750   0.000455878
  1350   775   0.000528889
  1350   800    0.00052517
  1350   825    0.00063138
  1350   850   0.000674872
  1350   875    0.00060998
  1350   900   0.000796013
  1350   925   0.000674464
  1350   950   0.000630008
  1350   975   0.000628848
  1350  1000   0.000649861
  1350  1025   0.000529986
  1350  1075   0.000422612
  1350  1125   0.000321137
  1350  1175   9.89013e-05
  1350  1225   7.04736e-05
  1350  1275   1.26358e-05
  1350  1325   6.13183e-06
  1375   700   0.000331144
  1375   725   0.000403539
  1375   750   0.000501022
  1375   775   0.000452258
  1375   800   0.000544151
  1375   825   0.000618027
  1375   850   0.000489058
  1375   875   0.000660176
  1375   900    0.00066492
  1375   925    0.00068162
  1375   950   0.000529978
  1375   975    0.00069951
  1375  1000   0.000644175
  1400    25   2.47889e-05
  1400    75   3.71653e-05
  1400   125   3.68582e-05
  1400   175   3.90295e-05
  1400   225   8.50696e-05
  1400   275   6.79312e-05
  1400   325    7.2946e-05
  1400   375   6.81257e-05
  1400   425   0.000117611
  1400   475    0.00014967
  1400   525   0.000190485
  1400   575   0.000183517
  1400   625   0.000253394
  1400   675   0.000307691
  1400   700   0.000268596
  1400   725   0.000230594
  1400   750   0.000334331
  1400   775   0.000347999
  1400   800   0.000449356
  1400   825   0.000539525
  1400   850   0.000484328
  1400   875   0.000577429
  1400   900   0.000654318
  1400   925   0.000552413
  1400   950   0.000677688
  1400   975     0.0004962
  1400  1000   0.000506367
  1400  1025   0.000489972
  1400  1075   0.000485551
  1400  1125   0.000519932
  1400  1175   0.000295343
  1400  1225   0.000165993
  1400  1275   6.61798e-05
  1400  1325   6.00944e-06
*/
