{
//=========Macro generated from canvas: c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf/c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf
//=========  (Sat Feb 22 16:30:38 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf = new TCanvas("c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf", "c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf",120,336,500,500);
   c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf->SetFillColor(0);
   c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf->SetLogz();
   c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1250HT1500_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1250HT1500_200MHTinf","h_EffAcc_8NJetinf_1250HT1500_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(141,0.0002857531);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(143,0.0003759315);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(145,0.0006747571);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(147,0.0009821963);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(149,0.001365939);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(151,0.001520855);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(153,0.001886381);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(155,0.002340183);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(157,0.002927983);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(159,0.002957483);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(161,0.003252598);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(163,0.003197171);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(165,0.003041515);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(167,0.003452193);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(169,0.002680196);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(171,0.002711803);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(173,0.00241829);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(175,0.002153189);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(177,0.002129004);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(179,0.001900697);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(181,0.001618803);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(265,0.0002085195);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(267,0.0003023858);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(269,0.0005882682);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(271,0.0008531871);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(273,0.001239119);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(275,0.001669542);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(277,0.001986199);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(279,0.002127828);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(281,0.002673042);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(283,0.003037551);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(285,0.003109675);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(287,0.003251345);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(289,0.003259136);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(291,0.003095816);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(293,0.002843759);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(295,0.002729857);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(297,0.002696389);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(299,0.00230499);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(301,0.001931576);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(303,0.00191831);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(305,0.001855637);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(389,0.0001260023);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(391,0.0002703195);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(393,0.000433621);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(395,0.000692276);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(397,0.001117876);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(399,0.001515256);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(401,0.002010444);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(403,0.00196444);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(405,0.002621033);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(407,0.002568993);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(409,0.003122376);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(411,0.003102915);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(413,0.003020023);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(415,0.003430011);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(417,0.003077699);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(419,0.003160699);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(421,0.002619327);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(423,0.002553828);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(425,0.002264854);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(427,0.001933549);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(429,0.001839901);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(513,0.0001077095);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(515,0.0001601955);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(517,0.0003419446);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(519,0.0006309078);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(521,0.0008130637);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(523,0.001141361);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(525,0.0015557);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(527,0.001905917);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(529,0.002208138);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(531,0.002901988);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(533,0.002881754);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(535,0.002878423);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(537,0.003180342);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(539,0.002967068);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(541,0.003228656);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(543,0.002965795);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(545,0.00268761);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(547,0.002604672);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(549,0.002693384);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(551,0.00212297);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(553,0.001878813);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(637,6.55337e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(639,0.0001557069);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(641,0.0002014897);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(643,0.0004345999);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(645,0.0005923964);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(647,0.0009298544);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(649,0.001246557);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(651,0.001563766);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(653,0.002057531);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(655,0.002324812);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(657,0.002576452);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(659,0.003043192);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(661,0.003213968);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(663,0.003180871);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(665,0.003336464);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(667,0.003226697);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(669,0.002967898);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(671,0.002674876);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(673,0.002529086);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(675,0.002295944);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(677,0.001933639);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(761,4.253713e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(763,5.849469e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(765,0.0001312357);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(767,0.0002316159);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(769,0.0004844932);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(771,0.0006676658);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(773,0.001132619);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(775,0.001372044);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(777,0.001702144);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(779,0.002295805);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(781,0.002556613);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(783,0.002537368);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(785,0.003045518);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(787,0.003470076);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(789,0.003217736);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(791,0.002784188);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(793,0.002724737);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(795,0.002984574);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(797,0.002617881);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(799,0.002363902);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(801,0.00207293);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(885,2.114368e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(887,4.460094e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(889,6.645268e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(891,0.0001924304);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(893,0.0003190548);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(895,0.0004978267);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(897,0.0009059665);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(899,0.0009841539);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(901,0.001226132);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(903,0.001621774);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(905,0.002288621);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(907,0.002568871);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(909,0.002835016);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(911,0.003141985);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(913,0.002947502);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(915,0.003158874);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(917,0.003037792);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(919,0.003023172);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(921,0.00281816);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(923,0.002462931);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(925,0.002375645);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1013,3.817441e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1015,0.0001187773);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1017,0.0002538482);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1019,0.0002691345);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1021,0.0005771635);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1023,0.0008422649);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1025,0.001176112);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1027,0.001521175);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1029,0.00166356);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1031,0.002411559);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1033,0.00262888);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1035,0.002869359);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1037,0.003050663);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1039,0.003313624);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1041,0.003041821);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1043,0.002870429);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1045,0.002741079);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1047,0.002863393);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1049,0.002399607);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1137,1.457273e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1139,4.390071e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1141,0.000158204);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1143,0.0002127107);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1145,0.0004426577);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1147,0.0006846836);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1149,0.000946183);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1151,0.001163523);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1153,0.001319431);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1155,0.001916666);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1157,0.002203132);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1159,0.002452774);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1161,0.002837103);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1163,0.002986064);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1165,0.002883702);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1167,0.003262639);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1169,0.003103055);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1171,0.002689369);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1173,0.002604108);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1263,1.467674e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1265,2.207256e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1267,0.0001552256);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1269,0.0001757949);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1271,0.0003428003);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1273,0.0005876694);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1275,0.000941771);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1277,0.001210041);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1279,0.00163314);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1281,0.001680405);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1283,0.002272547);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1285,0.002531823);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1287,0.002701293);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1289,0.002790973);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1291,0.00269403);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1293,0.003037715);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1295,0.002770139);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1297,0.00278477);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1389,7.342693e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1391,1.461863e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1393,0.000125729);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1395,0.0002782201);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1397,0.0004038331);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1399,0.0005609676);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1401,0.0008649397);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1403,0.001221578);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1405,0.001439091);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1407,0.001896995);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1409,0.002220928);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1411,0.002234721);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1413,0.002669659);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1415,0.002554302);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1417,0.003134021);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1419,0.002789635);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1421,0.002842986);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1517,9.445817e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1519,6.59186e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1521,0.0002746782);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1523,0.0004425374);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1525,0.0006365981);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1527,0.0007998752);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1529,0.00117419);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1531,0.001380076);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1533,0.001591197);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1535,0.002098183);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1537,0.002542473);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1539,0.002821669);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1541,0.002628715);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1543,0.002955044);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1545,0.002788233);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1639,7.312444e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1641,1.449869e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1643,8.064045e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1645,0.0001241857);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1647,0.0002706596);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1649,0.0004137096);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1651,0.0005971241);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1653,0.0007687366);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1655,0.001158788);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1657,0.001497322);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1659,0.00184213);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1661,0.001972066);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1663,0.002376574);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1665,0.002481682);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1667,0.0026673);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1669,0.002602778);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1767,3.693077e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1769,4.358659e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1771,0.0001635615);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1773,0.0002904139);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1775,0.0003783947);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1777,0.0006239347);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1783,0.001297848);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1785,0.001721578);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1787,0.002030127);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1789,0.002224163);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1791,0.002606048);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1793,0.00248302);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1845,0.001179429);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1846,0.001386091);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1847,0.001425337);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1848,0.001590277);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1849,0.002140676);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1850,0.001997513);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1851,0.002311837);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1852,0.00217733);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1853,0.00259235);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1854,0.002554162);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1855,0.002579224);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1893,2.147808e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1895,9.872395e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1897,0.0001456863);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1899,0.0002578809);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1901,0.0004263729);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1907,0.001033936);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1908,0.001237153);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1909,0.001295523);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1910,0.001467589);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1911,0.001711315);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1912,0.001843728);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1913,0.002266784);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1914,0.002129644);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1915,0.002271288);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1916,0.002451364);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1917,0.002368867);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1969,0.0008592553);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1970,0.0011322);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1971,0.001473097);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1972,0.001431538);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1973,0.0016597);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1974,0.001627874);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1975,0.002007325);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1976,0.001824278);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1977,0.002053683);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1978,0.002256502);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1979,0.002330403);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2019,1.410461e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2021,5.573131e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2023,0.0001113748);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2025,0.0002190486);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2031,0.0008231651);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2032,0.001127845);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2033,0.001177906);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2034,0.001180321);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2035,0.001316197);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2036,0.001484627);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2037,0.001628082);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2038,0.001788688);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2039,0.001924986);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2040,0.001864614);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2041,0.002174994);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2093,0.0007362913);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2094,0.0007930963);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2095,0.0008428619);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2096,0.001030286);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2097,0.001279528);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2098,0.001325913);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2099,0.001389889);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2100,0.00164727);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2101,0.001726595);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2102,0.002006779);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2103,0.002000482);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2145,2.092747e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2147,4.17326e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2149,0.000151809);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2155,0.0004802508);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2156,0.0006875039);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2157,0.0007535901);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2158,0.0007399586);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2159,0.001018189);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2160,0.001256994);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2161,0.001221538);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2162,0.001382564);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2163,0.001799275);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2164,0.002050286);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2165,0.001793492);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2217,0.0004242428);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2218,0.0004817433);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2219,0.0007554778);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2220,0.0008161795);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2221,0.0008156336);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2222,0.001099242);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2223,0.001205538);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2224,0.001390258);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2225,0.001499181);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2226,0.001844191);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2227,0.001680477);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2269,1.391998e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2271,6.894546e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2273,4.170112e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2279,0.000445327);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2280,0.0004577739);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2281,0.0006042053);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2282,0.0005369526);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2283,0.0008204785);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2284,0.0008211854);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2285,0.001074474);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2286,0.001313103);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2287,0.001302359);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2288,0.001380125);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2289,0.001520377);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2341,0.0002633235);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2342,0.0004113569);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2343,0.0004442589);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2344,0.0004652196);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2345,0.0005906225);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2346,0.0008472018);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2347,0.0008485904);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2348,0.0009283704);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2349,0.001075032);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2350,0.001209244);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2351,0.001474381);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2397,1.355707e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2403,0.0001428159);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2404,0.000278543);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2405,0.0002944933);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2406,0.0003876283);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2407,0.0003953117);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2408,0.0005441701);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2409,0.0005945195);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2410,0.0007019056);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2411,0.0009284888);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2412,0.0009941711);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2413,0.001219131);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2465,0.0001442945);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2466,0.0001834014);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2467,0.0002743844);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2468,0.0003222193);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2469,0.0004396099);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2470,0.0004427714);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2471,0.0006378865);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2472,0.0007861244);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2473,0.0007945738);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2474,0.0009168004);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2475,0.001105227);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2527,0.0001310431);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2528,0.0001297584);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2529,0.0002066452);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2530,0.0001948385);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2531,0.0003095481);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2532,0.0004726047);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2533,0.0005270754);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2534,0.0005847981);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2535,0.000784289);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2536,0.0008135688);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2537,0.000897026);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2589,9.084402e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2590,0.0001032747);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2591,0.0001230229);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2592,0.0001795289);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2593,0.0002180193);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2594,0.0003278564);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2595,0.0003198777);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2596,0.000553794);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2597,0.0006724283);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2598,0.0006504559);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2599,0.0007478112);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2651,7.135536e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2653,0.0001209078);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2655,0.000199701);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2657,0.0002877586);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2659,0.0004860116);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2661,0.0006852378);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2775,6.479464e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2777,3.828643e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2779,0.0001141051);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2781,0.0002265661);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2783,0.0002896595);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2785,0.0003341423);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2901,1.280513e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2903,1.896491e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2905,9.313834e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2907,0.0001733675);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2909,0.0002545226);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3027,6.273937e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3029,1.239352e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3031,6.506666e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3033,0.0001461644);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3153,6.301242e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3155,3.09774e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3157,9.013208e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3279,6.317923e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3281,1.203269e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3403,6.131828e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3405,6.009444e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(141,4.991644e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(143,5.330585e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(145,7.263148e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(147,8.931341e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(149,0.0001039938);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(151,0.000111147);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(153,0.0001215519);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(155,0.0001358263);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(157,0.0001543026);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(159,0.0001525573);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(161,0.0001588566);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(163,0.0001575767);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(165,0.0001534698);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(167,0.000164864);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(169,0.0001429622);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(171,0.0001436252);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(173,0.0001386157);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(175,0.0001311082);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(177,0.0001246778);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(179,0.0001249783);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(181,0.0001160796);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(265,3.949604e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(267,4.857327e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(269,6.811501e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(271,8.203563e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(273,9.865726e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(275,0.0001148946);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(277,0.00012492);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(279,0.0001593716);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(281,0.000144648);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(283,0.0001544373);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(285,0.0001563402);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(287,0.0001651237);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(289,0.0001892396);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(291,0.0001535206);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(293,0.0001464585);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(295,0.0001424634);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(297,0.0001448299);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(299,0.0001482307);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(301,0.0001262596);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(303,0.0001216219);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(305,0.0001146445);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(389,3.065572e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(391,4.519401e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(393,5.863366e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(395,7.236151e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(397,9.354394e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(399,0.0001095526);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(401,0.000126269);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(403,0.0001238295);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(405,0.0001435525);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(407,0.0001415542);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(409,0.0001561928);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(411,0.0001548818);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(413,0.0001524127);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(415,0.0001904709);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(417,0.0001522233);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(419,0.0001539533);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(421,0.0001393267);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(423,0.0001379238);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(425,0.0001523057);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(427,0.0001264085);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(429,0.0001143078);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(513,2.78123e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(515,3.417863e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(517,5.109114e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(519,6.936217e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(521,7.960607e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(523,9.449125e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(525,0.0001107179);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(527,0.0001243411);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(529,0.0001309676);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(531,0.0001488944);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(533,0.000148872);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(535,0.0001484109);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(537,0.0001575165);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(539,0.0001875537);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(541,0.0001561444);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(543,0.0001484989);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(545,0.0001491534);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(547,0.0001380988);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(549,0.0001572854);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(551,0.0001241313);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(553,0.0001214779);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(637,2.190914e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(639,3.40325e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(641,3.962736e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(643,5.876029e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(645,6.775668e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(647,8.444079e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(649,9.836361e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(651,0.0001148951);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(653,0.000137857);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(655,0.0001340372);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(657,0.0001427617);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(659,0.0001522109);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(661,0.0001567752);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(663,0.0001542777);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(665,0.0001590521);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(667,0.0001558603);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(669,0.000147147);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(671,0.0001399039);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(673,0.0001350799);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(675,0.000135873);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(677,0.0001168995);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(761,1.736616e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(763,2.069884e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(765,3.093502e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(767,4.168839e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(769,6.069724e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(771,7.139479e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(773,9.311528e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(775,0.0001029651);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(777,0.0001144501);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(779,0.0001325628);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(781,0.0001391845);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(783,0.0001385115);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(785,0.0001529247);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(787,0.0001634227);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(789,0.0001540751);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(791,0.0001428738);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(793,0.0001507133);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(795,0.0001476148);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(797,0.0001372763);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(799,0.000146212);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(801,0.000141022);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(885,1.220747e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(887,1.820875e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(889,2.216839e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(891,3.778582e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(893,4.868893e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(895,6.144305e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(897,8.401283e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(899,8.662572e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(901,9.63788e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(903,0.0001105546);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(905,0.0001316971);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(907,0.0001394171);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(909,0.0001464048);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(911,0.0001532731);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(913,0.000147267);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(915,0.0002089691);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(917,0.0001484518);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(919,0.0001488338);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(921,0.0001425218);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(923,0.0001322613);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(925,0.0001563379);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1013,1.714974e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1015,2.9721e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1017,4.359263e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1019,4.492823e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1021,6.595525e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1023,7.984913e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1025,9.389379e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1027,0.0001063591);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1029,0.0001114023);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1031,0.0001339889);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1033,0.0001441411);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1035,0.0001458866);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1037,0.0001496664);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1039,0.0001576594);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1041,0.0001523347);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1043,0.000143748);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1045,0.0001396989);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1047,0.0001438554);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1049,0.0001644782);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1137,1.030457e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1139,1.792286e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1141,3.458416e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1143,3.951462e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1145,5.780996e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1147,7.110934e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1149,8.494753e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1151,9.318063e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1153,9.900988e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1155,0.0001192022);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1157,0.0001269367);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1159,0.0001338796);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1161,0.0001436652);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1163,0.00014618);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1165,0.0001442454);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1167,0.0001584108);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1169,0.0001490439);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1171,0.000137584);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1173,0.0001561119);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1263,1.037812e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1265,1.274377e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1267,3.38984e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1269,3.589886e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1271,5.062889e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1273,6.541854e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1275,8.285029e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1277,9.395516e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1279,0.0001090521);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1281,0.0001102912);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1283,0.000128848);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1285,0.0001350867);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1287,0.000139161);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1289,0.0001420933);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1291,0.0001548363);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1293,0.0001476239);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1295,0.0001406254);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1297,0.0001460893);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1389,7.342726e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1391,1.033702e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1393,3.053496e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1395,4.517635e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1397,5.403952e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1399,6.411125e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1401,7.884791e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1403,9.434187e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1405,0.0001019235);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1407,0.0001200458);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1409,0.0001261806);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1411,0.0001255377);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1413,0.0001404836);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1415,0.0001422081);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1417,0.0001541162);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1419,0.0001398538);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1421,0.000141876);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1517,2.619948e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1519,2.199021e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1521,4.462567e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1523,5.679703e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1525,6.760197e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1527,7.583398e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1529,0.0001118205);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1531,9.952585e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1533,0.0001063237);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1535,0.000121107);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1537,0.0001331787);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1539,0.0001420285);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1541,0.0001352277);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1543,0.0001552933);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1545,0.0001762431);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1639,7.312476e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1641,1.025221e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1643,2.433052e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1645,3.01943e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1647,4.396613e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1649,5.492419e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1651,6.490044e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1653,7.871077e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1655,9.053807e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1657,0.0001039885);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1659,0.0001159038);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1661,0.0001165344);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1663,0.0001291846);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1665,0.0001318186);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1667,0.0001350846);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1669,0.0001408653);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1767,1.653594e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1769,1.781313e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1771,3.411924e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1773,4.54256e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1775,5.15678e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1777,6.708597e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1783,9.709055e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1785,0.0001107417);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1787,0.0001183693);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1789,0.0001237765);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1791,0.0001338427);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1793,0.0001285272);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1845,8.973729e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1846,9.692081e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1847,0.0001052382);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1848,0.0001037587);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1849,0.0001206108);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1850,0.0001201559);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1851,0.0001313364);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1852,0.0001409727);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1853,0.0001461633);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1854,0.0001305022);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1855,0.0001333537);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1893,1.240053e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1895,2.638666e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1897,3.179416e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1899,4.245656e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1901,6.09799e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1907,8.415213e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1908,9.206707e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1909,9.510445e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1910,0.0001002418);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1911,0.0001084727);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1912,0.0001112595);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1913,0.0001235059);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1914,0.0001225302);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1915,0.0001278583);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1916,0.0001281191);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1917,0.0001262102);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1969,7.615884e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1970,8.816728e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1971,9.972557e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1972,0.0001037502);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1973,0.000107534);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1974,0.0001062076);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1975,0.0001167964);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1976,0.0001107398);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1977,0.0001212202);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1978,0.0001226229);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1979,0.0001250171);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2019,9.973554e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2021,1.970466e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2023,2.786861e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2025,3.874521e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2031,8.092545e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2032,8.751422e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2033,8.910419e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2034,8.905451e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2035,9.637478e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2036,9.93861e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2037,0.0001062072);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2038,0.0001116171);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2039,0.0001194635);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2040,0.0001111503);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2041,0.0001355151);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2093,7.382507e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2094,7.727006e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2095,7.53571e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2096,8.331424e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2097,9.546935e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2098,9.361946e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2099,9.773075e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2100,0.0001042238);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2101,0.0001064975);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2102,0.0001179937);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2103,0.0001145423);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2145,1.208263e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2147,1.703769e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2149,3.239749e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2155,5.630091e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2156,6.757134e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2157,7.076215e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2158,7.008304e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2159,8.339844e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2160,9.68087e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2161,9.041684e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2162,9.645617e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2163,0.0001099462);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2164,0.0001269979);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2165,0.0001217594);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2217,5.316208e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2218,5.688469e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2219,7.095584e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2220,7.317324e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2221,7.378406e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2222,9.032831e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2223,9.175907e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2224,9.513313e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2225,0.0001015227);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2226,0.0001333119);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2227,0.0001053162);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2269,9.842994e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2271,6.894574e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2273,1.704255e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2279,5.405559e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2280,5.97107e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2281,6.385978e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2282,5.941707e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2283,7.361905e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2284,7.542468e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2285,8.447478e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2286,9.275802e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2287,9.177514e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2288,9.400742e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2289,0.0001019907);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2341,4.170759e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2342,5.232504e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2343,5.397893e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2344,5.533777e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2345,6.384634e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2346,7.538843e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2347,7.583321e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2348,7.897104e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2349,8.451163e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2350,9.179241e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2351,9.740304e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2397,9.586375e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2403,3.046128e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2404,4.249204e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2405,4.400723e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2406,5.055811e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2407,5.111677e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2408,6.024245e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2409,6.179389e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2410,6.740734e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2411,7.933762e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2412,8.015888e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2413,8.826451e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2465,3.079783e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2466,3.470744e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2467,4.241239e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2468,4.608831e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2469,5.342395e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2470,5.552782e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2471,6.429524e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2472,8.403092e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2473,7.098327e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2474,7.667444e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2475,8.334069e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2527,2.931517e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2528,2.902777e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2529,3.655104e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2530,3.563135e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2531,4.477993e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2532,5.505286e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2533,5.837715e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2534,6.43154e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2535,7.181461e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2536,7.216152e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2537,7.918984e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2589,2.428042e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2590,2.582029e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2591,2.826828e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2592,3.394049e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2593,3.803798e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2594,4.735895e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2595,4.533683e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2596,5.951249e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2597,6.51558e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2598,6.52271e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2599,6.992337e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2651,2.151538e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2653,2.774019e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2655,3.591326e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2657,4.300051e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2659,5.511256e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2661,8.269601e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2775,6.47949e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2777,1.563073e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2779,2.690755e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2781,3.781039e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2783,4.227187e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2785,4.685883e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2901,9.054666e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2903,1.094952e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2905,2.404957e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2907,3.345952e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2909,3.929968e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3027,6.27396e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3029,8.763606e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3031,2.1759e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3033,2.987475e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3153,6.301266e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3155,1.385377e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3157,2.327328e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3279,6.317947e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3281,8.508462e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3403,6.131851e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3405,6.009466e-06);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetEntries(82667.24);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->Draw("colz");
   c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf->Modified();
   c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf->cd();
   c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf->SetSelected(c_AccEffMap_T1qqqq_8NJetinf_1250HT1500_200MHTinf);
}
/*
Topology ~g ~g ; ~g ->q+qbar+LSP

mGluino(GeV) mLSP(GeV) AccXEff
   400    25   0.000285753
   400    75   0.000208519
   400   125   0.000126002
   400   175    0.00010771
   400   225   6.55337e-05
   400   275   4.25371e-05
   400   325   2.11437e-05
   450    25   0.000375932
   450    75   0.000302386
   450   125    0.00027032
   450   175   0.000160196
   450   225   0.000155707
   450   275   5.84947e-05
   450   325   4.46009e-05
   500    25   0.000674757
   500    75   0.000588268
   500   125   0.000433621
   500   175   0.000341945
   500   225    0.00020149
   500   275   0.000131236
   500   325   6.64527e-05
   500   375   3.81744e-05
   500   425   1.45727e-05
   550    25   0.000982196
   550    75   0.000853187
   550   125   0.000692276
   550   175   0.000630908
   550   225     0.0004346
   550   275   0.000231616
   550   325    0.00019243
   550   375   0.000118777
   550   425   4.39007e-05
   550   475   1.46767e-05
   600    25    0.00136594
   600    75    0.00123912
   600   125    0.00111788
   600   175   0.000813064
   600   225   0.000592396
   600   275   0.000484493
   600   325   0.000319055
   600   375   0.000253848
   600   425   0.000158204
   600   475   2.20726e-05
   600   525   7.34269e-06
   650    25    0.00152085
   650    75    0.00166954
   650   125    0.00151526
   650   175    0.00114136
   650   225   0.000929854
   650   275   0.000667666
   650   325   0.000497827
   650   375   0.000269135
   650   425   0.000212711
   650   475   0.000155226
   650   525   1.46186e-05
   650   625   7.31244e-06
   700    25    0.00188638
   700    75     0.0019862
   700   125    0.00201044
   700   175     0.0015557
   700   225    0.00124656
   700   275    0.00113262
   700   325   0.000905966
   700   375   0.000577164
   700   425   0.000442658
   700   475   0.000175795
   700   525   0.000125729
   700   575   9.44582e-05
   700   625   1.44987e-05
   750    25    0.00234018
   750    75    0.00212783
   750   125    0.00196444
   750   175    0.00190592
   750   225    0.00156377
   750   275    0.00137204
   750   325   0.000984154
   750   375   0.000842265
   750   425   0.000684684
   750   475     0.0003428
   750   525    0.00027822
   750   575   6.59186e-05
   750   625   8.06404e-05
   750   675   3.69308e-05
   800    25    0.00292798
   800    75    0.00267304
   800   125    0.00262103
   800   175    0.00220814
   800   225    0.00205753
   800   275    0.00170214
   800   325    0.00122613
   800   375    0.00117611
   800   425   0.000946183
   800   475   0.000587669
   800   525   0.000403833
   800   575   0.000274678
   800   625   0.000124186
   800   675   4.35866e-05
   800   725   2.14781e-05
   850    25    0.00295748
   850    75    0.00303755
   850   125    0.00256899
   850   175    0.00290199
   850   225    0.00232481
   850   275     0.0022958
   850   325    0.00162177
   850   375    0.00152117
   850   425    0.00116352
   850   475   0.000941771
   850   525   0.000560968
   850   575   0.000442537
   850   625    0.00027066
   850   675   0.000163562
   850   725   9.87239e-05
   850   775   1.41046e-05
   900    25     0.0032526
   900    75    0.00310968
   900   125    0.00312238
   900   175    0.00288175
   900   225    0.00257645
   900   275    0.00255661
   900   325    0.00228862
   900   375    0.00166356
   900   425    0.00131943
   900   475    0.00121004
   900   525    0.00086494
   900   575   0.000636598
   900   625    0.00041371
   900   675   0.000290414
   900   725   0.000145686
   900   775   5.57313e-05
   900   825   2.09275e-05
   900   875     1.392e-05
   950    25    0.00319717
   950    75    0.00325134
   950   125    0.00310291
   950   175    0.00287842
   950   225    0.00304319
   950   275    0.00253737
   950   325    0.00256887
   950   375    0.00241156
   950   425    0.00191667
   950   475    0.00163314
   950   525    0.00122158
   950   575   0.000799875
   950   625   0.000597124
   950   675   0.000378395
   950   725   0.000257881
   950   775   0.000111375
   950   825   4.17326e-05
   950   875   6.89455e-06
  1000    25    0.00304152
  1000    75    0.00325914
  1000   125    0.00302002
  1000   175    0.00318034
  1000   225    0.00321397
  1000   275    0.00304552
  1000   325    0.00283502
  1000   375    0.00262888
  1000   425    0.00220313
  1000   475     0.0016804
  1000   525    0.00143909
  1000   575    0.00117419
  1000   625   0.000768737
  1000   675   0.000623935
  1000   725   0.000426373
  1000   775   0.000219049
  1000   825   0.000151809
  1000   875   4.17011e-05
  1000   925   1.35571e-05
  1050    25    0.00345219
  1050    75    0.00309582
  1050   125    0.00343001
  1050   175    0.00296707
  1050   225    0.00318087
  1050   275    0.00347008
  1050   325    0.00314199
  1050   375    0.00286936
  1050   425    0.00245277
  1050   475    0.00227255
  1050   525      0.001897
  1050   575    0.00138008
  1050   625    0.00115879
  1100    25     0.0026802
  1100    75    0.00284376
  1100   125     0.0030777
  1100   175    0.00322866
  1100   225    0.00333646
  1100   275    0.00321774
  1100   325     0.0029475
  1100   375    0.00305066
  1100   425     0.0028371
  1100   475    0.00253182
  1100   525    0.00222093
  1100   575     0.0015912
  1100   625    0.00149732
  1150    25     0.0027118
  1150    75    0.00272986
  1150   125     0.0031607
  1150   175     0.0029658
  1150   225     0.0032267
  1150   275    0.00278419
  1150   325    0.00315887
  1150   375    0.00331362
  1150   425    0.00298606
  1150   475    0.00270129
  1150   525    0.00223472
  1150   575    0.00209818
  1150   625    0.00184213
  1150   675    0.00129785
  1150   700    0.00117943
  1150   725    0.00103394
  1150   750   0.000859255
  1150   775   0.000823165
  1150   800   0.000736291
  1150   825   0.000480251
  1150   850   0.000424243
  1150   875   0.000445327
  1150   900   0.000263323
  1150   925   0.000142816
  1150   950   0.000144295
  1150   975   0.000131043
  1150  1000    9.0844e-05
  1150  1025   7.13554e-05
  1150  1075   6.47946e-06
  1175   700    0.00138609
  1175   725    0.00123715
  1175   750     0.0011322
  1175   775    0.00112784
  1175   800   0.000793096
  1175   825   0.000687504
  1175   850   0.000481743
  1175   875   0.000457774
  1175   900   0.000411357
  1175   925   0.000278543
  1175   950   0.000183401
  1175   975   0.000129758
  1175  1000   0.000103275
  1200    25    0.00241829
  1200    75    0.00269639
  1200   125    0.00261933
  1200   175    0.00268761
  1200   225     0.0029679
  1200   275    0.00272474
  1200   325    0.00303779
  1200   375    0.00304182
  1200   425     0.0028837
  1200   475    0.00279097
  1200   525    0.00266966
  1200   575    0.00254247
  1200   625    0.00197207
  1200   675    0.00172158
  1200   700    0.00142534
  1200   725    0.00129552
  1200   750     0.0014731
  1200   775    0.00117791
  1200   800   0.000842862
  1200   825    0.00075359
  1200   850   0.000755478
  1200   875   0.000604205
  1200   900   0.000444259
  1200   925   0.000294493
  1200   950   0.000274384
  1200   975   0.000206645
  1200  1000   0.000123023
  1200  1025   0.000120908
  1200  1075   3.82864e-05
  1200  1125   1.28051e-05
  1225   700    0.00159028
  1225   725    0.00146759
  1225   750    0.00143154
  1225   775    0.00118032
  1225   800    0.00103029
  1225   825   0.000739959
  1225   850    0.00081618
  1225   875   0.000536953
  1225   900    0.00046522
  1225   925   0.000387628
  1225   950   0.000322219
  1225   975   0.000194838
  1225  1000   0.000179529
  1250    25    0.00215319
  1250    75    0.00230499
  1250   125    0.00255383
  1250   175    0.00260467
  1250   225    0.00267488
  1250   275    0.00298457
  1250   325    0.00302317
  1250   375    0.00287043
  1250   425    0.00326264
  1250   475    0.00269403
  1250   525     0.0025543
  1250   575    0.00282167
  1250   625    0.00237657
  1250   675    0.00203013
  1250   700    0.00214068
  1250   725    0.00171132
  1250   750     0.0016597
  1250   775     0.0013162
  1250   800    0.00127953
  1250   825    0.00101819
  1250   850   0.000815634
  1250   875   0.000820479
  1250   900   0.000590622
  1250   925   0.000395312
  1250   950    0.00043961
  1250   975   0.000309548
  1250  1000   0.000218019
  1250  1025   0.000199701
  1250  1075   0.000114105
  1250  1125   1.89649e-05
  1250  1175   6.27394e-06
  1275   700    0.00199751
  1275   725    0.00184373
  1275   750    0.00162787
  1275   775    0.00148463
  1275   800    0.00132591
  1275   825    0.00125699
  1275   850    0.00109924
  1275   875   0.000821185
  1275   900   0.000847202
  1275   925    0.00054417
  1275   950   0.000442771
  1275   975   0.000472605
  1275  1000   0.000327856
  1300    25      0.002129
  1300    75    0.00193158
  1300   125    0.00226485
  1300   175    0.00269338
  1300   225    0.00252909
  1300   275    0.00261788
  1300   325    0.00281816
  1300   375    0.00274108
  1300   425    0.00310305
  1300   475    0.00303772
  1300   525    0.00313402
  1300   575    0.00262872
  1300   625    0.00248168
  1300   675    0.00222416
  1300   700    0.00231184
  1300   725    0.00226678
  1300   750    0.00200733
  1300   775    0.00162808
  1300   800    0.00138989
  1300   825    0.00122154
  1300   850    0.00120554
  1300   875    0.00107447
  1300   900    0.00084859
  1300   925   0.000594519
  1300   950   0.000637887
  1300   975   0.000527075
  1300  1000   0.000319878
  1300  1025   0.000287759
  1300  1075   0.000226566
  1300  1125   9.31383e-05
  1300  1175   1.23935e-05
  1300  1225   6.30124e-06
  1325   700    0.00217733
  1325   725    0.00212964
  1325   750    0.00182428
  1325   775    0.00178869
  1325   800    0.00164727
  1325   825    0.00138256
  1325   850    0.00139026
  1325   875     0.0013131
  1325   900    0.00092837
  1325   925   0.000701906
  1325   950   0.000786124
  1325   975   0.000584798
  1325  1000   0.000553794
  1350    25     0.0019007
  1350    75    0.00191831
  1350   125    0.00193355
  1350   175    0.00212297
  1350   225    0.00229594
  1350   275     0.0023639
  1350   325    0.00246293
  1350   375    0.00286339
  1350   425    0.00268937
  1350   475    0.00277014
  1350   525    0.00278964
  1350   575    0.00295504
  1350   625     0.0026673
  1350   675    0.00260605
  1350   700    0.00259235
  1350   725    0.00227129
  1350   750    0.00205368
  1350   775    0.00192499
  1350   800     0.0017266
  1350   825    0.00179927
  1350   850    0.00149918
  1350   875    0.00130236
  1350   900    0.00107503
  1350   925   0.000928489
  1350   950   0.000794574
  1350   975   0.000784289
  1350  1000   0.000672428
  1350  1025   0.000486012
  1350  1075    0.00028966
  1350  1125   0.000173367
  1350  1175   6.50667e-05
  1350  1225   3.09774e-05
  1350  1275   6.31792e-06
  1350  1325   6.13183e-06
  1375   700    0.00255416
  1375   725    0.00245136
  1375   750     0.0022565
  1375   775    0.00186461
  1375   800    0.00200678
  1375   825    0.00205029
  1375   850    0.00184419
  1375   875    0.00138013
  1375   900    0.00120924
  1375   925   0.000994171
  1375   950     0.0009168
  1375   975   0.000813569
  1375  1000   0.000650456
  1400    25     0.0016188
  1400    75    0.00185564
  1400   125     0.0018399
  1400   175    0.00187881
  1400   225    0.00193364
  1400   275    0.00207293
  1400   325    0.00237564
  1400   375    0.00239961
  1400   425    0.00260411
  1400   475    0.00278477
  1400   525    0.00284299
  1400   575    0.00278823
  1400   625    0.00260278
  1400   675    0.00248302
  1400   700    0.00257922
  1400   725    0.00236887
  1400   750     0.0023304
  1400   775    0.00217499
  1400   800    0.00200048
  1400   825    0.00179349
  1400   850    0.00168048
  1400   875    0.00152038
  1400   900    0.00147438
  1400   925    0.00121913
  1400   950    0.00110523
  1400   975   0.000897026
  1400  1000   0.000747811
  1400  1025   0.000685238
  1400  1075   0.000334142
  1400  1125   0.000254523
  1400  1175   0.000146164
  1400  1225   9.01321e-05
  1400  1275   1.20327e-05
  1400  1325   6.00944e-06
*/
