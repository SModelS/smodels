{
//=========Macro generated from canvas: c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf/c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf
//=========  (Sat Feb 22 16:31:37 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf = new TCanvas("c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf", "c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf",110,288,500,500);
   c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf->SetFillColor(0);
   c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf->SetLogz();
   c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_800HT1000_200MHTinf = new TH2D("h_EffAcc_8NJetinf_800HT1000_200MHTinf","h_EffAcc_8NJetinf_800HT1000_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(79,0.0002885652);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(81,0.0009056931);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(83,0.001893735);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(85,0.004201463);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(87,0.007067152);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(89,0.01001197);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(91,0.01363503);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(93,0.01554451);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(95,0.01614627);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(97,0.01523766);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(99,0.01376481);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(101,0.01291669);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(103,0.01131971);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(105,0.009757486);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(107,0.00832248);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(109,0.006975905);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(111,0.005921553);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(113,0.004960645);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(115,0.004008442);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(117,0.003529855);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(119,0.002566566);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(141,0.0002429418);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(143,0.0006839666);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(145,0.001777496);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(147,0.004531171);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(149,0.007244825);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(151,0.01062268);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(153,0.01343235);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(155,0.01539309);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(156,0.0161015);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(158,0.01665468);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(160,0.01459927);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(162,0.01416272);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(164,0.01224834);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(166,0.01117462);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(168,0.009282596);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(169,0.008359197);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(171,0.007182724);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(173,0.005972785);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(175,0.004782323);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(177,0.004416073);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(179,0.003440987);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(181,0.002675512);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(265,0.0001706348);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(267,0.0004846504);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(269,0.001372139);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(271,0.003271402);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(273,0.006386243);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(275,0.009952694);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(277,0.01324473);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(279,0.01610844);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(280,0.0166022);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(282,0.0174747);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(284,0.01673704);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(286,0.0146659);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(288,0.01426919);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(290,0.01196259);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(292,0.009770959);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(293,0.008739344);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(295,0.007767136);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(297,0.006717773);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(299,0.005142848);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(301,0.004358742);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(303,0.003646454);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(305,0.002937773);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(389,0.0001539468);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(391,0.0003487162);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(393,0.0006483797);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(395,0.002083101);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(397,0.004575077);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(399,0.00831149);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(401,0.01211709);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(403,0.01597445);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(404,0.01677456);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(406,0.01858108);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(408,0.01766538);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(410,0.01735859);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(412,0.01489994);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(414,0.01335048);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(416,0.01137751);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(417,0.01001667);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(419,0.008284322);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(421,0.007233709);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(423,0.005830804);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(425,0.0046708);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(427,0.003901554);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(429,0.00331985);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(513,7.904657e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(515,0.000149337);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(517,0.000446284);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(519,0.00114391);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(521,0.003323262);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(523,0.006226621);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(525,0.009692983);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(527,0.01433416);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(528,0.01575156);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(530,0.01743785);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(532,0.01889861);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(534,0.01771169);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(536,0.01632683);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(538,0.01538262);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(540,0.01228642);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(541,0.01138456);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(543,0.009740629);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(545,0.007956665);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(547,0.006590296);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(549,0.005507281);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(551,0.004270031);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(553,0.003611085);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(639,0.0001522779);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(641,0.0003482583);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(643,0.0005635317);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(645,0.001265929);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(647,0.003457537);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(649,0.006718575);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(651,0.01096864);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(652,0.01389016);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(654,0.01743092);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(656,0.01901008);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(658,0.01933943);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(660,0.0185762);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(662,0.01667088);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(664,0.01435161);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(665,0.01309524);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(667,0.01064682);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(669,0.009310473);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(671,0.007454797);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(673,0.006188774);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(675,0.004847591);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(677,0.004024454);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(765,0.0001976087);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(767,0.0004339376);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(769,0.0008592482);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(771,0.001556192);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(773,0.004509441);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(775,0.008024678);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(776,0.009496633);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(778,0.01364609);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(780,0.01811539);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(782,0.01913567);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(784,0.01998533);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(786,0.01869885);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(788,0.01639685);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(789,0.015013);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(791,0.01216598);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(793,0.01052224);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(795,0.0089553);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(797,0.006981675);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(799,0.005939823);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(801,0.004761501);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(891,0.0002493419);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(893,0.0005178398);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(895,0.001009116);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(897,0.001814245);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(899,0.004751811);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(900,0.006359266);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(902,0.01046485);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(904,0.01521665);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(906,0.01852159);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(908,0.0191905);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(910,0.01990339);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(912,0.01920032);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(913,0.01801342);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(915,0.01526336);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(917,0.01243628);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(919,0.01031272);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(921,0.008369534);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(923,0.006959719);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(925,0.005280033);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1017,0.0002553882);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1019,0.0005645656);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1021,0.001308748);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1023,0.002138857);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1024,0.003125448);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1026,0.006745348);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1028,0.0110142);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1030,0.01553732);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1032,0.01863581);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1034,0.02091327);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1036,0.02058034);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1037,0.01921237);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1039,0.01595546);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1041,0.01437532);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1043,0.012384);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1045,0.0102072);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1047,0.007916704);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1049,0.006711614);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1143,0.0002611631);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1145,0.0006452686);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1147,0.001227593);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1148,0.001405761);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1150,0.003629278);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1152,0.007309178);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1154,0.01140354);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1156,0.01640524);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1158,0.0191398);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1160,0.02094252);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1161,0.02099309);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1163,0.01920853);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1165,0.01703834);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1167,0.01457076);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1169,0.0123231);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1171,0.009412407);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1173,0.007751996);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1269,0.0003187092);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1271,0.0005388887);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1272,0.001000367);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1274,0.001739299);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1276,0.003630731);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1278,0.007466761);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1280,0.01138315);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1282,0.01654765);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1284,0.01992768);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1285,0.02028049);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1287,0.0209197);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1289,0.0195593);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1291,0.01723681);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1293,0.01454872);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1295,0.01165061);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1297,0.00966867);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1395,0.0003247525);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1396,0.0005055059);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1398,0.0009757193);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1400,0.001765428);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1402,0.004285402);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1404,0.007526632);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1406,0.01210149);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1408,0.01682307);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1409,0.01899836);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1410,0.02036699);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1411,0.02040732);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1412,0.02169211);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1413,0.02159771);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1414,0.02006168);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1415,0.01929376);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1416,0.01852537);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1417,0.0166099);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1418,0.01566231);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1419,0.01425925);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1420,0.01271085);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1421,0.01196392);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1471,0.01630038);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1472,0.01887397);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1473,0.02015636);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1474,0.02133256);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1475,0.02123931);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1476,0.02176433);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1477,0.02100271);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1478,0.01921076);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1479,0.01745847);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1480,0.01692882);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1481,0.015946);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1482,0.01404876);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1483,0.0124492);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1520,0.0001656772);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1522,0.0004066129);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1524,0.0008742598);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1526,0.001990956);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1528,0.003950051);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1530,0.007479111);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1532,0.01274585);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1533,0.01483911);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1534,0.01684703);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1535,0.01877526);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1536,0.02000778);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1537,0.0210921);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1538,0.02144069);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1539,0.02117478);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1540,0.02074886);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1541,0.019697);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1542,0.01887803);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1543,0.01657333);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1544,0.01510362);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1545,0.01341461);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1595,0.0126279);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1596,0.01484149);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1597,0.01719183);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1598,0.01931648);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1599,0.02006376);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1600,0.02117902);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1601,0.02113871);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1602,0.02085817);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1603,0.020504);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1604,0.02058066);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1605,0.01824636);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1606,0.01689027);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1607,0.01495107);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1646,0.0001732734);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1648,0.0005653907);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1650,0.001028836);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1652,0.002018417);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1654,0.00393212);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1656,0.007855447);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1657,0.00991495);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1658,0.0118253);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1659,0.01416714);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1660,0.01724451);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1661,0.0195489);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1662,0.02090563);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1663,0.02168071);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1664,0.02264732);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1665,0.02142161);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1666,0.01992643);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1667,0.01951228);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1668,0.01843743);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1669,0.01686184);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1719,0.007945581);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1720,0.0106105);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1721,0.01259195);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1722,0.01502616);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1723,0.01734577);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1724,0.01894616);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1725,0.01990691);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1726,0.02171377);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1727,0.021362);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1728,0.02140099);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1729,0.02005279);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1730,0.01933695);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1731,0.01948298);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1772,0.0001440223);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1774,0.0006050295);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1776,0.0010236);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1778,0.001749079);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1780,0.004162303);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1781,0.0056681);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1782,0.008093014);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1783,0.01017742);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1784,0.01254554);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1785,0.01514844);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1786,0.01695332);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1787,0.01965947);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1788,0.02079478);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1789,0.02138336);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1790,0.02205374);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1791,0.02191743);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1792,0.02015517);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1793,0.0193029);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1843,0.004018877);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1844,0.005642342);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1845,0.008246392);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1846,0.009695175);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1847,0.01279248);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1848,0.01483414);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1849,0.01719767);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1850,0.01859752);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1851,0.02083239);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1852,0.02211451);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1853,0.02208744);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1854,0.02096938);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1855,0.02039901);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1898,0.0001595434);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1900,0.0004614083);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1902,0.00111235);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1904,0.001919766);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1905,0.00280357);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1906,0.004624377);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1907,0.005743797);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1908,0.007611144);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1909,0.01016683);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1910,0.01283147);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1911,0.01553093);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1912,0.01670808);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1913,0.01939571);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1914,0.0207853);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1915,0.02119579);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1916,0.02270818);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1917,0.02160949);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1967,0.001989702);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1968,0.002729342);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1969,0.004187781);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1970,0.00532221);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1971,0.007795709);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1972,0.009938431);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1973,0.01310324);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1974,0.01500328);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1975,0.01748658);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1976,0.02002865);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1977,0.02121494);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1978,0.02109027);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1979,0.02203031);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2024,0.0001550402);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2026,0.0003330925);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2028,0.0009981744);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2029,0.001362852);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2030,0.002142649);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2031,0.002840487);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2032,0.004224347);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2033,0.005567011);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2034,0.007670434);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2035,0.009508387);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2036,0.01254467);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2037,0.01483057);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2038,0.01730941);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2039,0.01942004);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2040,0.02028444);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2041,0.02165774);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2091,0.0008912803);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2092,0.001469907);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2093,0.002039609);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2094,0.002956516);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2095,0.00406114);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2096,0.005918095);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2097,0.007944767);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2098,0.009997398);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2099,0.01272918);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2100,0.01480648);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2101,0.01748956);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2102,0.01943432);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2103,0.02039049);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2150,0.0001238659);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2152,0.0003985367);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2153,0.0006252771);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2154,0.001106656);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2155,0.001514624);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2156,0.002062306);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2157,0.003043838);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2158,0.004193298);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2159,0.005600798);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2160,0.007637574);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2161,0.01015318);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2162,0.01290684);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2163,0.01507481);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2164,0.01787353);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2165,0.01903911);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2215,0.0005719613);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2216,0.000653906);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2217,0.0008865953);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2218,0.001391817);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2219,0.002118846);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2220,0.002885378);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2221,0.004143557);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2222,0.005584972);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2223,0.007250602);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2224,0.01005225);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2225,0.01269126);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2226,0.01422389);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2227,0.01710618);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2276,0.0001290705);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2277,0.0002347117);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2278,0.0005604811);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2279,0.0007457309);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2280,0.001009175);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2281,0.00142484);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2282,0.00196351);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2283,0.00293176);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2284,0.004233219);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2285,0.005743302);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2286,0.007696627);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2287,0.00970761);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2288,0.01285378);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2289,0.01453854);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2339,0.0002190264);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2340,0.000174396);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2341,0.0003834095);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2342,0.0005244107);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2343,0.000923701);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2344,0.001524455);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2345,0.001811663);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2346,0.002674578);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2347,0.004008841);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2348,0.005584784);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2349,0.007367361);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2350,0.01011034);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2351,0.01222583);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2402,0.0001196908);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2403,0.0001446234);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2404,0.0004489459);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2405,0.0005559713);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2406,0.0009010702);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2407,0.001412054);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2408,0.001917404);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2409,0.002949617);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2410,0.003958369);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2411,0.005897289);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2412,0.007900364);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2413,0.01013646);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2465,0.0001520269);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2466,0.0002620209);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2467,0.0004821081);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2468,0.0006174896);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2469,0.001062787);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2470,0.001275389);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2471,0.002091106);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2472,0.002665861);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2473,0.004096448);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2474,0.005426111);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2475,0.008073757);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2528,0.0001151573);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2529,0.000190741);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2530,0.0003385217);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2531,0.0006140924);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2532,0.0008227667);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2533,0.0014211);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2534,0.00194894);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2535,0.002586588);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2536,0.003834177);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2537,0.005524903);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2591,0.0001139466);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2592,0.0002470799);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2593,0.000378357);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2594,0.0005651797);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2595,0.000881947);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2596,0.001252682);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2597,0.001918198);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2598,0.002823);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2599,0.004004943);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2655,0.0001879959);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2657,0.0006130637);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2659,0.001328105);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2661,0.002741447);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2781,0.0002222745);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2783,0.000573631);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2785,0.001254039);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2907,0.0001923178);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2909,0.0005499533);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(3033,0.0001982996);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(79,4.827553e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(81,8.671043e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(83,0.0001271121);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(85,0.0001902294);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(87,0.000248924);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(89,0.0002981177);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(91,0.0003480059);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(93,0.0003705673);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(95,0.0003773658);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(97,0.0003651914);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(99,0.0003445989);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(101,0.000469031);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(103,0.00030895);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(105,0.0002843862);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(107,0.0002609073);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(109,0.0002366988);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(111,0.0002166201);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(113,0.0001964249);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(115,0.0001759192);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(117,0.0001635683);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(119,0.0001384432);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(141,4.380886e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(143,7.451682e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(145,0.0001220915);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(147,0.000197391);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(149,0.0002515177);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(151,0.0003056036);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(153,0.0003451731);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(155,0.0003698622);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(156,0.0003773271);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(158,0.0003818261);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(160,0.0003563872);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(162,0.00034908);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(164,0.0003221624);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(166,0.0003051872);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(168,0.0002759383);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(169,0.0002613869);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(171,0.0002407661);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(173,0.0002178913);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(175,0.0001928414);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(177,0.0001842254);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(179,0.0001613743);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(181,0.0001411097);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(265,3.566538e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(267,6.17946e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(269,0.00010605);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(271,0.0001669499);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(273,0.0002364932);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(275,0.0002954261);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(277,0.0003417397);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(279,0.0003780801);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(280,0.0003825871);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(282,0.000391045);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(284,0.0003819187);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(286,0.0003551529);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(288,0.0003488408);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(290,0.0003163345);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(292,0.0002840193);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(293,0.0002674678);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(295,0.0002495314);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(297,0.0002307061);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(299,0.0002002568);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(301,0.0001830945);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(303,0.0001661679);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(305,0.0001477638);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(389,3.368756e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(391,5.212471e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(393,7.14443e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(395,0.0001308841);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(397,0.000197508);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(399,0.0002690293);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(401,0.0003251858);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(403,0.0003753236);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(404,0.0003836843);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(406,0.0004339333);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(408,0.0003910141);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(410,0.0003863813);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(412,0.0003547967);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(414,0.0003347249);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(416,0.0003059965);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(417,0.0002871608);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(419,0.0002575573);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(421,0.0002396723);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(423,0.0002129953);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(425,0.000189539);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(427,0.0001717241);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(429,0.0001572412);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(513,2.384961e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(515,3.347773e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(517,5.880628e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(519,9.471609e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(521,0.00016608);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(523,0.0002298135);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(525,0.0002899839);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(527,0.0003535377);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(528,0.0003701879);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(530,0.0003895634);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(532,0.000405678);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(534,0.0003898311);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(536,0.0003728496);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(538,0.0003585412);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(540,0.0003185383);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(541,0.0003051935);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(543,0.0002803321);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(545,0.0002508498);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(547,0.0002268166);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(549,0.0002052923);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(551,0.0001797014);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(553,0.0001640412);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(639,3.324444e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(641,5.146662e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(643,6.519592e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(645,0.0001001862);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(647,0.0001690457);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(649,0.0002387794);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(651,0.0003066052);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(652,0.0003457272);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(654,0.0003887427);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(656,0.0004057215);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(658,0.0004069275);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(660,0.0003974833);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(662,0.0003736559);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(664,0.0003430405);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(665,0.0003269268);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(667,0.0002926559);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(669,0.000271497);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(671,0.0002415492);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(673,0.0002180358);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(675,0.0001917503);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(677,0.0001731789);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(765,3.804483e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(767,5.707995e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(769,8.141747e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(771,0.0001099275);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(773,0.0001926375);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(775,0.0002604408);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(776,0.0002839072);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(778,0.0003410589);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(780,0.0003948059);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(782,0.0004042067);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(784,0.0004109812);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(786,0.0003949662);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(788,0.0003678235);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(789,0.0003513496);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(791,0.0003125893);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(793,0.0002891882);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(795,0.0002647984);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(797,0.0002315614);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(799,0.0002119755);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(801,0.0001880951);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(891,4.350847e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(893,6.243374e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(895,8.776426e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(897,0.00011883);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(899,0.0001973616);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(900,0.000229052);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(902,0.0002969469);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(904,0.0003593127);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(906,0.0003959602);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(908,0.0004031471);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(910,0.0004078214);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(912,0.0003984552);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(913,0.0003850442);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(915,0.0003505156);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(917,0.0003144846);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(919,0.0002839279);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(921,0.0002539682);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(923,0.0002296928);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(925,0.0001980096);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1017,4.387214e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1019,6.487312e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1021,9.984565e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1023,0.0001281039);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1024,0.000156711);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1026,0.0002340281);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1028,0.000302825);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1030,0.0003607335);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1032,0.0003950982);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1034,0.0004183863);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1036,0.000412458);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1037,0.0003970053);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1039,0.0003585942);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1041,0.0003393826);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1043,0.0003120313);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1045,0.0002805655);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1047,0.0002454322);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1049,0.0002239049);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1143,4.41922e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1145,6.928845e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1147,9.614064e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1148,0.0001022402);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1150,0.0001681867);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1152,0.0002427804);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1154,0.0003052438);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1156,0.0003682143);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1158,0.0003984333);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1160,0.000415728);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1161,0.000415147);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1163,0.000394679);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1165,0.0003692246);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1167,0.0003381513);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1169,0.0003085818);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1171,0.0002665441);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1173,0.0002405719);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1269,4.869222e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1271,6.317294e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1272,8.597491e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1274,0.0001128196);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1276,0.0001673569);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1278,0.0002439713);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1280,0.0003039491);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1282,0.0003676389);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1284,0.0004035315);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1285,0.0004054928);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1287,0.0004097724);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1289,0.0003953043);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1291,0.0003680026);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1293,0.0003352);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1295,0.0002975379);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1297,0.0002687479);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1395,4.903862e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1396,6.096984e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1398,8.447116e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1400,0.0001133264);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1402,0.0001807881);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1404,0.0002428966);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1406,0.0003108069);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1408,0.0003677498);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1409,0.0003927916);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1410,0.0004118778);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1411,0.0005028582);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1412,0.0004282302);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1413,0.0004243163);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1414,0.0004205217);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1415,0.0003907137);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1416,0.0003872252);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1417,0.0003601058);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1418,0.0003471346);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1419,0.0003298115);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1420,0.0003279801);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1421,0.0003161338);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1471,0.0003622737);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1472,0.0003961113);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1473,0.0004337532);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1474,0.000419342);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1475,0.0004198167);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1476,0.0004771404);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1477,0.0004058695);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1478,0.0004669457);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1479,0.0003715789);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1480,0.0003610073);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1481,0.0004288943);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1482,0.0003264226);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1483,0.0003062397);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1520,3.456061e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1522,5.443747e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1524,8.002112e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1526,0.0001192949);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1528,0.0001724124);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1530,0.000240859);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1532,0.0003171781);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1533,0.0003427485);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1534,0.0003716345);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1535,0.0003861981);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1536,0.000421239);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1537,0.0005491575);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1538,0.0004464429);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1539,0.0004103345);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1540,0.0005009571);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1541,0.0004033606);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1542,0.0003874345);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1543,0.0004135047);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1544,0.0003384846);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1545,0.0003172578);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1595,0.0003141884);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1596,0.0003433475);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1597,0.0004712226);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1598,0.0003911588);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1599,0.0004006877);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1600,0.0004223633);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1601,0.0004271593);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1602,0.0004071072);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1603,0.0004069002);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1604,0.0003983676);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1605,0.0005529486);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1606,0.0003590439);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1607,0.0003362764);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1646,3.541441e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1648,6.370899e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1650,8.593255e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1652,0.0001192658);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1654,0.0001705162);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1656,0.0002444453);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1657,0.0002764029);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1658,0.0003243436);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1659,0.0004318151);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1660,0.0003934829);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1661,0.0004248622);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1662,0.0006866964);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1663,0.0004121438);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1664,0.0004328296);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1665,0.0004537388);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1666,0.0003914947);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1667,0.000535418);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1668,0.000374242);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1669,0.0003558817);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1719,0.0002478746);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1720,0.0003186606);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1721,0.0003242852);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1722,0.0003636942);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1723,0.0003686908);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1724,0.000397718);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1725,0.0003930281);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1726,0.0004100764);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1727,0.0004096787);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1728,0.0004071262);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1729,0.0003933628);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1730,0.0003834901);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1731,0.000445246);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1772,3.228122e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1774,6.575491e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1776,8.492977e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1778,0.0001102374);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1780,0.0001740367);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1781,0.0002054043);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1782,0.0002641095);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1783,0.0002829098);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1784,0.0003430524);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1785,0.0003521145);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1786,0.0003984);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1787,0.0003910849);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1788,0.0004128758);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1789,0.000424298);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1790,0.0004129594);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1791,0.0004082365);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1792,0.0003950055);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1793,0.0003890361);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1843,0.0001714506);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1844,0.0002445504);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1845,0.0002484364);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1846,0.0002704252);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1847,0.0003165535);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1848,0.0003385168);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1849,0.0003632494);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1850,0.0005577415);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1851,0.0004799395);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1852,0.0004125312);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1853,0.0004197349);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1854,0.0004064517);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1855,0.000474512);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1898,3.327029e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1900,5.6897e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1902,8.787123e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1904,0.0001146116);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1905,0.0001522493);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1906,0.0001848268);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1907,0.0002286011);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1908,0.0002561546);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1909,0.0002801904);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1910,0.000310949);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1911,0.000343485);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1912,0.0004520708);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1913,0.0004012206);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1914,0.000412392);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1915,0.000401516);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1916,0.0004174547);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1917,0.0004184822);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1967,0.0001230207);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1968,0.0001399513);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1969,0.0001828088);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1970,0.0001974026);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1971,0.0002404367);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1972,0.0002720718);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1973,0.0003707012);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1974,0.0003776043);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1975,0.0003651152);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1976,0.0004310057);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1977,0.0004022513);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1978,0.0003976088);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1979,0.000434878);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2024,3.310053e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2026,4.818658e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2028,8.249316e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2029,9.634792e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2030,0.000120692);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2031,0.0001672875);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2032,0.0001730695);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2033,0.000257473);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2034,0.0002457655);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2035,0.0002836055);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2036,0.0003052688);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2037,0.0003655788);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2038,0.0003701706);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2039,0.0004184016);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2040,0.0004565523);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2041,0.0004118712);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2091,7.772647e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2092,0.0001123717);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2093,0.0001171428);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2094,0.0001423967);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2095,0.0001715578);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2096,0.0002139887);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2097,0.0002410115);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2098,0.0002748735);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2099,0.0003158466);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2100,0.0003318524);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2101,0.0004011533);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2102,0.0003881925);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2103,0.0004013671);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2150,2.924068e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2152,5.195653e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2153,6.563982e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2154,0.0001280173);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2155,0.0001096226);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2156,0.0001178659);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2157,0.0001657844);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2158,0.0002308271);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2159,0.0002014251);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2160,0.0002347539);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2161,0.0002752764);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2162,0.0003082507);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2163,0.0003320105);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2164,0.0004844843);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2165,0.0003858367);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2215,8.10407e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2216,7.99787e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2217,8.01415e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2218,0.0001067261);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2219,0.0001186215);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2220,0.000156731);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2221,0.0001690296);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2222,0.0001984606);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2223,0.0002334935);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2224,0.0003024591);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2225,0.0003028801);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2226,0.0003532234);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2227,0.000359563);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2276,2.965498e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2277,3.971567e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2278,6.241813e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2279,7.36049e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2280,9.385445e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2281,9.815884e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2282,0.0001138562);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2283,0.0001497782);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2284,0.0001763883);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2285,0.0002209972);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2286,0.0002538577);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2287,0.0002851249);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2288,0.0003232637);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2289,0.000324575);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2339,3.876774e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2340,3.80853e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2341,5.723263e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2342,6.781458e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2343,8.313491e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2344,0.0001010115);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2345,0.0001126483);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2346,0.0001334474);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2347,0.0001671488);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2348,0.0002018964);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2349,0.0002678686);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2350,0.0004684583);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2351,0.0002953682);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2402,3.200728e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2403,3.235343e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2404,7.951978e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2405,6.428824e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2406,7.745507e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2407,9.607454e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2408,0.0001174388);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2409,0.0001454256);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2410,0.0001763271);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2411,0.0002436967);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2412,0.0002442379);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2413,0.0002927808);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2465,3.174298e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2466,4.256828e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2467,6.233409e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2468,6.377193e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2469,8.392873e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2470,0.0001298246);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2471,0.0001658045);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2472,0.0001338578);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2473,0.0001661567);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2474,0.0001962415);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2475,0.0002467473);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2528,2.88043e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2529,3.606914e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2530,4.700891e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2531,6.964288e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2532,7.931568e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2533,9.630659e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2534,0.0001171592);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2535,0.0001324268);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2536,0.0001598629);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2537,0.0002162078);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2591,3.163616e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2592,4.013598e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2593,5.162512e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2594,6.071348e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2595,8.204096e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2596,0.0001002179);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2597,0.0001137314);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2598,0.0001838802);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2599,0.0001690558);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2655,3.495113e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2657,6.23568e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2659,9.164301e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2661,0.0001321561);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2781,3.763281e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2783,5.988675e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2785,8.893386e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2907,3.457789e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2909,5.842029e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(3033,3.511936e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetEntries(581915.9);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->Draw("colz");
   c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf->Modified();
   c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf->cd();
   c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf->SetSelected(c_AccEffMap_T1tttt_8NJetinf_800HT1000_200MHTinf);
}
/*
   400     0   0.000288565
   400    25   0.000242942
   400    75   0.000170635
   400   125   0.000153947
   400   175   7.90466e-05
   450     0   0.000905693
   450    25   0.000683967
   450    75    0.00048465
   450   125   0.000348716
   450   175   0.000149337
   450   225   0.000152278
   500     0    0.00189373
   500    25     0.0017775
   500    75    0.00137214
   500   125    0.00064838
   500   175   0.000446284
   500   225   0.000348258
   500   275   0.000197609
   550     0    0.00420146
   550    25    0.00453117
   550    75     0.0032714
   550   125     0.0020831
   550   175    0.00114391
   550   225   0.000563532
   550   275   0.000433938
   550   325   0.000249342
   600     0    0.00706715
   600    25    0.00724482
   600    75    0.00638624
   600   125    0.00457508
   600   175    0.00332326
   600   225    0.00126593
   600   275   0.000859248
   600   325    0.00051784
   600   375   0.000255388
   650     0      0.010012
   650    25     0.0106227
   650    75    0.00995269
   650   125    0.00831149
   650   175    0.00622662
   650   225    0.00345754
   650   275    0.00155619
   650   325    0.00100912
   650   375   0.000564566
   650   425   0.000261163
   700     0      0.013635
   700    25     0.0134324
   700    75     0.0132447
   700   125     0.0121171
   700   175    0.00969298
   700   225    0.00671858
   700   275    0.00450944
   700   325    0.00181424
   700   375    0.00130875
   700   425   0.000645269
   700   475   0.000318709
   750     0     0.0155445
   750    25     0.0153931
   750    75     0.0161084
   750   125     0.0159745
   750   175     0.0143342
   750   225     0.0109686
   750   275    0.00802468
   750   325    0.00475181
   750   375    0.00213886
   750   425    0.00122759
   750   475   0.000538889
   750   525   0.000324753
   775    25     0.0161015
   775    75     0.0166022
   775   125     0.0167746
   775   175     0.0157516
   775   225     0.0138902
   775   275    0.00949663
   775   325    0.00635927
   775   375    0.00312545
   775   425    0.00140576
   775   475    0.00100037
   775   525   0.000505506
   775   575   0.000165677
   800     0     0.0161463
   825    25     0.0166547
   825    75     0.0174747
   825   125     0.0185811
   825   175     0.0174379
   825   225     0.0174309
   825   275     0.0136461
   825   325     0.0104648
   825   375    0.00674535
   825   425    0.00362928
   825   475     0.0017393
   825   525   0.000975719
   825   575   0.000406613
   825   625   0.000173273
   850     0     0.0152377
   875    25     0.0145993
   875    75      0.016737
   875   125     0.0176654
   875   175     0.0188986
   875   225     0.0190101
   875   275     0.0181154
   875   325     0.0152167
   875   375     0.0110142
   875   425    0.00730918
   875   475    0.00363073
   875   525    0.00176543
   875   575    0.00087426
   875   625   0.000565391
   875   675   0.000144022
   900     0     0.0137648
   925    25     0.0141627
   925    75     0.0146659
   925   125     0.0173586
   925   175     0.0177117
   925   225     0.0193394
   925   275     0.0191357
   925   325     0.0185216
   925   375     0.0155373
   925   425     0.0114035
   925   475    0.00746676
   925   525     0.0042854
   925   575    0.00199096
   925   625    0.00102884
   925   675    0.00060503
   925   725   0.000159543
   950     0     0.0129167
   975    25     0.0122483
   975    75     0.0142692
   975   125     0.0148999
   975   175     0.0163268
   975   225     0.0185762
   975   275     0.0199853
   975   325     0.0191905
   975   375     0.0186358
   975   425     0.0164052
   975   475     0.0113832
   975   525    0.00752663
   975   575    0.00395005
   975   625    0.00201842
   975   675     0.0010236
   975   725   0.000461408
   975   775    0.00015504
  1000     0     0.0113197
  1025    25     0.0111746
  1025    75     0.0119626
  1025   125     0.0133505
  1025   175     0.0153826
  1025   225     0.0166709
  1025   275     0.0186989
  1025   325     0.0199034
  1025   375     0.0209133
  1025   425     0.0191398
  1025   475     0.0165477
  1025   525     0.0121015
  1025   575    0.00747911
  1025   625    0.00393212
  1025   675    0.00174908
  1025   725    0.00111235
  1025   775   0.000333092
  1025   825   0.000123866
  1050     0    0.00975749
  1075    25     0.0092826
  1075    75    0.00977096
  1075   125     0.0113775
  1075   175     0.0122864
  1075   225     0.0143516
  1075   275     0.0163968
  1075   325     0.0192003
  1075   375     0.0205803
  1075   425     0.0209425
  1075   475     0.0199277
  1075   525     0.0168231
  1075   575     0.0127459
  1075   625    0.00785545
  1075   675     0.0041623
  1075   725    0.00191977
  1075   775   0.000998174
  1075   825   0.000398537
  1075   875   0.000129071
  1100     0    0.00832248
  1100    25     0.0083592
  1100    75    0.00873934
  1100   125     0.0100167
  1100   175     0.0113846
  1100   225     0.0130952
  1100   275      0.015013
  1100   325     0.0180134
  1100   375     0.0192124
  1100   425     0.0209931
  1100   475     0.0202805
  1100   525     0.0189984
  1100   550     0.0163004
  1100   575     0.0148391
  1100   600     0.0126279
  1100   625    0.00991495
  1100   650    0.00794558
  1100   675     0.0056681
  1100   700    0.00401888
  1100   725    0.00280357
  1100   750     0.0019897
  1100   775    0.00136285
  1100   800    0.00089128
  1100   825   0.000625277
  1100   850   0.000571961
  1100   875   0.000234712
  1100   900   0.000219026
  1125   525      0.020367
  1125   550      0.018874
  1125   575      0.016847
  1125   600     0.0148415
  1125   625     0.0118253
  1125   650     0.0106105
  1125   675    0.00809301
  1125   700    0.00564234
  1125   725    0.00462438
  1125   750    0.00272934
  1125   775    0.00214265
  1125   800    0.00146991
  1125   825    0.00110666
  1125   850   0.000653906
  1125   875   0.000560481
  1125   900   0.000174396
  1125   925   0.000119691
  1150     0    0.00697591
  1150    25    0.00718272
  1150    75    0.00776714
  1150   125    0.00828432
  1150   175    0.00974063
  1150   225     0.0106468
  1150   275      0.012166
  1150   325     0.0152634
  1150   375     0.0159555
  1150   425     0.0192085
  1150   475     0.0209197
  1150   525     0.0204073
  1150   550     0.0201564
  1150   575     0.0187753
  1150   600     0.0171918
  1150   625     0.0141671
  1150   650      0.012592
  1150   675     0.0101774
  1150   700    0.00824639
  1150   725     0.0057438
  1150   750    0.00418778
  1150   775    0.00284049
  1150   800    0.00203961
  1150   825    0.00151462
  1150   850   0.000886595
  1150   875   0.000745731
  1150   900   0.000383409
  1150   925   0.000144623
  1150   950   0.000152027
  1175   525     0.0216921
  1175   550     0.0213326
  1175   575     0.0200078
  1175   600     0.0193165
  1175   625     0.0172445
  1175   650     0.0150262
  1175   675     0.0125455
  1175   700    0.00969518
  1175   725    0.00761114
  1175   750    0.00532221
  1175   775    0.00422435
  1175   800    0.00295652
  1175   825    0.00206231
  1175   850    0.00139182
  1175   875    0.00100917
  1175   900   0.000524411
  1175   925   0.000448946
  1175   950   0.000262021
  1175   975   0.000115157
  1200     0    0.00592155
  1200    25    0.00597279
  1200    75    0.00671777
  1200   125    0.00723371
  1200   175    0.00795667
  1200   225    0.00931047
  1200   275     0.0105222
  1200   325     0.0124363
  1200   375     0.0143753
  1200   425     0.0170383
  1200   475     0.0195593
  1200   525     0.0215977
  1200   550     0.0212393
  1200   575     0.0210921
  1200   600     0.0200638
  1200   625     0.0195489
  1200   650     0.0173458
  1200   675     0.0151484
  1200   700     0.0127925
  1200   725     0.0101668
  1200   750    0.00779571
  1200   775    0.00556701
  1200   800    0.00406114
  1200   825    0.00304384
  1200   850    0.00211885
  1200   875    0.00142484
  1200   900   0.000923701
  1200   925   0.000555971
  1200   950   0.000482108
  1200   975   0.000190741
  1200  1000   0.000113947
  1225   525     0.0200617
  1225   550     0.0217643
  1225   575     0.0214407
  1225   600      0.021179
  1225   625     0.0209056
  1225   650     0.0189462
  1225   675     0.0169533
  1225   700     0.0148341
  1225   725     0.0128315
  1225   750    0.00993843
  1225   775    0.00767043
  1225   800     0.0059181
  1225   825     0.0041933
  1225   850    0.00288538
  1225   875    0.00196351
  1225   900    0.00152445
  1225   925    0.00090107
  1225   950    0.00061749
  1225   975   0.000338522
  1225  1000    0.00024708
  1250     0    0.00496064
  1250    25    0.00478232
  1250    75    0.00514285
  1250   125     0.0058308
  1250   175     0.0065903
  1250   225     0.0074548
  1250   275     0.0089553
  1250   325     0.0103127
  1250   375      0.012384
  1250   425     0.0145708
  1250   475     0.0172368
  1250   525     0.0192938
  1250   550     0.0210027
  1250   575     0.0211748
  1250   600     0.0211387
  1250   625     0.0216807
  1250   650     0.0199069
  1250   675     0.0196595
  1250   700     0.0171977
  1250   725     0.0155309
  1250   750     0.0131032
  1250   775    0.00950839
  1250   800    0.00794477
  1250   825     0.0056008
  1250   850    0.00414356
  1250   875    0.00293176
  1250   900    0.00181166
  1250   925    0.00141205
  1250   950    0.00106279
  1250   975   0.000614092
  1250  1000   0.000378357
  1250  1025   0.000187996
  1275   525     0.0185254
  1275   550     0.0192108
  1275   575     0.0207489
  1275   600     0.0208582
  1275   625     0.0226473
  1275   650     0.0217138
  1275   675     0.0207948
  1275   700     0.0185975
  1275   725     0.0167081
  1275   750     0.0150033
  1275   775     0.0125447
  1275   800     0.0099974
  1275   825    0.00763757
  1275   850    0.00558497
  1275   875    0.00423322
  1275   900    0.00267458
  1275   925     0.0019174
  1275   950    0.00127539
  1275   975   0.000822767
  1275  1000    0.00056518
  1300     0    0.00400844
  1300    25    0.00441607
  1300    75    0.00435874
  1300   125     0.0046708
  1300   175    0.00550728
  1300   225    0.00618877
  1300   275    0.00698168
  1300   325    0.00836953
  1300   375     0.0102072
  1300   425     0.0123231
  1300   475     0.0145487
  1300   525     0.0166099
  1300   550     0.0174585
  1300   575      0.019697
  1300   600      0.020504
  1300   625     0.0214216
  1300   650      0.021362
  1300   675     0.0213834
  1300   700     0.0208324
  1300   725     0.0193957
  1300   750     0.0174866
  1300   775     0.0148306
  1300   800     0.0127292
  1300   825     0.0101532
  1300   850     0.0072506
  1300   875     0.0057433
  1300   900    0.00400884
  1300   925    0.00294962
  1300   950    0.00209111
  1300   975     0.0014211
  1300  1000   0.000881947
  1300  1025   0.000613064
  1300  1075   0.000222274
  1325   525     0.0156623
  1325   550     0.0169288
  1325   575      0.018878
  1325   600     0.0205807
  1325   625     0.0199264
  1325   650      0.021401
  1325   675     0.0220537
  1325   700     0.0221145
  1325   725     0.0207853
  1325   750     0.0200286
  1325   775     0.0173094
  1325   800     0.0148065
  1325   825     0.0129068
  1325   850     0.0100522
  1325   875    0.00769663
  1325   900    0.00558478
  1325   925    0.00395837
  1325   950    0.00266586
  1325   975    0.00194894
  1325  1000    0.00125268
  1350     0    0.00352985
  1350    25    0.00344099
  1350    75    0.00364645
  1350   125    0.00390155
  1350   175    0.00427003
  1350   225    0.00484759
  1350   275    0.00593982
  1350   325    0.00695972
  1350   375     0.0079167
  1350   425    0.00941241
  1350   475     0.0116506
  1350   525     0.0142593
  1350   550      0.015946
  1350   575     0.0165733
  1350   600     0.0182464
  1350   625     0.0195123
  1350   650     0.0200528
  1350   675     0.0219174
  1350   700     0.0220874
  1350   725     0.0211958
  1350   750     0.0212149
  1350   775       0.01942
  1350   800     0.0174896
  1350   825     0.0150748
  1350   850     0.0126913
  1350   875    0.00970761
  1350   900    0.00736736
  1350   925    0.00589729
  1350   950    0.00409645
  1350   975    0.00258659
  1350  1000     0.0019182
  1350  1025    0.00132811
  1350  1075   0.000573631
  1350  1125   0.000192318
  1375   525     0.0127108
  1375   550     0.0140488
  1375   575     0.0151036
  1375   600     0.0168903
  1375   625     0.0184374
  1375   650     0.0193369
  1375   675     0.0201552
  1375   700     0.0209694
  1375   725     0.0227082
  1375   750     0.0210903
  1375   775     0.0202844
  1375   800     0.0194343
  1375   825     0.0178735
  1375   850     0.0142239
  1375   875     0.0128538
  1375   900     0.0101103
  1375   925    0.00790036
  1375   950    0.00542611
  1375   975    0.00383418
  1375  1000      0.002823
  1400     0    0.00256657
  1400    25    0.00267551
  1400    75    0.00293777
  1400   125    0.00331985
  1400   175    0.00361108
  1400   225    0.00402445
  1400   275     0.0047615
  1400   325    0.00528003
  1400   375    0.00671161
  1400   425      0.007752
  1400   475    0.00966867
  1400   525     0.0119639
  1400   550     0.0124492
  1400   575     0.0134146
  1400   600     0.0149511
  1400   625     0.0168618
  1400   650      0.019483
  1400   675     0.0193029
  1400   700      0.020399
  1400   725     0.0216095
  1400   750     0.0220303
  1400   775     0.0216577
  1400   800     0.0203905
  1400   825     0.0190391
  1400   850     0.0171062
  1400   875     0.0145385
  1400   900     0.0122258
  1400   925     0.0101365
  1400   950    0.00807376
  1400   975     0.0055249
  1400  1000    0.00400494
  1400  1025    0.00274145
  1400  1075    0.00125404
  1400  1125   0.000549953
  1400  1175     0.0001983
*/
