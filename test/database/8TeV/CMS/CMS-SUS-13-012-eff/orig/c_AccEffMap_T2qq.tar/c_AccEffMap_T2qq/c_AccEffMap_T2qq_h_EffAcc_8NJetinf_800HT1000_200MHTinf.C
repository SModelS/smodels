{
//=========Macro generated from canvas: c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf/c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf
//=========  (Sat Feb 22 16:28:33 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf = new TCanvas("c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf", "c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf",110,288,500,500);
   c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf->SetFillColor(0);
   c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf->SetLogz();
   c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_800HT1000_200MHTinf = new TH2D("h_EffAcc_8NJetinf_800HT1000_200MHTinf","h_EffAcc_8NJetinf_800HT1000_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(79,5.200293e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(81,2.983862e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(83,3.489731e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(85,3.423134e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(87,3.112367e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(91,5.969459e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(93,2.814602e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(97,9.366175e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(99,6.17174e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(101,0.0001080277);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(103,3.531797e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(199,2.384288e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(201,5.629143e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(203,5.507545e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(205,0.0001389838);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(209,3.432828e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(211,6.405584e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(213,5.910278e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(215,2.98057e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(219,0.0001675539);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(221,6.93642e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(227,3.472355e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(327,2.59384e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(329,2.67078e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(331,5.739695e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(333,0.0001273219);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(335,6.067528e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(337,2.770803e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(339,5.567541e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(343,2.821516e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(349,3.147877e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(447,5.095633e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(459,5.716266e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(461,5.622953e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(463,0.0001985696);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(465,0.0001214622);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(473,3.162528e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(579,5.423802e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(581,3.091583e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(583,0.0001033645);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(585,6.665848e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(593,6.277749e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(597,3.510238e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(703,2.716229e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(705,3.051375e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(707,5.522926e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(709,6.627021e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(713,6.801321e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(715,5.931374e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(717,5.986e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(719,2.805147e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(723,6.722499e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(823,5.181288e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(827,2.709917e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(829,0.000112003);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(831,5.882913e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(837,3.53894e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(839,3.257512e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(841,0.0001010105);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(953,3.449995e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(955,3.464067e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(957,0.0001158311);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(959,8.781065e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(965,3.186732e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(967,2.835864e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(969,3.172024e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1073,2.665942e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1075,2.702543e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1077,5.60939e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1079,2.770836e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1081,2.779259e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1087,2.834773e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1089,9.88547e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1093,2.924164e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1199,2.706268e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1201,8.92376e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1203,2.755367e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1205,6.273449e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1209,2.9839e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1213,3.180757e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1215,8.835999e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1217,9.878529e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1327,2.763299e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1331,5.785238e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1335,5.952329e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1337,8.76973e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1339,5.80542e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1341,6.145248e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1455,9.464817e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1457,5.60766e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1459,6.762637e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1461,6.001172e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1463,5.669045e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1465,5.806505e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1467,5.773297e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1581,5.995341e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1585,5.826869e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1587,6.206851e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1591,6.314549e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1703,2.798979e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1709,3.001465e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1711,9.14313e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1713,9.202742e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1715,2.806087e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1833,3.158842e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1839,3.138141e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1957,5.63819e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1961,6.664445e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(1963,2.820288e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2083,8.868377e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2087,2.808289e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2211,3.314915e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2333,2.850434e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinContent(2335,2.79414e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(79,3.677278e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(81,2.98391e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(83,3.48979e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(85,3.42319e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(87,3.112419e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(91,4.221197e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(93,2.81465e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(97,5.421298e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(99,4.380229e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(101,6.237307e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(103,3.531857e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(199,2.384322e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(201,4.005021e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(203,3.901276e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(205,6.226604e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(209,3.432885e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(211,4.531237e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(213,4.186562e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(215,2.980624e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(219,7.500974e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(221,4.911751e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(227,3.472413e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(327,2.593881e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(329,2.670823e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(331,4.065725e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(333,6.392042e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(335,4.297954e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(337,2.770849e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(339,3.936978e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(343,2.821564e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(349,3.14793e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(447,3.609491e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(459,4.04215e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(461,3.976163e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(463,8.126151e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(465,6.090717e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(473,3.162581e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(579,3.835333e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(581,3.091634e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(583,5.975152e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(585,4.720149e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(593,4.439188e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(597,3.510297e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(703,2.716273e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(705,3.051425e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(707,3.905429e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(709,4.692655e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(713,4.811003e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(715,4.201505e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(717,4.240201e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(719,2.805195e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(723,4.760265e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(823,3.66384e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(827,2.709961e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(829,5.608225e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(831,4.167177e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(837,3.539e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(839,3.257568e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(841,5.839579e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(953,3.450052e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(955,3.464125e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(957,5.79992e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(959,5.078113e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(965,3.186786e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(967,2.835912e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(969,3.172078e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1073,2.665986e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1075,2.702587e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1077,3.966572e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1079,2.770883e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1081,2.779306e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1087,2.834822e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1089,5.714945e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1093,2.924215e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1199,2.706313e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1201,5.160007e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1203,2.755412e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1205,4.463445e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1209,2.983954e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1213,3.180811e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1215,5.109882e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1217,5.710931e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1327,2.763345e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1331,4.090923e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1335,4.216349e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1337,5.071556e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1339,4.105195e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1341,4.353009e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1455,5.487232e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1457,3.965348e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1459,4.788688e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1461,4.250949e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1463,4.008757e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1465,4.105963e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1467,4.082479e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1581,4.246818e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1585,4.120363e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1587,4.405149e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1591,4.492687e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1703,2.799026e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1709,3.001519e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1711,5.310199e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1713,5.344822e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1715,2.806134e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1833,3.158896e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1839,3.138194e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1957,3.986938e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1961,4.712633e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(1963,2.820336e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2083,5.128607e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2087,2.808336e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2211,3.314971e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2333,2.850483e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetBinError(2335,2.794187e-05);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetEntries(208.0466);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_800HT1000_200MHTinf->Draw("colz");
   c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf->Modified();
   c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf->cd();
   c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf->SetSelected(c_AccEffMap_T2qq_8NJetinf_800HT1000_200MHTinf);
}
/*
Topology ~q ~q ; ~q ->q+LSP

mSquark(GeV) mLSP(GeV) AccXEff
   300    50   2.38429e-05
   300   150   5.09563e-05
   350    50   5.62914e-05
   400     0   5.20029e-05
   400    50   5.50754e-05
   400   100   2.59384e-05
   400   300   5.18129e-05
   450     0   2.98386e-05
   450    50   0.000138984
   450   100   2.67078e-05
   450   400   2.66594e-05
   500     0   3.48973e-05
   500   100   5.73969e-05
   500   200    5.4238e-05
   500   250   2.71623e-05
   500   300   2.70992e-05
   500   400   2.70254e-05
   500   450   2.70627e-05
   550     0   3.42313e-05
   550    50   3.43283e-05
   550   100   0.000127322
   550   200   3.09158e-05
   550   250   3.05137e-05
   550   300   0.000112003
   550   350   3.44999e-05
   550   400   5.60939e-05
   550   450   8.92376e-05
   600     0   3.11237e-05
   600    50   6.40558e-05
   600   100   6.06753e-05
   600   150   5.71627e-05
   600   200   0.000103365
   600   250   5.52293e-05
   600   300   5.88291e-05
   600   350   3.46407e-05
   600   400   2.77084e-05
   600   450   2.75537e-05
   600   500    2.7633e-05
   650    50   5.91028e-05
   650   100    2.7708e-05
   650   150   5.62295e-05
   650   200   6.66585e-05
   650   250   6.62702e-05
   650   350   0.000115831
   650   400   2.77926e-05
   650   450   6.27345e-05
   700     0   5.96946e-05
   700    50   2.98057e-05
   700   100   5.56754e-05
   700   150    0.00019857
   700   350   8.78107e-05
   700   500   5.78524e-05
   700   550   9.46482e-05
   700   650   2.79898e-05
   750     0    2.8146e-05
   750   150   0.000121462
   750   250   6.80132e-05
   750   300   3.53894e-05
   750   450    2.9839e-05
   750   550   5.60766e-05
   750   600   5.99534e-05
   800    50   0.000167554
   800   100   2.82152e-05
   800   250   5.93137e-05
   800   300   3.25751e-05
   800   400   2.83477e-05
   800   500   5.95233e-05
   800   550   6.76264e-05
   850     0   9.36618e-05
   850    50   6.93642e-05
   850   200   6.27775e-05
   850   250     5.986e-05
   850   300    0.00010101
   850   350   3.18673e-05
   850   400   9.88547e-05
   850   450   3.18076e-05
   850   500   8.76973e-05
   850   550   6.00117e-05
   850   600   5.82687e-05
   850   650   3.00147e-05
   850   700   3.15884e-05
   850   750   5.63819e-05
   900     0   6.17174e-05
   900   250   2.80515e-05
   900   350   2.83586e-05
   900   450     8.836e-05
   900   500   5.80542e-05
   900   550   5.66904e-05
   900   600   6.20685e-05
   900   650   9.14313e-05
   900   800   8.86838e-05
   950     0   0.000108028
   950   100   3.14788e-05
   950   150   3.16253e-05
   950   200   3.51024e-05
   950   350   3.17202e-05
   950   400   2.92416e-05
   950   450   9.87853e-05
   950   500   6.14525e-05
   950   550   5.80651e-05
   950   650   9.20274e-05
   950   750   6.66445e-05
   950   900   2.85043e-05
  1000     0    3.5318e-05
  1000    50   3.47235e-05
  1000   250    6.7225e-05
  1000   550    5.7733e-05
  1000   600   6.31455e-05
  1000   650   2.80609e-05
  1000   700   3.13814e-05
  1000   750   2.82029e-05
  1000   800   2.80829e-05
  1000   850   3.31492e-05
  1000   900   2.79414e-05
*/
