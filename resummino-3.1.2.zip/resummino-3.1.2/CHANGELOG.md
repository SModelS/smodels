* Version 3.1.2
    * minor bug fixes in Z'/W' code
    * add apptainer script
    * Update banner with publications
* Version 3.1.1
    * yukawas are properly zero now except for (s)top
    * Improved parsing/cases, e.g. load CKM from slha file (optional)
    * Fixed couplings for chargino-squark
    * docker version available
    * LoopTool clear cache bug in different versions
    * Support recent GCC with "-std=legacy" for looptools
* Version 3.1.0
    * Add squark-electroweakino production
    * Slightly changed installation
* Version 3.0.0 
    * Contains compatibility with new gsl, Z' boson option, NNLL for slepton pair production
