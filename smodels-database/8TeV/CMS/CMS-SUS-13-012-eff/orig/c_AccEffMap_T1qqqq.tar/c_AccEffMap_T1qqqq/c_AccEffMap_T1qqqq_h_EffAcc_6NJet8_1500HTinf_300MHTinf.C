{
//=========Macro generated from canvas: c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf/c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf
//=========  (Sat Feb 22 16:30:37 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf = new TCanvas("c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf", "c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf",100,240,500,500);
   c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf->SetFillColor(0);
   c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf->SetBorderMode(0);
   c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf->SetBorderSize(2);
   c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf->SetLogz();
   c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_6NJet8_1500HTinf_300MHTinf = new TH2D("h_EffAcc_6NJet8_1500HTinf_300MHTinf","h_EffAcc_6NJet8_1500HTinf_300MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(141,0.0002924104);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(143,0.0004970249);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(145,0.0009685443);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(147,0.001760858);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(149,0.002753435);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(151,0.004525889);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(153,0.006448729);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(155,0.009078232);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(157,0.01262458);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(159,0.01777973);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(161,0.02291852);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(163,0.02928559);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(165,0.03739619);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(167,0.04424445);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(169,0.05292159);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(171,0.06271147);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(173,0.07152044);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(175,0.0807009);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(177,0.09015775);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(179,0.09890318);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(181,0.1092084);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(265,0.0002468006);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(267,0.0004405528);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(269,0.0007784107);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(271,0.001381613);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(273,0.002547205);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(275,0.004021788);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(277,0.005869928);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(279,0.008394046);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(281,0.01186834);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(283,0.01652797);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(285,0.020915);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(287,0.02738577);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(289,0.03467943);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(291,0.04323542);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(293,0.05080877);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(295,0.06008598);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(297,0.06890874);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(299,0.07863143);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(301,0.0892361);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(303,0.09820581);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(305,0.1067954);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(389,0.000166503);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(391,0.0003706211);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(393,0.0005510698);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(395,0.001297217);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(397,0.001908098);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(399,0.003192584);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(401,0.004986811);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(403,0.007189093);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(405,0.009949108);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(407,0.01441505);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(409,0.0189866);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(411,0.02573885);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(413,0.03222379);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(415,0.03794975);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(417,0.04729206);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(419,0.05758892);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(421,0.06570882);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(423,0.07531136);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(425,0.08526997);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(427,0.09502518);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(429,0.1042722);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(513,0.0001077095);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(515,0.0003478403);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(517,0.0004803836);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(519,0.0008598212);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(521,0.001681416);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(523,0.002518582);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(525,0.004174178);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(527,0.006055115);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(529,0.008148668);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(531,0.01153562);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(533,0.01596005);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(535,0.02096983);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(537,0.02833035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(539,0.03437752);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(541,0.04236395);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(543,0.05066418);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(545,0.06137771);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(547,0.07013694);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(549,0.08001295);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(551,0.08962085);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(553,0.09964558);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(637,4.250835e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(639,0.0002166357);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(641,0.0003484974);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(643,0.0006552503);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(645,0.001265553);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(647,0.001931412);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(649,0.002841517);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(651,0.004275669);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(653,0.006515247);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(655,0.009623067);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(657,0.01329588);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(659,0.01726659);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(661,0.023184);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(663,0.02905274);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(665,0.0374213);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(667,0.04549276);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(669,0.05529039);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(671,0.06435262);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(673,0.07462784);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(675,0.08435566);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(677,0.09369661);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(761,4.962665e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(763,9.449142e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(765,0.0002565477);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(767,0.0004823812);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(769,0.0008025856);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(771,0.001430908);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(773,0.002138232);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(775,0.003102288);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(777,0.005088158);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(779,0.007218528);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(781,0.01037692);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(783,0.01353163);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(785,0.01920893);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(787,0.02491783);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(789,0.03141748);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(791,0.03942017);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(793,0.04837817);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(795,0.05754114);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(797,0.06826724);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(799,0.07729214);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(801,0.08772231);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(885,1.409579e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(887,8.920188e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(889,0.0001238023);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(891,0.0003390441);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(893,0.0004680083);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(895,0.0007111157);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(897,0.00159035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(899,0.002412399);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(901,0.003457128);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(903,0.00534904);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(905,0.007975536);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(907,0.01080738);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(909,0.01461385);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(911,0.01946123);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(913,0.02587279);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(915,0.0325269);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(917,0.04191953);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(919,0.05019726);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(921,0.05975529);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(923,0.06918213);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(925,0.08025586);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1009,2.121155e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1011,4.314867e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1013,0.0001017984);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1015,0.0001187773);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1017,0.0003668221);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1019,0.0006188263);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1021,0.001122465);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1023,0.001607345);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1025,0.002486815);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1027,0.003996007);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1029,0.005977122);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1031,0.008101526);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1033,0.0119743);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1035,0.01519023);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1037,0.02016493);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1039,0.0269412);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1041,0.03402916);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1043,0.04259965);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1045,0.05193052);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1047,0.06186892);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1049,0.0730022);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1135,2.201882e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1137,5.829093e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1139,5.121749e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1141,0.0001913164);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1143,0.0004235956);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1145,0.0006435352);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1147,0.001321914);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1149,0.001718069);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1151,0.002796166);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1153,0.003848049);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1155,0.005756009);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1157,0.008954038);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1159,0.01145509);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1161,0.01571014);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1163,0.02112997);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1165,0.02753123);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1167,0.03378229);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1169,0.04424599);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1171,0.05125535);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1173,0.06178433);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1261,7.287438e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1263,8.07221e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1265,0.0001259975);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1267,0.0001972279);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1269,0.0004736444);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1271,0.0007551543);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1273,0.001290917);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1275,0.001945067);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1277,0.002664347);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1279,0.004031559);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1281,0.006156089);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1283,0.00871507);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1285,0.01152448);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1287,0.01606396);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1289,0.02116396);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1291,0.02800337);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1293,0.03558742);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1295,0.04409634);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1297,0.05422509);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1387,1.478676e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1389,2.202808e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1391,0.0001315676);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1393,0.0002178698);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1395,0.0004578191);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1397,0.0006788305);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1399,0.001055447);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1401,0.001790638);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1403,0.002733619);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1405,0.004319392);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1407,0.006054477);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1409,0.008581815);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1411,0.0119725);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1413,0.01677611);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1415,0.02091307);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1417,0.02809971);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1419,0.03560803);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1421,0.04458751);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1515,9.497656e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1517,0.0001316965);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1519,0.0002022708);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1521,0.0004723396);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1523,0.0009175949);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1525,0.00129852);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1527,0.002026981);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1529,0.003015101);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1531,0.003917744);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1533,0.006302119);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1535,0.008674028);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1537,0.01189741);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1539,0.01636001);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1541,0.02188086);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1543,0.02836978);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1545,0.03522239);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1641,5.074541e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1643,0.0001322866);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1645,0.0002706268);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1647,0.0005391187);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1649,0.00078596);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1651,0.001274094);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1653,0.001846896);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1655,0.002925857);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1657,0.004303099);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1659,0.005738193);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1661,0.008662531);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1663,0.01161929);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1665,0.01578754);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1667,0.02095047);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1669,0.02771369);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1765,7.251579e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1767,2.882401e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1769,0.000120975);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1771,0.0002475525);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1773,0.0004484652);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1775,0.00071207);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1777,0.001224407);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1783,0.003847839);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1785,0.005923879);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1787,0.008282491);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1789,0.01195977);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1791,0.01645119);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1793,0.02103723);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1845,0.003304748);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1846,0.004050785);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1847,0.004411367);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1848,0.005948214);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1849,0.006926598);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1850,0.008697132);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1851,0.009453816);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1852,0.01215109);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1853,0.01358771);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1854,0.01545667);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1855,0.01803827);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1891,7.246013e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1893,4.295615e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1895,0.0001842259);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1897,0.0002636229);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1899,0.0005924407);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1901,0.0009711827);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1907,0.002752825);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1908,0.003073293);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1909,0.003936398);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1910,0.005316837);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1911,0.006141215);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1912,0.00692346);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1913,0.008440038);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1914,0.009744196);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1915,0.01117341);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1916,0.01348384);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1917,0.01561486);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1969,0.00230973);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1970,0.00285773);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1971,0.003256906);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1972,0.003593973);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1973,0.004757122);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1974,0.006223796);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1975,0.006988539);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1976,0.00857588);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1977,0.00987546);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1978,0.01123302);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1979,0.01352724);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2017,7.133593e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2019,4.936615e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2021,0.0001532611);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2023,0.0002604458);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2025,0.0004822465);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2031,0.001780881);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2032,0.002452316);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2033,0.002929982);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2034,0.003444929);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2035,0.004014983);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2036,0.00445778);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2037,0.005291368);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2038,0.007192399);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2039,0.008206992);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2040,0.009769238);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2041,0.01130073);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2093,0.001523608);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2094,0.001793009);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2095,0.002194396);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2096,0.002860358);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2097,0.00335238);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2098,0.003737126);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2099,0.004730114);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2100,0.005430475);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2101,0.007059762);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2102,0.007667938);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2103,0.009326684);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2143,7.052466e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2145,4.185494e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2147,0.0001738858);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2149,0.0003460228);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2155,0.001260304);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2156,0.001447589);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2157,0.002043797);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2158,0.002320021);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2159,0.002569094);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2160,0.003368183);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2161,0.003772327);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2162,0.004558919);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2163,0.005963468);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2164,0.006509726);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2165,0.007968002);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2217,0.0009807067);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2218,0.001165852);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2219,0.001480128);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2220,0.001987375);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2221,0.002123733);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2222,0.002490047);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2223,0.003104499);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2224,0.003986076);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2225,0.004898046);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2226,0.005221098);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2227,0.006526424);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2269,6.95999e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2271,4.136727e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2273,0.0001634003);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2279,0.0007089541);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2280,0.000873372);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2281,0.001335269);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2282,0.001538017);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2283,0.001851769);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2284,0.001998949);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2285,0.002681046);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2286,0.003181037);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2287,0.003894868);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2288,0.00438975);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2289,0.005183193);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2341,0.0006627649);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2342,0.0007125289);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2343,0.0009741677);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2344,0.00109838);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2345,0.001639176);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2346,0.001789119);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2347,0.001787405);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2348,0.002686134);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2349,0.003342308);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2350,0.003420995);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2351,0.004509783);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2395,1.458419e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2397,6.778535e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2403,0.0004595123);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2404,0.0006265199);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2405,0.0006709012);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2406,0.001035285);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2407,0.0009550665);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2408,0.001570974);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2409,0.001660461);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2410,0.002084554);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2411,0.002655454);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2412,0.002888445);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2413,0.003553027);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2465,0.0003362831);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2466,0.0003425648);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2467,0.0005068323);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2468,0.0008310506);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2469,0.0009382014);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2470,0.001020372);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2471,0.001349107);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2472,0.001589538);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2473,0.002214956);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2474,0.002496073);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2475,0.002882517);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2527,0.0002865041);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2528,0.0003296348);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2529,0.0004373188);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2530,0.0006942611);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2531,0.0006687185);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2532,0.0008674836);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2533,0.001091466);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2534,0.001344907);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2535,0.001585106);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2536,0.00187837);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2537,0.002221347);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2589,0.0001751992);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2590,0.0003316086);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2591,0.000327928);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2592,0.0003766118);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2593,0.0006047631);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2594,0.0007372544);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2595,0.0009032757);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2596,0.001136959);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2597,0.001244643);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2598,0.001611812);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2599,0.00199612);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2651,9.081592e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2653,0.0002235204);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2655,0.0003683461);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2657,0.0005646584);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2659,0.001136449);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2661,0.00147534);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2775,1.295893e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2777,0.0001531457);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2779,0.0002455228);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2781,0.0002420843);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2783,0.0007061408);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2785,0.0009606592);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2901,3.201283e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2903,8.850292e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2905,0.0002002474);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2907,0.0004467994);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2909,0.0005773683);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3027,2.509575e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3029,8.675462e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3031,0.0002446507);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3033,0.0004226713);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3153,3.780745e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3155,0.0001053232);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3157,0.0002103082);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3279,2.527169e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3281,7.821251e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3403,6.131828e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3405,3.004722e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3529,1.202156e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(141,4.94921e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(143,6.03518e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(145,8.513776e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(147,0.0001173134);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(149,0.0001457541);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(151,0.0001883226);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(153,0.0002228312);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(155,0.0002653224);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(157,0.0003172526);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(159,0.0003717019);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(161,0.0004224936);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(163,0.0004769123);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(165,0.0005408182);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(167,0.000593744);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(169,0.0006449351);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(171,0.0007076479);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(173,0.0007729726);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(175,0.0008283023);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(177,0.0008415077);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(179,0.0009378538);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(181,0.001001111);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(265,4.235029e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(267,5.79537e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(269,7.761613e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(271,0.0001024526);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(273,0.0001404554);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(275,0.0001753575);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(277,0.0002130843);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(279,0.0003134251);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(281,0.0003025802);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(283,0.0003601651);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(285,0.0004029277);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(287,0.0004801169);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(289,0.0006203828);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(291,0.0005802534);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(293,0.0006297873);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(295,0.0006842395);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(297,0.0007510148);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(299,0.0008918917);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(301,0.0008910164);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(303,0.0009096592);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(305,0.000910343);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(389,3.473293e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(391,5.195318e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(393,6.504504e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(395,9.888673e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(397,0.0001208893);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(399,0.0001556877);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(401,0.0001951905);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(403,0.0002349576);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(405,0.0002769513);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(407,0.0003334979);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(409,0.000381202);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(411,0.000445269);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(413,0.0004998512);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(415,0.0006404607);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(417,0.0006043517);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(419,0.0006694697);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(421,0.0007162497);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(423,0.0007711781);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(425,0.0009632515);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(427,0.0009252314);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(429,0.0008987414);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(513,2.78123e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(515,5.02421e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(517,6.015101e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(519,8.106506e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(521,0.0001134087);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(523,0.0001376162);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(525,0.0001790086);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(527,0.0002196431);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(529,0.0002483887);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(531,0.0002948576);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(533,0.0003493809);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(535,0.0003994331);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(537,0.0004691801);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(539,0.0006412622);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(541,0.0005705889);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(543,0.0006241008);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(545,0.0007287858);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(547,0.0007355112);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(549,0.0008840196);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(551,0.0008375172);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(553,0.0009201436);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(637,1.735441e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(639,3.955729e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(641,5.14351e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(643,7.114501e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(645,9.759027e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(647,0.0001200633);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(649,0.0001459334);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(651,0.0001867548);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(653,0.0002421973);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(655,0.0002693909);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(657,0.0003236551);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(659,0.0003610816);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(661,0.0004177429);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(663,0.0004678729);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(665,0.0005338498);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(667,0.0005882753);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(669,0.0006492902);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(671,0.0007007601);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(673,0.0007564323);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(675,0.0008500844);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(677,0.0008461623);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(761,1.875768e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(763,2.622295e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(765,4.339209e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(767,5.940121e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(769,7.734106e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(771,0.0001032547);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(773,0.0001258672);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(775,0.0001528955);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(777,0.0001944555);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(779,0.000231877);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(781,0.0002780194);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(783,0.0003161432);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(785,0.0003811783);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(787,0.000438792);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(789,0.0004847853);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(791,0.000543702);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(793,0.0006429658);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(795,0.0006583776);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(797,0.0007182238);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(799,0.0008595548);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(801,0.0009523271);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(885,9.967311e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(887,2.575176e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(889,3.002871e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(891,5.001557e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(893,5.904164e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(895,7.268966e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(897,0.0001096531);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(899,0.000134047);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(901,0.0001599377);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(903,0.0001983886);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(905,0.0002425883);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(907,0.0002824164);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(909,0.0003305832);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(911,0.0003778721);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(913,0.0004371524);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(915,0.0006705166);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(917,0.0005586299);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(919,0.0006160461);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(921,0.0006699961);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(923,0.0007191809);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(925,0.0009318427);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1009,1.224665e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1011,1.761583e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1013,2.720845e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1015,2.974908e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1017,5.189585e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1019,6.75775e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1021,9.085469e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1023,0.0001088661);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1025,0.0001346383);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1027,0.0001708273);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1029,0.0002086547);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1031,0.000242657);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1033,0.0003047641);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1035,0.0003348778);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1037,0.0003831972);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1039,0.0004501279);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1041,0.0005112284);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1043,0.0005622368);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1045,0.0006188257);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1047,0.0006809762);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1049,0.0009351359);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1135,1.271274e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1137,2.060968e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1139,1.935899e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1141,3.752458e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1143,5.563504e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1145,6.866258e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1147,9.810216e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1149,0.0001125359);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1151,0.0001423968);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1153,0.0001660621);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1155,0.0002031344);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1157,0.0002541324);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1159,0.0002870346);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1161,0.000335638);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1163,0.0003887026);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1165,0.0004447637);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1167,0.0005104794);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1169,0.0005666361);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1171,0.0006100109);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1173,0.0007765767);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1261,7.28747e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1263,2.433982e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1265,3.057422e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1267,3.796104e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1269,5.876516e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1271,7.411475e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1273,9.635389e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1275,0.0001179912);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1277,0.0001374153);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1279,0.0001691306);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1281,0.0002089455);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1283,0.0002491688);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1285,0.0002857494);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1287,0.000336405);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1289,0.0003891869);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1291,0.0004971623);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1293,0.0005066516);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1295,0.0005652398);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1297,0.0006525116);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1387,1.045591e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1389,1.271809e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1391,3.101325e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1393,3.978263e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1395,5.772358e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1397,6.970796e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1399,8.656053e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1401,0.0001126088);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1403,0.0001388696);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1405,0.0001738102);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1407,0.000211607);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1409,0.0002447321);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1411,0.0002881456);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1413,0.0003500456);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1415,0.0004035609);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1417,0.0004611295);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1419,0.0005021559);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1421,0.0005681417);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1515,2.634327e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1517,3.105615e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1519,3.823025e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1521,5.817899e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1523,8.055098e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1525,9.558643e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1527,0.000118614);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1529,0.0001770438);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1531,0.0001641688);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1533,0.000208773);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1535,0.0002433582);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1537,0.0002854174);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1539,0.0003397533);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1541,0.0003882851);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1543,0.0004802013);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1545,0.0006286692);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1641,1.918055e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1643,3.123239e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1645,4.390864e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1647,6.190484e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1649,7.465052e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1651,9.407249e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1653,0.0001202184);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1655,0.0001415196);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1657,0.0001740034);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1659,0.0002016554);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1661,0.0002421341);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1663,0.0002822907);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1665,0.0003290074);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1667,0.0003760238);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1669,0.0004589418);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1765,7.251611e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1767,1.441226e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1769,2.934289e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1771,4.185027e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1773,5.61061e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1775,7.022316e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1777,9.266537e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1783,0.0001655002);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1785,0.0002017409);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1787,0.000234293);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1789,0.0002844077);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1791,0.0003340293);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1793,0.0003742489);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1845,0.000148499);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1846,0.0001641804);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1847,0.0001817727);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1848,0.000197859);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1849,0.0002141457);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1850,0.0002470477);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1851,0.0002623125);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1852,0.000327462);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1853,0.000330334);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1854,0.0003194588);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1855,0.0003500487);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1891,7.246044e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1893,1.753723e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1895,3.614401e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1897,4.277208e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1899,6.393084e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1901,9.187008e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1907,0.0001351991);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1908,0.0001423342);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1909,0.0001635455);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1910,0.0001885976);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1911,0.000202902);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1912,0.0002127046);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1913,0.0002356426);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1914,0.0002587878);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1915,0.0002791883);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1916,0.0002977393);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1917,0.0003196416);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1969,0.0001235937);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1970,0.0001381926);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1971,0.0001460439);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1972,0.0001606427);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1973,0.0001800082);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1974,0.0002039138);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1975,0.0002152913);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1976,0.000236147);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1977,0.0002602684);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1978,0.0002702415);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1979,0.0002981038);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2017,7.133624e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2019,1.865921e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2021,3.26784e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2023,4.225653e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2025,5.72488e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2031,0.000117935);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2032,0.0001274185);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2033,0.0001381958);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2034,0.000150017);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2035,0.0001655197);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2036,0.0001692142);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2037,0.0001892971);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2038,0.0002217307);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2039,0.0002433821);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2040,0.000251033);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2041,0.0003067371);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2093,0.0001050563);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2094,0.0001143);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2095,0.0001194774);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2096,0.0001362643);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2097,0.0001514524);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2098,0.0001546946);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2099,0.0001772384);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2100,0.0001865883);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2101,0.0002121816);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2102,0.0002263982);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2103,0.0002439657);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2143,7.052496e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2145,1.708764e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2147,3.478082e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2149,4.846302e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2155,9.085688e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2156,9.73382e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2157,0.0001153935);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2158,0.0001223738);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2159,0.0001306068);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2160,0.0001553824);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2161,0.0001562686);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2162,0.0001732332);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2163,0.0001974595);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2164,0.0002234493);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2165,0.000253191);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2217,8.018089e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2218,8.772569e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2219,9.798178e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2220,0.0001130842);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2221,0.0001170014);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2222,0.0001344441);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2223,0.0001450931);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2224,0.0001591883);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2225,0.0001804355);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2226,0.0002206173);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2227,0.0002039313);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2269,6.960019e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2271,1.688854e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2273,3.335724e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2279,6.794406e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2280,8.149762e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2281,9.360334e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2282,9.941318e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2283,0.0001085708);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2284,0.0001172566);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2285,0.0001315018);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2286,0.0001414255);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2287,0.0001561267);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2288,0.0001661734);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2289,0.0001864507);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2341,6.565957e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2342,6.828213e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2343,7.906604e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2344,8.382099e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2345,0.0001053207);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2346,0.0001080772);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2347,0.0001085789);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2348,0.0001326454);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2349,0.0001467388);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2350,0.0001517045);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2351,0.0001675468);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2395,1.033049e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2397,2.143649e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2403,5.456244e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2404,6.403582e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2405,6.586085e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2406,8.193625e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2407,7.883026e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2408,0.0001011623);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2409,0.0001024047);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2410,0.0001151742);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2411,0.0001316644);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2412,0.0001337649);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2413,0.0001492096);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2465,4.664357e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2466,4.706465e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2467,5.705825e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2468,7.350635e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2469,7.690812e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2470,8.255138e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2471,9.191801e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2472,0.0001180321);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2473,0.000117151);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2474,0.0001245182);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2475,0.0001329415);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2527,4.319962e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2528,4.617419e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2529,5.307052e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2530,6.653079e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2531,6.498271e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2532,7.392063e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2533,8.285346e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2534,9.671939e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2535,0.0001001774);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2536,0.0001074032);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2537,0.0001233341);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2589,3.372067e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2590,4.647754e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2591,4.59499e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2592,4.904186e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2593,6.241573e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2594,7.102693e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2595,7.506192e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2596,8.413508e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2597,8.76865e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2598,0.0001010896);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2599,0.0001125102);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2651,2.427291e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2653,3.779507e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2655,4.842098e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2657,5.921255e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2659,8.363803e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2661,0.0001198426);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2775,9.163418e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2777,3.126364e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2779,3.932096e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2781,3.877021e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2783,6.588607e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2785,7.877013e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2901,1.431685e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2903,2.365467e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2905,3.541929e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2907,5.267009e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2909,5.895276e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3027,1.254806e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3029,2.318737e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3031,4.137676e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3033,5.053736e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3153,1.543518e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3155,2.554625e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3157,3.555311e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3279,1.263604e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3281,2.169328e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3403,6.131851e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3405,1.343777e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3529,8.500586e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetEntries(772379);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetLineColor(ci);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->Draw("colz");
   c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf->Modified();
   c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf->cd();
   c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf->SetSelected(c_AccEffMap_T1qqqq_6NJet8_1500HTinf_300MHTinf);
}
/*
Topology ~g ~g ; ~g ->q+qbar+LSP

mGluino(GeV) mLSP(GeV) AccXEff
   400    25    0.00029241
   400    75   0.000246801
   400   125   0.000166503
   400   175    0.00010771
   400   225   4.25083e-05
   400   275   4.96266e-05
   400   325   1.40958e-05
   400   375   2.12116e-05
   450    25   0.000497025
   450    75   0.000440553
   450   125   0.000370621
   450   175    0.00034784
   450   225   0.000216636
   450   275   9.44914e-05
   450   325   8.92019e-05
   450   375   4.31487e-05
   450   425   2.20188e-05
   500    25   0.000968544
   500    75   0.000778411
   500   125    0.00055107
   500   175   0.000480384
   500   225   0.000348497
   500   275   0.000256548
   500   325   0.000123802
   500   375   0.000101798
   500   425   5.82909e-05
   500   475   7.28744e-06
   550    25    0.00176086
   550    75    0.00138161
   550   125    0.00129722
   550   175   0.000859821
   550   225    0.00065525
   550   275   0.000482381
   550   325   0.000339044
   550   375   0.000118777
   550   425   5.12175e-05
   550   475   8.07221e-05
   550   525   1.47868e-05
   600    25    0.00275343
   600    75     0.0025472
   600   125     0.0019081
   600   175    0.00168142
   600   225    0.00126555
   600   275   0.000802586
   600   325   0.000468008
   600   375   0.000366822
   600   425   0.000191316
   600   475   0.000125998
   600   525   2.20281e-05
   650    25    0.00452589
   650    75    0.00402179
   650   125    0.00319258
   650   175    0.00251858
   650   225    0.00193141
   650   275    0.00143091
   650   325   0.000711116
   650   375   0.000618826
   650   425   0.000423596
   650   475   0.000197228
   650   525   0.000131568
   650   575   9.49766e-05
   700    25    0.00644873
   700    75    0.00586993
   700   125    0.00498681
   700   175    0.00417418
   700   225    0.00284152
   700   275    0.00213823
   700   325    0.00159035
   700   375    0.00112246
   700   425   0.000643535
   700   475   0.000473644
   700   525    0.00021787
   700   575   0.000131696
   700   625   5.07454e-05
   700   675   7.25158e-06
   750    25    0.00907823
   750    75    0.00839405
   750   125    0.00718909
   750   175    0.00605511
   750   225    0.00427567
   750   275    0.00310229
   750   325     0.0024124
   750   375    0.00160734
   750   425    0.00132191
   750   475   0.000755154
   750   525   0.000457819
   750   575   0.000202271
   750   625   0.000132287
   750   675    2.8824e-05
   750   725   7.24601e-06
   800    25     0.0126246
   800    75     0.0118683
   800   125    0.00994911
   800   175    0.00814867
   800   225    0.00651525
   800   275    0.00508816
   800   325    0.00345713
   800   375    0.00248681
   800   425    0.00171807
   800   475    0.00129092
   800   525   0.000678831
   800   575    0.00047234
   800   625   0.000270627
   800   675   0.000120975
   800   725   4.29562e-05
   800   775   7.13359e-06
   850    25     0.0177797
   850    75      0.016528
   850   125     0.0144151
   850   175     0.0115356
   850   225    0.00962307
   850   275    0.00721853
   850   325    0.00534904
   850   375    0.00399601
   850   425    0.00279617
   850   475    0.00194507
   850   525    0.00105545
   850   575   0.000917595
   850   625   0.000539119
   850   675   0.000247553
   850   725   0.000184226
   850   775   4.93662e-05
   850   825   7.05247e-06
   900    25     0.0229185
   900    75      0.020915
   900   125     0.0189866
   900   175       0.01596
   900   225     0.0132959
   900   275     0.0103769
   900   325    0.00797554
   900   375    0.00597712
   900   425    0.00384805
   900   475    0.00266435
   900   525    0.00179064
   900   575    0.00129852
   900   625    0.00078596
   900   675   0.000448465
   900   725   0.000263623
   900   775   0.000153261
   900   825   4.18549e-05
   900   875   6.95999e-06
   950    25     0.0292856
   950    75     0.0273858
   950   125     0.0257388
   950   175     0.0209698
   950   225     0.0172666
   950   275     0.0135316
   950   325     0.0108074
   950   375    0.00810153
   950   425    0.00575601
   950   475    0.00403156
   950   525    0.00273362
   950   575    0.00202698
   950   625    0.00127409
   950   675    0.00071207
   950   725   0.000592441
   950   775   0.000260446
   950   825   0.000173886
   950   875   4.13673e-05
   950   925   1.45842e-05
  1000    25     0.0373962
  1000    75     0.0346794
  1000   125     0.0322238
  1000   175     0.0283303
  1000   225      0.023184
  1000   275     0.0192089
  1000   325     0.0146138
  1000   375     0.0119743
  1000   425    0.00895404
  1000   475    0.00615609
  1000   525    0.00431939
  1000   575     0.0030151
  1000   625     0.0018469
  1000   675    0.00122441
  1000   725   0.000971183
  1000   775   0.000482246
  1000   825   0.000346023
  1000   875     0.0001634
  1000   925   6.77854e-05
  1050    25     0.0442445
  1050    75     0.0432354
  1050   125     0.0379498
  1050   175     0.0343775
  1050   225     0.0290527
  1050   275     0.0249178
  1050   325     0.0194612
  1050   375     0.0151902
  1050   425     0.0114551
  1050   475    0.00871507
  1050   525    0.00605448
  1050   575    0.00391774
  1050   625    0.00292586
  1100    25     0.0529216
  1100    75     0.0508088
  1100   125     0.0472921
  1100   175     0.0423639
  1100   225     0.0374213
  1100   275     0.0314175
  1100   325     0.0258728
  1100   375     0.0201649
  1100   425     0.0157101
  1100   475     0.0115245
  1100   525    0.00858181
  1100   575    0.00630212
  1100   625     0.0043031
  1150    25     0.0627115
  1150    75      0.060086
  1150   125     0.0575889
  1150   175     0.0506642
  1150   225     0.0454928
  1150   275     0.0394202
  1150   325     0.0325269
  1150   375     0.0269412
  1150   425       0.02113
  1150   475      0.016064
  1150   525     0.0119725
  1150   575    0.00867403
  1150   625    0.00573819
  1150   675    0.00384784
  1150   700    0.00330475
  1150   725    0.00275283
  1150   750    0.00230973
  1150   775    0.00178088
  1150   800    0.00152361
  1150   825     0.0012603
  1150   850   0.000980707
  1150   875   0.000708954
  1150   900   0.000662765
  1150   925   0.000459512
  1150   950   0.000336283
  1150   975   0.000286504
  1150  1000   0.000175199
  1150  1025   9.08159e-05
  1150  1075   1.29589e-05
  1175   700    0.00405078
  1175   725    0.00307329
  1175   750    0.00285773
  1175   775    0.00245232
  1175   800    0.00179301
  1175   825    0.00144759
  1175   850    0.00116585
  1175   875   0.000873372
  1175   900   0.000712529
  1175   925    0.00062652
  1175   950   0.000342565
  1175   975   0.000329635
  1175  1000   0.000331609
  1200    25     0.0715204
  1200    75     0.0689087
  1200   125     0.0657088
  1200   175     0.0613777
  1200   225     0.0552904
  1200   275     0.0483782
  1200   325     0.0419195
  1200   375     0.0340292
  1200   425     0.0275312
  1200   475      0.021164
  1200   525     0.0167761
  1200   575     0.0118974
  1200   625    0.00866253
  1200   675    0.00592388
  1200   700    0.00441137
  1200   725     0.0039364
  1200   750    0.00325691
  1200   775    0.00292998
  1200   800     0.0021944
  1200   825     0.0020438
  1200   850    0.00148013
  1200   875    0.00133527
  1200   900   0.000974168
  1200   925   0.000670901
  1200   950   0.000506832
  1200   975   0.000437319
  1200  1000   0.000327928
  1200  1025    0.00022352
  1200  1075   0.000153146
  1200  1125   3.20128e-05
  1225   700    0.00594821
  1225   725    0.00531684
  1225   750    0.00359397
  1225   775    0.00344493
  1225   800    0.00286036
  1225   825    0.00232002
  1225   850    0.00198738
  1225   875    0.00153802
  1225   900    0.00109838
  1225   925    0.00103529
  1225   950   0.000831051
  1225   975   0.000694261
  1225  1000   0.000376612
  1250    25     0.0807009
  1250    75     0.0786314
  1250   125     0.0753114
  1250   175     0.0701369
  1250   225     0.0643526
  1250   275     0.0575411
  1250   325     0.0501973
  1250   375     0.0425997
  1250   425     0.0337823
  1250   475     0.0280034
  1250   525     0.0209131
  1250   575       0.01636
  1250   625     0.0116193
  1250   675    0.00828249
  1250   700     0.0069266
  1250   725    0.00614122
  1250   750    0.00475712
  1250   775    0.00401498
  1250   800    0.00335238
  1250   825    0.00256909
  1250   850    0.00212373
  1250   875    0.00185177
  1250   900    0.00163918
  1250   925   0.000955067
  1250   950   0.000938201
  1250   975   0.000668719
  1250  1000   0.000604763
  1250  1025   0.000368346
  1250  1075   0.000245523
  1250  1125   8.85029e-05
  1250  1175   2.50957e-05
  1275   700    0.00869713
  1275   725    0.00692346
  1275   750     0.0062238
  1275   775    0.00445778
  1275   800    0.00373713
  1275   825    0.00336818
  1275   850    0.00249005
  1275   875    0.00199895
  1275   900    0.00178912
  1275   925    0.00157097
  1275   950    0.00102037
  1275   975   0.000867484
  1275  1000   0.000737254
  1300    25     0.0901578
  1300    75     0.0892361
  1300   125       0.08527
  1300   175      0.080013
  1300   225     0.0746278
  1300   275     0.0682672
  1300   325     0.0597553
  1300   375     0.0519305
  1300   425      0.044246
  1300   475     0.0355874
  1300   525     0.0280997
  1300   575     0.0218809
  1300   625     0.0157875
  1300   675     0.0119598
  1300   700    0.00945382
  1300   725    0.00844004
  1300   750    0.00698854
  1300   775    0.00529137
  1300   800    0.00473011
  1300   825    0.00377233
  1300   850     0.0031045
  1300   875    0.00268105
  1300   900     0.0017874
  1300   925    0.00166046
  1300   950    0.00134911
  1300   975    0.00109147
  1300  1000   0.000903276
  1300  1025   0.000564658
  1300  1075   0.000242084
  1300  1125   0.000200247
  1300  1175   8.67546e-05
  1300  1225   3.78075e-05
  1325   700     0.0121511
  1325   725     0.0097442
  1325   750    0.00857588
  1325   775     0.0071924
  1325   800    0.00543048
  1325   825    0.00455892
  1325   850    0.00398608
  1325   875    0.00318104
  1325   900    0.00268613
  1325   925    0.00208455
  1325   950    0.00158954
  1325   975    0.00134491
  1325  1000    0.00113696
  1350    25     0.0989032
  1350    75     0.0982058
  1350   125     0.0950252
  1350   175     0.0896209
  1350   225     0.0843557
  1350   275     0.0772921
  1350   325     0.0691821
  1350   375     0.0618689
  1350   425     0.0512554
  1350   475     0.0440963
  1350   525      0.035608
  1350   575     0.0283698
  1350   625     0.0209505
  1350   675     0.0164512
  1350   700     0.0135877
  1350   725     0.0111734
  1350   750    0.00987546
  1350   775    0.00820699
  1350   800    0.00705976
  1350   825    0.00596347
  1350   850    0.00489805
  1350   875    0.00389487
  1350   900    0.00334231
  1350   925    0.00265545
  1350   950    0.00221496
  1350   975    0.00158511
  1350  1000    0.00124464
  1350  1025    0.00113645
  1350  1075   0.000706141
  1350  1125   0.000446799
  1350  1175   0.000244651
  1350  1225   0.000105323
  1350  1275   2.52717e-05
  1350  1325   6.13183e-06
  1375   700     0.0154567
  1375   725     0.0134838
  1375   750      0.011233
  1375   775    0.00976924
  1375   800    0.00766794
  1375   825    0.00650973
  1375   850     0.0052211
  1375   875    0.00438975
  1375   900      0.003421
  1375   925    0.00288844
  1375   950    0.00249607
  1375   975    0.00187837
  1375  1000    0.00161181
  1400    25      0.109208
  1400    75      0.106795
  1400   125      0.104272
  1400   175     0.0996456
  1400   225     0.0936966
  1400   275     0.0877223
  1400   325     0.0802559
  1400   375     0.0730022
  1400   425     0.0617843
  1400   475     0.0542251
  1400   525     0.0445875
  1400   575     0.0352224
  1400   625     0.0277137
  1400   675     0.0210372
  1400   700     0.0180383
  1400   725     0.0156149
  1400   750     0.0135272
  1400   775     0.0113007
  1400   800    0.00932668
  1400   825      0.007968
  1400   850    0.00652642
  1400   875    0.00518319
  1400   900    0.00450978
  1400   925    0.00355303
  1400   950    0.00288252
  1400   975    0.00222135
  1400  1000    0.00199612
  1400  1025    0.00147534
  1400  1075   0.000960659
  1400  1125   0.000577368
  1400  1175   0.000422671
  1400  1225   0.000210308
  1400  1275   7.82125e-05
  1400  1325   3.00472e-05
  1400  1375   1.20216e-05
*/
