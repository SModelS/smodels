{
//=========Macro generated from canvas: c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf/c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf
//=========  (Sat Feb 22 16:31:36 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf = new TCanvas("c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf", "c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf",100,240,500,500);
   c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf->SetFillColor(0);
   c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf->SetBorderMode(0);
   c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf->SetBorderSize(2);
   c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf->SetLogz();
   c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_6NJet8_1500HTinf_300MHTinf = new TH2D("h_EffAcc_6NJet8_1500HTinf_300MHTinf","h_EffAcc_6NJet8_1500HTinf_300MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(79,3.540677e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(81,0.0001026332);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(83,0.0001658109);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(85,0.0001786492);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(87,0.0004507921);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(89,0.0007618999);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(91,0.001340182);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(93,0.001985734);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(95,0.003043447);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(97,0.004634493);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(99,0.006937629);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(101,0.008886026);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(103,0.01259879);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(105,0.01661903);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(107,0.02212735);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(109,0.0287365);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(111,0.03692361);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(113,0.0439945);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(115,0.05418605);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(117,0.06289866);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(119,0.07161133);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(141,1.413479e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(143,6.462676e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(145,0.0001877058);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(147,0.0002608661);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(149,0.0005959718);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(151,0.0009803096);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(153,0.001511583);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(155,0.002216417);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(156,0.002523958);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(158,0.003365722);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(160,0.005776762);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(162,0.00780507);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(164,0.01092307);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(166,0.0138241);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(168,0.0191148);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(169,0.02195463);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(171,0.02853276);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(173,0.03604574);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(175,0.0442181);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(177,0.05275205);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(179,0.06206933);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(181,0.07136003);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(265,4.243767e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(267,4.414102e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(269,0.0001021127);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(271,0.0002693119);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(273,0.0004873166);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(275,0.0007997048);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(277,0.001212444);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(279,0.001802466);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(280,0.002184405);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(282,0.003193515);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(284,0.004935275);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(286,0.0070139);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(288,0.009661989);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(290,0.0131959);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(292,0.01832736);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(293,0.02066039);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(295,0.02602868);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(297,0.03291249);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(299,0.04176103);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(301,0.0509981);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(303,0.06026895);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(305,0.06959714);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(389,6.370213e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(391,2.898421e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(393,8.760655e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(395,0.0002020645);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(397,0.0003553903);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(399,0.0005466581);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(401,0.0009921561);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(403,0.001692571);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(404,0.001883435);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(406,0.002970588);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(408,0.003872169);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(410,0.006142252);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(412,0.008233048);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(414,0.01132576);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(416,0.01623837);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(417,0.01725104);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(419,0.02328129);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(421,0.03013312);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(423,0.03820675);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(425,0.04661172);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(427,0.0561833);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(429,0.06592634);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(513,5.684248e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(515,6.496838e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(517,0.0001237403);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(519,0.0001171364);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(521,0.0003677663);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(523,0.0004387321);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(525,0.0007204952);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(527,0.001080546);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(528,0.001369798);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(530,0.002364319);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(532,0.003418255);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(534,0.004606761);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(536,0.006746911);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(538,0.009011534);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(540,0.01315095);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(541,0.01542805);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(543,0.02076625);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(545,0.02580979);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(547,0.03451265);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(549,0.04259653);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(551,0.05184775);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(553,0.06182245);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(639,0.0001081263);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(641,8.775013e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(643,0.0001679188);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(645,0.0002289153);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(647,0.0004446773);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(649,0.0006832449);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(651,0.0009559097);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(652,0.001131459);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(654,0.001697266);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(656,0.002327577);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(658,0.00351445);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(660,0.005521788);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(662,0.007639539);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(664,0.01031657);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(665,0.01142939);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(667,0.01602008);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(669,0.0218444);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(671,0.02921818);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(673,0.0370047);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(675,0.04545562);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(677,0.05507553);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(765,9.470646e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(767,0.000139153);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(769,0.0002434001);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(771,0.0002779567);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(773,0.0004108186);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(775,0.0006364774);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(776,0.0008185593);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(778,0.001043284);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(780,0.001918317);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(782,0.002795754);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(784,0.003847361);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(786,0.006039129);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(788,0.00792683);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(789,0.009749355);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(791,0.01295467);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(793,0.01805195);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(795,0.02411768);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(797,0.03077238);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(799,0.03974713);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(801,0.04855942);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(891,8.066945e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(893,0.0001100811);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(895,0.0002425715);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(897,0.0003223301);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(899,0.0004411687);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(900,0.0005595544);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(902,0.000772659);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(904,0.001252364);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(906,0.001808619);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(908,0.002868073);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(910,0.004095432);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(912,0.006436217);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(913,0.007298558);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(915,0.01000591);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(917,0.01322111);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(919,0.01898949);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(921,0.02503674);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(923,0.033069);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(925,0.04164409);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1017,0.0001185075);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1019,0.0002338653);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1021,0.0002679042);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1023,0.0003756659);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1024,0.0005091066);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1026,0.0005806784);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1028,0.0008572349);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1030,0.001325997);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1032,0.00189246);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1034,0.00275109);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1036,0.004451983);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1037,0.005148087);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1039,0.007345886);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1041,0.01048241);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1043,0.01434497);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1045,0.01972875);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1047,0.0257509);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1049,0.03475136);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1143,0.0001832724);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1145,0.0002399309);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1147,0.0003543567);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1148,0.0003652025);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1150,0.0003802777);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1152,0.0006935749);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1154,0.00097205);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1156,0.001307065);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1158,0.00193809);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1160,0.003193132);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1161,0.003672087);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1163,0.005843082);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1165,0.008026514);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1167,0.01046014);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1169,0.01525486);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1171,0.02094385);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1173,0.02845759);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1269,9.493465e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1271,0.0002389028);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1272,0.0002654492);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1274,0.0002981403);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1276,0.0003952564);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1278,0.0007257251);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1280,0.0009102932);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1282,0.001399658);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1284,0.002135332);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1285,0.002562147);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1287,0.003788708);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1289,0.005386975);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1291,0.007528621);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1293,0.01088467);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1295,0.01561845);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1297,0.02155034);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1395,0.0001587679);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1396,0.000171479);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1398,0.0002209678);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1400,0.0004212803);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1402,0.0004230577);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1404,0.0006599159);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1406,0.000884942);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1408,0.001295934);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1409,0.001890113);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1410,0.002305937);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1411,0.002249052);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1412,0.003015992);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1413,0.003813406);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1414,0.004181291);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1415,0.005663558);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1416,0.006648086);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1417,0.007801681);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1418,0.009241598);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1419,0.01142951);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1420,0.01342208);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1421,0.01589898);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1471,0.001321652);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1472,0.001487958);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1473,0.001856961);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1474,0.002604828);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1475,0.003011785);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1476,0.00343841);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1477,0.004363591);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1478,0.005468806);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1479,0.006459884);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1480,0.007918742);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1481,0.009519492);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1482,0.01118372);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1483,0.01327922);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1520,0.0001289595);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1522,0.0002130722);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1524,0.0002465184);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1526,0.0003809613);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1528,0.0005208013);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1530,0.0007720482);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1532,0.0009021559);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1533,0.001204283);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1534,0.00137177);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1535,0.001354304);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1536,0.001917266);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1537,0.002332913);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1538,0.003086291);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1539,0.003613715);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1540,0.004330554);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1541,0.005654144);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1542,0.006788988);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1543,0.007507918);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1544,0.009333072);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1545,0.01170405);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1595,0.0008779787);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1596,0.001146195);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1597,0.001208686);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1598,0.001587662);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1599,0.002135775);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1600,0.002544644);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1601,0.002717822);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1602,0.003413475);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1603,0.004109068);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1604,0.005410888);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1605,0.006268461);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1606,0.007703555);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1607,0.009705993);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1646,6.381423e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1648,0.0001757236);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1650,0.0002567753);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1652,0.0003890103);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1654,0.000560947);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1656,0.0006602541);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1657,0.0007337853);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1658,0.0008980236);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1659,0.001311873);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1660,0.001344605);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1661,0.001628722);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1662,0.001805486);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1663,0.002377726);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1664,0.002942813);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1665,0.003469222);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1666,0.004570519);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1667,0.005014247);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1668,0.006502065);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1669,0.007762086);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1719,0.0005703511);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1720,0.0007857359);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1721,0.0009552273);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1722,0.001160683);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1723,0.001344637);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1724,0.001471212);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1725,0.00183057);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1726,0.002229377);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1727,0.002935282);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1728,0.003414402);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1729,0.004501268);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1730,0.005294083);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1731,0.006337323);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1772,0.0001488376);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1774,0.0002008109);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1776,0.0002733016);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1778,0.0004517014);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1780,0.000503969);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1781,0.0005951217);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1782,0.0006336184);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1783,0.0008287318);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1784,0.0008895163);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1785,0.001160484);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1786,0.001213119);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1787,0.001563682);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1788,0.001943061);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1789,0.002129048);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1790,0.002841761);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1791,0.003560168);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1792,0.004500077);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1793,0.005070009);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1843,0.0004860308);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1844,0.000575353);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1845,0.000685406);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1846,0.0005971973);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1847,0.0009513331);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1848,0.001089234);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1849,0.001269643);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1850,0.001308343);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1851,0.00169132);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1852,0.002241449);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1853,0.00292534);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1854,0.003363476);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1855,0.003967825);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1898,0.0001404675);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1900,0.000211319);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1902,0.000355952);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1904,0.0003458738);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1905,0.0002968543);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1906,0.0004414919);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1907,0.0005254578);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1908,0.0006542987);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1909,0.0007744032);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1910,0.0008624065);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1911,0.001212861);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1912,0.001528605);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1913,0.001502505);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1914,0.001777949);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1915,0.002226654);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1916,0.002614822);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1917,0.003417135);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1967,0.0003167318);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1968,0.0004213134);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1969,0.0004840997);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1970,0.0004980059);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1971,0.0006548815);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1972,0.0008173247);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1973,0.0007838276);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1974,0.001139954);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1975,0.001362052);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1976,0.001469196);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1977,0.001606911);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1978,0.00211005);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1979,0.002804879);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2024,0.0001027891);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2026,0.0002358177);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2028,0.0002990785);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2029,0.0003640324);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2030,0.0003665166);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2031,0.0004434833);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2032,0.0004213048);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2033,0.0005512679);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2034,0.000592818);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2035,0.0006565929);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2036,0.0007713566);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2037,0.000940299);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2038,0.001228449);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2039,0.001601568);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2040,0.001551472);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2041,0.002252866);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2091,0.0002446166);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2092,0.0003748965);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2093,0.0003180298);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2094,0.0003479676);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2095,0.0003635239);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2096,0.0005805087);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2097,0.0004835496);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2098,0.0007506937);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2099,0.0008658434);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2100,0.0008910194);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2101,0.001254594);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2102,0.001203442);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2103,0.001699441);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2150,0.0001276449);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2152,0.0001926261);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2153,0.0002780416);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2154,0.0002325977);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2155,0.0001911801);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2156,0.0003309422);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2157,0.0004267561);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2158,0.0004061305);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2159,0.0005404173);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2160,0.000627284);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2161,0.0006810959);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2162,0.0008619788);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2163,0.0008801531);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2164,0.001082794);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2165,0.001402076);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2215,0.0001676077);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2216,0.0003664284);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2217,0.0002446986);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2218,0.0002518057);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2219,0.0002896265);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2220,0.0004060829);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2221,0.0003979577);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2222,0.000477057);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2223,0.0006055808);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2224,0.0006321863);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2225,0.0007150434);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2226,0.000723781);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2227,0.001094285);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2276,9.2964e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2277,0.0001054144);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2278,0.0001934994);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2279,0.0002694881);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2280,0.0002994901);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2281,0.0002917762);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2282,0.0003714856);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2283,0.0002786439);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2284,0.0002943905);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2285,0.0004706467);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2286,0.0005537207);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2287,0.0006450299);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2288,0.0007299835);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2289,0.0009791201);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2339,8.025394e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2340,0.0001805512);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2341,0.0001759912);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2342,0.0002392424);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2343,0.0002677919);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2344,0.0002900654);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2345,0.0002923819);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2346,0.000270963);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2347,0.0003314866);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2348,0.0004606342);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2349,0.0006508719);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2350,0.0004497091);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2351,0.0008116456);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2402,9.321051e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2403,0.0001365388);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2404,0.0001510793);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2405,0.0002260342);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2406,0.0002559631);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2407,0.0003038547);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2408,0.0004326808);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2409,0.0002771339);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2410,0.0003780464);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2411,0.0004033101);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2412,0.0004854584);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2413,0.0005879094);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2465,0.0001046207);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2466,0.000100939);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2467,0.0001495519);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2468,0.0002261571);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2469,0.0002186672);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2470,0.0002937066);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2471,0.0002030046);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2472,0.0003681976);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2473,0.0005111912);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2474,0.0004237669);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2475,0.0005259004);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2528,8.569849e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2529,0.0001080303);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2530,0.0001792645);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2531,0.0001466489);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2532,0.0002296524);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2533,0.0002627901);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2534,0.0002749827);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2535,0.0003550763);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2536,0.000377182);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2537,0.000414791);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2591,7.739768e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2592,0.0001145878);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2593,0.0001007832);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2594,0.0001714102);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2595,0.0001487733);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2596,0.0002474434);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2597,0.0003084785);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2598,0.0003026895);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2599,0.000345598);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2655,0.0001396088);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2657,0.0001676225);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2659,0.0003549774);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2661,0.0003067774);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2781,9.913286e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2783,0.0002138704);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2785,0.0003255677);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2907,9.176199e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2909,0.0001684067);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3033,5.428734e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(79,1.583473e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(81,2.748638e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(83,3.637016e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(85,3.740918e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(87,5.943399e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(89,7.775444e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(91,0.0001030528);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(93,0.0001263397);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(95,0.0001559382);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(97,0.0001923862);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(99,0.0002348149);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(101,0.000375158);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(103,0.0003169737);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(105,0.0003631537);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(107,0.0004195639);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(109,0.000476362);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(111,0.0005406344);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(113,0.0005883702);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(115,0.0006539831);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(117,0.0007020647);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(119,0.0007470544);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(141,9.994894e-06);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(143,2.15431e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(145,3.850024e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(147,4.487452e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(149,6.823106e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(151,8.815141e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(153,0.0001093828);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(155,0.0001330599);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(156,0.0001422359);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(158,0.0001636465);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(160,0.0002143821);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(162,0.0002488569);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(164,0.000295344);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(166,0.0003307389);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(168,0.0003883215);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(169,0.0004172735);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(171,0.0004760705);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(173,0.0005342366);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(175,0.0005899145);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(177,0.0006430685);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(179,0.0006968917);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(181,0.0007452386);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(265,1.732555e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(267,1.803972e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(269,2.729245e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(271,4.569591e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(273,6.163458e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(275,7.873774e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(277,9.757415e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(279,0.0001195742);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(280,0.0001316153);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(282,0.0001592073);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(284,0.0001984573);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(286,0.0002360929);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(288,0.000276851);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(290,0.0003221644);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(292,0.0003809147);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(293,0.0004044545);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(295,0.0004514785);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(297,0.0005082639);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(299,0.0005724906);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(301,0.0006320794);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(303,0.0006858979);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(305,0.0007351247);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(389,2.123486e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(391,1.449236e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(393,2.529117e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(395,3.897224e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(397,5.1967e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(399,6.512844e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(401,8.737542e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(403,0.0001152428);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(404,0.0001212541);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(406,0.0001646041);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(408,0.0001742609);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(410,0.0002204477);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(412,0.0002541382);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(414,0.0002987581);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(416,0.0003566322);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(417,0.0003690302);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(419,0.0004256936);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(421,0.0004847417);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(423,0.0005450883);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(425,0.0006024359);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(427,0.0006600761);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(429,0.0007151091);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(513,2.009755e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(515,2.165698e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(517,3.001368e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(519,2.928616e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(521,5.263029e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(523,5.782497e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(525,7.41923e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(527,9.142822e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(528,0.0001029231);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(530,0.0001355385);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(532,0.0001633203);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(534,0.0001891657);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(536,0.0002293901);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(538,0.0002643171);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(540,0.0003200175);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(541,0.0003462789);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(543,0.0004017455);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(545,0.0004471801);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(547,0.0005172018);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(549,0.0005732352);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(551,0.0006327992);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(553,0.0006902062);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(639,2.791993e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(641,2.533263e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(643,3.501704e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(645,4.113001e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(647,5.750467e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(649,7.137764e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(651,8.515922e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(652,9.245419e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(654,0.0001139773);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(656,0.0001332059);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(658,0.0001653664);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(660,0.0002064492);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(662,0.000242584);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(664,0.0002810646);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(665,0.0002959261);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(667,0.0003503886);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(669,0.000408561);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(671,0.0004739957);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(673,0.0005323825);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(675,0.0005893816);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(677,0.0006479301);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(765,2.626835e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(767,3.192657e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(769,4.238637e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(771,4.50981e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(773,5.494802e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(775,6.879283e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(776,7.831605e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(778,8.855638e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(780,0.0001200454);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(782,0.0001454932);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(784,0.0001710901);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(786,0.0002144862);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(788,0.0002450636);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(789,0.0002729973);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(791,0.0003131046);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(793,0.0003700375);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(795,0.0004288039);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(797,0.0004832155);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(799,0.000548204);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(801,0.0006055687);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(891,2.432394e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(893,2.842471e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(895,4.225399e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(897,4.863582e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(899,5.650796e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(900,6.38611e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(902,7.524107e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(904,9.554543e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(906,0.0001159287);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(908,0.0001471251);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(910,0.0001747704);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(912,0.0002194436);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(913,0.0002347314);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(915,0.0002739027);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(917,0.0003147615);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(919,0.0003771092);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(921,0.0004334839);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(923,0.0004980957);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(925,0.000557765);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1017,2.964232e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1019,4.134778e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1021,4.40503e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1023,5.21073e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1024,6.04384e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1026,6.461238e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1028,7.880681e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1030,9.935608e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1032,0.0001172952);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1034,0.0001418013);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1036,0.0001811422);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1037,0.0001956756);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1039,0.0002329586);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1041,0.0002799748);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1043,0.0003263651);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1045,0.0003820748);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1047,0.0004368716);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1049,0.0005069077);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1143,3.665853e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1145,4.177265e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1147,5.063321e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1148,5.114985e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1150,5.229877e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1152,7.018299e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1154,8.362787e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1156,9.706897e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1158,0.0001180966);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1160,0.0001525347);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1161,0.0001640581);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1163,0.0002066091);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1165,0.0002428717);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1167,0.0002763844);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1169,0.0003343568);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1171,0.0003907781);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1173,0.000456163);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1269,2.634595e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1271,4.159363e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1272,4.364657e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1274,4.602059e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1276,5.284709e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1278,7.125375e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1280,8.003925e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1282,9.93699e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1284,0.0001235675);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1285,0.0001353128);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1287,0.000164341);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1289,0.0001972686);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1291,0.0002330053);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1293,0.0002801212);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1295,0.0003352432);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1297,0.0003938661);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1395,3.385267e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1396,3.500663e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1398,3.970186e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1400,5.440088e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1402,5.419407e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1404,6.741072e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1406,7.774112e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1408,9.42996e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1409,0.0001156074);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1410,0.0001289552);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1411,0.0001560356);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1412,0.0001494988);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1413,0.0001675899);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1414,0.0001812477);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1415,0.0002011166);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1416,0.0002206269);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1417,0.0002363437);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1418,0.0002567596);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1419,0.0002846855);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1420,0.0003261644);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1421,0.0003551999);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1471,9.598821e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1472,0.000103386);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1473,0.000122236);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1474,0.0001373882);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1475,0.0001477169);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1476,0.0001780658);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1477,0.0001750232);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1478,0.0002370273);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1479,0.0002158731);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1480,0.0002357967);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1481,0.0003190427);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1482,0.000281276);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1483,0.0003071583);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1520,3.039842e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1522,3.89065e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1524,4.167541e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1526,5.138063e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1528,5.976481e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1530,7.237024e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1532,7.84163e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1533,9.111663e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1534,9.805815e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1535,9.588156e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1536,0.0001211457);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1537,0.0001706938);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1538,0.000158914);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1539,0.0001595983);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1540,0.0002149112);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1541,0.0002047654);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1542,0.000221119);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1543,0.0002662478);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1544,0.0002557108);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1545,0.0002869195);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1595,7.722308e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1596,8.844198e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1597,0.0001156313);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1598,0.0001042462);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1599,0.0001223939);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1600,0.00013682);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1601,0.0001429123);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1602,0.0001546125);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1603,0.000171878);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1604,0.0001934301);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1605,0.000308474);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1606,0.0002315983);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1607,0.0002612105);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1646,2.127223e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1648,3.514845e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1650,4.222014e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1652,5.153778e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1654,6.159281e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1656,6.640427e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1657,7.007679e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1658,8.284561e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1659,0.0001216306);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1660,0.0001020426);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1661,0.0001139881);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1662,0.0001882153);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1663,0.0001267264);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1664,0.0001457335);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1665,0.0001721183);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1666,0.000176849);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1667,0.0002558898);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1668,0.000211895);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1669,0.0002313922);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1719,6.233689e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1720,8.076195e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1721,8.303395e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1722,9.381619e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1723,9.492951e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1724,0.0001024315);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1725,0.0001107287);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1726,0.0001224991);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1727,0.0001421105);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1728,0.0001532829);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1729,0.0001760285);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1730,0.0001904982);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1731,0.0002410631);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1772,3.252683e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1774,3.729418e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1776,4.321992e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1778,5.519918e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1780,5.782682e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1781,6.275925e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1782,6.920961e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1783,7.512293e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1784,8.458337e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1785,9.065845e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1786,9.836458e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1787,0.0001024656);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1788,0.0001171064);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1789,0.0001246716);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1790,0.0001382074);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1791,0.0001548691);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1792,0.000176241);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1793,0.0001885997);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1843,5.691402e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1844,7.370123e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1845,6.693535e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1846,6.231496e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1847,8.034676e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1848,8.446725e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1849,9.121402e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1850,0.0001378441);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1851,0.0001254795);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1852,0.0001224405);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1853,0.000142802);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1854,0.0001526724);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1855,0.0001976366);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1898,3.145757e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1900,3.795886e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1902,4.890428e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1904,4.797409e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1905,4.817432e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1906,5.435841e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1907,6.521073e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1908,7.018812e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1909,7.200279e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1910,7.464669e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1911,8.896858e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1912,0.0001270366);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1913,0.0001033624);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1914,0.0001111678);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1915,0.0001210806);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1916,0.0001321966);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1917,0.0001563803);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1967,4.83104e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1968,5.309404e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1969,5.963982e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1970,5.718753e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1971,6.5214e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1972,7.231116e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1973,8.423659e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1974,9.665066e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1975,9.408064e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1976,0.0001079037);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1977,0.0001024924);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1978,0.0001171493);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1979,0.0001451679);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2024,2.654167e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2026,3.986614e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2028,4.459205e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2029,4.910372e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2030,4.89887e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2031,6.402848e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2032,5.229424e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2033,7.647263e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2034,6.402305e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2035,6.928316e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2036,6.997343e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2037,8.4974e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2038,9.139492e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2039,0.0001112663);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2040,0.0001164459);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2041,0.0001239692);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2091,4.022067e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2092,5.589895e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2093,4.544157e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2094,4.736236e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2095,4.902834e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2096,6.338477e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2097,5.548319e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2098,6.973648e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2099,7.637603e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2100,7.521189e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2101,9.921333e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2102,8.904205e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2103,0.0001066539);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2150,2.9286e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2152,3.577393e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2153,4.344806e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2154,5.815759e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2155,3.824044e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2156,4.635047e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2157,6.036802e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2158,6.866548e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2159,5.898368e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2160,6.275225e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2161,6.624261e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2162,7.346525e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2163,7.43344e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2164,0.0001103101);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2165,9.693179e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2215,4.328051e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2216,5.945572e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2217,4.136773e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2218,4.452016e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2219,4.31898e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2220,5.687697e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2221,5.016194e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2222,5.47504e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2223,6.31795e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2224,7.02829e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2225,6.650021e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2226,7.366832e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2227,8.337022e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2276,2.484707e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2277,2.635528e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2278,3.593615e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2279,4.373254e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2280,5.063224e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2281,4.350311e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2282,4.878942e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2283,4.464563e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2284,4.439659e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2285,5.982794e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2286,6.354383e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2287,6.804186e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2288,7.13835e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2289,7.756932e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2339,2.316844e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2340,3.849784e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2341,3.840853e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2342,4.521911e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2343,4.403185e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2344,4.324799e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2345,4.459572e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2346,4.132826e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2347,4.598488e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2348,5.46825e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2349,7.474592e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2350,9.193338e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2351,7.017657e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2402,2.810561e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2403,3.132674e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2404,4.555629e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2405,4.06025e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2406,4.04776e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2407,4.386572e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2408,5.496493e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2409,4.328832e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2410,5.194802e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2411,6.013663e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2412,5.645585e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2413,6.535872e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2465,2.615683e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2466,2.606394e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2467,3.431267e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2468,3.823276e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2469,3.750608e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2470,6.125297e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2471,5.075741e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2472,4.835751e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2473,5.613311e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2474,5.179059e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2475,5.884392e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2528,2.474031e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2529,2.700935e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2530,3.388148e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2531,3.364656e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2532,4.125253e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2533,4.055586e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2534,4.348584e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2535,4.74593e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2536,4.791313e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2537,5.595222e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2591,2.580043e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2592,2.701047e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2593,2.60237e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2594,3.300043e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2595,3.326973e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2596,4.37488e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2597,4.503355e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2598,5.826333e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2599,4.74815e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2655,2.976722e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2657,3.226224e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2659,4.662085e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2661,4.296543e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2781,2.47847e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2783,3.615539e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2785,4.431291e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2907,2.369416e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2909,3.182914e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3033,1.809638e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetEntries(412153.6);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetLineColor(ci);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->Draw("colz");
   c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf->Modified();
   c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf->cd();
   c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf->SetSelected(c_AccEffMap_T1tttt_6NJet8_1500HTinf_300MHTinf);
}
/*
   400     0   3.54068e-05
   400    25   1.41348e-05
   400    75   4.24377e-05
   400   125   6.37021e-05
   400   175   5.68425e-05
   450     0   0.000102633
   450    25   6.46268e-05
   450    75    4.4141e-05
   450   125   2.89842e-05
   450   175   6.49684e-05
   450   225   0.000108126
   500     0   0.000165811
   500    25   0.000187706
   500    75   0.000102113
   500   125   8.76065e-05
   500   175    0.00012374
   500   225   8.77501e-05
   500   275   9.47065e-05
   550     0   0.000178649
   550    25   0.000260866
   550    75   0.000269312
   550   125   0.000202064
   550   175   0.000117136
   550   225   0.000167919
   550   275   0.000139153
   550   325   8.06694e-05
   600     0   0.000450792
   600    25   0.000595972
   600    75   0.000487317
   600   125    0.00035539
   600   175   0.000367766
   600   225   0.000228915
   600   275     0.0002434
   600   325   0.000110081
   600   375   0.000118507
   650     0     0.0007619
   650    25    0.00098031
   650    75   0.000799705
   650   125   0.000546658
   650   175   0.000438732
   650   225   0.000444677
   650   275   0.000277957
   650   325   0.000242572
   650   375   0.000233865
   650   425   0.000183272
   700     0    0.00134018
   700    25    0.00151158
   700    75    0.00121244
   700   125   0.000992156
   700   175   0.000720495
   700   225   0.000683245
   700   275   0.000410819
   700   325    0.00032233
   700   375   0.000267904
   700   425   0.000239931
   700   475   9.49346e-05
   750     0    0.00198573
   750    25    0.00221642
   750    75    0.00180247
   750   125    0.00169257
   750   175    0.00108055
   750   225    0.00095591
   750   275   0.000636477
   750   325   0.000441169
   750   375   0.000375666
   750   425   0.000354357
   750   475   0.000238903
   750   525   0.000158768
   775    25    0.00252396
   775    75    0.00218441
   775   125    0.00188343
   775   175     0.0013698
   775   225    0.00113146
   775   275   0.000818559
   775   325   0.000559554
   775   375   0.000509107
   775   425   0.000365202
   775   475   0.000265449
   775   525   0.000171479
   775   575    0.00012896
   800     0    0.00304345
   825    25    0.00336572
   825    75    0.00319352
   825   125    0.00297059
   825   175    0.00236432
   825   225    0.00169727
   825   275    0.00104328
   825   325   0.000772659
   825   375   0.000580678
   825   425   0.000380278
   825   475    0.00029814
   825   525   0.000220968
   825   575   0.000213072
   825   625   6.38142e-05
   850     0    0.00463449
   875    25    0.00577676
   875    75    0.00493527
   875   125    0.00387217
   875   175    0.00341826
   875   225    0.00232758
   875   275    0.00191832
   875   325    0.00125236
   875   375   0.000857235
   875   425   0.000693575
   875   475   0.000395256
   875   525    0.00042128
   875   575   0.000246518
   875   625   0.000175724
   875   675   0.000148838
   900     0    0.00693763
   925    25    0.00780507
   925    75     0.0070139
   925   125    0.00614225
   925   175    0.00460676
   925   225    0.00351445
   925   275    0.00279575
   925   325    0.00180862
   925   375      0.001326
   925   425    0.00097205
   925   475   0.000725725
   925   525   0.000423058
   925   575   0.000380961
   925   625   0.000256775
   925   675   0.000200811
   925   725   0.000140468
   950     0    0.00888603
   975    25     0.0109231
   975    75    0.00966199
   975   125    0.00823305
   975   175    0.00674691
   975   225    0.00552179
   975   275    0.00384736
   975   325    0.00286807
   975   375    0.00189246
   975   425    0.00130706
   975   475   0.000910293
   975   525   0.000659916
   975   575   0.000520801
   975   625    0.00038901
   975   675   0.000273302
   975   725   0.000211319
   975   775   0.000102789
  1000     0     0.0125988
  1025    25     0.0138241
  1025    75     0.0131959
  1025   125     0.0113258
  1025   175    0.00901153
  1025   225    0.00763954
  1025   275    0.00603913
  1025   325    0.00409543
  1025   375    0.00275109
  1025   425    0.00193809
  1025   475    0.00139966
  1025   525   0.000884942
  1025   575   0.000772048
  1025   625   0.000560947
  1025   675   0.000451701
  1025   725   0.000355952
  1025   775   0.000235818
  1025   825   0.000127645
  1050     0      0.016619
  1075    25     0.0191148
  1075    75     0.0183274
  1075   125     0.0162384
  1075   175      0.013151
  1075   225     0.0103166
  1075   275    0.00792683
  1075   325    0.00643622
  1075   375    0.00445198
  1075   425    0.00319313
  1075   475    0.00213533
  1075   525    0.00129593
  1075   575   0.000902156
  1075   625   0.000660254
  1075   675   0.000503969
  1075   725   0.000345874
  1075   775   0.000299078
  1075   825   0.000192626
  1075   875    9.2964e-05
  1100     0     0.0221274
  1100    25     0.0219546
  1100    75     0.0206604
  1100   125      0.017251
  1100   175     0.0154281
  1100   225     0.0114294
  1100   275    0.00974935
  1100   325    0.00729856
  1100   375    0.00514809
  1100   425    0.00367209
  1100   475    0.00256215
  1100   525    0.00189011
  1100   550    0.00132165
  1100   575    0.00120428
  1100   600   0.000877979
  1100   625   0.000733785
  1100   650   0.000570351
  1100   675   0.000595122
  1100   700   0.000486031
  1100   725   0.000296854
  1100   750   0.000316732
  1100   775   0.000364032
  1100   800   0.000244617
  1100   825   0.000278042
  1100   850   0.000167608
  1100   875   0.000105414
  1100   900   8.02539e-05
  1125   525    0.00230594
  1125   550    0.00148796
  1125   575    0.00137177
  1125   600     0.0011462
  1125   625   0.000898024
  1125   650   0.000785736
  1125   675   0.000633618
  1125   700   0.000575353
  1125   725   0.000441492
  1125   750   0.000421313
  1125   775   0.000366517
  1125   800   0.000374897
  1125   825   0.000232598
  1125   850   0.000366428
  1125   875   0.000193499
  1125   900   0.000180551
  1125   925   9.32105e-05
  1150     0     0.0287365
  1150    25     0.0285328
  1150    75     0.0260287
  1150   125     0.0232813
  1150   175     0.0207663
  1150   225     0.0160201
  1150   275     0.0129547
  1150   325     0.0100059
  1150   375    0.00734589
  1150   425    0.00584308
  1150   475    0.00378871
  1150   525    0.00224905
  1150   550    0.00185696
  1150   575     0.0013543
  1150   600    0.00120869
  1150   625    0.00131187
  1150   650   0.000955227
  1150   675   0.000828732
  1150   700   0.000685406
  1150   725   0.000525458
  1150   750     0.0004841
  1150   775   0.000443483
  1150   800    0.00031803
  1150   825    0.00019118
  1150   850   0.000244699
  1150   875   0.000269488
  1150   900   0.000175991
  1150   925   0.000136539
  1150   950   0.000104621
  1175   525    0.00301599
  1175   550    0.00260483
  1175   575    0.00191727
  1175   600    0.00158766
  1175   625     0.0013446
  1175   650    0.00116068
  1175   675   0.000889516
  1175   700   0.000597197
  1175   725   0.000654299
  1175   750   0.000498006
  1175   775   0.000421305
  1175   800   0.000347968
  1175   825   0.000330942
  1175   850   0.000251806
  1175   875    0.00029949
  1175   900   0.000239242
  1175   925   0.000151079
  1175   950   0.000100939
  1175   975   8.56985e-05
  1200     0     0.0369236
  1200    25     0.0360457
  1200    75     0.0329125
  1200   125     0.0301331
  1200   175     0.0258098
  1200   225     0.0218444
  1200   275      0.018052
  1200   325     0.0132211
  1200   375     0.0104824
  1200   425    0.00802651
  1200   475    0.00538698
  1200   525    0.00381341
  1200   550    0.00301178
  1200   575    0.00233291
  1200   600    0.00213577
  1200   625    0.00162872
  1200   650    0.00134464
  1200   675    0.00116048
  1200   700   0.000951333
  1200   725   0.000774403
  1200   750   0.000654881
  1200   775   0.000551268
  1200   800   0.000363524
  1200   825   0.000426756
  1200   850   0.000289626
  1200   875   0.000291776
  1200   900   0.000267792
  1200   925   0.000226034
  1200   950   0.000149552
  1200   975    0.00010803
  1200  1000   7.73977e-05
  1225   525    0.00418129
  1225   550    0.00343841
  1225   575    0.00308629
  1225   600    0.00254464
  1225   625    0.00180549
  1225   650    0.00147121
  1225   675    0.00121312
  1225   700    0.00108923
  1225   725   0.000862407
  1225   750   0.000817325
  1225   775   0.000592818
  1225   800   0.000580509
  1225   825   0.000406131
  1225   850   0.000406083
  1225   875   0.000371486
  1225   900   0.000290065
  1225   925   0.000255963
  1225   950   0.000226157
  1225   975   0.000179264
  1225  1000   0.000114588
  1250     0     0.0439945
  1250    25     0.0442181
  1250    75      0.041761
  1250   125     0.0382067
  1250   175     0.0345126
  1250   225     0.0292182
  1250   275     0.0241177
  1250   325     0.0189895
  1250   375      0.014345
  1250   425     0.0104601
  1250   475    0.00752862
  1250   525    0.00566356
  1250   550    0.00436359
  1250   575    0.00361371
  1250   600    0.00271782
  1250   625    0.00237773
  1250   650    0.00183057
  1250   675    0.00156368
  1250   700    0.00126964
  1250   725    0.00121286
  1250   750   0.000783828
  1250   775   0.000656593
  1250   800    0.00048355
  1250   825   0.000540417
  1250   850   0.000397958
  1250   875   0.000278644
  1250   900   0.000292382
  1250   925   0.000303855
  1250   950   0.000218667
  1250   975   0.000146649
  1250  1000   0.000100783
  1250  1025   0.000139609
  1275   525    0.00664809
  1275   550    0.00546881
  1275   575    0.00433055
  1275   600    0.00341347
  1275   625    0.00294281
  1275   650    0.00222938
  1275   675    0.00194306
  1275   700    0.00130834
  1275   725     0.0015286
  1275   750    0.00113995
  1275   775   0.000771357
  1275   800   0.000750694
  1275   825   0.000627284
  1275   850   0.000477057
  1275   875   0.000294391
  1275   900   0.000270963
  1275   925   0.000432681
  1275   950   0.000293707
  1275   975   0.000229652
  1275  1000    0.00017141
  1300     0     0.0541861
  1300    25      0.052752
  1300    75     0.0509981
  1300   125     0.0466117
  1300   175     0.0425965
  1300   225     0.0370047
  1300   275     0.0307724
  1300   325     0.0250367
  1300   375     0.0197287
  1300   425     0.0152549
  1300   475     0.0108847
  1300   525    0.00780168
  1300   550    0.00645988
  1300   575    0.00565414
  1300   600    0.00410907
  1300   625    0.00346922
  1300   650    0.00293528
  1300   675    0.00212905
  1300   700    0.00169132
  1300   725    0.00150251
  1300   750    0.00136205
  1300   775   0.000940299
  1300   800   0.000865843
  1300   825   0.000681096
  1300   850   0.000605581
  1300   875   0.000470647
  1300   900   0.000331487
  1300   925   0.000277134
  1300   950   0.000203005
  1300   975    0.00026279
  1300  1000   0.000148773
  1300  1025   0.000167622
  1300  1075   9.91329e-05
  1325   525     0.0092416
  1325   550    0.00791874
  1325   575    0.00678899
  1325   600    0.00541089
  1325   625    0.00457052
  1325   650     0.0034144
  1325   675    0.00284176
  1325   700    0.00224145
  1325   725    0.00177795
  1325   750     0.0014692
  1325   775    0.00122845
  1325   800   0.000891019
  1325   825   0.000861979
  1325   850   0.000632186
  1325   875   0.000553721
  1325   900   0.000460634
  1325   925   0.000378046
  1325   950   0.000368198
  1325   975   0.000274983
  1325  1000   0.000247443
  1350     0     0.0628987
  1350    25     0.0620693
  1350    75     0.0602689
  1350   125     0.0561833
  1350   175     0.0518478
  1350   225     0.0454556
  1350   275     0.0397471
  1350   325      0.033069
  1350   375     0.0257509
  1350   425     0.0209439
  1350   475     0.0156184
  1350   525     0.0114295
  1350   550    0.00951949
  1350   575    0.00750792
  1350   600    0.00626846
  1350   625    0.00501425
  1350   650    0.00450127
  1350   675    0.00356017
  1350   700    0.00292534
  1350   725    0.00222665
  1350   750    0.00160691
  1350   775    0.00160157
  1350   800    0.00125459
  1350   825   0.000880153
  1350   850   0.000715043
  1350   875    0.00064503
  1350   900   0.000650872
  1350   925    0.00040331
  1350   950   0.000511191
  1350   975   0.000355076
  1350  1000   0.000308479
  1350  1025   0.000354977
  1350  1075    0.00021387
  1350  1125    9.1762e-05
  1375   525     0.0134221
  1375   550     0.0111837
  1375   575    0.00933307
  1375   600    0.00770355
  1375   625    0.00650207
  1375   650    0.00529408
  1375   675    0.00450008
  1375   700    0.00336348
  1375   725    0.00261482
  1375   750    0.00211005
  1375   775    0.00155147
  1375   800    0.00120344
  1375   825    0.00108279
  1375   850   0.000723781
  1375   875   0.000729983
  1375   900   0.000449709
  1375   925   0.000485458
  1375   950   0.000423767
  1375   975   0.000377182
  1375  1000    0.00030269
  1400     0     0.0716113
  1400    25       0.07136
  1400    75     0.0695971
  1400   125     0.0659263
  1400   175     0.0618225
  1400   225     0.0550755
  1400   275     0.0485594
  1400   325     0.0416441
  1400   375     0.0347514
  1400   425     0.0284576
  1400   475     0.0215503
  1400   525      0.015899
  1400   550     0.0132792
  1400   575      0.011704
  1400   600    0.00970599
  1400   625    0.00776209
  1400   650    0.00633732
  1400   675    0.00507001
  1400   700    0.00396782
  1400   725    0.00341713
  1400   750    0.00280488
  1400   775    0.00225287
  1400   800    0.00169944
  1400   825    0.00140208
  1400   850    0.00109428
  1400   875    0.00097912
  1400   900   0.000811646
  1400   925   0.000587909
  1400   950     0.0005259
  1400   975   0.000414791
  1400  1000   0.000345598
  1400  1025   0.000306777
  1400  1075   0.000325568
  1400  1125   0.000168407
  1400  1175   5.42873e-05
*/
