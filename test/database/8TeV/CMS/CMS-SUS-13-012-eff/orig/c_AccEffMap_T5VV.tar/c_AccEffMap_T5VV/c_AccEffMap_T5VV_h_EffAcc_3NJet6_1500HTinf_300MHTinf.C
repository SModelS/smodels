{
//=========Macro generated from canvas: c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf/c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf
//=========  (Sat Feb 22 16:32:51 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf = new TCanvas("c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf", "c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf",90,432,500,500);
   c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf->Range(0,0,1,1);
   c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf->SetFillColor(0);
   c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf->SetBorderMode(0);
   c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf->SetBorderSize(2);
   c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf->SetLogz();
   c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_3NJet6_1500HTinf_300MHTinf = new TH2D("h_EffAcc_3NJet6_1500HTinf_300MHTinf","h_EffAcc_3NJet6_1500HTinf_300MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(141,6.16573e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(143,0.0001114574);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(145,0.0002837851);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(147,0.0003951743);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(149,0.0005875673);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(151,0.000987808);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(153,0.001682765);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(155,0.002299562);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(157,0.003520635);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(159,0.004752145);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(161,0.006587741);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(163,0.009516805);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(165,0.01218126);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(167,0.01595041);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(169,0.02110445);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(171,0.02718801);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(173,0.03475169);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(175,0.04128376);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(177,0.04890222);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(179,0.05838554);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(181,0.06693055);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(265,7.963601e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(267,0.0001510406);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(269,0.0002607911);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(271,0.0003331557);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(273,0.0006509393);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(275,0.0009487685);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(277,0.001563586);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(279,0.002228399);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(281,0.003203311);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(283,0.004912946);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(285,0.006294375);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(287,0.008474523);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(289,0.01178523);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(291,0.01563619);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(293,0.02081648);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(295,0.02645023);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(297,0.03430521);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(299,0.04119373);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(301,0.04998479);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(303,0.05681292);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(305,0.06664281);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(389,8.533496e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(391,0.0001202345);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(393,0.000155188);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(395,0.0002738252);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(397,0.0004751152);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(399,0.0007458114);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(401,0.00137571);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(403,0.00192706);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(405,0.002504431);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(407,0.003876819);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(409,0.005658336);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(411,0.008012161);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(413,0.01028846);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(415,0.01407907);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(417,0.01898089);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(419,0.02577089);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(421,0.03095226);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(423,0.039677);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(425,0.04771738);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(427,0.055694);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(429,0.06498425);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(513,3.549271e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(515,5.09922e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(517,0.0001896649);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(519,0.0002121825);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(521,0.0003385966);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(523,0.0005427489);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(525,0.0008814594);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(527,0.001321789);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(529,0.001959986);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(531,0.003029361);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(533,0.004737008);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(535,0.006343449);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(537,0.009019304);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(539,0.01271323);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(541,0.01699896);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(543,0.02241872);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(545,0.02884264);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(547,0.03658341);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(549,0.04484928);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(551,0.05329194);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(553,0.06283683);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(639,7.248649e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(641,0.0001347387);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(643,0.0001476324);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(645,0.0002508187);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(647,0.0003791514);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(649,0.000594458);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(651,0.001148447);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(653,0.001698581);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(655,0.002423839);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(657,0.003174391);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(659,0.00487163);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(661,0.007173172);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(663,0.009932804);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(665,0.01354934);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(667,0.01861924);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(669,0.02474144);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(671,0.03246995);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(673,0.03988192);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(675,0.04891401);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(677,0.05889207);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(765,0.0001651706);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(767,0.0001208181);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(769,0.0001912955);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(771,0.0002198779);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(773,0.0004454596);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(775,0.0006861017);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(777,0.000929184);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(779,0.001864386);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(781,0.002703587);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(783,0.004005142);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(785,0.005062951);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(787,0.007232593);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(789,0.01038502);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(791,0.01529968);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(793,0.0205432);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(795,0.02775087);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(797,0.03470095);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(799,0.04344384);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(801,0.05290971);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(891,5.926845e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(893,0.0001059724);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(895,0.0001388518);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(897,0.0002691092);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(899,0.0003890637);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(901,0.0006440798);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(903,0.001118458);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(905,0.001909731);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(907,0.002651383);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(909,0.004293284);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(911,0.00563371);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(913,0.007990293);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(915,0.01148292);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(917,0.01584294);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(919,0.02230977);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(921,0.03025192);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(923,0.0377743);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(925,0.04733345);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1017,5.859923e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1019,0.000211656);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1021,0.0002460909);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1023,0.0002934804);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1025,0.0004531983);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1027,0.0006660007);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1029,0.001111211);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1031,0.001938892);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1033,0.002450536);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1035,0.004267214);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1037,0.006366431);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1039,0.008435575);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1041,0.01217958);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1043,0.01738079);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1045,0.02398033);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1047,0.03246501);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1049,0.04130294);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1143,0.0001296123);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1145,0.0001753275);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1147,0.0001082349);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1149,0.0003326434);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1151,0.0005561129);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1153,0.0007244274);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1155,0.001231647);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1157,0.001784804);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1159,0.002789711);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1161,0.004241689);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1163,0.006709031);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1165,0.009452099);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1167,0.01347828);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1169,0.0187868);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1171,0.0250754);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1173,0.03383896);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1269,8.0137e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1271,0.0001283924);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1273,0.0002664523);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1275,0.0003246769);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1277,0.0004961549);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1279,0.0009204208);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1281,0.00103711);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1283,0.001833036);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1285,0.002716858);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1287,0.004257638);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1289,0.006321869);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1291,0.009396725);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1293,0.01331688);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1295,0.01938852);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1297,0.02698619);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1395,0.0001113538);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1397,0.0001142835);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1399,0.0002148756);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1401,0.0003338591);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1403,0.0004736953);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1405,0.0007782619);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1407,0.001196191);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1409,0.001713655);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1411,0.003040863);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1413,0.004369396);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1415,0.006622939);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1417,0.009735628);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1419,0.01380658);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1421,0.02024427);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1473,0.002261448);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1474,0.002700689);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1475,0.00324838);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1476,0.004366296);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1477,0.004987621);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1478,0.00645121);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1479,0.007608572);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1480,0.009563098);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1481,0.01199815);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1482,0.01455031);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1483,0.01738973);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1521,8.713494e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1523,0.0002189652);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1525,0.0002201236);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1527,0.0003502264);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1529,0.0005027641);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1531,0.0006560487);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1533,0.0009624898);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1535,0.001859099);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1536,0.002288098);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1537,0.002644894);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1538,0.003465669);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1539,0.004078845);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1540,0.005130179);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1541,0.006737878);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1542,0.007512472);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1543,0.009938557);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1544,0.01153261);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1545,0.01426472);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1597,0.001519538);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1598,0.001729753);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1599,0.002189532);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1600,0.00260459);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1601,0.003370961);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1602,0.0042406);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1603,0.005085199);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1604,0.006700844);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1605,0.008163022);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1606,0.009976104);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1607,0.01286806);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1647,0.0001795467);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1649,0.0001720402);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1651,0.000265256);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1653,0.0002752816);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1655,0.0004336926);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1657,0.0006019046);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1659,0.001079509);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1660,0.001323831);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1661,0.001613173);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1662,0.002158028);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1663,0.002670535);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1664,0.003311283);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1665,0.003964642);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1666,0.005398355);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1667,0.00657904);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1668,0.00808141);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1669,0.01025453);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1721,0.0007959159);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1722,0.000956004);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1723,0.001244153);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1724,0.001457821);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1725,0.001764779);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1726,0.002940116);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1727,0.003312371);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1728,0.003919108);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1729,0.005151748);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1730,0.006549186);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1731,0.008797835);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1773,0.0001290598);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1775,0.000155619);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1777,0.0001908817);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1779,0.0003134586);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1781,0.0004082052);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1783,0.0005801384);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1784,0.0007617664);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1785,0.001091814);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1786,0.001379547);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1787,0.001449228);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1788,0.001968528);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1789,0.002637135);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1790,0.003756239);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1791,0.003990754);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1792,0.00534141);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1793,0.00646914);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1845,0.0004577608);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1846,0.0006806916);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1847,0.0009356672);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1848,0.0008972854);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1849,0.001210705);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1850,0.00158303);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1851,0.002111342);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1852,0.002400458);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1853,0.003445341);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1854,0.004125595);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1855,0.00538419);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1899,0.0002413127);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1901,0.0001574764);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1903,0.000233435);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1905,0.0003041068);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1907,0.0003790507);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1908,0.0005154211);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1909,0.0006120337);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1910,0.0007229414);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1911,0.0009356079);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1912,0.001215165);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1913,0.001542475);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1914,0.00189695);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1915,0.002522561);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1916,0.00322342);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1917,0.004037544);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1969,0.0003737129);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1970,0.0003924859);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1971,0.0004184941);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1972,0.000646549);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1973,0.0007320154);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1974,0.000932022);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1975,0.001116838);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1976,0.001311224);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1977,0.001776017);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1978,0.002306037);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1979,0.00312878);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2025,0.0001967876);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2027,0.0001259811);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2029,0.0002237453);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2031,0.0002400795);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2032,0.0003459965);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2033,0.000283619);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2034,0.0005572757);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2035,0.0005395936);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2036,0.0006433745);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2037,0.0009270255);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2038,0.001132247);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2039,0.001496233);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2040,0.001884715);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2041,0.002298692);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2093,0.00026488);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2094,0.0002678497);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2095,0.0003044818);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2096,0.0004305608);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2097,0.0004984192);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2098,0.0005196384);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2099,0.0006398267);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2100,0.0007972414);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2101,0.0009859997);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2102,0.001313279);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2103,0.001846859);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2151,0.0001606717);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2153,0.0001923111);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2155,0.0001511829);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2156,0.0002070047);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2157,0.00025593);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2158,0.0003330681);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2159,0.0004378078);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2160,0.000497426);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2161,0.0004569038);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2162,0.0008270554);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2163,0.0007835132);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2164,0.001062536);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2165,0.001505991);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2217,0.0002305795);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2218,0.0001743763);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2219,0.0002188231);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2220,0.000300513);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2221,0.0002551163);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2222,0.000364399);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2223,0.0004806956);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2224,0.0005144752);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2225,0.000562738);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2226,0.000820591);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2227,0.001023849);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2277,0.0001681881);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2279,0.0001951575);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2281,0.0002042845);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2283,0.0002284804);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2285,0.0002775841);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2287,0.0005740304);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2289,0.0007942612);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2403,0.0001828202);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2405,0.0001344873);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2407,0.0002823147);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2409,0.0002655852);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2411,0.000444082);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2413,0.0004011922);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2529,0.0001868933);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2531,0.0001409594);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2533,0.0002052265);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2535,0.0002421783);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2537,0.0003339262);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2655,0.0002037222);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2657,0.0001681351);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2659,0.0002400019);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2661,0.0003310535);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2781,0.0002103914);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2783,0.0002140543);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2785,0.0001996701);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2907,0.0001721423);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2909,0.0001929086);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3033,0.000160223);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(141,2.183992e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(143,2.99306e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(145,4.959879e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(147,5.672389e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(149,6.963646e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(151,9.473191e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(153,0.000127252);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(155,0.0001418016);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(157,0.0001773505);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(159,0.0002021385);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(161,0.0002413137);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(163,0.0003202513);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(165,0.0003578191);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(167,0.0003615462);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(169,0.0004218323);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(171,0.0004693571);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(173,0.0005312174);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(175,0.000576789);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(177,0.0006262081);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(179,0.0006827603);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(181,0.0007282292);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(265,2.521425e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(267,3.388425e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(269,4.566329e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(271,5.23352e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(273,7.32017e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(275,9.270152e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(277,0.0001143832);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(279,0.0001395706);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(281,0.000166443);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(283,0.0002259688);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(285,0.0002335223);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(287,0.0002825767);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(289,0.0003120143);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(291,0.0003588744);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(293,0.0004228826);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(295,0.0004634559);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(297,0.0005273168);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(299,0.0005755684);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(301,0.0006334339);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(303,0.000671677);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(305,0.0007251049);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(389,2.463536e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(391,3.111426e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(393,3.480289e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(395,4.650273e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(397,6.271793e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(399,7.906621e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(401,0.0001058439);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(403,0.0001272269);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(405,0.0001442894);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(407,0.0001956253);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(409,0.0002351316);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(411,0.0002592353);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(413,0.0003548316);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(415,0.0003439808);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(417,0.0004378448);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(419,0.0004557085);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(421,0.0004993078);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(423,0.0005640543);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(425,0.000617419);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(427,0.0006657577);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(429,0.0007151926);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(513,1.587316e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(515,2.081812e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(517,3.796252e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(519,4.022566e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(521,5.183767e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(523,6.620724e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(525,9.142597e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(527,0.0001041504);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(529,0.0001262512);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(531,0.0001604467);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(533,0.0002038761);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(535,0.00023011);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(537,0.0002714087);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(539,0.0003907215);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(541,0.0003738528);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(543,0.0004243457);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(545,0.000480263);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(547,0.0005583212);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(549,0.0005973709);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(551,0.0006502962);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(553,0.0007037003);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(639,2.292325e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(641,3.176081e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(643,3.394666e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(645,4.375039e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(647,5.741587e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(649,7.247963e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(651,9.762586e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(653,0.00011739);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(655,0.0001614902);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(657,0.0001678906);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(659,0.0001987685);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(661,0.0002449006);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(663,0.0002913066);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(665,0.0003374912);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(667,0.0003861747);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(669,0.0004441636);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(671,0.0005119721);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(673,0.0005621913);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(675,0.0006207816);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(677,0.0006795033);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(765,3.521801e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(767,3.023709e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(769,3.752047e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(771,4.176825e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(773,5.981323e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(775,7.391488e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(777,8.949493e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(779,0.0001288583);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(781,0.00016146);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(783,0.000179475);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(785,0.0002018246);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(787,0.0002407436);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(789,0.0002890307);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(791,0.0003489272);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(793,0.0004032382);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(795,0.0004678382);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(797,0.0005233667);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(799,0.000582952);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(801,0.000641654);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(891,2.095531e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(893,2.832413e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(895,3.185747e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(897,4.560692e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(899,5.413503e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(901,7.735679e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(903,9.64596e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(905,0.0001227915);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(907,0.0001453415);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(909,0.0001939018);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(911,0.0002119651);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(913,0.000286786);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(915,0.000300116);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(917,0.000352156);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(919,0.0004180171);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(921,0.0004856725);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(923,0.0005406558);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(925,0.000605475);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1017,2.071869e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1019,3.930856e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1021,4.289206e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1023,4.647857e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1025,5.923955e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1027,8.113805e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1029,9.318193e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1031,0.0001226867);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1033,0.0001592019);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1035,0.0002148531);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1037,0.0002230515);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1039,0.0002568174);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1041,0.0003070004);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1043,0.0003663576);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1045,0.0004315689);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1047,0.0004992697);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1049,0.0005636068);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1143,3.146793e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1145,3.656218e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1147,2.794795e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1149,4.968288e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1151,6.404517e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1153,7.584221e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1155,0.0001440526);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1157,0.0001171243);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1159,0.0001530098);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1161,0.0001955013);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1163,0.0002280895);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1165,0.0002700125);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1167,0.0003217696);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1169,0.0003795165);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1171,0.0004382217);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1173,0.0005066967);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1269,2.416338e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1271,3.114215e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1273,4.385003e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1275,4.969984e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1277,6.036932e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1279,9.911515e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1281,9.367272e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1283,0.0001193233);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1285,0.0001443001);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1287,0.0001794172);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1289,0.000219484);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1291,0.0002675657);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1293,0.0003177221);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1295,0.0003824006);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1297,0.0004651545);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1395,2.976256e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1397,2.857284e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1399,3.923582e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1401,5.170347e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1403,5.85226e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1405,8.243554e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1407,9.397382e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1409,0.0001170775);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1411,0.0001513297);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1413,0.0001812508);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1415,0.0002225505);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1417,0.0002700072);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1419,0.000321542);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1421,0.0003912631);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1473,0.0001292653);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1474,0.0001428682);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1475,0.0001593456);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1476,0.0001920845);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1477,0.0002005299);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1478,0.000239084);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1479,0.0002522215);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1480,0.0002846019);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1481,0.0003078467);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1482,0.0003475936);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1483,0.0003797238);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1521,2.515501e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1523,3.933251e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1525,4.023396e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1527,4.960946e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1529,5.939909e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1531,6.875332e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1533,8.62205e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1535,0.000116046);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1536,0.0001982174);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1537,0.0001474593);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1538,0.000159766);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1539,0.000173671);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1540,0.0002114197);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1541,0.000223346);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1542,0.0002576381);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1543,0.0002734417);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1544,0.0002925114);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1545,0.0003318863);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1597,0.0001070708);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1598,0.0001130832);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1599,0.0001285637);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1600,0.0001423645);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1601,0.0001564103);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1602,0.0001770982);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1603,0.0001932827);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1604,0.0002531916);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1605,0.0002479287);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1606,0.0002864834);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1607,0.0003093247);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1647,3.592387e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1649,3.51212e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1651,4.303711e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1653,4.359597e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1655,5.480065e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1657,6.936116e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1659,8.749186e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1660,9.714652e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1661,0.000112301);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1662,0.0001298014);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1663,0.0001412883);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1664,0.0001541276);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1665,0.00017658);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1666,0.0002078672);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1667,0.0002277249);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1668,0.0002424263);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1669,0.0003049199);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1721,7.391918e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1722,8.182255e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1723,0.0001221795);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1724,0.0001047898);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1725,0.0001171309);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1726,0.0001461847);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1727,0.0001733675);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1728,0.000169334);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1729,0.0001971327);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1730,0.0002209587);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1731,0.000287415);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1773,3.042205e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1775,3.318121e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1777,3.608701e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1779,4.73332e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1781,5.370735e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1783,6.431656e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1784,7.501299e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1785,8.965154e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1786,9.864087e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1787,0.0001018592);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1788,0.0001221817);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1789,0.0001652455);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1790,0.0001767298);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1791,0.0001774135);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1792,0.0001960424);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1793,0.000218251);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1845,5.52421e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1846,8.424079e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1847,8.37522e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1848,9.017798e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1849,9.537736e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1850,0.00012442);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1851,0.0001245861);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1852,0.0001365015);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1853,0.0001665286);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1854,0.0001705102);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1855,0.0001975974);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1899,4.139083e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1901,3.288093e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1903,4.263583e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1905,5.219945e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1907,5.173328e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1908,5.850083e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1909,6.443872e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1910,7.616805e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1911,8.100073e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1912,9.695261e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1913,0.000109496);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1914,0.0001188681);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1915,0.0001645671);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1916,0.0001564963);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1917,0.0001798328);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1969,5.135939e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1970,5.117858e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1971,5.290043e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1972,7.58994e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1973,7.318299e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1974,8.008053e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1975,0.000115813);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1976,9.572836e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1977,0.0001110763);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1978,0.0001440079);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1979,0.0001489445);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2025,3.720367e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2027,2.969628e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2029,3.895433e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2031,3.94826e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2032,4.799814e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2033,4.278532e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2034,6.101751e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2035,6.052544e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2036,6.588262e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2037,7.935753e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2038,8.733154e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2039,0.0001067337);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2040,0.0001185871);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2041,0.0001347426);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2093,4.137394e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2094,4.465817e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2095,4.704541e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2096,5.310088e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2097,5.76885e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2098,5.903032e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2099,6.522855e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2100,7.890412e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2101,8.352796e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2102,9.959545e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2103,0.0001185014);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2151,3.280017e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2153,3.635727e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2155,3.15267e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2156,3.660677e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2157,4.331151e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2158,4.717854e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2159,5.400703e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2160,6.093307e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2161,5.559028e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2162,8.807264e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2163,7.278216e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2164,8.499472e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2165,0.000103128);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2217,3.954958e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2218,3.356228e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2219,4.571895e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2220,4.431629e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2221,4.040194e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2222,4.788356e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2223,5.98179e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2224,5.958567e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2225,6.354025e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2226,7.349283e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2227,8.611449e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2277,3.433474e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2279,3.688565e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2281,3.61172e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2283,3.809329e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2285,4.509789e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2287,6.074089e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2289,7.200833e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2403,5.27815e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2405,2.934992e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2407,4.99152e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2409,4.489933e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2411,5.23885e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2413,5.033535e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2529,3.986362e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2531,3.005521e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2533,3.573791e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2535,4.661408e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2537,4.508403e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2655,4.452274e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2657,3.236092e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2659,3.845335e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2661,4.506608e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2781,4.213305e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2783,3.618649e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2785,3.477022e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2907,3.25439e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2909,3.410575e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3033,3.204771e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetEntries(358249.7);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetLineColor(ci);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->Draw("colz");
   c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf->Modified();
   c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf->cd();
   c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf->SetSelected(c_AccEffMap_T5VV_3NJet6_1500HTinf_300MHTinf);
}
/*
   400    25   6.16573e-05
   400    75    7.9636e-05
   400   125    8.5335e-05
   400   175   3.54927e-05
   450    25   0.000111457
   450    75   0.000151041
   450   125   0.000120234
   450   175   5.09922e-05
   450   225   7.24865e-05
   500    25   0.000283785
   500    75   0.000260791
   500   125   0.000155188
   500   175   0.000189665
   500   225   0.000134739
   500   275   0.000165171
   550    25   0.000395174
   550    75   0.000333156
   550   125   0.000273825
   550   175   0.000212182
   550   225   0.000147632
   550   275   0.000120818
   550   325   5.92685e-05
   600    25   0.000587567
   600    75   0.000650939
   600   125   0.000475115
   600   175   0.000338597
   600   225   0.000250819
   600   275   0.000191296
   600   325   0.000105972
   600   375   5.85992e-05
   650    25   0.000987808
   650    75   0.000948769
   650   125   0.000745811
   650   175   0.000542749
   650   225   0.000379151
   650   275   0.000219878
   650   325   0.000138852
   650   375   0.000211656
   650   425   0.000129612
   700    25    0.00168277
   700    75    0.00156359
   700   125    0.00137571
   700   175   0.000881459
   700   225   0.000594458
   700   275    0.00044546
   700   325   0.000269109
   700   375   0.000246091
   700   425   0.000175328
   700   475    8.0137e-05
   750    25    0.00229956
   750    75     0.0022284
   750   125    0.00192706
   750   175    0.00132179
   750   225    0.00114845
   750   275   0.000686102
   750   325   0.000389064
   750   375    0.00029348
   750   425   0.000108235
   750   475   0.000128392
   750   525   0.000111354
   800    25    0.00352063
   800    75    0.00320331
   800   125    0.00250443
   800   175    0.00195999
   800   225    0.00169858
   800   275   0.000929184
   800   325    0.00064408
   800   375   0.000453198
   800   425   0.000332643
   800   475   0.000266452
   800   525   0.000114283
   800   575   8.71349e-05
   850    25    0.00475214
   850    75    0.00491295
   850   125    0.00387682
   850   175    0.00302936
   850   225    0.00242384
   850   275    0.00186439
   850   325    0.00111846
   850   375   0.000666001
   850   425   0.000556113
   850   475   0.000324677
   850   525   0.000214876
   850   575   0.000218965
   850   625   0.000179547
   900    25    0.00658774
   900    75    0.00629438
   900   125    0.00565834
   900   175    0.00473701
   900   225    0.00317439
   900   275    0.00270359
   900   325    0.00190973
   900   375    0.00111121
   900   425   0.000724427
   900   475   0.000496155
   900   525   0.000333859
   900   575   0.000220124
   900   625    0.00017204
   900   675    0.00012906
   950    25     0.0095168
   950    75    0.00847452
   950   125    0.00801216
   950   175    0.00634345
   950   225    0.00487163
   950   275    0.00400514
   950   325    0.00265138
   950   375    0.00193889
   950   425    0.00123165
   950   475   0.000920421
   950   525   0.000473695
   950   575   0.000350226
   950   625   0.000265256
   950   675   0.000155619
   950   725   0.000241313
  1000    25     0.0121813
  1000    75     0.0117852
  1000   125     0.0102885
  1000   175     0.0090193
  1000   225    0.00717317
  1000   275    0.00506295
  1000   325    0.00429328
  1000   375    0.00245054
  1000   425     0.0017848
  1000   475    0.00103711
  1000   525   0.000778262
  1000   575   0.000502764
  1000   625   0.000275282
  1000   675   0.000190882
  1000   725   0.000157476
  1000   775   0.000196788
  1050    25     0.0159504
  1050    75     0.0156362
  1050   125     0.0140791
  1050   175     0.0127132
  1050   225     0.0099328
  1050   275    0.00723259
  1050   325    0.00563371
  1050   375    0.00426721
  1050   425    0.00278971
  1050   475    0.00183304
  1050   525    0.00119619
  1050   575   0.000656049
  1050   625   0.000433693
  1050   675   0.000313459
  1050   725   0.000233435
  1050   775   0.000125981
  1050   825   0.000160672
  1100    25     0.0211044
  1100    75     0.0208165
  1100   125     0.0189809
  1100   175      0.016999
  1100   225     0.0135493
  1100   275      0.010385
  1100   325    0.00799029
  1100   375    0.00636643
  1100   425    0.00424169
  1100   475    0.00271686
  1100   525    0.00171365
  1100   575    0.00096249
  1100   625   0.000601905
  1100   675   0.000408205
  1100   725   0.000304107
  1100   775   0.000223745
  1100   825   0.000192311
  1100   875   0.000168188
  1150    25      0.027188
  1150    75     0.0264502
  1150   125     0.0257709
  1150   175     0.0224187
  1150   225     0.0186192
  1150   275     0.0152997
  1150   325     0.0114829
  1150   375    0.00843558
  1150   425    0.00670903
  1150   475    0.00425764
  1150   525    0.00304086
  1150   550    0.00226145
  1150   575     0.0018591
  1150   600    0.00151954
  1150   625    0.00107951
  1150   650   0.000795916
  1150   675   0.000580138
  1150   700   0.000457761
  1150   725   0.000379051
  1150   750   0.000373713
  1150   775    0.00024008
  1150   800    0.00026488
  1150   825   0.000151183
  1150   850    0.00023058
  1150   875   0.000195157
  1150   925    0.00018282
  1175   550    0.00270069
  1175   575     0.0022881
  1175   600    0.00172975
  1175   625    0.00132383
  1175   650   0.000956004
  1175   675   0.000761766
  1175   700   0.000680692
  1175   725   0.000515421
  1175   750   0.000392486
  1175   775   0.000345997
  1175   800    0.00026785
  1175   825   0.000207005
  1175   850   0.000174376
  1200    25     0.0347517
  1200    75     0.0343052
  1200   125     0.0309523
  1200   175     0.0288426
  1200   225     0.0247414
  1200   275     0.0205432
  1200   325     0.0158429
  1200   375     0.0121796
  1200   425     0.0094521
  1200   475    0.00632187
  1200   525     0.0043694
  1200   550    0.00324838
  1200   575    0.00264489
  1200   600    0.00218953
  1200   625    0.00161317
  1200   650    0.00124415
  1200   675    0.00109181
  1200   700   0.000935667
  1200   725   0.000612034
  1200   750   0.000418494
  1200   775   0.000283619
  1200   800   0.000304482
  1200   825    0.00025593
  1200   850   0.000218823
  1200   875   0.000204284
  1200   925   0.000134487
  1200   975   0.000186893
  1225   550     0.0043663
  1225   575    0.00346567
  1225   600    0.00260459
  1225   625    0.00215803
  1225   650    0.00145782
  1225   675    0.00137955
  1225   700   0.000897285
  1225   725   0.000722941
  1225   750   0.000646549
  1225   775   0.000557276
  1225   800   0.000430561
  1225   825   0.000333068
  1225   850   0.000300513
  1250    25     0.0412838
  1250    75     0.0411937
  1250   125      0.039677
  1250   175     0.0365834
  1250   225       0.03247
  1250   275     0.0277509
  1250   325     0.0223098
  1250   375     0.0173808
  1250   425     0.0134783
  1250   475    0.00939673
  1250   525    0.00662294
  1250   550    0.00498762
  1250   575    0.00407884
  1250   600    0.00337096
  1250   625    0.00267053
  1250   650    0.00176478
  1250   675    0.00144923
  1250   700    0.00121071
  1250   725   0.000935608
  1250   750   0.000732015
  1250   775   0.000539594
  1250   800   0.000498419
  1250   825   0.000437808
  1250   850   0.000255116
  1250   875    0.00022848
  1250   925   0.000282315
  1250   975   0.000140959
  1250  1025   0.000203722
  1275   550    0.00645121
  1275   575    0.00513018
  1275   600     0.0042406
  1275   625    0.00331128
  1275   650    0.00294012
  1275   675    0.00196853
  1275   700    0.00158303
  1275   725    0.00121517
  1275   750   0.000932022
  1275   775   0.000643374
  1275   800   0.000519638
  1275   825   0.000497426
  1275   850   0.000364399
  1300    25     0.0489022
  1300    75     0.0499848
  1300   125     0.0477174
  1300   175     0.0448493
  1300   225     0.0398819
  1300   275     0.0347009
  1300   325     0.0302519
  1300   375     0.0239803
  1300   425     0.0187868
  1300   475     0.0133169
  1300   525    0.00973563
  1300   550    0.00760857
  1300   575    0.00673788
  1300   600     0.0050852
  1300   625    0.00396464
  1300   650    0.00331237
  1300   675    0.00263713
  1300   700    0.00211134
  1300   725    0.00154247
  1300   750    0.00111684
  1300   775   0.000927025
  1300   800   0.000639827
  1300   825   0.000456904
  1300   850   0.000480696
  1300   875   0.000277584
  1300   925   0.000265585
  1300   975   0.000205226
  1300  1025   0.000168135
  1300  1075   0.000210391
  1325   550     0.0095631
  1325   575    0.00751247
  1325   600    0.00670084
  1325   625    0.00539836
  1325   650    0.00391911
  1325   675    0.00375624
  1325   700    0.00240046
  1325   725    0.00189695
  1325   750    0.00131122
  1325   775    0.00113225
  1325   800   0.000797241
  1325   825   0.000827055
  1325   850   0.000514475
  1350    25     0.0583855
  1350    75     0.0568129
  1350   125      0.055694
  1350   175     0.0532919
  1350   225      0.048914
  1350   275     0.0434438
  1350   325     0.0377743
  1350   375      0.032465
  1350   425     0.0250754
  1350   475     0.0193885
  1350   525     0.0138066
  1350   550     0.0119982
  1350   575    0.00993856
  1350   600    0.00816302
  1350   625    0.00657904
  1350   650    0.00515175
  1350   675    0.00399075
  1350   700    0.00344534
  1350   725    0.00252256
  1350   750    0.00177602
  1350   775    0.00149623
  1350   800      0.000986
  1350   825   0.000783513
  1350   850   0.000562738
  1350   875    0.00057403
  1350   925   0.000444082
  1350   975   0.000242178
  1350  1025   0.000240002
  1350  1075   0.000214054
  1350  1125   0.000172142
  1375   550     0.0145503
  1375   575     0.0115326
  1375   600     0.0099761
  1375   625    0.00808141
  1375   650    0.00654919
  1375   675    0.00534141
  1375   700     0.0041256
  1375   725    0.00322342
  1375   750    0.00230604
  1375   775    0.00188471
  1375   800    0.00131328
  1375   825    0.00106254
  1375   850   0.000820591
  1400    25     0.0669305
  1400    75     0.0666428
  1400   125     0.0649843
  1400   175     0.0628368
  1400   225     0.0588921
  1400   275     0.0529097
  1400   325     0.0473335
  1400   375     0.0413029
  1400   425      0.033839
  1400   475     0.0269862
  1400   525     0.0202443
  1400   550     0.0173897
  1400   575     0.0142647
  1400   600     0.0128681
  1400   625     0.0102545
  1400   650    0.00879784
  1400   675    0.00646914
  1400   700    0.00538419
  1400   725    0.00403754
  1400   750    0.00312878
  1400   775    0.00229869
  1400   800    0.00184686
  1400   825    0.00150599
  1400   850    0.00102385
  1400   875   0.000794261
  1400   925   0.000401192
  1400   975   0.000333926
  1400  1025   0.000331054
  1400  1075    0.00019967
  1400  1125   0.000192909
  1400  1175   0.000160223
*/
