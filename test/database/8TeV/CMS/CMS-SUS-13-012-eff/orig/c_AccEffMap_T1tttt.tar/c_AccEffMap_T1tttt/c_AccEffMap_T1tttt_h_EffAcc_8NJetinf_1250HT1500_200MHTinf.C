{
//=========Macro generated from canvas: c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf/c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf
//=========  (Sat Feb 22 16:31:37 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf = new TCanvas("c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf", "c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf",120,336,500,500);
   c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf->SetFillColor(0);
   c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf->SetLogz();
   c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1250HT1500_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1250HT1500_200MHTinf","h_EffAcc_8NJetinf_1250HT1500_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(79,0.0001314476);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(81,0.0003560652);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(83,0.001010023);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(85,0.001882688);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(87,0.002996711);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(89,0.00470205);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(91,0.007104599);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(93,0.009255828);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(95,0.01252106);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(97,0.01613212);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(99,0.01995971);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(101,0.02326551);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(103,0.02563879);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(105,0.0288615);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(107,0.03051425);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(109,0.03133686);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(111,0.03147056);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(113,0.03065704);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(115,0.02961447);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(117,0.0277749);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(119,0.02649509);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(141,0.0001157286);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(143,0.000260751);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(145,0.0009065595);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(147,0.001852241);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(149,0.002952458);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(151,0.004323743);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(153,0.006611585);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(155,0.009812198);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(156,0.01023394);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(158,0.01419445);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(160,0.01730875);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(162,0.02124017);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(164,0.02570798);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(166,0.02750212);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(168,0.0308541);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(169,0.03002629);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(171,0.0314555);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(173,0.03206897);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(175,0.03106642);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(177,0.02920302);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(179,0.0275669);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(181,0.02691224);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(265,0.0001564889);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(267,0.0001842212);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(269,0.0007024806);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(271,0.001208676);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(273,0.002780653);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(275,0.00405881);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(277,0.006679561);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(279,0.008569953);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(280,0.009719572);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(282,0.01291216);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(284,0.01621295);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(286,0.02016404);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(288,0.02346049);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(290,0.02684617);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(292,0.02977359);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(293,0.03134718);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(295,0.03110209);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(297,0.03231047);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(299,0.03210027);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(301,0.03071114);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(303,0.02989457);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(305,0.02737531);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(389,0.0001274043);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(391,0.00027535);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(393,0.000515601);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(395,0.000984605);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(397,0.001984033);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(399,0.00311801);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(401,0.005021062);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(403,0.007047938);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(404,0.008962876);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(406,0.01154932);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(408,0.01484091);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(410,0.0183805);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(412,0.02221065);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(414,0.02632516);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(416,0.02944793);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(417,0.0303639);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(419,0.03237547);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(421,0.03253808);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(423,0.03241168);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(425,0.03195408);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(427,0.03035947);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(429,0.02851043);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(513,5.106942e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(515,0.0001660303);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(517,0.000458567);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(519,0.0006552315);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(521,0.001372902);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(523,0.002153527);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(525,0.003903973);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(527,0.005618477);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(528,0.006676477);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(530,0.00926742);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(532,0.01231884);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(534,0.01674143);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(536,0.02018594);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(538,0.02421477);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(540,0.02747665);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(541,0.02944787);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(543,0.03102876);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(545,0.03290308);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(547,0.03374308);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(549,0.03368452);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(551,0.0321721);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(553,0.03008635);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(639,0.0001081263);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(641,0.0001992659);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(643,0.0005283965);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(645,0.0007304145);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(647,0.001619994);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(649,0.002371771);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(651,0.004409708);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(652,0.005434675);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(654,0.007102683);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(656,0.009572439);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(658,0.01335404);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(660,0.01712011);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(662,0.02135689);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(664,0.02591945);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(665,0.02770004);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(667,0.02966559);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(669,0.03189896);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(671,0.03440311);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(673,0.03350941);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(675,0.03279594);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(677,0.03146395);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(765,8.104687e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(767,0.0002572499);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(769,0.0004812892);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(771,0.0009458757);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(773,0.001737553);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(775,0.002744809);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(776,0.003461272);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(778,0.005465266);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(780,0.007587248);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(782,0.01050019);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(784,0.01335549);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(786,0.01743104);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(788,0.02222183);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(789,0.02375294);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(791,0.02758123);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(793,0.03160551);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(795,0.03324501);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(797,0.03351382);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(799,0.03382295);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(801,0.03365345);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(891,0.0002145074);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(893,0.0002366743);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(895,0.0006075709);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(897,0.001140903);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(899,0.002033526);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(900,0.002653284);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(902,0.00402262);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(904,0.005433331);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(906,0.008397559);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(908,0.01120996);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(910,0.0148151);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(912,0.01862087);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(913,0.02028654);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(915,0.02429255);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(917,0.02922009);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(919,0.03185196);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(921,0.03373606);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(923,0.03454714);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(925,0.03354857);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1017,0.000155254);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1019,0.0003471439);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1021,0.0006272217);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1023,0.001289094);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1024,0.001511186);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1026,0.002708504);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1028,0.003949685);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1030,0.005866388);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1032,0.008311871);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1034,0.01124897);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1036,0.01535198);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1037,0.01659108);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1039,0.02120518);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1041,0.02467201);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1043,0.02858698);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1045,0.03193632);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1047,0.03435174);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1049,0.03499009);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1143,0.0001777742);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1145,0.0004126084);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1147,0.0007096173);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1148,0.001009677);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1150,0.001716353);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1152,0.002429696);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1154,0.004043365);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1156,0.005833192);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1158,0.008664304);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1160,0.01110289);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1161,0.01328633);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1163,0.01673787);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1165,0.02054069);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1167,0.02492571);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1169,0.03002427);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1171,0.03311823);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1173,0.03491859);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1269,0.0001537037);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1271,0.0003339209);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1272,0.0004806783);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1274,0.0008961901);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1276,0.001671596);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1278,0.002428587);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1280,0.003950732);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1282,0.005897865);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1284,0.008289256);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1285,0.009560343);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1287,0.01300134);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1289,0.01686882);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1291,0.02135132);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1293,0.02676323);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1295,0.03035142);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1297,0.03311157);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1395,0.0001804181);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1396,0.0002724016);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1398,0.0004357237);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1400,0.001027748);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1402,0.001622297);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1404,0.002664881);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1406,0.004164309);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1408,0.006204046);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1409,0.007295364);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1410,0.0081512);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1411,0.009694795);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1412,0.01162874);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1413,0.01339949);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1414,0.01510036);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1415,0.01708464);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1416,0.01977075);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1417,0.02201468);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1418,0.02345434);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1419,0.02629954);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1420,0.02834103);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1421,0.03012819);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1471,0.006042792);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1472,0.006960105);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1473,0.008474632);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1474,0.009577041);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1475,0.01150559);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1476,0.01310204);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1477,0.01462364);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1478,0.01667707);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1479,0.0189805);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1480,0.02227991);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1481,0.02419742);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1482,0.02600738);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1483,0.02814279);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1520,7.253973e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1522,0.0002077454);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1524,0.0006114536);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1526,0.001046778);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1528,0.00173857);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1530,0.002655913);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1532,0.003628524);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1533,0.004820014);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1534,0.005677864);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1535,0.006959358);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1536,0.008425443);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1537,0.01001941);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1538,0.01150081);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1539,0.01317929);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1540,0.01466136);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1541,0.01801288);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1542,0.01977679);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1543,0.02149386);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1544,0.02387641);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1545,0.02616254);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1595,0.004196252);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1596,0.004970424);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1597,0.005674701);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1598,0.0071285);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1599,0.008506092);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1600,0.009713672);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1601,0.01093602);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1602,0.01269123);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1603,0.01496093);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1604,0.01726392);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1605,0.0199377);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1606,0.02219995);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1607,0.02423386);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1646,9.217611e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1648,0.0001273996);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1650,0.0004675739);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1652,0.0008616237);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1654,0.00154894);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1656,0.002580051);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1657,0.003105933);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1658,0.003927276);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1659,0.004597374);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1660,0.00566972);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1661,0.006937027);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1662,0.007885978);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1663,0.009438243);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1664,0.01162413);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1665,0.01344149);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1666,0.01508526);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1667,0.01617264);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1668,0.01947537);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1669,0.02155403);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1719,0.002709063);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1720,0.003206721);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1721,0.00379894);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1722,0.004599695);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1723,0.005721471);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1724,0.007089648);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1725,0.008590477);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1726,0.009368225);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1727,0.01138473);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1728,0.01348099);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1729,0.01475457);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1730,0.01763375);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1731,0.01986244);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1772,8.404947e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1774,0.0002155255);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1776,0.0003433352);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1778,0.0009505956);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1780,0.001520196);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1781,0.001938479);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1782,0.002435807);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1783,0.003034336);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1784,0.003519562);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1785,0.004638104);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1786,0.005403632);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1787,0.006740651);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1788,0.008102386);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1789,0.009586231);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1790,0.01093911);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1791,0.01323752);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1792,0.01494792);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1793,0.01702201);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1843,0.001694058);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1844,0.002266703);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1845,0.002335578);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1846,0.003035215);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1847,0.003837085);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1848,0.004421576);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1849,0.005940411);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1850,0.006645496);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1851,0.007921735);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1852,0.009648396);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1853,0.01131687);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1854,0.01318487);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1855,0.01527828);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1898,5.549334e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1900,0.0001917209);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1902,0.0005322489);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1904,0.000799833);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1905,0.00111588);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1906,0.001552747);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1907,0.001821486);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1908,0.002501427);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1909,0.002926947);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1910,0.003640655);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1911,0.004623859);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1912,0.005431465);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1913,0.006661701);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1914,0.007829775);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1915,0.009555352);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1916,0.0108455);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1917,0.01323139);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1967,0.0008673294);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1968,0.00117951);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1969,0.001575375);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1970,0.001717654);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1971,0.0026026);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1972,0.003183599);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1973,0.003794738);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1974,0.004313487);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1975,0.005616315);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1976,0.006103865);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1977,0.007629161);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1978,0.009178149);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1979,0.01107996);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2024,9.679302e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2026,0.00022908);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2028,0.0004747871);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2029,0.0005208718);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2030,0.00093429);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2031,0.001247297);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2032,0.001772789);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2033,0.002017561);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2034,0.002456873);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2035,0.002902665);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2036,0.00392418);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2037,0.004288532);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2038,0.005205645);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2039,0.006414981);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2040,0.007936034);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2041,0.009599441);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2091,0.0004714654);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2092,0.0006222241);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2093,0.0007958857);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2094,0.001136936);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2095,0.001516886);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2096,0.001774612);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2097,0.002370029);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2098,0.002858535);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2099,0.003333724);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2100,0.004154866);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2101,0.005129074);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2102,0.006476001);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2103,0.007656483);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2150,6.046335e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2152,0.0001942866);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2153,0.0003510328);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2154,0.000365251);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2155,0.000566849);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2156,0.0009396975);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2157,0.001171446);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2158,0.001405502);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2159,0.001969467);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2160,0.002316638);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2161,0.002690965);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2162,0.003352269);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2163,0.004067951);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2164,0.004792816);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2165,0.006504196);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2215,0.0001354829);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2216,0.0002615624);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2217,0.0005488239);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2218,0.0005134475);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2219,0.0008869309);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2220,0.00111623);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2221,0.001454197);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2222,0.001959495);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2223,0.002186228);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2224,0.00283803);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2225,0.003313922);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2226,0.004076389);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2227,0.005219256);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2276,2.656114e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2277,0.0001120028);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2278,0.0002010059);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2279,0.0002403303);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2280,0.0003026989);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2281,0.0005543747);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2282,0.0007509774);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2283,0.001087911);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2284,0.001431922);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2285,0.001767278);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2286,0.002376726);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2287,0.002839204);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2288,0.00316953);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2289,0.003911589);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2339,6.269839e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2340,0.0001492625);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2341,0.0001592302);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2342,0.0002563311);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2343,0.0004514464);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2344,0.0005374267);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2345,0.0007330796);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2346,0.001067311);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2347,0.001486125);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2348,0.001634116);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2349,0.002110033);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2350,0.002860521);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2351,0.003429748);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2402,5.08421e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2403,0.0001077938);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2404,0.0002472207);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2405,0.0002716056);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2406,0.00027796);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2407,0.0005194807);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2408,0.0008461702);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2409,0.001029535);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2410,0.00130982);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2411,0.001607639);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2412,0.002129304);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2413,0.002634739);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2465,3.923275e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2466,8.075122e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2467,8.658268e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2468,0.0003069275);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2469,0.0002652947);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2470,0.0006400889);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2471,0.0007279619);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2472,0.001172836);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2473,0.001289893);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2474,0.001511593);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2475,0.002009545);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2528,5.891771e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2529,7.427085e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2530,0.000147253);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2531,0.0001707688);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2532,0.0003805933);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2533,0.0005709428);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2534,0.0006423424);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2535,0.001159942);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2536,0.001165386);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2537,0.001697727);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2591,6.019819e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2592,8.355359e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2593,0.0001427762);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2594,0.0002223593);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2595,0.0002547743);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2596,0.00056738);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2597,0.0007597711);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2598,0.0008267908);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2599,0.001169246);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2655,7.615026e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2657,0.0001870232);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2659,0.0004184755);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2661,0.0008255922);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2781,8.674125e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2783,0.0002146342);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2785,0.0004499165);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2907,6.117466e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2909,0.0002533619);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3033,7.238312e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(79,3.103701e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(81,5.21207e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(83,8.967258e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(85,0.0001221263);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(87,0.0001544161);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(89,0.0001945902);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(91,0.0002409309);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(93,0.0002736165);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(95,0.0003199668);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(97,0.0003643376);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(99,0.0004053767);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(101,0.0006189599);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(103,0.0004593197);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(105,0.0004853501);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(107,0.0004978289);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(109,0.0005009305);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(111,0.0004996819);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(113,0.0004896587);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(115,0.0004790674);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(117,0.0004598049);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(119,0.0004455733);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(141,2.899393e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(143,4.419212e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(145,8.376254e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(147,0.0001211602);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(149,0.0001529024);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(151,0.0001855802);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(153,0.0002317339);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(155,0.0002837283);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(156,0.0002890978);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(158,0.000340393);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(160,0.0003783894);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(162,0.0004182407);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(164,0.0004598271);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(166,0.0004732846);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(168,0.0004999853);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(169,0.0004924951);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(171,0.0005031841);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(173,0.0005051976);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(175,0.0004928681);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(177,0.0004751676);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(179,0.0004581659);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(181,0.0004488703);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(265,3.337788e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(267,3.691911e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(269,7.347409e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(271,9.748323e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(273,0.0001490625);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(275,0.0001801361);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(277,0.0002323209);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(279,0.000264499);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(280,0.0002810557);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(282,0.000323691);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(284,0.0003644445);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(286,0.0004071392);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(288,0.000438179);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(290,0.0004677362);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(292,0.0004912684);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(293,0.0005043175);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(295,0.0004981333);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(297,0.0005058297);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(299,0.0005015765);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(301,0.0004873171);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(303,0.0004776941);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(305,0.0004529206);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(389,3.00318e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(391,4.534948e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(393,6.167652e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(395,8.65889e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(397,0.0001245475);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(399,0.0001565554);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(401,0.0001998668);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(403,0.0002370959);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(404,0.0002684739);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(406,0.0003281586);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(408,0.0003458819);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(410,0.0003857169);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(412,0.0004239993);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(414,0.0004631464);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(416,0.0004882235);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(417,0.0004967222);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(419,0.0005073478);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(421,0.0005075114);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(423,0.000502902);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(425,0.0004968477);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(427,0.0004808305);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(429,0.0004632168);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(513,1.934237e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(515,3.462319e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(517,5.779004e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(519,6.997011e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(521,0.000102684);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(523,0.0001295333);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(525,0.00017567);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(527,0.0002112399);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(528,0.000229613);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(530,0.0002719662);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(532,0.0003143144);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(534,0.0003667381);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(536,0.0004027458);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(538,0.000441244);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(540,0.0004694942);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(541,0.0004860847);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(543,0.0004972915);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(545,0.0005093379);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(547,0.0005136795);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(549,0.0005096838);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(551,0.0004955587);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(553,0.0004757585);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(639,2.791993e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(641,3.837349e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(643,6.280041e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(645,7.390739e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(647,0.0001108649);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(649,0.0001357743);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(651,0.0001851773);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(652,0.0002061589);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(654,0.0002354655);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(656,0.0002748941);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(658,0.0003249505);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(660,0.0003686846);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(662,0.0004127123);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(664,0.0004533285);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(665,0.0004689159);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(667,0.0004840326);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(669,0.0004997504);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(671,0.0005188188);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(673,0.0005085075);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(675,0.0004997787);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(677,0.0004862072);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(765,2.445316e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(767,4.349927e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(769,5.974032e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(771,8.409961e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(773,0.0001138551);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(775,0.0001449362);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(776,0.0001627679);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(778,0.0002052579);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(780,0.0002432228);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(782,0.0002860398);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(784,0.0003227692);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(786,0.0003689624);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(788,0.0004183047);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(789,0.0004322419);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(791,0.0004640644);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(793,0.0004970164);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(795,0.0005090056);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(797,0.0005078468);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(799,0.0005070342);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(801,0.0005022497);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(891,3.985778e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(893,4.186329e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(895,6.720633e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(897,9.178062e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(899,0.0001235212);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(900,0.0001414389);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(902,0.0001744397);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(904,0.0002028808);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(906,0.000254107);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(908,0.0002939421);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(910,0.0003379604);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(912,0.0003795545);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(913,0.0003973742);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(915,0.0004335977);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(917,0.0004757031);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(919,0.0004954963);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(921,0.0005090004);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(923,0.0005128735);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(925,0.0005013228);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1017,3.389421e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1019,5.069325e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1021,6.770108e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1023,9.732788e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1024,0.0001055736);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1026,0.0001415741);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1028,0.000171857);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1030,0.0002102175);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1032,0.000250797);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1034,0.0002926613);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1036,0.000342403);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1037,0.0003556314);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1039,0.0004021753);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1041,0.0004359863);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1043,0.0004684309);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1045,0.0004929683);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1047,0.0005102042);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1049,0.0005126588);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1143,3.631306e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1145,5.520573e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1147,7.213883e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1148,8.543909e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1150,0.0001115066);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1152,0.0001328586);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1154,0.0001724279);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1156,0.0002074723);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1158,0.0002550387);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1160,0.0002889032);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1161,0.0003162373);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1163,0.0003546564);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1165,0.000394064);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1167,0.0004337891);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1169,0.000476245);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1171,0.0004983966);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1173,0.0005106056);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1269,3.359036e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1271,4.925199e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1272,5.874123e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1274,7.991523e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1276,0.0001095234);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1278,0.0001320047);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1280,0.0001695447);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1282,0.0002076993);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1284,0.0002469414);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1285,0.0002650627);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1287,0.0003085774);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1289,0.000353766);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1291,0.00039862);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1293,0.0004464872);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1295,0.0004756475);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1297,0.0004950013);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1395,3.608754e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1396,4.42054e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1398,5.583751e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1400,8.54549e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1402,0.0001067159);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1404,0.0001380002);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1406,0.0001727077);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1408,0.000211043);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1409,0.0002305057);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1410,0.0002468238);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1411,0.0003297967);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1412,0.0002986413);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1413,0.000320195);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1414,0.0003506664);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1415,0.0003547568);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1416,0.000387571);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1417,0.0004043653);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1418,0.0004153469);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1419,0.0004401306);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1420,0.0004833262);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1421,0.0004967189);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1471,0.000208791);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1472,0.0002271225);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1473,0.0002655804);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1474,0.0002665253);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1475,0.0002945258);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1476,0.0003539538);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1477,0.0003251553);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1478,0.0004198744);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1479,0.0003753473);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1480,0.0004033917);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1481,0.0005171698);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1482,0.000436692);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1483,0.0004547214);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1520,2.29558e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1522,3.860117e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1524,6.60103e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1526,8.557724e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1528,0.0001104622);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1530,0.0001362143);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1532,0.0001598141);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1533,0.0001845411);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1534,0.0002039667);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1535,0.0002223886);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1536,0.000258821);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1537,0.0003588372);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1538,0.0003108598);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1539,0.0003101073);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1540,0.0004041949);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1541,0.0003724826);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1542,0.0003842858);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1543,0.0004584192);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1544,0.0004168306);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1545,0.000436146);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1595,0.0001706828);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1596,0.0001871613);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1597,0.0002550304);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1598,0.0002253675);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1599,0.0002471415);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1600,0.0002721433);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1601,0.0002921704);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1602,0.0003033242);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1603,0.0003338762);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1604,0.0003517417);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1605,0.0005598077);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1606,0.0004016464);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1607,0.0004198715);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1646,2.556648e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1648,3.004281e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1650,5.715815e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1652,7.681822e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1654,0.0001032341);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1656,0.0001333992);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1657,0.000146447);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1658,0.0001761948);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1659,0.0002318522);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1660,0.0002121757);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1661,0.0002389823);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1662,0.0004002633);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1663,0.0002579855);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1664,0.0002953282);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1665,0.0003438553);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1666,0.0003278666);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1667,0.0004704857);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1668,0.0003735739);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1669,0.0003920515);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1719,0.0001369686);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1720,0.0001654627);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1721,0.000167953);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1722,0.0001899064);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1723,0.0002003634);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1724,0.0002294447);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1725,0.0002443871);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1726,0.0002558878);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1727,0.0002856552);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1728,0.0003095855);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1729,0.0003240464);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1730,0.0003527152);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1731,0.0004355359);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1772,2.426422e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1774,3.872391e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1776,4.857937e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1778,8.044341e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1780,0.0001015981);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1781,0.0001147539);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1782,0.000137524);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1783,0.0001466845);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1784,0.0001713933);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1785,0.0001835863);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1786,0.0002122928);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1787,0.0002160508);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1788,0.0002433582);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1789,0.0002686411);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1790,0.000277096);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1791,0.0003033131);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1792,0.0003271081);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1793,0.0003525141);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1843,0.0001069392);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1844,0.0001483089);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1845,0.0001252495);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1846,0.0001430745);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1847,0.0001637828);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1848,0.000173335);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1849,0.0002017154);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1850,0.0003129215);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1851,0.0002799044);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1852,0.0002585437);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1853,0.0002864528);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1854,0.0003085598);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1855,0.0003937485);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1898,1.962052e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1900,3.624568e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1902,5.991335e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1904,7.305898e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1905,9.376824e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1906,0.0001028048);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1907,0.0001225487);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1908,0.0001394679);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1909,0.0001418793);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1910,0.0001561931);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1911,0.0001762201);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1912,0.0002436032);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1913,0.0002221878);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1914,0.0002394534);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1915,0.0002555886);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1916,0.0002742186);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1917,0.0003127314);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1967,8.025651e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1968,8.927197e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1969,0.0001084602);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1970,0.0001069988);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1971,0.0001319355);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1972,0.0001450216);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1973,0.0001879555);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1974,0.0001908148);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1975,0.0001942937);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1976,0.0002240886);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1977,0.0002277806);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1978,0.0002491294);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1979,0.0002941507);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2024,2.588369e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2026,3.929234e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2028,5.63879e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2029,5.904382e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2030,7.848953e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2031,0.0001078773);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2032,0.0001081404);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2033,0.0001479117);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2034,0.0001313835);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2035,0.0001481533);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2036,0.0001606566);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2037,0.000185638);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2038,0.0001900185);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2039,0.0002258575);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2040,0.0002692424);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2041,0.0002595848);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2091,5.598782e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2092,7.24178e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2093,7.211253e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2094,8.606134e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2095,0.0001008578);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2096,0.0001118627);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2097,0.0001250297);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2098,0.0001385459);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2099,0.0001524289);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2100,0.000165447);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2101,0.0002051082);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2102,0.0002112816);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2103,0.0002323076);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2150,2.015519e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2152,3.610011e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2153,4.868982e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2154,7.308795e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2155,6.592426e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2156,7.839003e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2157,0.000100585);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2158,0.0001284969);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2159,0.0001137876);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2160,0.0001228899);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2161,0.0001337744);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2162,0.0001483329);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2163,0.000162325);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2164,0.0002347561);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2165,0.0002124393);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2215,3.913657e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2216,5.035953e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2217,6.219817e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2218,6.371977e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2219,7.586515e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2220,9.482241e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2221,9.649693e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2222,0.000112333);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2223,0.0001214721);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2224,0.0001514279);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2225,0.0001457588);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2226,0.0001777518);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2227,0.0001868163);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2276,1.328078e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2277,2.716651e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2278,3.671209e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2279,4.122231e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2280,5.120538e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2281,6.018218e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2282,6.946846e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2283,8.833293e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2284,9.905043e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2285,0.0001165322);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2286,0.0001339788);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2287,0.0001456795);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2288,0.000150767);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2289,0.0001582129);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2339,2.096699e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2340,3.521641e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2341,3.653343e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2342,4.680671e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2343,5.738397e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2344,5.903626e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2345,7.094582e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2346,8.245138e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2347,9.795003e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2348,0.0001042363);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2349,0.0001357923);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2350,0.0002352864);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2351,0.0001475132);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2402,2.075684e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2403,2.783406e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2404,5.82792e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2405,4.467658e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2406,4.244055e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2407,5.778332e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2408,7.697365e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2409,8.388755e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2410,9.789367e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2411,0.0001214481);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2412,0.0001201833);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2413,0.0001412216);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2465,1.601709e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2466,2.331201e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2467,2.610703e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2468,4.481942e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2469,4.146912e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2470,9.057106e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2471,9.650026e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2472,8.682648e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2473,8.956205e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2474,9.858183e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2475,0.000116131);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2528,2.089812e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2529,2.239451e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2530,3.07071e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2531,3.642398e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2532,5.334471e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2533,5.988172e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2534,6.665645e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2535,8.608443e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2536,8.466143e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2537,0.0001141999);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2591,2.275361e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2592,2.318737e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2593,3.117946e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2594,3.760876e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2595,4.371876e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2596,6.644977e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2597,7.058918e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2598,9.691298e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2599,8.802796e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2655,2.19837e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2657,3.415799e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2659,5.077695e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2661,7.087405e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2781,2.318379e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2783,3.629232e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2785,5.235204e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2907,1.934584e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2909,3.910765e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3033,2.089613e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetEntries(631557.2);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->Draw("colz");
   c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf->Modified();
   c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf->cd();
   c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf->SetSelected(c_AccEffMap_T1tttt_8NJetinf_1250HT1500_200MHTinf);
}
/*
   400     0   0.000131448
   400    25   0.000115729
   400    75   0.000156489
   400   125   0.000127404
   400   175   5.10694e-05
   450     0   0.000356065
   450    25   0.000260751
   450    75   0.000184221
   450   125    0.00027535
   450   175    0.00016603
   450   225   0.000108126
   500     0    0.00101002
   500    25    0.00090656
   500    75   0.000702481
   500   125   0.000515601
   500   175   0.000458567
   500   225   0.000199266
   500   275   8.10469e-05
   550     0    0.00188269
   550    25    0.00185224
   550    75    0.00120868
   550   125   0.000984605
   550   175   0.000655232
   550   225   0.000528397
   550   275    0.00025725
   550   325   0.000214507
   600     0    0.00299671
   600    25    0.00295246
   600    75    0.00278065
   600   125    0.00198403
   600   175     0.0013729
   600   225   0.000730415
   600   275   0.000481289
   600   325   0.000236674
   600   375   0.000155254
   650     0    0.00470205
   650    25    0.00432374
   650    75    0.00405881
   650   125    0.00311801
   650   175    0.00215353
   650   225    0.00161999
   650   275   0.000945876
   650   325   0.000607571
   650   375   0.000347144
   650   425   0.000177774
   700     0     0.0071046
   700    25    0.00661158
   700    75    0.00667956
   700   125    0.00502106
   700   175    0.00390397
   700   225    0.00237177
   700   275    0.00173755
   700   325     0.0011409
   700   375   0.000627222
   700   425   0.000412608
   700   475   0.000153704
   750     0    0.00925583
   750    25     0.0098122
   750    75    0.00856995
   750   125    0.00704794
   750   175    0.00561848
   750   225    0.00440971
   750   275    0.00274481
   750   325    0.00203353
   750   375    0.00128909
   750   425   0.000709617
   750   475   0.000333921
   750   525   0.000180418
   775    25     0.0102339
   775    75    0.00971957
   775   125    0.00896288
   775   175    0.00667648
   775   225    0.00543468
   775   275    0.00346127
   775   325    0.00265328
   775   375    0.00151119
   775   425    0.00100968
   775   475   0.000480678
   775   525   0.000272402
   775   575   7.25397e-05
   800     0     0.0125211
   825    25     0.0141945
   825    75     0.0129122
   825   125     0.0115493
   825   175    0.00926742
   825   225    0.00710268
   825   275    0.00546527
   825   325    0.00402262
   825   375     0.0027085
   825   425    0.00171635
   825   475    0.00089619
   825   525   0.000435724
   825   575   0.000207745
   825   625   9.21761e-05
   850     0     0.0161321
   875    25     0.0173087
   875    75     0.0162129
   875   125     0.0148409
   875   175     0.0123188
   875   225    0.00957244
   875   275    0.00758725
   875   325    0.00543333
   875   375    0.00394969
   875   425     0.0024297
   875   475     0.0016716
   875   525    0.00102775
   875   575   0.000611454
   875   625     0.0001274
   875   675   8.40495e-05
   900     0     0.0199597
   925    25     0.0212402
   925    75      0.020164
   925   125     0.0183805
   925   175     0.0167414
   925   225      0.013354
   925   275     0.0105002
   925   325    0.00839756
   925   375    0.00586639
   925   425    0.00404336
   925   475    0.00242859
   925   525     0.0016223
   925   575    0.00104678
   925   625   0.000467574
   925   675   0.000215526
   925   725   5.54933e-05
   950     0     0.0232655
   975    25      0.025708
   975    75     0.0234605
   975   125     0.0222106
   975   175     0.0201859
   975   225     0.0171201
   975   275     0.0133555
   975   325       0.01121
   975   375    0.00831187
   975   425    0.00583319
   975   475    0.00395073
   975   525    0.00266488
   975   575    0.00173857
   975   625   0.000861624
   975   675   0.000343335
   975   725   0.000191721
   975   775    9.6793e-05
  1000     0     0.0256388
  1025    25     0.0275021
  1025    75     0.0268462
  1025   125     0.0263252
  1025   175     0.0242148
  1025   225     0.0213569
  1025   275      0.017431
  1025   325     0.0148151
  1025   375      0.011249
  1025   425     0.0086643
  1025   475    0.00589787
  1025   525    0.00416431
  1025   575    0.00265591
  1025   625    0.00154894
  1025   675   0.000950596
  1025   725   0.000532249
  1025   775    0.00022908
  1025   825   6.04634e-05
  1050     0     0.0288615
  1075    25     0.0308541
  1075    75     0.0297736
  1075   125     0.0294479
  1075   175     0.0274767
  1075   225     0.0259194
  1075   275     0.0222218
  1075   325     0.0186209
  1075   375      0.015352
  1075   425     0.0111029
  1075   475    0.00828926
  1075   525    0.00620405
  1075   575    0.00362852
  1075   625    0.00258005
  1075   675     0.0015202
  1075   725   0.000799833
  1075   775   0.000474787
  1075   825   0.000194287
  1075   875   2.65611e-05
  1100     0     0.0305142
  1100    25     0.0300263
  1100    75     0.0313472
  1100   125     0.0303639
  1100   175     0.0294479
  1100   225        0.0277
  1100   275     0.0237529
  1100   325     0.0202865
  1100   375     0.0165911
  1100   425     0.0132863
  1100   475    0.00956034
  1100   525    0.00729536
  1100   550    0.00604279
  1100   575    0.00482001
  1100   600    0.00419625
  1100   625    0.00310593
  1100   650    0.00270906
  1100   675    0.00193848
  1100   700    0.00169406
  1100   725    0.00111588
  1100   750   0.000867329
  1100   775   0.000520872
  1100   800   0.000471465
  1100   825   0.000351033
  1100   850   0.000135483
  1100   875   0.000112003
  1100   900   6.26984e-05
  1125   525     0.0081512
  1125   550     0.0069601
  1125   575    0.00567786
  1125   600    0.00497042
  1125   625    0.00392728
  1125   650    0.00320672
  1125   675    0.00243581
  1125   700     0.0022667
  1125   725    0.00155275
  1125   750    0.00117951
  1125   775    0.00093429
  1125   800   0.000622224
  1125   825   0.000365251
  1125   850   0.000261562
  1125   875   0.000201006
  1125   900   0.000149262
  1125   925   5.08421e-05
  1150     0     0.0313369
  1150    25     0.0314555
  1150    75     0.0311021
  1150   125     0.0323755
  1150   175     0.0310288
  1150   225     0.0296656
  1150   275     0.0275812
  1150   325     0.0242925
  1150   375     0.0212052
  1150   425     0.0167379
  1150   475     0.0130013
  1150   525    0.00969479
  1150   550    0.00847463
  1150   575    0.00695936
  1150   600     0.0056747
  1150   625    0.00459737
  1150   650    0.00379894
  1150   675    0.00303434
  1150   700    0.00233558
  1150   725    0.00182149
  1150   750    0.00157538
  1150   775     0.0012473
  1150   800   0.000795886
  1150   825   0.000566849
  1150   850   0.000548824
  1150   875    0.00024033
  1150   900    0.00015923
  1150   925   0.000107794
  1150   950   3.92328e-05
  1175   525     0.0116287
  1175   550    0.00957704
  1175   575    0.00842544
  1175   600     0.0071285
  1175   625    0.00566972
  1175   650    0.00459969
  1175   675    0.00351956
  1175   700    0.00303521
  1175   725    0.00250143
  1175   750    0.00171765
  1175   775    0.00177279
  1175   800    0.00113694
  1175   825   0.000939698
  1175   850   0.000513448
  1175   875   0.000302699
  1175   900   0.000256331
  1175   925   0.000247221
  1175   950   8.07512e-05
  1175   975   5.89177e-05
  1200     0     0.0314706
  1200    25      0.032069
  1200    75     0.0323105
  1200   125     0.0325381
  1200   175     0.0329031
  1200   225      0.031899
  1200   275     0.0316055
  1200   325     0.0292201
  1200   375      0.024672
  1200   425     0.0205407
  1200   475     0.0168688
  1200   525     0.0133995
  1200   550     0.0115056
  1200   575     0.0100194
  1200   600    0.00850609
  1200   625    0.00693703
  1200   650    0.00572147
  1200   675     0.0046381
  1200   700    0.00383708
  1200   725    0.00292695
  1200   750     0.0026026
  1200   775    0.00201756
  1200   800    0.00151689
  1200   825    0.00117145
  1200   850   0.000886931
  1200   875   0.000554375
  1200   900   0.000451446
  1200   925   0.000271606
  1200   950   8.65827e-05
  1200   975   7.42708e-05
  1200  1000   6.01982e-05
  1225   525     0.0151004
  1225   550      0.013102
  1225   575     0.0115008
  1225   600    0.00971367
  1225   625    0.00788598
  1225   650    0.00708965
  1225   675    0.00540363
  1225   700    0.00442158
  1225   725    0.00364066
  1225   750     0.0031836
  1225   775    0.00245687
  1225   800    0.00177461
  1225   825     0.0014055
  1225   850    0.00111623
  1225   875   0.000750977
  1225   900   0.000537427
  1225   925    0.00027796
  1225   950   0.000306927
  1225   975   0.000147253
  1225  1000   8.35536e-05
  1250     0      0.030657
  1250    25     0.0310664
  1250    75     0.0321003
  1250   125     0.0324117
  1250   175     0.0337431
  1250   225     0.0344031
  1250   275      0.033245
  1250   325      0.031852
  1250   375      0.028587
  1250   425     0.0249257
  1250   475     0.0213513
  1250   525     0.0170846
  1250   550     0.0146236
  1250   575     0.0131793
  1250   600      0.010936
  1250   625    0.00943824
  1250   650    0.00859048
  1250   675    0.00674065
  1250   700    0.00594041
  1250   725    0.00462386
  1250   750    0.00379474
  1250   775    0.00290267
  1250   800    0.00237003
  1250   825    0.00196947
  1250   850     0.0014542
  1250   875    0.00108791
  1250   900    0.00073308
  1250   925   0.000519481
  1250   950   0.000265295
  1250   975   0.000170769
  1250  1000   0.000142776
  1250  1025   7.61503e-05
  1275   525     0.0197707
  1275   550     0.0166771
  1275   575     0.0146614
  1275   600     0.0126912
  1275   625     0.0116241
  1275   650    0.00936822
  1275   675    0.00810239
  1275   700     0.0066455
  1275   725    0.00543147
  1275   750    0.00431349
  1275   775    0.00392418
  1275   800    0.00285854
  1275   825    0.00231664
  1275   850     0.0019595
  1275   875    0.00143192
  1275   900    0.00106731
  1275   925    0.00084617
  1275   950   0.000640089
  1275   975   0.000380593
  1275  1000   0.000222359
  1300     0     0.0296145
  1300    25      0.029203
  1300    75     0.0307111
  1300   125     0.0319541
  1300   175     0.0336845
  1300   225     0.0335094
  1300   275     0.0335138
  1300   325     0.0337361
  1300   375     0.0319363
  1300   425     0.0300243
  1300   475     0.0267632
  1300   525     0.0220147
  1300   550     0.0189805
  1300   575     0.0180129
  1300   600     0.0149609
  1300   625     0.0134415
  1300   650     0.0113847
  1300   675    0.00958623
  1300   700    0.00792173
  1300   725     0.0066617
  1300   750    0.00561631
  1300   775    0.00428853
  1300   800    0.00333372
  1300   825    0.00269097
  1300   850    0.00218623
  1300   875    0.00176728
  1300   900    0.00148613
  1300   925    0.00102954
  1300   950   0.000727962
  1300   975   0.000570943
  1300  1000   0.000254774
  1300  1025   0.000187023
  1300  1075   8.67413e-05
  1325   525     0.0234543
  1325   550     0.0222799
  1325   575     0.0197768
  1325   600     0.0172639
  1325   625     0.0150853
  1325   650      0.013481
  1325   675     0.0109391
  1325   700     0.0096484
  1325   725    0.00782977
  1325   750    0.00610387
  1325   775    0.00520565
  1325   800    0.00415487
  1325   825    0.00335227
  1325   850    0.00283803
  1325   875    0.00237673
  1325   900    0.00163412
  1325   925    0.00130982
  1325   950    0.00117284
  1325   975   0.000642342
  1325  1000    0.00056738
  1350     0     0.0277749
  1350    25     0.0275669
  1350    75     0.0298946
  1350   125     0.0303595
  1350   175     0.0321721
  1350   225     0.0327959
  1350   275      0.033823
  1350   325     0.0345471
  1350   375     0.0343517
  1350   425     0.0331182
  1350   475     0.0303514
  1350   525     0.0262995
  1350   550     0.0241974
  1350   575     0.0214939
  1350   600     0.0199377
  1350   625     0.0161726
  1350   650     0.0147546
  1350   675     0.0132375
  1350   700     0.0113169
  1350   725    0.00955535
  1350   750    0.00762916
  1350   775    0.00641498
  1350   800    0.00512907
  1350   825    0.00406795
  1350   850    0.00331392
  1350   875     0.0028392
  1350   900    0.00211003
  1350   925    0.00160764
  1350   950    0.00128989
  1350   975    0.00115994
  1350  1000   0.000759771
  1350  1025   0.000418476
  1350  1075   0.000214634
  1350  1125   6.11747e-05
  1375   525      0.028341
  1375   550     0.0260074
  1375   575     0.0238764
  1375   600        0.0222
  1375   625     0.0194754
  1375   650     0.0176338
  1375   675     0.0149479
  1375   700     0.0131849
  1375   725     0.0108455
  1375   750    0.00917815
  1375   775    0.00793603
  1375   800      0.006476
  1375   825    0.00479282
  1375   850    0.00407639
  1375   875    0.00316953
  1375   900    0.00286052
  1375   925     0.0021293
  1375   950    0.00151159
  1375   975    0.00116539
  1375  1000   0.000826791
  1400     0     0.0264951
  1400    25     0.0269122
  1400    75     0.0273753
  1400   125     0.0285104
  1400   175     0.0300863
  1400   225     0.0314639
  1400   275     0.0336534
  1400   325     0.0335486
  1400   375     0.0349901
  1400   425     0.0349186
  1400   475     0.0331116
  1400   525     0.0301282
  1400   550     0.0281428
  1400   575     0.0261625
  1400   600     0.0242339
  1400   625      0.021554
  1400   650     0.0198624
  1400   675      0.017022
  1400   700     0.0152783
  1400   725     0.0132314
  1400   750       0.01108
  1400   775    0.00959944
  1400   800    0.00765648
  1400   825     0.0065042
  1400   850    0.00521926
  1400   875    0.00391159
  1400   900    0.00342975
  1400   925    0.00263474
  1400   950    0.00200954
  1400   975    0.00169773
  1400  1000    0.00116925
  1400  1025   0.000825592
  1400  1075   0.000449916
  1400  1125   0.000253362
  1400  1175   7.23831e-05
*/
