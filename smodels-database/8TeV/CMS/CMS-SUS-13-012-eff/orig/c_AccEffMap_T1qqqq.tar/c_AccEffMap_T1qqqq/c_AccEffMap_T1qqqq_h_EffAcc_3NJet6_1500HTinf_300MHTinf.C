{
//=========Macro generated from canvas: c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf/c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf
//=========  (Sat Feb 22 16:30:35 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf = new TCanvas("c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf", "c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf",90,432,500,500);
   c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf->SetFillColor(0);
   c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf->SetBorderMode(0);
   c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf->SetBorderSize(2);
   c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf->SetLogz();
   c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_3NJet6_1500HTinf_300MHTinf = new TH2D("h_EffAcc_3NJet6_1500HTinf_300MHTinf","h_EffAcc_3NJet6_1500HTinf_300MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(141,0.0001961352);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(143,0.0004075604);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(145,0.0009635495);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(147,0.001787933);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(149,0.002620419);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(151,0.004746404);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(153,0.007656249);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(155,0.0109638);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(157,0.01561392);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(159,0.0230726);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(161,0.03373516);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(163,0.04515042);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(165,0.06411889);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(167,0.08583066);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(169,0.1084367);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(171,0.1354822);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(173,0.1658052);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(175,0.1975556);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(177,0.2247438);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(179,0.2548616);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(181,0.2836562);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(265,0.0002877839);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(267,0.0004842825);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(269,0.0008746557);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(271,0.001507297);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(273,0.00262215);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(275,0.004351495);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(277,0.006121841);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(279,0.009315127);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(281,0.01447671);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(283,0.02121872);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(285,0.03022923);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(287,0.04252582);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(289,0.058313);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(291,0.07855728);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(293,0.1041602);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(295,0.1296349);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(297,0.1600707);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(299,0.1910463);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(301,0.2208005);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(303,0.2528853);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(305,0.2798258);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(389,0.0001260023);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(391,0.00037287);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(393,0.0006506664);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(395,0.00113718);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(397,0.00188653);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(399,0.003295305);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(401,0.005089945);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(403,0.008066043);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(405,0.01241281);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(407,0.01757421);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(409,0.02615777);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(411,0.0365825);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(413,0.05031158);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(415,0.06802601);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(417,0.09204913);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(419,0.1184315);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(421,0.1482084);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(423,0.1786349);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(425,0.2104324);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(427,0.24145);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(429,0.2736312);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(513,8.706521e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(515,0.0002816922);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(517,0.0005505261);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(519,0.0009119316);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(521,0.001291145);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(523,0.00244499);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(525,0.004150222);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(527,0.006243586);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(529,0.009885576);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(531,0.01459542);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(533,0.02123448);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(535,0.03073471);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(537,0.0417997);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(539,0.05975069);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(541,0.07903238);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(543,0.1044192);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(545,0.1330632);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(547,0.1639425);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(549,0.1962141);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(551,0.2281783);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(553,0.2607086);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(637,0.0001354954);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(639,0.0002094145);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(641,0.0003212563);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(643,0.0004532666);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(645,0.001086137);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(647,0.001727721);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(649,0.003072277);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(651,0.004484957);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(653,0.007339542);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(655,0.01116253);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(657,0.0161502);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(659,0.02368354);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(661,0.03447445);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(663,0.04709823);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(665,0.06579596);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(667,0.08867117);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(669,0.1139298);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(671,0.1445993);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(673,0.1773226);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(675,0.2127594);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(677,0.2451193);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(761,5.671617e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(763,0.000165585);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(765,0.0002364978);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(767,0.0004960593);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(769,0.0006711197);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(771,0.001120969);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(773,0.002128253);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(775,0.003230605);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(777,0.004824747);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(779,0.008124801);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(781,0.01243517);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(783,0.01764805);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(785,0.0258854);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(787,0.03681499);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(789,0.05261494);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(791,0.07103106);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(793,0.0964607);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(795,0.1241718);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(797,0.1550952);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(799,0.1909682);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(801,0.225303);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(885,7.047893e-06);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(887,9.663537e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(889,8.010734e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(891,0.0003225501);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(893,0.0005525992);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(895,0.0008243827);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(897,0.001476753);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(899,0.002070616);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(901,0.003362363);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(903,0.005278241);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(905,0.008706169);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(907,0.01289569);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(909,0.01931137);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(911,0.02817534);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(913,0.04131444);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(915,0.05638458);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(917,0.07671789);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(919,0.1016079);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(921,0.1337114);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(923,0.168443);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(925,0.2038493);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1009,4.949362e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1011,9.348878e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1013,0.0001163411);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1015,0.0001608062);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1017,0.0002927259);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1019,0.0004870053);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1021,0.001079223);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1023,0.001391588);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1025,0.002210057);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1027,0.003796979);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1029,0.005507678);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1031,0.008638723);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1033,0.01419414);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1035,0.02054738);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1037,0.03005502);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1039,0.0427651);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1041,0.06097628);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1043,0.0815295);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1045,0.1098282);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1047,0.1429744);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1049,0.1774292);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1135,3.669804e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1137,4.37182e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1139,0.0001756028);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1141,0.0001545248);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1143,0.0003742978);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1145,0.0006926183);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1147,0.0009793461);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1149,0.001459114);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1151,0.002407442);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1153,0.003823212);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1155,0.006240437);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1157,0.009660735);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1159,0.01426736);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1161,0.02150527);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1163,0.03165892);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1165,0.04398146);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1167,0.06366818);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1169,0.08782619);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1171,0.1166332);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1173,0.1506809);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1261,1.457488e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1263,8.07221e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1265,9.564775e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1267,0.0002848847);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1269,0.0003880241);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1271,0.0005618493);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1273,0.001014419);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1275,0.001506482);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1277,0.00212549);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1279,0.003780472);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1281,0.006015559);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1283,0.009556459);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1285,0.01483248);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1287,0.02229481);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1289,0.03255);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1291,0.04678544);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1293,0.06659918);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1295,0.09131506);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1297,0.1210328);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1387,8.872057e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1389,9.545501e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1391,0.0001608049);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1393,0.0002251321);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1395,0.0004053418);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1397,0.0005268933);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1399,0.001083627);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1401,0.00162442);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1403,0.002416086);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1405,0.004246929);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1407,0.006423744);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1409,0.009556384);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1411,0.01511099);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1413,0.02253909);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1415,0.03285874);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1417,0.04852366);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1419,0.06858253);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1421,0.09345727);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1513,1.468264e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1515,0.0001095883);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1517,0.0001089902);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1519,0.0002618684);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1521,0.0004211435);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1523,0.0007066535);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1525,0.001026504);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1527,0.001617802);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1529,0.002723766);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1531,0.004120155);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1533,0.006465223);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1535,0.009926705);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1537,0.01487757);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1539,0.02266086);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1541,0.03432932);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1543,0.04948557);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1545,0.06956636);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1639,8.043688e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1641,0.0001159895);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1643,0.0001667173);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1645,0.0002777486);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1647,0.0005069916);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1649,0.0007436187);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1651,0.000939687);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1653,0.001578922);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1655,0.002520616);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1657,0.004082754);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1659,0.00619151);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1661,0.009892322);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1663,0.01541373);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1665,0.02320266);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1667,0.03538462);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1669,0.05097441);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1765,0.0001015221);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1767,0.0001801501);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1769,0.0002490662);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1771,0.0003607194);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1773,0.0004893931);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1775,0.0007714092);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1777,0.001048002);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1783,0.003744356);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1785,0.006173766);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1787,0.009197645);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1789,0.01468035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1791,0.022741);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1793,0.03481733);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1845,0.003129897);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1846,0.004090641);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1847,0.004818801);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1848,0.005954938);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1849,0.007470651);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1850,0.01010008);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1851,0.01215503);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1852,0.0150743);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1853,0.01921999);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1854,0.02302757);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1855,0.02867965);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1891,0.0001014442);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1893,8.591231e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1895,0.0001833445);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1897,0.0002913726);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1899,0.0004592165);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1901,0.0008107545);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1907,0.002445329);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1908,0.003057541);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1909,0.003564954);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1910,0.004826969);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1911,0.005877349);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1912,0.007812295);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1913,0.009268025);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1914,0.012434);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1915,0.01461985);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1916,0.01820768);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1917,0.02305077);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1969,0.001883144);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1970,0.002141148);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1971,0.003001564);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1972,0.003715862);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1973,0.00475671);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1974,0.005984854);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1975,0.007169695);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1976,0.009381615);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1977,0.01134905);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1978,0.01445577);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(1979,0.01813277);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2017,0.0001284047);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2019,0.0001339938);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2021,0.000188964);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2023,0.0003786745);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2025,0.0004491345);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2031,0.001479583);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2032,0.001824418);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2033,0.002191992);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2034,0.002985073);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2035,0.003442362);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2036,0.004449205);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2037,0.005906719);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2038,0.007182987);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2039,0.0090348);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2040,0.01113972);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2041,0.01421352);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2093,0.001285936);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2094,0.001493575);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2095,0.001973199);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2096,0.002273557);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2097,0.002882913);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2098,0.003640022);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2099,0.00446713);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2100,0.005782607);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2101,0.007284288);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2102,0.008886596);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2103,0.01149111);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2143,9.873452e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2145,0.0001255648);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2147,0.0002156184);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2149,0.00037401);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2155,0.001040206);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2156,0.001129039);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2157,0.001652364);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2158,0.001702064);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2159,0.0023007);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2160,0.003063457);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2161,0.003451555);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2162,0.004113059);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2163,0.005654076);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2164,0.006905815);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2165,0.009352084);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2217,0.0008079271);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2218,0.0008672199);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2219,0.001196273);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2220,0.001636732);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2221,0.001713543);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2222,0.002474959);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2223,0.002591556);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2224,0.003624794);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2225,0.004432465);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2226,0.005709596);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2227,0.006976456);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2269,0.0001200598);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2271,0.0001447855);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2273,0.0001506346);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2279,0.0007555958);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2280,0.0008311961);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2281,0.0009197257);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2282,0.001291234);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2283,0.001631535);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2284,0.001910332);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2285,0.002139856);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2286,0.002823479);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2287,0.00325437);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2288,0.004189489);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2289,0.005416015);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2341,0.0004472448);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2342,0.0006121382);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2343,0.0007924618);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2344,0.0009789907);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2345,0.001213476);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2346,0.001330453);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2347,0.0015273);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2348,0.002188417);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2349,0.002692316);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2350,0.003135092);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2351,0.004209935);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2395,8.23578e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2397,0.0001160824);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2403,0.0004970317);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2404,0.0005708113);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2405,0.0007048658);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2406,0.0008372448);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2407,0.0009587118);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2408,0.001204575);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2409,0.001317185);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2410,0.001823936);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2411,0.002339024);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2412,0.002359307);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2413,0.003202847);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2465,0.0003694264);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2466,0.000440325);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2467,0.0006422272);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2468,0.0007990716);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2469,0.0007761985);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2470,0.0009741803);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2471,0.001129494);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2472,0.001197827);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2473,0.001726222);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2474,0.0019166);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2475,0.002354093);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2521,0.0001428161);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2527,0.0002799927);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2528,0.0003360824);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2529,0.0003460105);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2530,0.0004580692);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2531,0.0006632049);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2532,0.0008553755);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2533,0.0008811799);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2534,0.00117862);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2535,0.001375752);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2536,0.001449039);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2537,0.00203732);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2589,0.0003114652);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2590,0.0002848122);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2591,0.0003259309);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2592,0.0004484233);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2593,0.0004745126);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2594,0.0007055672);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2595,0.0007711269);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2596,0.001012133);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2597,0.001145576);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2598,0.001201204);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2599,0.00152771);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2651,0.0001686581);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2653,0.0003690871);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2655,0.0003915398);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2657,0.0006530802);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2659,0.0009307256);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2661,0.001322262);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2775,0.0001555071);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2777,0.0002233375);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2779,0.0003084773);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2781,0.0004034739);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2783,0.0006628452);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2785,0.0008811397);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2899,0.0001232928);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2901,0.0002240898);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2903,0.0002212573);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2905,0.0002173228);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2907,0.000435164);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(2909,0.0007402928);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3025,0.0001277087);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3027,0.0001380266);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3029,0.0001433);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3031,0.0003487573);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3033,0.0003978083);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3151,0.0001134607);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3153,0.0001268125);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3155,0.0001982554);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3157,0.0001990417);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3277,0.0001056306);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3279,0.0001074047);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3281,0.0002286212);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3403,9.810925e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3405,0.0001682644);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinContent(3529,0.000108194);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(141,4.105278e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(143,5.568308e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(145,8.655076e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(147,0.0001209626);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(149,0.0001458493);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(151,0.000198746);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(153,0.000251206);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(155,0.000301332);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(157,0.0003647399);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(159,0.0004391103);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(161,0.0005328092);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(163,0.0006162827);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(165,0.0007416674);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(167,0.0008711403);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(169,0.0009768743);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(171,0.00110701);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(173,0.001262779);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(175,0.001399762);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(177,0.001443584);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(179,0.001646728);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(181,0.001774371);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(265,4.61808e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(267,6.120773e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(269,8.336093e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(271,0.0001090708);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(273,0.0001456943);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(275,0.0001874269);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(277,0.0002239694);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(279,0.0003397738);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(281,0.0003462091);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(283,0.0004224285);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(285,0.0005028315);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(287,0.0006230464);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(289,0.0008412764);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(291,0.0008218487);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(293,0.000953472);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(295,0.001068794);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(297,0.001227243);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(299,0.001500789);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(301,0.001522282);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(303,0.001597349);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(305,0.001620313);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(389,3.060282e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(391,5.230454e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(393,7.168412e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(395,9.350919e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(397,0.0001227576);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(399,0.0001626292);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(401,0.0002032777);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(403,0.0002564758);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(405,0.0003197553);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(407,0.0003796064);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(409,0.0004642938);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(411,0.0005524957);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(413,0.0006516414);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(415,0.0008981729);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(417,0.0008897518);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(419,0.001017621);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(421,0.00114948);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(423,0.001277542);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(425,0.001641246);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(427,0.00160893);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(429,0.001599557);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(513,2.514956e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(515,4.512327e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(517,6.456818e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(519,8.386322e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(521,0.000100317);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(523,0.0001390071);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(525,0.000182909);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(527,0.0002289846);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(529,0.0002831743);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(531,0.0003437843);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(533,0.000416939);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(535,0.0005034033);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(537,0.0005933531);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(539,0.0008840613);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(541,0.0008191215);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(543,0.0009478922);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(545,0.001141836);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(547,0.001205253);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(549,0.001497177);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(551,0.001455575);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(553,0.001631749);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(637,3.109926e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(639,3.889224e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(641,4.966168e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(643,5.962658e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(645,9.115711e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(647,0.0001151673);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(649,0.0001543403);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(651,0.0001974264);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(653,0.0002650322);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(655,0.0002990911);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(657,0.0003698263);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(659,0.0004391118);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(661,0.0005304764);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(663,0.0006215378);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(665,0.0007427893);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(667,0.0008660109);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(669,0.0009880416);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(671,0.001122078);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(673,0.001253819);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(675,0.00146465);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(677,0.001496628);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(761,2.005288e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(763,3.453032e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(765,4.185159e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(767,6.017408e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(769,7.130525e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(771,9.143146e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(773,0.0001278106);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(775,0.0001587804);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(777,0.0001940925);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(779,0.0002527762);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(781,0.0003148404);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(783,0.0003745227);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(785,0.0004590942);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(787,0.000554421);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(789,0.0006554545);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(791,0.0007659977);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(793,0.0009592513);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(795,0.001029062);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(797,0.001157952);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(799,0.00146125);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(801,0.001663204);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(885,7.047923e-06);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(887,2.68034e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(889,2.415444e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(891,4.863573e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(893,6.435088e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(895,7.798281e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(897,0.0001069293);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(899,0.0001259259);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(901,0.0001607154);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(903,0.0002014615);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(905,0.0002607369);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(907,0.0003186368);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(909,0.0003935552);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(911,0.0004733865);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(913,0.0005759098);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(915,0.0009247686);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(917,0.0007942451);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(919,0.000925874);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(921,0.001068626);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(923,0.001208198);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(925,0.001611403);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1009,1.870739e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1011,2.593059e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1013,2.908731e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1015,3.428732e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1017,4.629221e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1019,6.000393e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1021,8.94933e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1023,0.0001018006);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1025,0.0001290913);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1027,0.0001695072);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1029,0.0002056311);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1031,0.0002579106);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1033,0.0003426664);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1035,0.0004040208);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1037,0.0004865529);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1039,0.0005916123);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1041,0.0007169611);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1043,0.0008183277);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1045,0.0009555745);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1047,0.001107082);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1049,0.00157075);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1135,1.641223e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1137,1.784835e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1139,3.584858e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1141,3.372323e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1143,5.243923e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1145,7.110214e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1147,8.512015e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1149,0.0001045613);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1151,0.000133296);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1153,0.0001692292);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1155,0.0002169601);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1157,0.0002707392);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1159,0.0003303155);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1161,0.0004072307);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1163,0.0004954537);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1165,0.0005868042);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1167,0.0007363857);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1169,0.0008417953);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1171,0.0009790362);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1173,0.001300745);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1261,1.030608e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1263,2.433982e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1265,2.652945e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1267,4.56259e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1269,5.332661e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1271,6.412359e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1273,8.522094e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1275,0.0001048117);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1277,0.0001240499);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1279,0.0001668312);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1281,0.0002120617);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1283,0.0002684173);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1285,0.0003345502);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1287,0.0004122198);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1289,0.0005030142);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1291,0.0006728098);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1293,0.0007279764);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1295,0.0008603691);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1297,0.001038065);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1387,2.56128e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1389,2.647598e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1391,3.428705e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1393,4.044041e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1395,5.417933e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1397,6.127591e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1399,8.804694e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1401,0.0001076419);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1403,0.0001313804);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1405,0.0001758596);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1407,0.0002232221);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1409,0.0002652405);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1411,0.0003353223);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1413,0.0004202764);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1415,0.0005272487);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1417,0.0006339407);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1419,0.0007334539);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1421,0.0008696723);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1513,1.038228e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1515,2.829746e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1517,2.8143e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1519,4.368789e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1521,5.484923e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1523,7.072724e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1525,8.505955e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1527,0.0001064503);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1529,0.000170083);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1531,0.0001714484);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1533,0.0002163233);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1535,0.0002681081);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1537,0.0003298226);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1539,0.0004148464);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1541,0.0005058647);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1543,0.0006652256);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1545,0.0009295066);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1639,2.425381e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1641,2.899941e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1643,3.476647e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1645,4.448283e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1647,5.976782e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1649,7.262856e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1651,8.066382e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1653,0.0001116687);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1655,0.00013245);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1657,0.0001717056);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1659,0.0002141111);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1661,0.0002659895);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1663,0.0003367273);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1665,0.0004143325);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1667,0.000511156);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1669,0.0006529162);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1765,2.713459e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1767,3.603393e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1769,4.21062e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1771,5.052182e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1773,5.852348e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1775,7.293027e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1777,8.566592e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1783,0.0001654624);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1785,0.0002109068);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1787,0.0002538904);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1789,0.0003257419);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1791,0.000407088);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1793,0.0005032589);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1845,0.0001462358);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1846,0.0001671781);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1847,0.0001941058);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1848,0.000202841);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1849,0.0002282471);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1850,0.0002737057);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1851,0.0003066143);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1852,0.000376857);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1853,0.0004072771);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1854,0.0004044034);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1855,0.0004602146);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1891,2.711376e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1893,2.480203e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1895,3.596079e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1897,4.496769e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1899,5.611778e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1901,8.36707e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1907,0.0001285089);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1908,0.000144049);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1909,0.0001578432);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1910,0.0001828145);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1911,0.0002028391);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1912,0.0002317897);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1913,0.0002531289);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1914,0.0003021805);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1915,0.0003307794);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1916,0.0003586825);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1917,0.000403957);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1969,0.0001116264);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1970,0.0001202826);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1971,0.0001411851);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1972,0.0001658022);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1973,0.0001832489);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1974,0.0002038846);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1975,0.000223456);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1976,0.0002536445);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1977,0.0002882254);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1978,0.0003172153);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(1979,0.0003577169);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2017,3.026762e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2019,3.074278e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2021,3.63803e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2023,5.108593e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2025,5.530602e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2031,0.0001072296);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2032,0.000110736);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2033,0.0001203595);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2034,0.0001403609);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2035,0.0001548909);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2036,0.0001716938);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2037,0.0002043534);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2038,0.000227675);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2039,0.0002626948);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2040,0.0002767622);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2041,0.0003550701);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2093,9.654392e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2094,0.0001042319);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2095,0.0001134598);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2096,0.0001218936);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2097,0.0001414045);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2098,0.000154649);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2099,0.0001751666);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2100,0.0001965599);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2101,0.0002207764);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2102,0.0002509946);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2103,0.0002796164);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2143,2.638948e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2145,2.959816e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2147,3.873126e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2149,5.044986e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2155,8.231915e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2156,8.569451e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2157,0.000103672);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2158,0.0001050056);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2159,0.0001240828);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2160,0.000149835);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2161,0.0001517714);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2162,0.0001673202);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2163,0.0001967208);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2164,0.0002354813);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2165,0.000282051);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2217,7.262499e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2218,7.553557e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2219,8.809839e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2220,0.0001029149);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2221,0.0001050985);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2222,0.0001347124);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2223,0.0001329059);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2224,0.0001534387);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2225,0.0001741743);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2226,0.0002350496);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2227,0.0002162563);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2269,2.916975e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2271,3.159754e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2273,3.212908e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2279,7.021606e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2280,7.97034e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2281,7.751895e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2282,9.094195e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2283,0.0001019721);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2284,0.0001151248);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2285,0.0001179941);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2286,0.000134923);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2287,0.0001445759);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2288,0.0001644489);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2289,0.0001943952);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2341,5.385652e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2342,6.354951e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2343,7.15225e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2344,7.923046e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2345,9.056642e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2346,9.304873e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2347,0.0001002147);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2348,0.0001204686);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2349,0.0001328616);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2350,0.0001461782);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2351,0.0001638668);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2395,2.377583e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2397,2.816808e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2403,5.665907e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2404,6.088514e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2405,6.724426e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2406,7.346847e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2407,7.916806e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2408,8.843081e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2409,9.104011e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2410,0.0001079096);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2411,0.0001238133);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2412,0.0001221855);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2413,0.0001432335);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2465,4.894919e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2466,5.341748e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2467,6.427656e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2468,7.209793e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2469,7.003321e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2470,8.068501e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2471,8.405458e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2472,0.0001025025);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2473,0.0001033567);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2474,0.0001093404);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2475,0.0001210591);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2521,3.116772e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2527,4.270572e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2528,4.662254e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2529,4.709593e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2530,5.399895e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2531,6.475753e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2532,7.342985e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2533,7.427275e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2534,9.053952e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2535,9.352698e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2536,9.426342e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2537,0.0001185761);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2589,4.496461e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2590,4.295185e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2591,4.564847e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2592,5.362288e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2593,5.517684e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2594,6.924138e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2595,6.928163e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2596,7.934764e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2597,8.409667e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2598,8.698637e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2599,9.861238e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2651,3.307996e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2653,4.847434e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2655,4.97618e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2657,6.377797e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2659,7.553824e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2661,0.0001135399);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2775,3.174575e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2777,3.775603e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2779,4.407643e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2781,5.005702e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2783,6.381248e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2785,7.532532e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2899,2.828741e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2901,3.788323e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2903,3.740432e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2905,3.67391e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2907,5.203146e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(2909,6.678819e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3025,2.855874e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3027,2.942983e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3029,2.989231e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3031,4.934676e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3033,4.897864e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3151,2.674478e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3153,2.836869e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3155,3.505114e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3157,3.466077e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3277,2.562082e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3279,2.605116e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3281,3.70924e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3403,2.452877e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3405,3.180224e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetBinError(3529,2.550325e-05);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetEntries(1306930);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->SetLineColor(ci);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_3NJet6_1500HTinf_300MHTinf->Draw("colz");
   c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf->Modified();
   c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf->cd();
   c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf->SetSelected(c_AccEffMap_T1qqqq_3NJet6_1500HTinf_300MHTinf);
}
/*
Topology ~g ~g ; ~g ->q+qbar+LSP

mGluino(GeV) mLSP(GeV) AccXEff
   400    25   0.000196135
   400    75   0.000287784
   400   125   0.000126002
   400   175   8.70652e-05
   400   225   0.000135495
   400   275   5.67162e-05
   400   325   7.04789e-06
   400   375   4.94936e-05
   450    25    0.00040756
   450    75   0.000484282
   450   125    0.00037287
   450   175   0.000281692
   450   225   0.000209415
   450   275   0.000165585
   450   325   9.66354e-05
   450   375   9.34888e-05
   450   425    3.6698e-05
   500    25   0.000963549
   500    75   0.000874656
   500   125   0.000650666
   500   175   0.000550526
   500   225   0.000321256
   500   275   0.000236498
   500   325   8.01073e-05
   500   375   0.000116341
   500   425   4.37182e-05
   500   475   1.45749e-05
   550    25    0.00178793
   550    75     0.0015073
   550   125    0.00113718
   550   175   0.000911932
   550   225   0.000453267
   550   275   0.000496059
   550   325    0.00032255
   550   375   0.000160806
   550   425   0.000175603
   550   475   8.07221e-05
   550   525   8.87206e-05
   600    25    0.00262042
   600    75    0.00262215
   600   125    0.00188653
   600   175    0.00129115
   600   225    0.00108614
   600   275    0.00067112
   600   325   0.000552599
   600   375   0.000292726
   600   425   0.000154525
   600   475   9.56478e-05
   600   525    9.5455e-05
   600   575   1.46826e-05
   650    25     0.0047464
   650    75     0.0043515
   650   125    0.00329531
   650   175    0.00244499
   650   225    0.00172772
   650   275    0.00112097
   650   325   0.000824383
   650   375   0.000487005
   650   425   0.000374298
   650   475   0.000284885
   650   525   0.000160805
   650   575   0.000109588
   650   625   8.04369e-05
   700    25    0.00765625
   700    75    0.00612184
   700   125    0.00508995
   700   175    0.00415022
   700   225    0.00307228
   700   275    0.00212825
   700   325    0.00147675
   700   375    0.00107922
   700   425   0.000692618
   700   475   0.000388024
   700   525   0.000225132
   700   575    0.00010899
   700   625    0.00011599
   700   675   0.000101522
   750    25     0.0109638
   750    75    0.00931513
   750   125    0.00806604
   750   175    0.00624359
   750   225    0.00448496
   750   275    0.00323061
   750   325    0.00207062
   750   375    0.00139159
   750   425   0.000979346
   750   475   0.000561849
   750   525   0.000405342
   750   575   0.000261868
   750   625   0.000166717
   750   675    0.00018015
   750   725   0.000101444
   800    25     0.0156139
   800    75     0.0144767
   800   125     0.0124128
   800   175    0.00988558
   800   225    0.00733954
   800   275    0.00482475
   800   325    0.00336236
   800   375    0.00221006
   800   425    0.00145911
   800   475    0.00101442
   800   525   0.000526893
   800   575   0.000421144
   800   625   0.000277749
   800   675   0.000249066
   800   725   8.59123e-05
   800   775   0.000128405
   850    25     0.0230726
   850    75     0.0212187
   850   125     0.0175742
   850   175     0.0145954
   850   225     0.0111625
   850   275     0.0081248
   850   325    0.00527824
   850   375    0.00379698
   850   425    0.00240744
   850   475    0.00150648
   850   525    0.00108363
   850   575   0.000706654
   850   625   0.000506992
   850   675   0.000360719
   850   725   0.000183344
   850   775   0.000133994
   850   825   9.87345e-05
   900    25     0.0337352
   900    75     0.0302292
   900   125     0.0261578
   900   175     0.0212345
   900   225     0.0161502
   900   275     0.0124352
   900   325    0.00870617
   900   375    0.00550768
   900   425    0.00382321
   900   475    0.00212549
   900   525    0.00162442
   900   575     0.0010265
   900   625   0.000743619
   900   675   0.000489393
   900   725   0.000291373
   900   775   0.000188964
   900   825   0.000125565
   900   875    0.00012006
   950    25     0.0451504
   950    75     0.0425258
   950   125     0.0365825
   950   175     0.0307347
   950   225     0.0236835
   950   275      0.017648
   950   325     0.0128957
   950   375    0.00863872
   950   425    0.00624044
   950   475    0.00378047
   950   525    0.00241609
   950   575     0.0016178
   950   625   0.000939687
   950   675   0.000771409
   950   725   0.000459216
   950   775   0.000378674
   950   825   0.000215618
   950   875   0.000144785
   950   925   8.23578e-05
  1000    25     0.0641189
  1000    75      0.058313
  1000   125     0.0503116
  1000   175     0.0417997
  1000   225     0.0344745
  1000   275     0.0258854
  1000   325     0.0193114
  1000   375     0.0141941
  1000   425    0.00966073
  1000   475    0.00601556
  1000   525    0.00424693
  1000   575    0.00272377
  1000   625    0.00157892
  1000   675      0.001048
  1000   725   0.000810755
  1000   775   0.000449134
  1000   825    0.00037401
  1000   875   0.000150635
  1000   925   0.000116082
  1000   975   0.000142816
  1050    25     0.0858307
  1050    75     0.0785573
  1050   125      0.068026
  1050   175     0.0597507
  1050   225     0.0470982
  1050   275      0.036815
  1050   325     0.0281753
  1050   375     0.0205474
  1050   425     0.0142674
  1050   475    0.00955646
  1050   525    0.00642374
  1050   575    0.00412016
  1050   625    0.00252062
  1100    25      0.108437
  1100    75       0.10416
  1100   125     0.0920491
  1100   175     0.0790324
  1100   225      0.065796
  1100   275     0.0526149
  1100   325     0.0413144
  1100   375      0.030055
  1100   425     0.0215053
  1100   475     0.0148325
  1100   525    0.00955638
  1100   575    0.00646522
  1100   625    0.00408275
  1150    25      0.135482
  1150    75      0.129635
  1150   125      0.118431
  1150   175      0.104419
  1150   225     0.0886712
  1150   275     0.0710311
  1150   325     0.0563846
  1150   375     0.0427651
  1150   425     0.0316589
  1150   475     0.0222948
  1150   525      0.015111
  1150   575    0.00992671
  1150   625    0.00619151
  1150   675    0.00374436
  1150   700     0.0031299
  1150   725    0.00244533
  1150   750    0.00188314
  1150   775    0.00147958
  1150   800    0.00128594
  1150   825    0.00104021
  1150   850   0.000807927
  1150   875   0.000755596
  1150   900   0.000447245
  1150   925   0.000497032
  1150   950   0.000369426
  1150   975   0.000279993
  1150  1000   0.000311465
  1150  1025   0.000168658
  1150  1075   0.000155507
  1150  1125   0.000123293
  1175   700    0.00409064
  1175   725    0.00305754
  1175   750    0.00214115
  1175   775    0.00182442
  1175   800    0.00149357
  1175   825    0.00112904
  1175   850    0.00086722
  1175   875   0.000831196
  1175   900   0.000612138
  1175   925   0.000570811
  1175   950   0.000440325
  1175   975   0.000336082
  1175  1000   0.000284812
  1200    25      0.165805
  1200    75      0.160071
  1200   125      0.148208
  1200   175      0.133063
  1200   225       0.11393
  1200   275     0.0964607
  1200   325     0.0767179
  1200   375     0.0609763
  1200   425     0.0439815
  1200   475       0.03255
  1200   525     0.0225391
  1200   575     0.0148776
  1200   625    0.00989232
  1200   675    0.00617377
  1200   700     0.0048188
  1200   725    0.00356495
  1200   750    0.00300156
  1200   775    0.00219199
  1200   800     0.0019732
  1200   825    0.00165236
  1200   850    0.00119627
  1200   875   0.000919726
  1200   900   0.000792462
  1200   925   0.000704866
  1200   950   0.000642227
  1200   975   0.000346011
  1200  1000   0.000325931
  1200  1025   0.000369087
  1200  1075   0.000223337
  1200  1125    0.00022409
  1200  1175   0.000127709
  1225   700    0.00595494
  1225   725    0.00482697
  1225   750    0.00371586
  1225   775    0.00298507
  1225   800    0.00227356
  1225   825    0.00170206
  1225   850    0.00163673
  1225   875    0.00129123
  1225   900   0.000978991
  1225   925   0.000837245
  1225   950   0.000799072
  1225   975   0.000458069
  1225  1000   0.000448423
  1250    25      0.197556
  1250    75      0.191046
  1250   125      0.178635
  1250   175      0.163942
  1250   225      0.144599
  1250   275      0.124172
  1250   325      0.101608
  1250   375     0.0815295
  1250   425     0.0636682
  1250   475     0.0467854
  1250   525     0.0328587
  1250   575     0.0226609
  1250   625     0.0154137
  1250   675    0.00919764
  1250   700    0.00747065
  1250   725    0.00587735
  1250   750    0.00475671
  1250   775    0.00344236
  1250   800    0.00288291
  1250   825     0.0023007
  1250   850    0.00171354
  1250   875    0.00163154
  1250   900    0.00121348
  1250   925   0.000958712
  1250   950   0.000776198
  1250   975   0.000663205
  1250  1000   0.000474513
  1250  1025    0.00039154
  1250  1075   0.000308477
  1250  1125   0.000221257
  1250  1175   0.000138027
  1250  1225   0.000113461
  1275   700     0.0101001
  1275   725     0.0078123
  1275   750    0.00598485
  1275   775     0.0044492
  1275   800    0.00364002
  1275   825    0.00306346
  1275   850    0.00247496
  1275   875    0.00191033
  1275   900    0.00133045
  1275   925    0.00120457
  1275   950    0.00097418
  1275   975   0.000855376
  1275  1000   0.000705567
  1300    25      0.224744
  1300    75        0.2208
  1300   125      0.210432
  1300   175      0.196214
  1300   225      0.177323
  1300   275      0.155095
  1300   325      0.133711
  1300   375      0.109828
  1300   425     0.0878262
  1300   475     0.0665992
  1300   525     0.0485237
  1300   575     0.0343293
  1300   625     0.0232027
  1300   675     0.0146803
  1300   700      0.012155
  1300   725    0.00926802
  1300   750     0.0071697
  1300   775    0.00590672
  1300   800    0.00446713
  1300   825    0.00345155
  1300   850    0.00259156
  1300   875    0.00213986
  1300   900     0.0015273
  1300   925    0.00131718
  1300   950    0.00112949
  1300   975    0.00088118
  1300  1000   0.000771127
  1300  1025    0.00065308
  1300  1075   0.000403474
  1300  1125   0.000217323
  1300  1175     0.0001433
  1300  1225   0.000126812
  1300  1275   0.000105631
  1325   700     0.0150743
  1325   725      0.012434
  1325   750    0.00938162
  1325   775    0.00718299
  1325   800    0.00578261
  1325   825    0.00411306
  1325   850    0.00362479
  1325   875    0.00282348
  1325   900    0.00218842
  1325   925    0.00182394
  1325   950    0.00119783
  1325   975    0.00117862
  1325  1000    0.00101213
  1350    25      0.254862
  1350    75      0.252885
  1350   125       0.24145
  1350   175      0.228178
  1350   225      0.212759
  1350   275      0.190968
  1350   325      0.168443
  1350   375      0.142974
  1350   425      0.116633
  1350   475     0.0913151
  1350   525     0.0685825
  1350   575     0.0494856
  1350   625     0.0353846
  1350   675      0.022741
  1350   700       0.01922
  1350   725     0.0146199
  1350   750      0.011349
  1350   775     0.0090348
  1350   800    0.00728429
  1350   825    0.00565408
  1350   850    0.00443246
  1350   875    0.00325437
  1350   900    0.00269232
  1350   925    0.00233902
  1350   950    0.00172622
  1350   975    0.00137575
  1350  1000    0.00114558
  1350  1025   0.000930726
  1350  1075   0.000662845
  1350  1125   0.000435164
  1350  1175   0.000348757
  1350  1225   0.000198255
  1350  1275   0.000107405
  1350  1325   9.81093e-05
  1375   700     0.0230276
  1375   725     0.0182077
  1375   750     0.0144558
  1375   775     0.0111397
  1375   800     0.0088866
  1375   825    0.00690581
  1375   850     0.0057096
  1375   875    0.00418949
  1375   900    0.00313509
  1375   925    0.00235931
  1375   950     0.0019166
  1375   975    0.00144904
  1375  1000     0.0012012
  1400    25      0.283656
  1400    75      0.279826
  1400   125      0.273631
  1400   175      0.260709
  1400   225      0.245119
  1400   275      0.225303
  1400   325      0.203849
  1400   375      0.177429
  1400   425      0.150681
  1400   475      0.121033
  1400   525     0.0934573
  1400   575     0.0695664
  1400   625     0.0509744
  1400   675     0.0348173
  1400   700     0.0286797
  1400   725     0.0230508
  1400   750     0.0181328
  1400   775     0.0142135
  1400   800     0.0114911
  1400   825    0.00935208
  1400   850    0.00697646
  1400   875    0.00541601
  1400   900    0.00420993
  1400   925    0.00320285
  1400   950    0.00235409
  1400   975    0.00203732
  1400  1000    0.00152771
  1400  1025    0.00132226
  1400  1075    0.00088114
  1400  1125   0.000740293
  1400  1175   0.000397808
  1400  1225   0.000199042
  1400  1275   0.000228621
  1400  1325   0.000168264
  1400  1375   0.000108194
*/
