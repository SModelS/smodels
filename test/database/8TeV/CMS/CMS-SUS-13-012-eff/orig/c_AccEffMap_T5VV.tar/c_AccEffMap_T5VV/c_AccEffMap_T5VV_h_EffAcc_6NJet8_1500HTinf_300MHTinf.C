{
//=========Macro generated from canvas: c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf/c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf
//=========  (Sat Feb 22 16:32:53 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf = new TCanvas("c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf", "c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf",100,240,500,500);
   c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf->Range(0,0,1,1);
   c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf->SetFillColor(0);
   c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf->SetBorderMode(0);
   c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf->SetBorderSize(2);
   c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf->SetLogz();
   c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_6NJet8_1500HTinf_300MHTinf = new TH2D("h_EffAcc_6NJet8_1500HTinf_300MHTinf","h_EffAcc_6NJet8_1500HTinf_300MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(141,0.0001073119);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(143,0.0002878941);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(145,0.0005410291);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(147,0.0008671493);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(149,0.001334795);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(151,0.00230992);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(153,0.003566896);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(155,0.005681927);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(157,0.007883871);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(159,0.01197513);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(161,0.01664259);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(163,0.02303601);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(165,0.03277768);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(167,0.04241771);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(169,0.05314181);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(171,0.0681799);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(173,0.08543035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(175,0.1010447);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(177,0.1183525);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(179,0.1351858);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(181,0.1507529);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(265,6.409727e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(267,0.0002582748);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(269,0.0004475924);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(271,0.0008439028);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(273,0.001485242);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(275,0.002070497);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(277,0.003328866);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(279,0.004954667);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(281,0.007933062);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(283,0.01112433);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(285,0.01510987);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(287,0.02146421);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(289,0.0292275);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(291,0.03865772);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(293,0.05150261);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(295,0.06531142);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(297,0.08053701);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(299,0.0972364);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(301,0.1138094);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(303,0.1315857);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(305,0.1484312);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(389,0.0001066687);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(391,0.0001886606);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(393,0.0003423541);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(395,0.0006514205);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(397,0.001053188);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(399,0.001608894);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(401,0.002803914);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(403,0.00416039);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(405,0.006423498);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(407,0.009328943);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(409,0.01365034);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(411,0.01868456);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(413,0.02641365);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(415,0.03521467);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(417,0.04562593);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(419,0.05852374);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(421,0.07463412);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(423,0.09133375);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(425,0.1078739);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(427,0.1239732);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(429,0.142771);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(513,7.808396e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(515,9.454803e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(517,0.0002494352);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(519,0.000402415);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(521,0.0006566439);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(523,0.001507484);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(525,0.002005732);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(527,0.002909306);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(529,0.004692722);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(531,0.00737714);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(533,0.009788272);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(535,0.01480197);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(537,0.02112222);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(539,0.0295542);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(541,0.04014159);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(543,0.05179012);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(545,0.06542455);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(547,0.08035022);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(549,0.09919434);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(551,0.1169213);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(553,0.1344239);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(639,0.0001304757);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(641,0.0001646807);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(643,0.0003208988);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(645,0.0004620098);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(647,0.0008375055);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(649,0.001776339);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(651,0.002424396);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(653,0.003492271);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(655,0.005472998);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(657,0.007871218);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(659,0.01168788);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(661,0.01744161);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(663,0.0233825);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(665,0.03224548);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(667,0.04363977);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(669,0.05679418);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(671,0.07213348);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(673,0.08862121);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(675,0.1073599);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(677,0.1262829);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(765,8.25853e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(767,0.0003060104);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(769,0.0004460496);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(771,0.000737507);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(773,0.001083373);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(775,0.001715952);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(777,0.002439108);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(779,0.004081895);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(781,0.006273468);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(783,0.008797772);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(785,0.01291108);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(787,0.0179679);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(789,0.02552613);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(791,0.03509683);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(793,0.0469744);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(795,0.06060422);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(797,0.07876427);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(799,0.09695234);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(801,0.1137892);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(891,0.0001926225);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(893,0.000296155);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(895,0.0004252338);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(897,0.0008152978);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(899,0.001175747);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(901,0.001763424);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(903,0.002994414);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(905,0.004599764);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(907,0.006168077);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(909,0.009066506);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(911,0.01411837);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(913,0.01959606);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(915,0.0276224);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(917,0.03677955);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(919,0.04933002);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(921,0.06480187);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(923,0.08369125);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(925,0.09844321);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1017,0.000153823);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1019,0.0002846409);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1021,0.0004525492);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1023,0.0006471967);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1025,0.001227947);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1027,0.002015618);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1029,0.003004129);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1031,0.004341245);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1033,0.006875256);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1035,0.009302677);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1037,0.01391396);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1039,0.02023417);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1041,0.027822);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1043,0.03869702);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1045,0.05158449);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1047,0.06724616);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1049,0.08605993);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1143,0.0001885269);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1145,0.0005269354);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1147,0.0005799585);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1149,0.0009330352);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1151,0.001365683);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1153,0.001912526);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1155,0.002711547);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1157,0.004612372);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1159,0.006803727);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1161,0.01003022);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1163,0.01487234);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1165,0.02106385);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1167,0.02890506);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1169,0.03990362);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1171,0.05399054);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1173,0.07193642);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1269,0.0002549814);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1271,0.0004002823);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1273,0.000523102);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1275,0.001075152);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1277,0.001653556);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1279,0.00189821);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1281,0.003046031);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1283,0.004609134);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1285,0.006859448);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1287,0.01043051);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1289,0.01530423);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1291,0.02127475);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1293,0.02999155);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1295,0.04174451);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1297,0.05768913);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1395,0.0003271018);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1397,0.0004763299);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1399,0.0006177673);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1401,0.0009139453);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1403,0.001299537);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1405,0.002193563);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1407,0.003119642);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1409,0.004575454);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1411,0.006323226);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1413,0.01020084);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1415,0.01471839);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1417,0.02100632);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1419,0.03129082);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1421,0.04258802);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1473,0.005485154);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1474,0.006953997);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1475,0.008285462);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1476,0.01024487);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1477,0.01298275);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1478,0.01515827);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1479,0.01829124);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1480,0.02332438);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1481,0.02665908);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1482,0.03057275);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1483,0.03721074);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1521,0.0002759273);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1523,0.0003823062);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1525,0.0006658283);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1527,0.001013155);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1529,0.001386526);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1531,0.001945524);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1533,0.002860158);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1535,0.004797125);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1536,0.00533796);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1537,0.007227795);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1538,0.008266789);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1539,0.009885506);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1540,0.01237967);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1541,0.01513069);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1542,0.01838103);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1543,0.02149071);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1544,0.02567476);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1545,0.03134365);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1597,0.003754374);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1598,0.004680196);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1599,0.005464596);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1600,0.006943608);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1601,0.008265636);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1602,0.009995673);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1603,0.01236569);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1604,0.01529062);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1605,0.01811135);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1606,0.02184088);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1607,0.0266515);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1647,0.0002786993);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1649,0.0004157637);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1651,0.0006727382);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1653,0.001055671);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1655,0.001407408);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1657,0.001836279);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1659,0.003066714);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1660,0.003892506);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1661,0.004490385);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1662,0.004983678);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1663,0.00654802);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1664,0.008097066);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1665,0.01008918);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1666,0.01219271);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1667,0.01504111);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1668,0.01867551);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1669,0.02163115);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1721,0.002528346);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1722,0.00293944);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1723,0.003696835);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1724,0.004338825);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1725,0.005580845);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1726,0.006731839);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1727,0.008497784);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1728,0.009942915);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1729,0.01309182);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1730,0.01454635);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1731,0.01818845);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1773,0.0003450557);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1775,0.0004668571);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1777,0.0006863258);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1779,0.0009746191);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1781,0.00128891);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1783,0.001963415);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1784,0.002548669);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1785,0.002867849);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1786,0.00366553);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1787,0.004141108);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1788,0.005153009);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1789,0.006928113);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1790,0.007881439);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1791,0.01009575);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1792,0.01203697);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1793,0.01486046);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1845,0.001566109);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1846,0.001839125);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1847,0.002715278);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1848,0.003025239);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1849,0.003580906);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1850,0.003968486);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1851,0.005281001);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1852,0.00659206);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1853,0.007746155);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1854,0.009533757);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1855,0.01222818);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1899,0.0002697025);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1901,0.0003928445);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1903,0.0006789955);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1905,0.00099264);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1907,0.001212962);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1908,0.001522468);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1909,0.002104838);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1910,0.00238197);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1911,0.002994103);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1912,0.00355751);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1913,0.00418182);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1914,0.005634311);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1915,0.006697431);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1916,0.007782568);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1917,0.00985491);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1969,0.001028588);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1970,0.001368164);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1971,0.001417519);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1972,0.001713461);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1973,0.002096594);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1974,0.002477423);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1975,0.003744894);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1976,0.004373749);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1977,0.005235424);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1978,0.00616463);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(1979,0.008009738);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2025,0.0002868725);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2027,0.0004899263);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2029,0.0006356401);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2031,0.001024986);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2032,0.001154981);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2033,0.001387736);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2034,0.001655495);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2035,0.001978239);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2036,0.002213692);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2037,0.002786899);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2038,0.003321744);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2039,0.004099568);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2040,0.004703561);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2041,0.006435729);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2093,0.0007179218);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2094,0.0008841819);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2095,0.001089348);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2096,0.001429892);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2097,0.001669664);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2098,0.001865627);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2099,0.002084482);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2100,0.002755281);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2101,0.003481924);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2102,0.003900286);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2103,0.004978728);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2151,0.0003146488);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2153,0.0004376145);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2155,0.0007624876);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2156,0.0008690977);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2157,0.0009898071);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2158,0.001253517);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2159,0.001056247);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2160,0.001506309);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2161,0.0017935);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2162,0.002320396);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2163,0.002679962);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2164,0.003116589);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2165,0.00432938);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2217,0.0005772965);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2218,0.0006531038);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2219,0.0007305774);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2220,0.0008574421);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2221,0.001039756);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2222,0.00112604);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2223,0.001351677);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2224,0.001782765);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2225,0.002114661);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2226,0.002485294);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2227,0.003398765);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2277,0.0002382665);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2279,0.000313646);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2281,0.0005326558);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2283,0.0008324907);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2285,0.001172871);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2287,0.001786765);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2289,0.002420373);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2403,0.0002742303);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2405,0.0003410213);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2407,0.0005039758);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2409,0.0008451301);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2411,0.001124549);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2413,0.001577697);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2529,0.0002111789);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2531,0.0004420999);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2533,0.0005897357);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2535,0.0007938065);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2537,0.001126249);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2655,0.0002013255);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2657,0.0003611792);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2659,0.0005940718);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2661,0.0007553832);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2781,0.0001916436);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2783,0.0003126722);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2785,0.0004407812);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2907,0.0002639516);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(2909,0.0003617037);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinContent(3033,0.0002114943);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(141,2.873948e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(143,4.619379e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(145,6.784182e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(147,8.17993e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(149,0.0001022159);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(151,0.0001413314);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(153,0.0001801708);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(155,0.0002162625);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(157,0.0002581561);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(159,0.000312796);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(161,0.0003759252);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(163,0.0004889653);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(165,0.0005801891);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(167,0.0005869764);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(169,0.0006685479);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(171,0.0007471696);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(173,0.0008423944);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(175,0.0009169795);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(177,0.0009952614);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(179,0.001065346);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(181,0.001124147);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(265,2.273538e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(267,4.368933e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(269,5.788822e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(271,7.995401e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(273,0.0001070704);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(275,0.0001325815);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(277,0.0001613097);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(279,0.0002024391);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(281,0.000255061);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(283,0.0003313458);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(285,0.0003549864);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(287,0.0004411645);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(289,0.000484782);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(291,0.0005593763);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(293,0.0006635045);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(295,0.0007302507);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(297,0.000815175);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(299,0.0008964759);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(301,0.000973089);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(303,0.001047012);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(305,0.001112215);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(389,2.754353e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(391,3.852645e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(393,5.109449e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(395,7.000763e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(397,9.088863e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(399,0.000112327);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(401,0.0001475751);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(403,0.0001807263);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(405,0.0002249368);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(407,0.0002959784);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(409,0.0003564922);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(411,0.0003874425);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(413,0.000560471);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(415,0.0005386064);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(417,0.0006756497);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(419,0.0006861078);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(421,0.0007798783);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(423,0.0008656569);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(425,0.000943206);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(427,0.001013413);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(429,0.001087567);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(513,2.354432e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(515,2.852691e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(517,4.343752e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(519,5.485353e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(521,7.048878e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(523,0.0001069686);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(525,0.0001333255);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(527,0.0001503934);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(529,0.0001903699);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(531,0.0002432254);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(533,0.0002844623);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(535,0.0003439401);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(537,0.0004089247);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(539,0.0005874334);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(541,0.000570751);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(543,0.0006433316);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(545,0.0007250691);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(547,0.000832359);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(549,0.000900065);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(551,0.0009801332);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(553,0.001052088);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(639,3.075584e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(641,3.511354e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(643,4.956083e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(645,5.926839e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(647,8.34825e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(649,0.0001221937);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(651,0.0001383243);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(653,0.0001626371);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(655,0.0002350939);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(657,0.0002571243);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(659,0.0003000116);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(661,0.0003740998);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(663,0.0004374373);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(665,0.0005143856);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(667,0.0005870208);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(669,0.0006713146);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(671,0.0007658359);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(673,0.0008456139);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(675,0.0009337048);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(677,0.001015);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(765,2.490165e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(767,4.779964e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(769,5.764843e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(771,7.382171e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(773,9.110488e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(775,0.00011475);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(777,0.0001419237);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(779,0.0001859764);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(781,0.0002388319);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(783,0.0002596525);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(785,0.0003146388);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(787,0.0003712379);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(789,0.0004455328);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(791,0.0005222108);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(793,0.0006056155);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(795,0.0006906487);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(797,0.0007934816);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(799,0.0008816702);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(801,0.0009567902);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(891,3.778077e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(893,4.74404e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(895,5.586673e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(897,7.895932e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(899,9.315367e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(901,0.0001254206);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(903,0.0001537608);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(905,0.0001851537);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(907,0.0002146991);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(909,0.0002738886);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(911,0.0003262366);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(913,0.000439797);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(915,0.0004583289);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(917,0.0005302318);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(919,0.0006182728);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(921,0.0007118954);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(923,0.0008112618);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(925,0.0008826192);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1017,3.357005e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1019,4.558685e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1021,5.797961e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1023,6.864842e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1025,9.57761e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1027,0.0001375859);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1029,0.0001479988);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1031,0.0001779965);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1033,0.0002585036);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1035,0.0003081861);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1037,0.000321743);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1039,0.0003891401);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1041,0.0004567434);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1043,0.0005410988);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1045,0.0006301473);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1047,0.0007191006);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1049,0.0008187125);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1143,3.770967e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1145,6.346275e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1147,6.488203e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1149,8.254501e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1151,9.873955e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1153,0.0001210752);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1155,0.000208893);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1157,0.000182923);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1159,0.0002326613);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1161,0.0002925034);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1163,0.0003305579);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1165,0.0003949528);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1167,0.0004636777);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1169,0.0005475397);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1171,0.0006413057);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1173,0.0007406645);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1269,4.310635e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1271,5.499629e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1273,6.12753e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1275,8.879501e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1277,0.000109058);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1279,0.000140328);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1281,0.000155889);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1283,0.0001835572);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1285,0.0002215316);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1287,0.0002736563);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1289,0.0003332503);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1291,0.0003943942);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1293,0.0004699085);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1295,0.0005556464);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1297,0.0006773616);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1395,5.110421e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1397,5.871535e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1399,6.665207e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1401,8.389082e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1403,9.516624e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1405,0.0001359435);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1407,0.0001475449);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1409,0.0001849098);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1411,0.0002105132);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1413,0.0002690119);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1415,0.0003239368);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1417,0.0003882043);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1419,0.0004766402);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1421,0.0005623951);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1473,0.0001952855);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1474,0.0002223424);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1475,0.0002463974);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1476,0.0002869888);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1477,0.0003145671);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1478,0.000357662);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1479,0.0003819448);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1480,0.000436905);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1481,0.0004516688);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1482,0.0004971504);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1483,0.0005483405);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1521,4.476877e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1523,5.204462e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1525,6.986018e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1527,8.394004e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1529,9.800593e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1531,0.0001158095);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1533,0.0001450964);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1535,0.000181379);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1536,0.0002932231);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1537,0.0002372022);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1538,0.0002394039);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1539,0.000262988);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1540,0.0003193491);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1541,0.0003268893);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1542,0.0003933527);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1543,0.0003931432);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1544,0.0004281228);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1545,0.0004838112);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1597,0.0001620801);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1598,0.0001804515);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1599,0.0001984724);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1600,0.0002261161);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1601,0.0002385758);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1602,0.0002631962);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1603,0.0002939506);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1604,0.0003733534);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1605,0.0003620913);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1606,0.0004145725);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1607,0.0004371402);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1647,4.463512e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1649,5.460615e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1651,6.870494e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1653,8.519016e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1655,9.80448e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1657,0.0001185427);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1659,0.000143566);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1660,0.000162668);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1661,0.0001809595);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1662,0.0001915291);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1663,0.000214589);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1664,0.000235652);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1665,0.0002734873);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1666,0.000304068);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1667,0.0003360781);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1668,0.0003602263);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1669,0.0004343788);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1721,0.000129804);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1722,0.0001403863);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1723,0.0002048819);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1724,0.0001764163);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1725,0.000202918);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1726,0.0002150451);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1727,0.0002696987);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1728,0.0002619551);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1729,0.0003068697);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1730,0.000321839);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1731,0.0004028224);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1773,4.982274e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1775,5.748234e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1777,6.832547e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1779,8.304963e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1781,9.49035e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1783,0.0001163689);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1784,0.0001353444);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1785,0.0001413461);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1786,0.0001563787);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1787,0.000167391);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1788,0.0001904708);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1789,0.0002579152);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1790,0.0002483644);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1791,0.0002741709);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1792,0.0002857846);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1793,0.0003227699);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1845,0.0001012464);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1846,0.0001340941);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1847,0.0001407944);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1848,0.0001625651);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1849,0.0001597924);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1850,0.0001913792);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1851,0.0001919845);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1852,0.0002175492);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1853,0.0002420391);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1854,0.000252583);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1855,0.0002895299);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1899,4.375865e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1901,5.159525e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1903,7.288172e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1905,9.385196e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1907,9.158419e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1908,9.994619e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1909,0.0001172616);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1910,0.0001341782);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1911,0.0001396829);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1912,0.0001613128);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1913,0.0001750418);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1914,0.0001987657);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1915,0.0002604079);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1916,0.0002366142);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1917,0.0002731813);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1969,8.520239e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1970,9.521915e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1971,9.596351e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1972,0.000122019);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1973,0.0001214391);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1974,0.0001263289);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1975,0.0002081084);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1976,0.000170328);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1977,0.0001849478);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1978,0.0002286576);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(1979,0.0002309686);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2025,4.480973e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2027,5.857474e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2029,6.599028e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2031,8.161754e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2032,8.791622e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2033,9.479282e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2034,0.0001036992);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2035,0.0001142871);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2036,0.0001209179);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2037,0.0001336526);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2038,0.000146071);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2039,0.0001717192);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2040,0.0001816571);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2041,0.0002193328);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2093,6.817643e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2094,8.110652e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2095,8.879114e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2096,9.587631e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2097,0.0001049521);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2098,0.0001105534);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2099,0.0001163194);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2100,0.0001449436);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2101,0.0001525543);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2102,0.0001672077);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2103,0.0001892703);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2151,4.590498e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2153,5.471629e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2155,7.082787e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2156,7.516374e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2157,8.496886e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2158,9.104409e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2159,8.339065e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2160,0.0001051234);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2161,0.0001090019);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2162,0.0001452003);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2163,0.0001318202);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2164,0.0001427329);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2165,0.0001694318);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2217,6.264411e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2218,6.501688e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2219,8.277412e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2220,7.497154e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2221,8.12834e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2222,8.427079e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2223,9.931451e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2224,0.0001097406);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2225,0.000122298);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2226,0.0001246904);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2227,0.0001529991);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2277,4.086825e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2279,4.676446e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2281,5.850765e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2283,7.280081e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2285,9.259095e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2287,0.0001053043);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2289,0.0001223043);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2403,6.464744e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2405,4.687933e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2407,6.678252e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2409,8.027353e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2411,8.321297e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2413,9.821932e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2529,4.224117e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2531,5.323684e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2533,6.053823e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2535,8.468893e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2537,8.267692e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2655,4.393819e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2657,4.743553e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2659,6.034059e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2661,6.815831e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2781,3.99651e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2783,4.37977e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2785,5.160875e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2907,4.026576e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(2909,4.6706e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetBinError(3033,3.682116e-05);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetEntries(823296.7);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->SetLineColor(ci);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_6NJet8_1500HTinf_300MHTinf->Draw("colz");
   c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf->Modified();
   c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf->cd();
   c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf->SetSelected(c_AccEffMap_T5VV_6NJet8_1500HTinf_300MHTinf);
}
/*
   400    25   0.000107312
   400    75   6.40973e-05
   400   125   0.000106669
   400   175    7.8084e-05
   450    25   0.000287894
   450    75   0.000258275
   450   125   0.000188661
   450   175    9.4548e-05
   450   225   0.000130476
   500    25   0.000541029
   500    75   0.000447592
   500   125   0.000342354
   500   175   0.000249435
   500   225   0.000164681
   500   275   8.25853e-05
   550    25   0.000867149
   550    75   0.000843903
   550   125   0.000651421
   550   175   0.000402415
   550   225   0.000320899
   550   275    0.00030601
   550   325   0.000192622
   600    25    0.00133479
   600    75    0.00148524
   600   125    0.00105319
   600   175   0.000656644
   600   225    0.00046201
   600   275    0.00044605
   600   325   0.000296155
   600   375   0.000153823
   650    25    0.00230992
   650    75     0.0020705
   650   125    0.00160889
   650   175    0.00150748
   650   225   0.000837506
   650   275   0.000737507
   650   325   0.000425234
   650   375   0.000284641
   650   425   0.000188527
   700    25     0.0035669
   700    75    0.00332887
   700   125    0.00280391
   700   175    0.00200573
   700   225    0.00177634
   700   275    0.00108337
   700   325   0.000815298
   700   375   0.000452549
   700   425   0.000526935
   700   475   0.000254981
   750    25    0.00568193
   750    75    0.00495467
   750   125    0.00416039
   750   175    0.00290931
   750   225     0.0024244
   750   275    0.00171595
   750   325    0.00117575
   750   375   0.000647197
   750   425   0.000579959
   750   475   0.000400282
   750   525   0.000327102
   800    25    0.00788387
   800    75    0.00793306
   800   125     0.0064235
   800   175    0.00469272
   800   225    0.00349227
   800   275    0.00243911
   800   325    0.00176342
   800   375    0.00122795
   800   425   0.000933035
   800   475   0.000523102
   800   525    0.00047633
   800   575   0.000275927
   850    25     0.0119751
   850    75     0.0111243
   850   125    0.00932894
   850   175    0.00737714
   850   225      0.005473
   850   275    0.00408189
   850   325    0.00299441
   850   375    0.00201562
   850   425    0.00136568
   850   475    0.00107515
   850   525   0.000617767
   850   575   0.000382306
   850   625   0.000278699
   900    25     0.0166426
   900    75     0.0151099
   900   125     0.0136503
   900   175    0.00978827
   900   225    0.00787122
   900   275    0.00627347
   900   325    0.00459976
   900   375    0.00300413
   900   425    0.00191253
   900   475    0.00165356
   900   525   0.000913945
   900   575   0.000665828
   900   625   0.000415764
   900   675   0.000345056
   950    25      0.023036
   950    75     0.0214642
   950   125     0.0186846
   950   175      0.014802
   950   225     0.0116879
   950   275    0.00879777
   950   325    0.00616808
   950   375    0.00434124
   950   425    0.00271155
   950   475    0.00189821
   950   525    0.00129954
   950   575    0.00101316
   950   625   0.000672738
   950   675   0.000466857
   950   725   0.000269702
  1000    25     0.0327777
  1000    75     0.0292275
  1000   125     0.0264136
  1000   175     0.0211222
  1000   225     0.0174416
  1000   275     0.0129111
  1000   325    0.00906651
  1000   375    0.00687526
  1000   425    0.00461237
  1000   475    0.00304603
  1000   525    0.00219356
  1000   575    0.00138653
  1000   625    0.00105567
  1000   675   0.000686326
  1000   725   0.000392844
  1000   775   0.000286873
  1050    25     0.0424177
  1050    75     0.0386577
  1050   125     0.0352147
  1050   175     0.0295542
  1050   225     0.0233825
  1050   275     0.0179679
  1050   325     0.0141184
  1050   375    0.00930268
  1050   425    0.00680373
  1050   475    0.00460913
  1050   525    0.00311964
  1050   575    0.00194552
  1050   625    0.00140741
  1050   675   0.000974619
  1050   725   0.000678995
  1050   775   0.000489926
  1050   825   0.000314649
  1100    25     0.0531418
  1100    75     0.0515026
  1100   125     0.0456259
  1100   175     0.0401416
  1100   225     0.0322455
  1100   275     0.0255261
  1100   325     0.0195961
  1100   375      0.013914
  1100   425     0.0100302
  1100   475    0.00685945
  1100   525    0.00457545
  1100   575    0.00286016
  1100   625    0.00183628
  1100   675    0.00128891
  1100   725    0.00099264
  1100   775    0.00063564
  1100   825   0.000437615
  1100   875   0.000238266
  1150    25     0.0681799
  1150    75     0.0653114
  1150   125     0.0585237
  1150   175     0.0517901
  1150   225     0.0436398
  1150   275     0.0350968
  1150   325     0.0276224
  1150   375     0.0202342
  1150   425     0.0148723
  1150   475     0.0104305
  1150   525    0.00632323
  1150   550    0.00548515
  1150   575    0.00479712
  1150   600    0.00375437
  1150   625    0.00306671
  1150   650    0.00252835
  1150   675    0.00196342
  1150   700    0.00156611
  1150   725    0.00121296
  1150   750    0.00102859
  1150   775    0.00102499
  1150   800   0.000717922
  1150   825   0.000762488
  1150   850   0.000577296
  1150   875   0.000313646
  1150   925    0.00027423
  1175   550      0.006954
  1175   575    0.00533796
  1175   600     0.0046802
  1175   625    0.00389251
  1175   650    0.00293944
  1175   675    0.00254867
  1175   700    0.00183912
  1175   725    0.00152247
  1175   750    0.00136816
  1175   775    0.00115498
  1175   800   0.000884182
  1175   825   0.000869098
  1175   850   0.000653104
  1200    25     0.0854304
  1200    75      0.080537
  1200   125     0.0746341
  1200   175     0.0654245
  1200   225     0.0567942
  1200   275     0.0469744
  1200   325     0.0367795
  1200   375      0.027822
  1200   425     0.0210639
  1200   475     0.0153042
  1200   525     0.0102008
  1200   550    0.00828546
  1200   575    0.00722779
  1200   600     0.0054646
  1200   625    0.00449039
  1200   650    0.00369684
  1200   675    0.00286785
  1200   700    0.00271528
  1200   725    0.00210484
  1200   750    0.00141752
  1200   775    0.00138774
  1200   800    0.00108935
  1200   825   0.000989807
  1200   850   0.000730577
  1200   875   0.000532656
  1200   925   0.000341021
  1200   975   0.000211179
  1225   550     0.0102449
  1225   575    0.00826679
  1225   600    0.00694361
  1225   625    0.00498368
  1225   650    0.00433882
  1225   675    0.00366553
  1225   700    0.00302524
  1225   725    0.00238197
  1225   750    0.00171346
  1225   775     0.0016555
  1225   800    0.00142989
  1225   825    0.00125352
  1225   850   0.000857442
  1250    25      0.101045
  1250    75     0.0972364
  1250   125     0.0913338
  1250   175     0.0803502
  1250   225     0.0721335
  1250   275     0.0606042
  1250   325       0.04933
  1250   375      0.038697
  1250   425     0.0289051
  1250   475     0.0212747
  1250   525     0.0147184
  1250   550     0.0129828
  1250   575    0.00988551
  1250   600    0.00826564
  1250   625    0.00654802
  1250   650    0.00558085
  1250   675    0.00414111
  1250   700    0.00358091
  1250   725     0.0029941
  1250   750    0.00209659
  1250   775    0.00197824
  1250   800    0.00166966
  1250   825    0.00105625
  1250   850    0.00103976
  1250   875   0.000832491
  1250   925   0.000503976
  1250   975     0.0004421
  1250  1025   0.000201326
  1275   550     0.0151583
  1275   575     0.0123797
  1275   600    0.00999567
  1275   625    0.00809707
  1275   650    0.00673184
  1275   675    0.00515301
  1275   700    0.00396849
  1275   725    0.00355751
  1275   750    0.00247742
  1275   775    0.00221369
  1275   800    0.00186563
  1275   825    0.00150631
  1275   850    0.00112604
  1300    25      0.118352
  1300    75      0.113809
  1300   125      0.107874
  1300   175     0.0991943
  1300   225     0.0886212
  1300   275     0.0787643
  1300   325     0.0648019
  1300   375     0.0515845
  1300   425     0.0399036
  1300   475     0.0299915
  1300   525     0.0210063
  1300   550     0.0182912
  1300   575     0.0151307
  1300   600     0.0123657
  1300   625     0.0100892
  1300   650    0.00849778
  1300   675    0.00692811
  1300   700      0.005281
  1300   725    0.00418182
  1300   750    0.00374489
  1300   775     0.0027869
  1300   800    0.00208448
  1300   825     0.0017935
  1300   850    0.00135168
  1300   875    0.00117287
  1300   925    0.00084513
  1300   975   0.000589736
  1300  1025   0.000361179
  1300  1075   0.000191644
  1325   550     0.0233244
  1325   575      0.018381
  1325   600     0.0152906
  1325   625     0.0121927
  1325   650    0.00994291
  1325   675    0.00788144
  1325   700    0.00659206
  1325   725    0.00563431
  1325   750    0.00437375
  1325   775    0.00332174
  1325   800    0.00275528
  1325   825     0.0023204
  1325   850    0.00178276
  1350    25      0.135186
  1350    75      0.131586
  1350   125      0.123973
  1350   175      0.116921
  1350   225       0.10736
  1350   275     0.0969523
  1350   325     0.0836912
  1350   375     0.0672462
  1350   425     0.0539905
  1350   475     0.0417445
  1350   525     0.0312908
  1350   550     0.0266591
  1350   575     0.0214907
  1350   600     0.0181113
  1350   625     0.0150411
  1350   650     0.0130918
  1350   675     0.0100957
  1350   700    0.00774615
  1350   725    0.00669743
  1350   750    0.00523542
  1350   775    0.00409957
  1350   800    0.00348192
  1350   825    0.00267996
  1350   850    0.00211466
  1350   875    0.00178677
  1350   925    0.00112455
  1350   975   0.000793807
  1350  1025   0.000594072
  1350  1075   0.000312672
  1350  1125   0.000263952
  1375   550     0.0305728
  1375   575     0.0256748
  1375   600     0.0218409
  1375   625     0.0186755
  1375   650     0.0145463
  1375   675      0.012037
  1375   700    0.00953376
  1375   725    0.00778257
  1375   750    0.00616463
  1375   775    0.00470356
  1375   800    0.00390029
  1375   825    0.00311659
  1375   850    0.00248529
  1400    25      0.150753
  1400    75      0.148431
  1400   125      0.142771
  1400   175      0.134424
  1400   225      0.126283
  1400   275      0.113789
  1400   325     0.0984432
  1400   375     0.0860599
  1400   425     0.0719364
  1400   475     0.0576891
  1400   525      0.042588
  1400   550     0.0372107
  1400   575     0.0313437
  1400   600     0.0266515
  1400   625     0.0216311
  1400   650     0.0181884
  1400   675     0.0148605
  1400   700     0.0122282
  1400   725    0.00985491
  1400   750    0.00800974
  1400   775    0.00643573
  1400   800    0.00497873
  1400   825    0.00432938
  1400   850    0.00339876
  1400   875    0.00242037
  1400   925     0.0015777
  1400   975    0.00112625
  1400  1025   0.000755383
  1400  1075   0.000440781
  1400  1125   0.000361704
  1400  1175   0.000211494
*/
