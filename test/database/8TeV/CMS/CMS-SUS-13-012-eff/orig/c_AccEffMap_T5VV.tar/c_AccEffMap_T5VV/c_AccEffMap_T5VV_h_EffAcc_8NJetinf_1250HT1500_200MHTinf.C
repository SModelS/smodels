{
//=========Macro generated from canvas: c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf/c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf
//=========  (Sat Feb 22 16:32:54 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf = new TCanvas("c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf", "c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf",120,336,500,500);
   c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf->SetFillColor(0);
   c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf->SetLogz();
   c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1250HT1500_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1250HT1500_200MHTinf","h_EffAcc_8NJetinf_1250HT1500_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(141,0.0002951078);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(143,0.0005383348);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(145,0.001310209);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(147,0.00221279);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(149,0.003258077);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(151,0.004956661);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(153,0.006988012);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(155,0.008964755);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(157,0.01091117);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(159,0.01343433);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(161,0.01553764);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(163,0.01924993);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(165,0.0202994);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(167,0.02017111);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(169,0.02134424);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(171,0.01955016);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(173,0.01819125);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(175,0.01661043);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(177,0.01546054);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(179,0.01424912);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(181,0.0122728);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(265,0.0003059188);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(267,0.0004941902);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(269,0.0009157375);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(271,0.001787844);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(273,0.002427729);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(275,0.004372279);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(277,0.005896836);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(279,0.007833545);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(281,0.01068785);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(283,0.01300521);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(285,0.01539176);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(287,0.01760033);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(289,0.01852109);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(291,0.02057622);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(293,0.02016748);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(295,0.02033357);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(297,0.0191973);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(299,0.0174317);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(301,0.01589849);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(303,0.01392399);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(305,0.01297466);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(389,0.0001484473);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(391,0.0004594326);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(393,0.0006837678);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(395,0.001330269);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(397,0.002193748);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(399,0.003807392);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(401,0.005475688);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(403,0.006815631);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(405,0.009405134);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(407,0.01144851);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(409,0.01415147);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(411,0.01541865);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(413,0.01867409);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(415,0.01928213);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(417,0.02048996);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(419,0.01943577);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(421,0.01921187);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(423,0.01779887);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(425,0.01686857);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(427,0.01499939);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(429,0.0125843);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(513,0.0001286611);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(515,0.000261335);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(517,0.0004381589);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(519,0.0009401879);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(521,0.001527654);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(523,0.002669541);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(525,0.004108164);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(527,0.005699902);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(529,0.007648539);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(531,0.009147599);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(533,0.01210579);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(535,0.01538398);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(537,0.01694306);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(539,0.01794646);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(541,0.01996251);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(543,0.01937534);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(545,0.01929867);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(547,0.01819261);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(549,0.01680799);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(551,0.0154159);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(553,0.01372269);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(639,0.0001712493);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(641,0.0003448002);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(643,0.0005905298);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(645,0.001020524);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(647,0.001734796);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(649,0.002956713);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(651,0.004099137);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(653,0.005991024);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(655,0.008427955);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(657,0.01099532);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(659,0.01300718);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(661,0.01523321);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(663,0.01728699);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(665,0.01904648);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(667,0.02003517);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(669,0.01985286);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(671,0.0187803);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(673,0.0177832);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(675,0.01585208);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(677,0.01379803);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(765,0.0003115718);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(767,0.0005383171);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(769,0.0008001302);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(771,0.001236355);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(773,0.001961618);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(775,0.003470512);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(777,0.004792453);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(779,0.006699938);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(781,0.008521768);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(783,0.01120465);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(785,0.01324552);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(787,0.01502032);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(789,0.01692744);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(791,0.01874988);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(793,0.01913679);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(795,0.01936964);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(797,0.01896659);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(799,0.01737899);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(801,0.01506126);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(891,0.0002222567);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(893,0.0003936118);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(895,0.0009203502);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(897,0.001482914);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(899,0.002102475);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(901,0.003097819);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(903,0.004720088);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(905,0.007047589);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(907,0.00878593);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(909,0.01144143);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(911,0.01417359);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(913,0.01647309);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(915,0.01799441);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(917,0.01836283);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(919,0.01981609);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(921,0.01917246);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(923,0.01772217);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(925,0.01675605);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1017,0.0002966586);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1019,0.000531877);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1021,0.0008908121);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1023,0.00129847);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1025,0.002303147);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1027,0.003550488);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1029,0.005060065);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1031,0.006619464);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1033,0.009472276);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1035,0.01157337);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1037,0.01390573);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1039,0.01586322);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1041,0.01788224);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1043,0.01908645);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1045,0.01940999);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1047,0.01874882);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1049,0.01747593);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1143,0.0002130354);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1145,0.0005316997);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1147,0.0008514476);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1149,0.001613298);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1151,0.002457703);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1153,0.003280215);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1155,0.005284534);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1157,0.007246678);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1159,0.00941808);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1161,0.01158857);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1163,0.01398368);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1165,0.01661477);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1167,0.01759884);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1169,0.01927974);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1171,0.01909693);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1173,0.01893162);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1269,0.000320548);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1271,0.0005046011);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1273,0.0009481781);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1275,0.001321834);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1277,0.002390965);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1279,0.00357388);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1281,0.005245089);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1283,0.007012755);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1285,0.009633699);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1287,0.01195904);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1289,0.01432137);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1291,0.01660342);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1293,0.0180306);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1295,0.01876349);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1297,0.01813303);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1395,0.0002316557);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1397,0.0006410588);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1399,0.0009817127);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1401,0.001635481);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1403,0.002468905);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1405,0.003682033);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1407,0.005612509);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1409,0.007485111);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1411,0.009764288);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1413,0.01191128);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1415,0.01445059);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1417,0.016769);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1419,0.01743144);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1421,0.0183027);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1473,0.0082069);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1474,0.009789946);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1475,0.01065058);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1476,0.01176121);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1477,0.01367108);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1478,0.01430289);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1479,0.0158182);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1480,0.01710815);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1481,0.01759572);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1482,0.01762983);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1483,0.01891559);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1521,0.0002405287);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1523,0.0005791983);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1525,0.0009209715);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1527,0.00164201);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1529,0.002434482);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1531,0.003678648);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1533,0.00529039);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1535,0.007140888);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1536,0.00864611);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1537,0.009866869);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1538,0.01100983);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1539,0.01154753);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1540,0.01316512);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1541,0.0144035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1542,0.01500564);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1543,0.0169096);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1544,0.01766646);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1545,0.01780827);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1597,0.005682713);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1598,0.007258662);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1599,0.008746795);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1600,0.009342561);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1601,0.01104968);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1602,0.01163964);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1603,0.01323134);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1604,0.01453464);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1605,0.01507156);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1606,0.01652807);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1607,0.01792596);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1647,0.000237609);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1649,0.0005680909);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1651,0.000913999);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1653,0.001606234);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1655,0.002544804);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1657,0.00371535);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1659,0.00523951);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1660,0.005911499);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1661,0.007346452);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1662,0.007852859);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1663,0.009083143);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1664,0.01068457);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1665,0.01257825);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1666,0.012992);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1667,0.01458854);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1668,0.01497302);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1669,0.01615235);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1721,0.004207042);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1722,0.005272348);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1723,0.005937118);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1724,0.006828231);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1725,0.008257356);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1726,0.009494521);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1727,0.01078297);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1728,0.0116073);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1729,0.01345139);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1730,0.01416711);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1731,0.01531841);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1773,0.000209274);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1775,0.0005632348);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1777,0.001033306);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1779,0.001491343);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1781,0.002456998);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1783,0.003337383);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1784,0.004336007);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1785,0.005296202);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1786,0.005869543);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1787,0.007178882);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1788,0.007904947);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1789,0.009649833);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1790,0.01057105);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1791,0.01158069);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1792,0.01269999);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1793,0.01450703);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1845,0.002919542);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1846,0.003575876);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1847,0.004092008);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1848,0.004839327);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1849,0.005782964);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1850,0.007342926);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1851,0.00793697);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1852,0.009291112);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1853,0.01082716);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1854,0.01185208);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1855,0.01302193);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1899,0.0002581691);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1901,0.0004681961);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1903,0.001044161);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1905,0.001384267);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1907,0.00243572);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1908,0.003035258);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1909,0.003783843);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1910,0.004367175);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1911,0.004957384);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1912,0.00610034);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1913,0.006846331);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1914,0.008404759);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1915,0.009120117);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1916,0.01005536);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1917,0.01195347);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1969,0.001754521);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1970,0.002334409);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1971,0.002805831);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1972,0.003525079);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1973,0.004326787);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1974,0.00489096);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1975,0.005848721);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1976,0.00682784);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1977,0.008300968);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1978,0.009287388);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1979,0.01036712);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2025,0.0001967876);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2027,0.0004278107);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2029,0.0009204068);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2031,0.001499083);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2032,0.002107094);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2033,0.002256968);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2034,0.002958859);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2035,0.003301258);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2036,0.004418107);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2037,0.005178221);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2038,0.005965448);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2039,0.007204071);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2040,0.007880675);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2041,0.009038423);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2093,0.001095457);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2094,0.001350833);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2095,0.00195547);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2096,0.002285039);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2097,0.002895384);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2098,0.003396769);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2099,0.003768528);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2100,0.005111019);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2101,0.005942733);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2102,0.006765429);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2103,0.007706689);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2151,0.0002159027);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2153,0.0004141098);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2155,0.0008742315);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2156,0.001130874);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2157,0.00148765);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2158,0.001649343);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2159,0.002251004);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2160,0.002735617);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2161,0.003337632);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2162,0.004039146);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2163,0.004995785);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2164,0.005931445);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2165,0.006914067);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2217,0.0008324598);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2218,0.0008234436);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2219,0.001125043);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2220,0.001406613);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2221,0.001972427);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2222,0.002145731);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2223,0.002386023);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2224,0.003540555);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2225,0.004303896);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2226,0.00490306);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2227,0.005609037);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2277,0.0001357768);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2279,0.0004656771);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2281,0.0007808295);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2283,0.001377602);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2285,0.002350692);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2287,0.003249012);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2289,0.005047111);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2403,0.0002285253);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2405,0.0004074644);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2407,0.0006423762);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2409,0.001335514);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2411,0.002092655);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2413,0.003449426);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2529,0.0002111789);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2531,0.0004661271);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2533,0.0008127742);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2535,0.001358329);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2537,0.002109978);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2655,0.0002396732);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2657,0.0003934829);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2659,0.0006775174);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2661,0.001256551);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2781,7.499098e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2783,0.0003940893);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2785,0.0007636441);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2907,0.0002081009);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2909,0.0003714999);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(3033,0.0001874609);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(141,4.798627e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(143,6.366462e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(145,0.0001067126);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(147,0.0001328846);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(149,0.0001608082);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(151,0.0002083841);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(153,0.0002554797);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(155,0.0002734701);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(157,0.0003068156);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(159,0.000334872);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(161,0.0003656773);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(163,0.0004497478);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(165,0.0004566574);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(167,0.000402871);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(169,0.0004190628);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(171,0.0003922038);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(173,0.0003774897);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(175,0.0003578856);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(177,0.0003432883);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(179,0.0003274646);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(181,0.0003010451);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(265,4.974288e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(267,6.14815e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(269,8.425412e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(271,0.000118945);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(273,0.0001381007);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(275,0.0001947776);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(277,0.000216558);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(279,0.0002568656);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(281,0.000299763);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(283,0.0003605595);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(285,0.0003605837);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(287,0.0004011289);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(289,0.0003865118);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(291,0.0004066591);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(293,0.0004101376);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(295,0.0004000816);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(297,0.000387373);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(299,0.0003658939);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(301,0.0003476852);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(303,0.0003229132);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(305,0.0003091653);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(389,3.329829e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(391,6.101137e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(393,7.306446e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(395,0.0001012235);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(397,0.0001326363);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(399,0.0001748208);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(401,0.0002083878);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(403,0.0002336883);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(405,0.0002745898);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(407,0.0003301763);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(409,0.0003648859);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(411,0.0003537751);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(413,0.0004717996);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(415,0.0003979673);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(417,0.0004491503);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(419,0.0003896327);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(421,0.0003860546);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(423,0.0003698251);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(425,0.0003574691);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(427,0.000335525);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(429,0.000304064);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(513,3.034032e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(515,4.782434e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(517,5.87045e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(519,8.471274e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(521,0.0001098321);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(523,0.0001437803);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(525,0.0001939262);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(527,0.0002134791);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(529,0.0002458204);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(531,0.000273158);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(533,0.0003202384);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(535,0.0003537218);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(537,0.0003673989);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(539,0.0004569371);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(541,0.0004005617);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(543,0.0003886248);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(545,0.0003863774);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(547,0.0003858478);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(549,0.000356633);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(551,0.0003396236);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(553,0.0003176708);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(639,3.577946e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(641,5.150931e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(643,6.836409e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(645,8.948987e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(647,0.0001218793);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(649,0.0001595374);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(651,0.0001815322);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(653,0.0002161785);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(655,0.0002940617);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(657,0.000306349);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(659,0.0003197839);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(661,0.0003517012);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(663,0.000378331);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(665,0.0003950891);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(667,0.0003951638);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(669,0.0003916755);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(671,0.0003820314);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(673,0.0003668209);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(675,0.0003441339);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(677,0.0003183755);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(765,4.873721e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(767,6.400126e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(769,7.790663e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(771,9.713806e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(773,0.0001240238);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(775,0.0001655615);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(777,0.0002016578);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(779,0.000239663);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(781,0.0002809905);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(783,0.000295034);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(785,0.000320524);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(787,0.0003409439);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(789,0.0003629119);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(791,0.000380623);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(793,0.0003832673);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(795,0.0003839648);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(797,0.0003792399);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(799,0.000359531);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(801,0.0003325803);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(891,4.058379e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(893,5.523291e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(895,8.2795e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(897,0.0001076227);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(899,0.0001259009);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(901,0.0001683738);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(903,0.0001953628);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(905,0.0002325761);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(907,0.0002589814);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(909,0.0003104091);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(911,0.0003298287);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(913,0.0004050465);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(915,0.0003709086);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(917,0.000373339);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(919,0.000387706);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(921,0.0003796177);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(923,0.0003623839);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(925,0.00035101);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1017,4.69463e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1019,6.274412e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1021,8.179209e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1023,9.873147e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1025,0.000132785);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1027,0.0001852898);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1029,0.0001945818);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1031,0.0002235963);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1033,0.0003074678);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1035,0.0003478387);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1037,0.0003242042);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1039,0.0003468509);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1041,0.0003671511);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1043,0.0003779652);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1045,0.0003819557);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1047,0.0003717531);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1049,0.0003579947);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1143,4.028553e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1145,6.40789e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1147,7.958343e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1149,0.0001100674);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1151,0.0001346717);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1153,0.0001612473);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1155,0.0002954658);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1157,0.0002323904);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1159,0.0002764554);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1161,0.0003173426);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1163,0.0003231348);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1165,0.0003529822);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1167,0.0003619831);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1169,0.0003778812);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1171,0.0003759926);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1173,0.0003714765);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1269,4.833378e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1271,6.217818e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1273,8.335537e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1275,9.999931e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1277,0.0001330047);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1279,0.0001956784);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1281,0.000207997);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1283,0.000230624);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1285,0.0002665436);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1287,0.0002958267);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1289,0.0003253333);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1291,0.0003505716);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1293,0.0003641981);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1295,0.0003707411);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1297,0.0003739419);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1395,4.303446e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1397,6.801097e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1399,8.463281e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1401,0.0001134407);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1403,0.0001330233);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1405,0.0001789412);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1407,0.0002013965);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1409,0.0002395713);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1411,0.0002654125);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1413,0.0002935469);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1415,0.0003242769);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1417,0.0003490987);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1419,0.0003558922);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1421,0.0003659097);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1473,0.0002417665);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1474,0.0002676905);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1475,0.0002831596);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1476,0.0003104821);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1477,0.0003259907);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1478,0.0003506212);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1479,0.0003583685);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1480,0.0003759891);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1481,0.0003678478);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1482,0.0003772569);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1483,0.0003901533);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1521,4.188627e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1523,6.445753e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1525,8.247965e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1527,0.0001081039);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1529,0.0001312001);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1531,0.0001613864);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1533,0.000200885);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1535,0.0002254492);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1536,0.000378908);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1537,0.0002805952);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1538,0.0002803861);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1539,0.0002872504);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1540,0.0003330609);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1541,0.0003211936);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1542,0.0003583276);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1543,0.0003511666);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1544,0.0003566318);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1545,0.0003649315);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1597,0.0002021355);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1598,0.0002279248);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1599,0.0002549687);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1600,0.0002652874);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1601,0.0002804506);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1602,0.000287609);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1603,0.0003071423);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1604,0.0003668419);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1605,0.0003324616);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1606,0.0003630545);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1607,0.0003599702);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1647,4.138643e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1649,6.441218e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1651,8.058488e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1653,0.0001059768);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1655,0.0001333614);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1657,0.0001714746);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1659,0.0001910302);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1660,0.0002036174);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1661,0.0002355565);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1662,0.0002447236);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1663,0.0002561769);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1664,0.0002744379);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1665,0.0003102066);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1666,0.0003172492);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1667,0.0003342818);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1668,0.0003253896);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1669,0.0003773736);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1721,0.000170186);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1722,0.0001913332);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1723,0.000262399);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1724,0.0002243878);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1725,0.0002507661);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1726,0.0002591955);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1727,0.0003081559);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1728,0.0002866867);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1729,0.0003146166);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1730,0.0003203179);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1731,0.0003726685);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1773,3.888853e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1775,6.341912e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1777,8.45034e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1779,0.0001036556);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1781,0.0001329886);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1783,0.0001546871);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1784,0.0001794998);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1785,0.0001958006);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1786,0.000200939);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1787,0.0002244796);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1788,0.0002412158);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1789,0.0003091061);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1790,0.0002920515);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1791,0.0002981337);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1792,0.0002972705);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1793,0.0003216321);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1845,0.0001407438);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1846,0.0001907682);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1847,0.0001753067);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1848,0.000208915);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1849,0.0002067406);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1850,0.0002645049);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1851,0.0002387307);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1852,0.0002636362);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1853,0.0002912996);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1854,0.0002857427);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1855,0.000302648);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1899,4.305997e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1901,5.685479e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1903,9.068997e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1905,0.0001125879);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1907,0.0001314208);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1908,0.0001437516);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1909,0.0001593929);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1910,0.0001852699);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1911,0.0001831231);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1912,0.0002153268);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1913,0.0002275537);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1914,0.0002469048);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1915,0.0003082653);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1916,0.0002731997);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1917,0.0003054331);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1969,0.0001128822);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1970,0.0001261157);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1971,0.0001366003);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1972,0.0001784774);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1973,0.0001768698);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1974,0.000181888);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1975,0.0002641301);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1976,0.0002161323);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1977,0.0002371957);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1978,0.0002853308);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1979,0.0002675367);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2025,3.720367e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2027,5.479655e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2029,7.997589e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2031,9.974404e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2032,0.0001202521);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2033,0.0001224714);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2034,0.0001405193);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2035,0.0001499798);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2036,0.0001738489);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2037,0.0001863795);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2038,0.0001994734);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2039,0.0002320634);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2040,0.0002392721);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2041,0.0002646211);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2093,8.491551e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2094,0.0001014802);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2095,0.000120029);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2096,0.0001231131);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2097,0.0001405444);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2098,0.0001515374);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2099,0.0001590873);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2100,0.0002017956);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2101,0.0002025281);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2102,0.000224246);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2103,0.0002395529);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2151,3.820703e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2153,5.350816e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2155,7.649923e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2156,8.643245e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2157,0.0001054939);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2158,0.0001059014);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2159,0.0001228452);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2160,0.0001441887);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2161,0.0001510514);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2162,0.0001944416);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2163,0.0001836479);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2164,0.0002006588);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2165,0.0002183811);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2217,7.57887e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2218,7.346469e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2219,0.0001037828);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2220,9.732499e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2221,0.0001135214);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2222,0.0001185987);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2223,0.0001337298);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2224,0.0001580441);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2225,0.0001771206);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2226,0.0001784921);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2227,0.0002004307);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2277,3.12014e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2279,5.738059e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2281,7.107299e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2283,9.438372e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2285,0.0001324913);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2287,0.0001450043);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2289,0.0001803422);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2403,5.901314e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2405,5.138942e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2407,7.580343e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2409,0.0001017582);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2411,0.0001154499);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2413,0.0001478015);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2529,4.224117e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2531,5.499272e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2533,7.167657e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2535,0.0001123756);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2537,0.0001144475);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2655,4.794161e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2657,4.95995e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2659,6.49994e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2661,8.859577e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2781,2.499813e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2783,4.929693e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2785,6.840336e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2907,3.569352e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2909,4.761561e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(3033,3.48317e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetEntries(411386);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->Draw("colz");
   c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf->Modified();
   c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf->cd();
   c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf->SetSelected(c_AccEffMap_T5VV_8NJetinf_1250HT1500_200MHTinf);
}
/*
   400    25   0.000295108
   400    75   0.000305919
   400   125   0.000148447
   400   175   0.000128661
   450    25   0.000538335
   450    75    0.00049419
   450   125   0.000459433
   450   175   0.000261335
   450   225   0.000171249
   500    25    0.00131021
   500    75   0.000915738
   500   125   0.000683768
   500   175   0.000438159
   500   225     0.0003448
   500   275   0.000311572
   550    25    0.00221279
   550    75    0.00178784
   550   125    0.00133027
   550   175   0.000940188
   550   225    0.00059053
   550   275   0.000538317
   550   325   0.000222257
   600    25    0.00325808
   600    75    0.00242773
   600   125    0.00219375
   600   175    0.00152765
   600   225    0.00102052
   600   275    0.00080013
   600   325   0.000393612
   600   375   0.000296659
   650    25    0.00495666
   650    75    0.00437228
   650   125    0.00380739
   650   175    0.00266954
   650   225     0.0017348
   650   275    0.00123635
   650   325    0.00092035
   650   375   0.000531877
   650   425   0.000213035
   700    25    0.00698801
   700    75    0.00589684
   700   125    0.00547569
   700   175    0.00410816
   700   225    0.00295671
   700   275    0.00196162
   700   325    0.00148291
   700   375   0.000890812
   700   425     0.0005317
   700   475   0.000320548
   750    25    0.00896476
   750    75    0.00783355
   750   125    0.00681563
   750   175     0.0056999
   750   225    0.00409914
   750   275    0.00347051
   750   325    0.00210248
   750   375    0.00129847
   750   425   0.000851448
   750   475   0.000504601
   750   525   0.000231656
   800    25     0.0109112
   800    75     0.0106879
   800   125    0.00940513
   800   175    0.00764854
   800   225    0.00599102
   800   275    0.00479245
   800   325    0.00309782
   800   375    0.00230315
   800   425     0.0016133
   800   475   0.000948178
   800   525   0.000641059
   800   575   0.000240529
   850    25     0.0134343
   850    75     0.0130052
   850   125     0.0114485
   850   175     0.0091476
   850   225    0.00842795
   850   275    0.00669994
   850   325    0.00472009
   850   375    0.00355049
   850   425     0.0024577
   850   475    0.00132183
   850   525   0.000981713
   850   575   0.000579198
   850   625   0.000237609
   900    25     0.0155376
   900    75     0.0153918
   900   125     0.0141515
   900   175     0.0121058
   900   225     0.0109953
   900   275    0.00852177
   900   325    0.00704759
   900   375    0.00506007
   900   425    0.00328021
   900   475    0.00239096
   900   525    0.00163548
   900   575   0.000920972
   900   625   0.000568091
   900   675   0.000209274
   950    25     0.0192499
   950    75     0.0176003
   950   125     0.0154186
   950   175      0.015384
   950   225     0.0130072
   950   275     0.0112047
   950   325    0.00878593
   950   375    0.00661946
   950   425    0.00528453
   950   475    0.00357388
   950   525     0.0024689
   950   575    0.00164201
   950   625   0.000913999
   950   675   0.000563235
   950   725   0.000258169
  1000    25     0.0202994
  1000    75     0.0185211
  1000   125     0.0186741
  1000   175     0.0169431
  1000   225     0.0152332
  1000   275     0.0132455
  1000   325     0.0114414
  1000   375    0.00947228
  1000   425    0.00724668
  1000   475    0.00524509
  1000   525    0.00368203
  1000   575    0.00243448
  1000   625    0.00160623
  1000   675    0.00103331
  1000   725   0.000468196
  1000   775   0.000196788
  1050    25     0.0201711
  1050    75     0.0205762
  1050   125     0.0192821
  1050   175     0.0179465
  1050   225      0.017287
  1050   275     0.0150203
  1050   325     0.0141736
  1050   375     0.0115734
  1050   425    0.00941808
  1050   475    0.00701276
  1050   525    0.00561251
  1050   575    0.00367865
  1050   625     0.0025448
  1050   675    0.00149134
  1050   725    0.00104416
  1050   775   0.000427811
  1050   825   0.000215903
  1100    25     0.0213442
  1100    75     0.0201675
  1100   125       0.02049
  1100   175     0.0199625
  1100   225     0.0190465
  1100   275     0.0169274
  1100   325     0.0164731
  1100   375     0.0139057
  1100   425     0.0115886
  1100   475     0.0096337
  1100   525    0.00748511
  1100   575    0.00529039
  1100   625    0.00371535
  1100   675      0.002457
  1100   725    0.00138427
  1100   775   0.000920407
  1100   825    0.00041411
  1100   875   0.000135777
  1150    25     0.0195502
  1150    75     0.0203336
  1150   125     0.0194358
  1150   175     0.0193753
  1150   225     0.0200352
  1150   275     0.0187499
  1150   325     0.0179944
  1150   375     0.0158632
  1150   425     0.0139837
  1150   475      0.011959
  1150   525    0.00976429
  1150   550     0.0082069
  1150   575    0.00714089
  1150   600    0.00568271
  1150   625    0.00523951
  1150   650    0.00420704
  1150   675    0.00333738
  1150   700    0.00291954
  1150   725    0.00243572
  1150   750    0.00175452
  1150   775    0.00149908
  1150   800    0.00109546
  1150   825   0.000874231
  1150   850    0.00083246
  1150   875   0.000465677
  1150   925   0.000228525
  1175   550    0.00978995
  1175   575    0.00864611
  1175   600    0.00725866
  1175   625     0.0059115
  1175   650    0.00527235
  1175   675    0.00433601
  1175   700    0.00357588
  1175   725    0.00303526
  1175   750    0.00233441
  1175   775    0.00210709
  1175   800    0.00135083
  1175   825    0.00113087
  1175   850   0.000823444
  1200    25     0.0181912
  1200    75     0.0191973
  1200   125     0.0192119
  1200   175     0.0192987
  1200   225     0.0198529
  1200   275     0.0191368
  1200   325     0.0183628
  1200   375     0.0178822
  1200   425     0.0166148
  1200   475     0.0143214
  1200   525     0.0119113
  1200   550     0.0106506
  1200   575    0.00986687
  1200   600     0.0087468
  1200   625    0.00734645
  1200   650    0.00593712
  1200   675     0.0052962
  1200   700    0.00409201
  1200   725    0.00378384
  1200   750    0.00280583
  1200   775    0.00225697
  1200   800    0.00195547
  1200   825    0.00148765
  1200   850    0.00112504
  1200   875   0.000780829
  1200   925   0.000407464
  1200   975   0.000211179
  1225   550     0.0117612
  1225   575     0.0110098
  1225   600    0.00934256
  1225   625    0.00785286
  1225   650    0.00682823
  1225   675    0.00586954
  1225   700    0.00483933
  1225   725    0.00436717
  1225   750    0.00352508
  1225   775    0.00295886
  1225   800    0.00228504
  1225   825    0.00164934
  1225   850    0.00140661
  1250    25     0.0166104
  1250    75     0.0174317
  1250   125     0.0177989
  1250   175     0.0181926
  1250   225     0.0187803
  1250   275     0.0193696
  1250   325     0.0198161
  1250   375     0.0190864
  1250   425     0.0175988
  1250   475     0.0166034
  1250   525     0.0144506
  1250   550     0.0136711
  1250   575     0.0115475
  1250   600     0.0110497
  1250   625    0.00908314
  1250   650    0.00825736
  1250   675    0.00717888
  1250   700    0.00578296
  1250   725    0.00495738
  1250   750    0.00432679
  1250   775    0.00330126
  1250   800    0.00289538
  1250   825      0.002251
  1250   850    0.00197243
  1250   875     0.0013776
  1250   925   0.000642376
  1250   975   0.000466127
  1250  1025   0.000239673
  1275   550     0.0143029
  1275   575     0.0131651
  1275   600     0.0116396
  1275   625     0.0106846
  1275   650    0.00949452
  1275   675    0.00790495
  1275   700    0.00734293
  1275   725    0.00610034
  1275   750    0.00489096
  1275   775    0.00441811
  1275   800    0.00339677
  1275   825    0.00273562
  1275   850    0.00214573
  1300    25     0.0154605
  1300    75     0.0158985
  1300   125     0.0168686
  1300   175      0.016808
  1300   225     0.0177832
  1300   275     0.0189666
  1300   325     0.0191725
  1300   375       0.01941
  1300   425     0.0192797
  1300   475     0.0180306
  1300   525      0.016769
  1300   550     0.0158182
  1300   575     0.0144035
  1300   600     0.0132313
  1300   625     0.0125782
  1300   650      0.010783
  1300   675    0.00964983
  1300   700    0.00793697
  1300   725    0.00684633
  1300   750    0.00584872
  1300   775    0.00517822
  1300   800    0.00376853
  1300   825    0.00333763
  1300   850    0.00238602
  1300   875    0.00235069
  1300   925    0.00133551
  1300   975   0.000812774
  1300  1025   0.000393483
  1300  1075    7.4991e-05
  1325   550     0.0171081
  1325   575     0.0150056
  1325   600     0.0145346
  1325   625      0.012992
  1325   650     0.0116073
  1325   675      0.010571
  1325   700    0.00929111
  1325   725    0.00840476
  1325   750    0.00682784
  1325   775    0.00596545
  1325   800    0.00511102
  1325   825    0.00403915
  1325   850    0.00354056
  1350    25     0.0142491
  1350    75      0.013924
  1350   125     0.0149994
  1350   175     0.0154159
  1350   225     0.0158521
  1350   275      0.017379
  1350   325     0.0177222
  1350   375     0.0187488
  1350   425     0.0190969
  1350   475     0.0187635
  1350   525     0.0174314
  1350   550     0.0175957
  1350   575     0.0169096
  1350   600     0.0150716
  1350   625     0.0145885
  1350   650     0.0134514
  1350   675     0.0115807
  1350   700     0.0108272
  1350   725    0.00912012
  1350   750    0.00830097
  1350   775    0.00720407
  1350   800    0.00594273
  1350   825    0.00499578
  1350   850     0.0043039
  1350   875    0.00324901
  1350   925    0.00209266
  1350   975    0.00135833
  1350  1025   0.000677517
  1350  1075   0.000394089
  1350  1125   0.000208101
  1375   550     0.0176298
  1375   575     0.0176665
  1375   600     0.0165281
  1375   625      0.014973
  1375   650     0.0141671
  1375   675        0.0127
  1375   700     0.0118521
  1375   725     0.0100554
  1375   750    0.00928739
  1375   775    0.00788067
  1375   800    0.00676543
  1375   825    0.00593145
  1375   850    0.00490306
  1400    25     0.0122728
  1400    75     0.0129747
  1400   125     0.0125843
  1400   175     0.0137227
  1400   225      0.013798
  1400   275     0.0150613
  1400   325     0.0167561
  1400   375     0.0174759
  1400   425     0.0189316
  1400   475      0.018133
  1400   525     0.0183027
  1400   550     0.0189156
  1400   575     0.0178083
  1400   600      0.017926
  1400   625     0.0161523
  1400   650     0.0153184
  1400   675      0.014507
  1400   700     0.0130219
  1400   725     0.0119535
  1400   750     0.0103671
  1400   775    0.00903842
  1400   800    0.00770669
  1400   825    0.00691407
  1400   850    0.00560904
  1400   875    0.00504711
  1400   925    0.00344943
  1400   975    0.00210998
  1400  1025    0.00125655
  1400  1075   0.000763644
  1400  1125     0.0003715
  1400  1175   0.000187461
*/
