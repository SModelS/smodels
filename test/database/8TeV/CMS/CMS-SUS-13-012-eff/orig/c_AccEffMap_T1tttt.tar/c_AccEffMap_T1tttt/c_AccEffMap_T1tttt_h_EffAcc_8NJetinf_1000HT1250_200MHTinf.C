{
//=========Macro generated from canvas: c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf/c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf
//=========  (Sat Feb 22 16:31:37 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf = new TCanvas("c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf", "c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf",115,312,500,500);
   c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf->SetFillColor(0);
   c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf->SetLogz();
   c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1000HT1250_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1000HT1250_200MHTinf","h_EffAcc_8NJetinf_1000HT1250_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(79,0.000177919);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(81,0.0006022949);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(83,0.001951608);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(85,0.003387464);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(87,0.006600752);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(89,0.009720871);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(91,0.01387915);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(93,0.01807058);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(95,0.02264865);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(97,0.02604278);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(99,0.02842584);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(101,0.02934203);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(103,0.02878594);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(105,0.02910715);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(107,0.02725339);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(109,0.02388271);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(111,0.02264509);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(113,0.02041836);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(115,0.01747927);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(117,0.01621423);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(119,0.01322873);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(141,0.0003312842);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(143,0.0007584669);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(145,0.001794394);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(147,0.003462906);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(149,0.006126864);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(151,0.01008995);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(153,0.0134419);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(155,0.01803839);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(156,0.02049298);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(158,0.02459964);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(160,0.02731852);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(162,0.02926999);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(164,0.03005766);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(166,0.02953162);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(168,0.02752959);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(169,0.02709406);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(171,0.02450924);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(173,0.02222653);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(175,0.02015585);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(177,0.01767632);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(179,0.01622125);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(181,0.01394176);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(265,0.0002758449);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(267,0.0004004221);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(269,0.001318804);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(271,0.002908477);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(273,0.005366931);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(275,0.008230428);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(277,0.01327061);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(279,0.01638515);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(280,0.01999802);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(282,0.02353419);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(284,0.02825297);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(286,0.02988456);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(288,0.03045067);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(290,0.03173768);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(292,0.0297503);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(293,0.02872662);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(295,0.02651124);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(297,0.02381821);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(299,0.02190396);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(301,0.01858376);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(303,0.01713581);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(305,0.01404773);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(389,0.0001933183);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(391,0.0003577738);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(393,0.0006502048);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(395,0.002177245);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(397,0.003797718);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(399,0.007461082);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(401,0.0109391);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(403,0.01512388);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(404,0.01728123);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(406,0.0216267);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(408,0.0266764);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(410,0.02915549);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(412,0.03069586);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(414,0.03201633);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(416,0.03189038);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(417,0.02936832);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(419,0.02738953);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(421,0.02529357);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(423,0.0230436);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(425,0.02033706);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(427,0.01761849);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(429,0.01497911);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(513,0.0001438825);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(515,0.000285139);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(517,0.0006555507);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(519,0.001129268);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(521,0.002541182);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(523,0.004954207);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(525,0.008245161);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(527,0.01202863);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(528,0.01408916);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(530,0.01959812);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(532,0.02442762);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(534,0.02712818);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(536,0.03144563);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(538,0.03244824);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(540,0.03315994);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(541,0.03086682);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(543,0.02941602);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(545,0.02702226);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(547,0.02480828);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(549,0.02218904);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(551,0.0193077);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(553,0.01737314);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(639,0.0002099453);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(641,0.0003679107);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(643,0.0006949464);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(645,0.001276961);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(647,0.002889263);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(649,0.005849943);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(651,0.009081142);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(652,0.01130877);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(654,0.0160172);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(656,0.02065313);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(658,0.02571045);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(660,0.02971337);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(662,0.03172607);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(664,0.03281588);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(665,0.03252319);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(667,0.03089928);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(669,0.02913902);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(671,0.02637335);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(673,0.02310845);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(675,0.02100444);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(677,0.01888551);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(765,0.0002203746);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(767,0.0004856622);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(769,0.0008959878);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(771,0.001683284);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(773,0.003482394);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(775,0.005931264);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(776,0.007966264);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(778,0.01213262);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(780,0.01722316);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(782,0.02213943);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(784,0.02668542);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(786,0.03148696);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(788,0.03376688);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(789,0.03339979);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(791,0.03447028);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(793,0.03170148);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(795,0.02968554);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(797,0.02724783);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(799,0.02361925);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(801,0.0208173);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(891,0.0003414701);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(893,0.0006595692);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(895,0.001213314);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(897,0.002205776);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(899,0.003877593);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(900,0.005115862);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(902,0.008489041);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(904,0.01252451);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(906,0.01800058);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(908,0.0231169);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(910,0.02834478);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(912,0.03176269);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(913,0.03305499);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(915,0.03437978);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(917,0.03341943);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(919,0.03136672);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(921,0.02940097);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(923,0.02680778);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(925,0.02250294);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1017,0.000306374);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1019,0.0006440432);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1021,0.001250823);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1023,0.002183558);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1024,0.003300229);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1026,0.005472374);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1028,0.008574542);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1030,0.01267936);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1032,0.01773188);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1034,0.02369351);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1036,0.02796732);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1037,0.03116543);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1039,0.03498923);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1041,0.03407426);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1043,0.03381151);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1045,0.03194097);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1047,0.02963468);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1049,0.02601504);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1143,0.0002437522);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1145,0.0007184293);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1147,0.001137648);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1148,0.001747243);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1150,0.003381233);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1152,0.005345069);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1154,0.008975362);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1156,0.01380433);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1158,0.01869314);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1160,0.02344323);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1161,0.02620719);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1163,0.0311183);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1165,0.03444697);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1167,0.03444624);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1169,0.03400028);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1171,0.03097561);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1173,0.02921669);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1269,0.0003521623);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1271,0.000798605);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1272,0.000984673);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1274,0.00197728);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1276,0.003102697);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1278,0.005715949);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1280,0.00947064);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1282,0.01379596);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1284,0.01915818);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1285,0.02238668);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1287,0.02660377);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1289,0.03150132);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1291,0.03511138);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1293,0.03478107);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1295,0.03371034);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1297,0.0319166);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1395,0.0002715292);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1396,0.0005470359);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1398,0.0008599108);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1400,0.002043209);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1402,0.003766508);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1404,0.00574862);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1406,0.009115281);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1408,0.01385471);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1409,0.01696739);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1410,0.01988955);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1411,0.0214596);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1412,0.02454489);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1413,0.02704699);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1414,0.03018521);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1415,0.03244622);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1416,0.03427135);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1417,0.03441512);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1418,0.03612078);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1419,0.03550586);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1420,0.03517664);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1421,0.03350511);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1471,0.01312075);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1472,0.01645897);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1473,0.01960693);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1474,0.02180146);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1475,0.0246994);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1476,0.02726536);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1477,0.02963069);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1478,0.03158864);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1479,0.03338063);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1480,0.03571045);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1481,0.03544468);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1482,0.0355244);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1483,0.03489727);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1520,0.0001791104);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1522,0.0005877243);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1524,0.001078958);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1526,0.002150267);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1528,0.003416422);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1530,0.006120038);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1532,0.009194444);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1533,0.01106615);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1534,0.01345644);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1535,0.01619595);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1536,0.01942779);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1537,0.02240563);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1538,0.02493793);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1539,0.02825355);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1540,0.03072828);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1541,0.03307349);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1542,0.03416179);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1543,0.03471346);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1544,0.03525738);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1545,0.03534704);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1595,0.009396143);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1596,0.01128812);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1597,0.01307391);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1598,0.01597612);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1599,0.01855383);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1600,0.02197156);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1601,0.02501561);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1602,0.02887419);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1603,0.03080464);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1604,0.03150931);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1605,0.03467379);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1606,0.03524763);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1607,0.03583497);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1646,0.0001444683);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1648,0.0004111932);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1650,0.001064403);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1652,0.002205671);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1654,0.00312238);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1656,0.005491472);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1657,0.007472017);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1658,0.009020907);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1659,0.0112854);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1660,0.01391028);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1661,0.01591785);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1662,0.01952032);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1663,0.02237574);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1664,0.02495968);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1665,0.02774991);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1666,0.03023538);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1667,0.03203539);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1668,0.03407656);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1669,0.03628945);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1719,0.005436957);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1720,0.007369591);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1721,0.009724953);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1722,0.01204684);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1723,0.01413383);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1724,0.01639484);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1725,0.01919241);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1726,0.02192936);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1727,0.02516322);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1728,0.02808275);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1729,0.03026005);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1730,0.03229444);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1731,0.03480314);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1772,0.0001969909);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1774,0.0004427362);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1776,0.001071855);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1778,0.001896556);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1780,0.003485509);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1781,0.004825768);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1782,0.005852203);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1783,0.007440918);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1784,0.009363616);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1785,0.01103992);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1786,0.01316991);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1787,0.01654599);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1788,0.01885546);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1789,0.02240887);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1790,0.02548886);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1791,0.02829358);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1792,0.03064837);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1793,0.03297412);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1843,0.003495523);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1844,0.004786961);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1845,0.006019635);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1846,0.007716757);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1847,0.009069211);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1848,0.011395);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1849,0.01332591);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1850,0.01582431);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1851,0.01904987);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1852,0.02216807);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1853,0.02501678);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1854,0.0276031);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1855,0.03004746);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1898,0.0001387334);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1900,0.0004243422);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1902,0.0009352134);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1904,0.002109747);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1905,0.002393814);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1906,0.003324568);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1907,0.004600775);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1908,0.005279853);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1909,0.007390716);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1910,0.008731866);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1911,0.01141272);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1912,0.01395735);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1913,0.0162746);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1914,0.01903429);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1915,0.02248329);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1916,0.02565486);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1917,0.02778032);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1967,0.002065662);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1968,0.002424224);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1969,0.003518156);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1970,0.004515335);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1971,0.005379297);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1972,0.007214676);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1973,0.009387767);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1974,0.01126027);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1975,0.01379254);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1976,0.01664223);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1977,0.0188038);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1978,0.02279157);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1979,0.02477773);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2024,0.000131056);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2026,0.0004522646);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2028,0.0007726194);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2029,0.001356661);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2030,0.002063701);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2031,0.002618746);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2032,0.003338558);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2033,0.004166976);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2034,0.005423518);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2035,0.007153787);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2036,0.009031106);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2037,0.01104687);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2038,0.0136261);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2039,0.01618711);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2040,0.01838341);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2041,0.02263126);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2091,0.0008102924);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2092,0.0013288);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2093,0.002141428);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2094,0.002556192);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2095,0.003292369);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2096,0.004280554);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2097,0.00527928);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2098,0.006403927);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2099,0.00885167);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2100,0.01122653);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2101,0.01365577);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2102,0.01653587);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2103,0.01873025);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2150,0.0001150483);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2152,0.000349965);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2153,0.0006294963);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2154,0.0009594653);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2155,0.00120778);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2156,0.001998632);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2157,0.002691764);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2158,0.003254121);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2159,0.004396118);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2160,0.005314663);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2161,0.00709581);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2162,0.008880396);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2163,0.01063677);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2164,0.01332742);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2165,0.01676268);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2215,0.000368737);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2216,0.0005960488);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2217,0.0008201771);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2218,0.00125411);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2219,0.00175902);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2220,0.002465859);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2221,0.003316576);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2222,0.003720184);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2223,0.005629037);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2224,0.007187471);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2225,0.008875286);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2226,0.01021487);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2227,0.01330264);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2276,0.0001128849);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2277,0.0002466532);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2278,0.0003769902);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2279,0.0005407433);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2280,0.0008947266);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2281,0.001144411);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2282,0.002059183);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2283,0.002505128);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2284,0.003092351);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2285,0.00416287);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2286,0.005394003);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2287,0.006874214);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2288,0.008277277);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2289,0.01097615);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2339,0.0001814073);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2340,0.0002554388);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2341,0.0002430355);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2342,0.0004945054);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2343,0.0007721634);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2344,0.001270245);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2345,0.001935755);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2346,0.00224726);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2347,0.003116928);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2348,0.004361833);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2349,0.005237187);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2350,0.006756068);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2351,0.008130372);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2402,9.321051e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2403,0.0001652838);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2404,0.0002643888);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2405,0.0004420427);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2406,0.0007930858);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2407,0.00119168);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2408,0.001796585);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2409,0.002271146);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2410,0.003067513);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2411,0.003911547);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2412,0.005272913);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2413,0.007342084);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2465,8.50043e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2466,0.0002271128);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2467,0.0004466879);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2468,0.0005351038);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2469,0.0008678354);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2470,0.001122151);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2471,0.002014187);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2472,0.00246986);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2473,0.003016028);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2474,0.003970152);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2475,0.005267183);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2528,0.0001245306);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2529,0.0001080303);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2530,0.0003473249);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2531,0.0006232579);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2532,0.0007111816);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2533,0.001177472);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2534,0.00170876);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2535,0.002322659);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2536,0.00280263);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2537,0.003986132);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2591,8.599742e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2592,0.0001607412);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2593,0.0003393035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2594,0.0005726838);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2595,0.000921);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2596,0.001054534);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2597,0.00181782);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2598,0.002020032);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2599,0.002886232);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2655,0.0001610261);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2657,0.0005145079);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2659,0.001043129);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2661,0.002115486);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2781,0.0001626398);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2783,0.0005006859);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2785,0.001101429);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2907,0.0001659363);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2909,0.0003856815);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(3033,0.0001417503);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(79,3.724919e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(81,6.847784e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(83,0.0001263675);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(85,0.0001670973);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(87,0.00023604);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(89,0.0002875996);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(91,0.0003442834);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(93,0.0003931202);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(95,0.0004418152);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(97,0.0004743733);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(99,0.0004938449);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(101,0.000707779);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(103,0.0004929814);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(105,0.0004932401);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(107,0.0004739359);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(109,0.0004390896);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(111,0.0004250162);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(113,0.0003998791);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(115,0.0003681066);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(117,0.0003515143);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(119,0.0003143943);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(141,5.01238e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(143,7.738185e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(145,0.0001204918);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(147,0.0001683737);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(149,0.0002256705);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(151,0.0002914424);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(153,0.0003381055);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(155,0.0003950057);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(156,0.0004204745);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(158,0.0004603716);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(160,0.0004855425);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(162,0.0005014724);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(164,0.0005050531);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(166,0.0004965991);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(168,0.0004764547);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(169,0.0004718347);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(171,0.0004464068);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(173,0.0004216344);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(175,0.0003974975);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(177,0.0003695521);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(179,0.00035145);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(181,0.000322848);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(265,4.484525e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(267,5.517197e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(269,0.0001022214);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(271,0.0001539731);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(273,0.0002110265);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(275,0.0002625686);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(277,0.0003351462);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(279,0.0003740068);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(280,0.0004138764);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(282,0.000449094);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(284,0.0004939309);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(286,0.0005055035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(288,0.0005090277);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(290,0.0005171025);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(292,0.0004972447);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(293,0.0004868504);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(295,0.0004625882);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(297,0.0004361209);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(299,0.0004151204);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(301,0.0003792951);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(303,0.0003609721);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(305,0.0003241183);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(389,3.724017e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(391,5.114414e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(393,7.076221e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(395,0.0001312509);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(397,0.0001757213);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(399,0.0002486823);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(401,0.0003022373);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(403,0.0003577461);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(404,0.0003818841);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(406,0.0004609293);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(408,0.0004758739);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(410,0.0004973224);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(412,0.0005086272);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(414,0.000518731);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(416,0.0005142795);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(417,0.0004933056);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(419,0.0004700622);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(421,0.0004496023);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(423,0.0004251265);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(425,0.0003970711);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(427,0.000365945);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(429,0.0003354514);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(513,3.219795e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(515,4.569856e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(517,7.001052e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(519,9.244141e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(521,0.0001414104);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(523,0.0002001936);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(525,0.0002615596);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(527,0.0003170154);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(528,0.0003426079);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(530,0.0004057626);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(532,0.0004558824);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(534,0.0004787207);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(536,0.0005155871);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(538,0.0005202842);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(540,0.0005247015);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(541,0.0005036689);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(543,0.0004881128);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(545,0.0004642637);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(547,0.000441885);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(549,0.0004141029);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(551,0.0003838101);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(553,0.0003612711);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(639,3.900085e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(641,5.206702e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(643,7.2216e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(645,9.84772e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(647,0.0001512276);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(649,0.0002169084);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(651,0.0002725888);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(652,0.0003054688);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(654,0.0003634901);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(656,0.0004154353);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(658,0.0004642534);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(660,0.0004989341);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(662,0.0005147965);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(664,0.0005192959);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(665,0.0005165069);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(667,0.0005006155);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(669,0.000482066);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(671,0.000456338);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(673,0.0004229264);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(675,0.0004000055);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(677,0.0003761988);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(765,4.025927e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(767,6.035051e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(769,8.231749e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(771,0.0001130409);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(773,0.0001648642);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(775,0.0002172899);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(776,0.0002525828);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(778,0.0003139792);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(780,0.0003756966);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(782,0.000427982);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(784,0.0004694903);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(786,0.0005097795);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(788,0.0005270055);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(789,0.0005241178);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(791,0.0005276605);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(793,0.0005039742);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(795,0.0004846921);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(797,0.0004600201);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(799,0.0004246553);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(801,0.0003952373);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(891,5.03974e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(893,6.998959e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(895,9.524264e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(897,0.000128822);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(899,0.0001737567);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(900,0.0002001946);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(902,0.0002601331);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(904,0.0003177785);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(906,0.0003820182);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(908,0.0004354709);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(910,0.0004816605);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(912,0.0005099437);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(913,0.0005202723);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(915,0.0005265194);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(917,0.0005166558);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(919,0.0004974091);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(921,0.0004785174);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(923,0.0004534502);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(925,0.0004104873);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1017,4.790486e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1019,6.916012e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1021,9.578569e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1023,0.0001272746);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1024,0.0001578732);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1026,0.0002052314);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1028,0.0002590617);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1030,0.000317717);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1032,0.0003770481);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1034,0.0004376055);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1036,0.0004754015);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1037,0.0005024288);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1039,0.0005307319);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1041,0.0005228585);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1043,0.000517063);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1045,0.0004984444);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1047,0.0004766194);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1049,0.0004431175);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1143,4.24566e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1145,7.26423e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1147,9.120069e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1148,0.0001127705);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1150,0.0001587043);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1152,0.0002017002);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1154,0.0002636354);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1156,0.0003295773);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1158,0.0003859507);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1160,0.0004326468);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1161,0.0004576945);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1163,0.0004991584);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1165,0.0005240288);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1167,0.000521133);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1169,0.0005147447);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1171,0.0004864589);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1173,0.0004699889);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1269,5.090213e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1271,7.659436e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1272,8.454546e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1274,0.0001195204);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1276,0.0001513755);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1278,0.0002071978);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1280,0.000268778);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1282,0.0003267753);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1284,0.0003869254);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1285,0.00041773);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1287,0.0004563646);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1289,0.0004984139);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1291,0.0005247287);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1293,0.0005199131);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1295,0.0005086159);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1297,0.0004907814);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1395,4.470392e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1396,6.280156e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1398,7.858837e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1400,0.0001206384);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1402,0.0001651434);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1404,0.000207174);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1406,0.0002619435);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1408,0.0003249923);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1409,0.0003622058);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1410,0.0003986852);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1411,0.0005070573);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1412,0.0004472253);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1413,0.0004683801);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1414,0.0005118356);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1415,0.0005035753);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1416,0.0005250255);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1417,0.000518055);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1418,0.0005277974);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1419,0.0005215404);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1420,0.0005472755);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1421,0.000531882);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1471,0.0003172189);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1472,0.000361311);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1473,0.0004178198);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1474,0.0004162256);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1475,0.0004454147);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1476,0.0005276809);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1477,0.0004773249);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1478,0.0005948186);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1479,0.0005125894);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1480,0.0005239999);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1481,0.0006407142);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1482,0.0005208992);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1483,0.0005150474);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1520,3.582596e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1522,6.497198e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1524,8.795871e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1526,0.0001232065);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1528,0.0001564793);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1530,0.0002112819);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1532,0.0002610782);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1533,0.0002867219);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1534,0.0003233958);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1535,0.0003498882);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1536,0.0004054269);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1537,0.0005551197);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1538,0.0004736616);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1539,0.0004685878);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1540,0.0006045721);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1541,0.0005196958);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1542,0.0005192296);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1543,0.0005980889);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1544,0.0005179383);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1545,0.0005166874);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1595,0.0002640653);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1596,0.000290912);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1597,0.0003993284);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1598,0.0003464175);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1599,0.0003767195);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1600,0.0004217705);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1601,0.0004575359);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1602,0.0004739268);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1603,0.0004950205);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1604,0.0004895947);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1605,0.000761499);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1606,0.0005188959);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1607,0.0005216336);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1646,3.233785e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1648,5.458304e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1650,8.676193e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1652,0.0001237702);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1654,0.0001484472);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1656,0.0001985767);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1657,0.0002328176);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1658,0.0002752188);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1659,0.000374083);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1660,0.0003437243);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1661,0.0003733291);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1662,0.0006484214);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1663,0.0004108655);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1664,0.0004469281);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1665,0.0005107848);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1666,0.0004787757);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1667,0.0006826816);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1668,0.0005073423);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1669,0.0005225152);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1719,0.000198859);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1720,0.0002572668);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1721,0.000276819);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1722,0.0003166192);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1723,0.0003243955);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1724,0.0003604088);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1725,0.0003776164);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1726,0.0004040674);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1727,0.0004379456);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1728,0.0004610555);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1729,0.0004791819);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1730,0.0004924408);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1731,0.0005932777);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1772,3.724212e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1774,5.5857e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1776,8.621434e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1778,0.0001137354);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1780,0.000156004);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1781,0.000183972);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1782,0.0002184667);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1783,0.0002342971);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1784,0.0002877006);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1785,0.0002920973);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1786,0.0003412811);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1787,0.0003493326);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1788,0.0003842005);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1789,0.0004261237);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1790,0.0004369103);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1791,0.0004583323);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1792,0.0004829729);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1793,0.0005063305);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1843,0.0001554493);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1844,0.0002188437);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1845,0.0002060027);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1846,0.0002345765);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1847,0.0002587743);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1848,0.0002875766);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1849,0.0003108097);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1850,0.0005004917);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1851,0.0004477311);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1852,0.0004056831);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1853,0.0004393192);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1854,0.0004603878);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1855,0.000570933);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1898,3.102432e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1900,5.391831e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1902,7.969627e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1904,0.0001195061);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1905,0.0001383762);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1906,0.0001521947);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1907,0.0001981744);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1908,0.0002073601);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1909,0.0002316113);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1910,0.0002480009);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1911,0.0002860604);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1912,0.0004025883);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1913,0.000358533);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1914,0.0003852512);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1915,0.0004063099);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1916,0.0004370577);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1917,0.0004690417);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1967,0.0001241081);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1968,0.0001292509);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1969,0.0001636706);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1970,0.0001764957);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1971,0.0001932427);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1972,0.0002241428);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1973,0.0003043986);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1974,0.0003178314);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1975,0.0003152844);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1976,0.0003827904);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1977,0.0003703314);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1978,0.0004060081);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1979,0.0004546343);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2024,3.008024e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2026,5.575982e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2028,7.215283e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2029,9.537607e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2030,0.0001172612);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2031,0.0001575197);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2032,0.0001504517);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2033,0.0002153839);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2034,0.0001998929);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2035,0.0002383786);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2036,0.000250848);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2037,0.0003066132);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2038,0.0003194789);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2039,0.0003715017);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2040,0.0004239986);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2041,0.0004130144);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2091,7.377943e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2092,0.0001062636);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2093,0.000118647);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2094,0.0001301613);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2095,0.0001509413);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2096,0.0001772383);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2097,0.000190635);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2098,0.0002127284);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2099,0.0002561353);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2100,0.0002801116);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2101,0.0003439225);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2102,0.0003489852);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2103,0.0003761083);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2150,2.791713e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2152,4.858179e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2153,6.571062e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2154,0.0001192277);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2155,9.684847e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2156,0.0001148683);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2157,0.0001541658);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2158,0.0001985074);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2159,0.0001734044);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2160,0.0001889684);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2161,0.0002227154);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2162,0.0002478888);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2163,0.0002701902);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2164,0.0004069159);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2165,0.0003528919);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2215,6.420318e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2216,7.640576e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2217,7.624803e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2218,9.991569e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2219,0.0001068224);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2220,0.0001423436);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2221,0.0001481068);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2222,0.0001570318);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2223,0.0001991372);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2224,0.0002485707);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2225,0.0002454829);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2226,0.0002905795);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2227,0.0003088243);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2276,2.738047e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2277,4.058827e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2278,5.041446e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2279,6.207151e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2280,8.828311e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2281,8.689701e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2282,0.0001157002);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2283,0.0001348125);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2284,0.000146506);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2285,0.0001821431);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2286,0.0002058331);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2287,0.0002320876);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2288,0.0002518979);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2289,0.0002735629);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2339,3.492531e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2340,4.589633e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2341,4.51372e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2342,6.557159e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2343,7.506651e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2344,9.110768e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2345,0.0001157131);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2346,0.0001204426);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2347,0.000143739);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2348,0.0001735213);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2349,0.0002192963);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2350,0.000371506);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2351,0.0002339646);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2402,2.810561e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2403,3.446751e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2404,6.070799e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2405,5.713047e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2406,7.1588e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2407,8.80587e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2408,0.0001126912);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2409,0.0001255659);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2410,0.0001503999);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2411,0.0001928257);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2412,0.0001926564);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2413,0.0002408671);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2465,2.357716e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2466,3.962021e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2467,5.978292e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2468,5.915948e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2469,7.569203e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2470,0.0001212522);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2471,0.0001610707);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2472,0.0001271168);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2473,0.0001386133);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2474,0.0001626496);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2475,0.0001924561);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2528,3.025185e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2529,2.700935e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2530,4.778302e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2531,6.974548e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2532,7.303984e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2533,8.646317e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2534,0.0001091312);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2535,0.000122732);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2536,0.0001334041);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2537,0.0001785339);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2591,2.719619e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2592,3.216945e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2593,4.802156e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2594,6.042171e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2595,8.313617e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2596,9.086928e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2597,0.0001098321);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2598,0.0001522377);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2599,0.0001406007);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2655,3.223409e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2657,5.686934e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2659,8.034008e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2661,0.0001141785);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2781,3.191677e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2783,5.569854e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2785,8.197559e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2907,3.194646e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2909,4.822723e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(3033,2.959123e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetEntries(860635.7);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->Draw("colz");
   c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf->Modified();
   c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf->cd();
   c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf->SetSelected(c_AccEffMap_T1tttt_8NJetinf_1000HT1250_200MHTinf);
}
/*
   400     0   0.000177919
   400    25   0.000331284
   400    75   0.000275845
   400   125   0.000193318
   400   175   0.000143883
   450     0   0.000602295
   450    25   0.000758467
   450    75   0.000400422
   450   125   0.000357774
   450   175   0.000285139
   450   225   0.000209945
   500     0    0.00195161
   500    25    0.00179439
   500    75     0.0013188
   500   125   0.000650205
   500   175   0.000655551
   500   225   0.000367911
   500   275   0.000220375
   550     0    0.00338746
   550    25    0.00346291
   550    75    0.00290848
   550   125    0.00217724
   550   175    0.00112927
   550   225   0.000694946
   550   275   0.000485662
   550   325    0.00034147
   600     0    0.00660075
   600    25    0.00612686
   600    75    0.00536693
   600   125    0.00379772
   600   175    0.00254118
   600   225    0.00127696
   600   275   0.000895988
   600   325   0.000659569
   600   375   0.000306374
   650     0    0.00972087
   650    25     0.0100899
   650    75    0.00823043
   650   125    0.00746108
   650   175    0.00495421
   650   225    0.00288926
   650   275    0.00168328
   650   325    0.00121331
   650   375   0.000644043
   650   425   0.000243752
   700     0     0.0138792
   700    25     0.0134419
   700    75     0.0132706
   700   125     0.0109391
   700   175    0.00824516
   700   225    0.00584994
   700   275    0.00348239
   700   325    0.00220578
   700   375    0.00125082
   700   425   0.000718429
   700   475   0.000352162
   750     0     0.0180706
   750    25     0.0180384
   750    75     0.0163852
   750   125     0.0151239
   750   175     0.0120286
   750   225    0.00908114
   750   275    0.00593126
   750   325    0.00387759
   750   375    0.00218356
   750   425    0.00113765
   750   475   0.000798605
   750   525   0.000271529
   775    25      0.020493
   775    75      0.019998
   775   125     0.0172812
   775   175     0.0140892
   775   225     0.0113088
   775   275    0.00796626
   775   325    0.00511586
   775   375    0.00330023
   775   425    0.00174724
   775   475   0.000984673
   775   525   0.000547036
   775   575    0.00017911
   800     0     0.0226487
   825    25     0.0245996
   825    75     0.0235342
   825   125     0.0216267
   825   175     0.0195981
   825   225     0.0160172
   825   275     0.0121326
   825   325    0.00848904
   825   375    0.00547237
   825   425    0.00338123
   825   475    0.00197728
   825   525   0.000859911
   825   575   0.000587724
   825   625   0.000144468
   850     0     0.0260428
   875    25     0.0273185
   875    75      0.028253
   875   125     0.0266764
   875   175     0.0244276
   875   225     0.0206531
   875   275     0.0172232
   875   325     0.0125245
   875   375    0.00857454
   875   425    0.00534507
   875   475     0.0031027
   875   525    0.00204321
   875   575    0.00107896
   875   625   0.000411193
   875   675   0.000196991
   900     0     0.0284258
   925    25       0.02927
   925    75     0.0298846
   925   125     0.0291555
   925   175     0.0271282
   925   225     0.0257105
   925   275     0.0221394
   925   325     0.0180006
   925   375     0.0126794
   925   425    0.00897536
   925   475    0.00571595
   925   525    0.00376651
   925   575    0.00215027
   925   625     0.0010644
   925   675   0.000442736
   925   725   0.000138733
   950     0      0.029342
   975    25     0.0300577
   975    75     0.0304507
   975   125     0.0306959
   975   175     0.0314456
   975   225     0.0297134
   975   275     0.0266854
   975   325     0.0231169
   975   375     0.0177319
   975   425     0.0138043
   975   475    0.00947064
   975   525    0.00574862
   975   575    0.00341642
   975   625    0.00220567
   975   675    0.00107185
   975   725   0.000424342
   975   775   0.000131056
  1000     0     0.0287859
  1025    25     0.0295316
  1025    75     0.0317377
  1025   125     0.0320163
  1025   175     0.0324482
  1025   225     0.0317261
  1025   275      0.031487
  1025   325     0.0283448
  1025   375     0.0236935
  1025   425     0.0186931
  1025   475      0.013796
  1025   525    0.00911528
  1025   575    0.00612004
  1025   625    0.00312238
  1025   675    0.00189656
  1025   725   0.000935213
  1025   775   0.000452265
  1025   825   0.000115048
  1050     0     0.0291072
  1075    25     0.0275296
  1075    75     0.0297503
  1075   125     0.0318904
  1075   175     0.0331599
  1075   225     0.0328159
  1075   275     0.0337669
  1075   325     0.0317627
  1075   375     0.0279673
  1075   425     0.0234432
  1075   475     0.0191582
  1075   525     0.0138547
  1075   575    0.00919444
  1075   625    0.00549147
  1075   675    0.00348551
  1075   725    0.00210975
  1075   775   0.000772619
  1075   825   0.000349965
  1075   875   0.000112885
  1100     0     0.0272534
  1100    25     0.0270941
  1100    75     0.0287266
  1100   125     0.0293683
  1100   175     0.0308668
  1100   225     0.0325232
  1100   275     0.0333998
  1100   325      0.033055
  1100   375     0.0311654
  1100   425     0.0262072
  1100   475     0.0223867
  1100   525     0.0169674
  1100   550     0.0131208
  1100   575     0.0110662
  1100   600    0.00939614
  1100   625    0.00747202
  1100   650    0.00543696
  1100   675    0.00482577
  1100   700    0.00349552
  1100   725    0.00239381
  1100   750    0.00206566
  1100   775    0.00135666
  1100   800   0.000810292
  1100   825   0.000629496
  1100   850   0.000368737
  1100   875   0.000246653
  1100   900   0.000181407
  1125   525     0.0198896
  1125   550      0.016459
  1125   575     0.0134564
  1125   600     0.0112881
  1125   625    0.00902091
  1125   650    0.00736959
  1125   675     0.0058522
  1125   700    0.00478696
  1125   725    0.00332457
  1125   750    0.00242422
  1125   775     0.0020637
  1125   800     0.0013288
  1125   825   0.000959465
  1125   850   0.000596049
  1125   875    0.00037699
  1125   900   0.000255439
  1125   925   9.32105e-05
  1150     0     0.0238827
  1150    25     0.0245092
  1150    75     0.0265112
  1150   125     0.0273895
  1150   175      0.029416
  1150   225     0.0308993
  1150   275     0.0344703
  1150   325     0.0343798
  1150   375     0.0349892
  1150   425     0.0311183
  1150   475     0.0266038
  1150   525     0.0214596
  1150   550     0.0196069
  1150   575     0.0161959
  1150   600     0.0130739
  1150   625     0.0112854
  1150   650    0.00972495
  1150   675    0.00744092
  1150   700    0.00601963
  1150   725    0.00460078
  1150   750    0.00351816
  1150   775    0.00261875
  1150   800    0.00214143
  1150   825    0.00120778
  1150   850   0.000820177
  1150   875   0.000540743
  1150   900   0.000243036
  1150   925   0.000165284
  1150   950   8.50043e-05
  1175   525     0.0245449
  1175   550     0.0218015
  1175   575     0.0194278
  1175   600     0.0159761
  1175   625     0.0139103
  1175   650     0.0120468
  1175   675    0.00936362
  1175   700    0.00771676
  1175   725    0.00527985
  1175   750    0.00451534
  1175   775    0.00333856
  1175   800    0.00255619
  1175   825    0.00199863
  1175   850    0.00125411
  1175   875   0.000894727
  1175   900   0.000494505
  1175   925   0.000264389
  1175   950   0.000227113
  1175   975   0.000124531
  1200     0     0.0226451
  1200    25     0.0222265
  1200    75     0.0238182
  1200   125     0.0252936
  1200   175     0.0270223
  1200   225      0.029139
  1200   275     0.0317015
  1200   325     0.0334194
  1200   375     0.0340743
  1200   425      0.034447
  1200   475     0.0315013
  1200   525      0.027047
  1200   550     0.0246994
  1200   575     0.0224056
  1200   600     0.0185538
  1200   625     0.0159178
  1200   650     0.0141338
  1200   675     0.0110399
  1200   700    0.00906921
  1200   725    0.00739072
  1200   750     0.0053793
  1200   775    0.00416698
  1200   800    0.00329237
  1200   825    0.00269176
  1200   850    0.00175902
  1200   875    0.00114441
  1200   900   0.000772163
  1200   925   0.000442043
  1200   950   0.000446688
  1200   975    0.00010803
  1200  1000   8.59974e-05
  1225   525     0.0301852
  1225   550     0.0272654
  1225   575     0.0249379
  1225   600     0.0219716
  1225   625     0.0195203
  1225   650     0.0163948
  1225   675     0.0131699
  1225   700      0.011395
  1225   725    0.00873187
  1225   750    0.00721468
  1225   775    0.00542352
  1225   800    0.00428055
  1225   825    0.00325412
  1225   850    0.00246586
  1225   875    0.00205918
  1225   900    0.00127024
  1225   925   0.000793086
  1225   950   0.000535104
  1225   975   0.000347325
  1225  1000   0.000160741
  1250     0     0.0204184
  1250    25     0.0201558
  1250    75      0.021904
  1250   125     0.0230436
  1250   175     0.0248083
  1250   225     0.0263734
  1250   275     0.0296855
  1250   325     0.0313667
  1250   375     0.0338115
  1250   425     0.0344462
  1250   475     0.0351114
  1250   525     0.0324462
  1250   550     0.0296307
  1250   575     0.0282536
  1250   600     0.0250156
  1250   625     0.0223757
  1250   650     0.0191924
  1250   675      0.016546
  1250   700     0.0133259
  1250   725     0.0114127
  1250   750    0.00938777
  1250   775    0.00715379
  1250   800    0.00527928
  1250   825    0.00439612
  1250   850    0.00331658
  1250   875    0.00250513
  1250   900    0.00193576
  1250   925    0.00119168
  1250   950   0.000867835
  1250   975   0.000623258
  1250  1000   0.000339303
  1250  1025   0.000161026
  1275   525     0.0342714
  1275   550     0.0315886
  1275   575     0.0307283
  1275   600     0.0288742
  1275   625     0.0249597
  1275   650     0.0219294
  1275   675     0.0188555
  1275   700     0.0158243
  1275   725     0.0139573
  1275   750     0.0112603
  1275   775    0.00903111
  1275   800    0.00640393
  1275   825    0.00531466
  1275   850    0.00372018
  1275   875    0.00309235
  1275   900    0.00224726
  1275   925    0.00179659
  1275   950    0.00112215
  1275   975   0.000711182
  1275  1000   0.000572684
  1300     0     0.0174793
  1300    25     0.0176763
  1300    75     0.0185838
  1300   125     0.0203371
  1300   175      0.022189
  1300   225     0.0231085
  1300   275     0.0272478
  1300   325      0.029401
  1300   375      0.031941
  1300   425     0.0340003
  1300   475     0.0347811
  1300   525     0.0344151
  1300   550     0.0333806
  1300   575     0.0330735
  1300   600     0.0308046
  1300   625     0.0277499
  1300   650     0.0251632
  1300   675     0.0224089
  1300   700     0.0190499
  1300   725     0.0162746
  1300   750     0.0137925
  1300   775     0.0110469
  1300   800    0.00885167
  1300   825    0.00709581
  1300   850    0.00562904
  1300   875    0.00416287
  1300   900    0.00311693
  1300   925    0.00227115
  1300   950    0.00201419
  1300   975    0.00117747
  1300  1000      0.000921
  1300  1025   0.000514508
  1300  1075    0.00016264
  1325   525     0.0361208
  1325   550     0.0357104
  1325   575     0.0341618
  1325   600     0.0315093
  1325   625     0.0302354
  1325   650     0.0280827
  1325   675     0.0254889
  1325   700     0.0221681
  1325   725     0.0190343
  1325   750     0.0166422
  1325   775     0.0136261
  1325   800     0.0112265
  1325   825     0.0088804
  1325   850    0.00718747
  1325   875      0.005394
  1325   900    0.00436183
  1325   925    0.00306751
  1325   950    0.00246986
  1325   975    0.00170876
  1325  1000    0.00105453
  1350     0     0.0162142
  1350    25     0.0162212
  1350    75     0.0171358
  1350   125     0.0176185
  1350   175     0.0193077
  1350   225     0.0210044
  1350   275     0.0236192
  1350   325     0.0268078
  1350   375     0.0296347
  1350   425     0.0309756
  1350   475     0.0337103
  1350   525     0.0355059
  1350   550     0.0354447
  1350   575     0.0347135
  1350   600     0.0346738
  1350   625     0.0320354
  1350   650     0.0302601
  1350   675     0.0282936
  1350   700     0.0250168
  1350   725     0.0224833
  1350   750     0.0188038
  1350   775     0.0161871
  1350   800     0.0136558
  1350   825     0.0106368
  1350   850    0.00887529
  1350   875    0.00687421
  1350   900    0.00523719
  1350   925    0.00391155
  1350   950    0.00301603
  1350   975    0.00232266
  1350  1000    0.00181782
  1350  1025    0.00104313
  1350  1075   0.000500686
  1350  1125   0.000165936
  1375   525     0.0351766
  1375   550     0.0355244
  1375   575     0.0352574
  1375   600     0.0352476
  1375   625     0.0340766
  1375   650     0.0322944
  1375   675     0.0306484
  1375   700     0.0276031
  1375   725     0.0256549
  1375   750     0.0227916
  1375   775     0.0183834
  1375   800     0.0165359
  1375   825     0.0133274
  1375   850     0.0102149
  1375   875    0.00827728
  1375   900    0.00675607
  1375   925    0.00527291
  1375   950    0.00397015
  1375   975    0.00280263
  1375  1000    0.00202003
  1400     0     0.0132287
  1400    25     0.0139418
  1400    75     0.0140477
  1400   125     0.0149791
  1400   175     0.0173731
  1400   225     0.0188855
  1400   275     0.0208173
  1400   325     0.0225029
  1400   375      0.026015
  1400   425     0.0292167
  1400   475     0.0319166
  1400   525     0.0335051
  1400   550     0.0348973
  1400   575      0.035347
  1400   600      0.035835
  1400   625     0.0362895
  1400   650     0.0348031
  1400   675     0.0329741
  1400   700     0.0300475
  1400   725     0.0277803
  1400   750     0.0247777
  1400   775     0.0226313
  1400   800     0.0187302
  1400   825     0.0167627
  1400   850     0.0133026
  1400   875     0.0109762
  1400   900    0.00813037
  1400   925    0.00734208
  1400   950    0.00526718
  1400   975    0.00398613
  1400  1000    0.00288623
  1400  1025    0.00211549
  1400  1075    0.00110143
  1400  1125   0.000385682
  1400  1175    0.00014175
*/
