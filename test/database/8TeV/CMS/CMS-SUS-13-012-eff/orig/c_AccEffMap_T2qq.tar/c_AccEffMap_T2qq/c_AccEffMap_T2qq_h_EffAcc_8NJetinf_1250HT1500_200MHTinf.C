{
//=========Macro generated from canvas: c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf/c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf
//=========  (Sat Feb 22 16:28:33 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf = new TCanvas("c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf", "c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf",120,336,500,500);
   c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf->SetFillColor(0);
   c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf->SetLogz();
   c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1250HT1500_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1250HT1500_200MHTinf","h_EffAcc_8NJetinf_1250HT1500_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(77,2.813925e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(79,2.600146e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(85,3.08082e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(87,8.991282e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(89,0.0001430792);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(91,2.984729e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(93,0.0002392412);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(95,0.0001148038);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(97,0.0001201698);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(99,0.0001516485);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(101,0.0002736702);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(103,0.0001642285);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(199,2.682323e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(201,3.127301e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(203,7.775357e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(205,2.64731e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(207,2.700937e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(209,8.925353e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(211,5.886213e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(213,0.0002051214);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(215,8.941711e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(217,9.427224e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(219,0.0001202017);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(221,0.0001259508);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(223,0.0001474944);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(225,0.0001866947);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(227,0.0001215324);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(323,2.70123e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(327,0.0001102382);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(329,6.676949e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(333,5.505812e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(335,8.922835e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(337,0.0001420036);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(339,0.0001391885);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(341,5.641401e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(343,0.0001163875);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(345,8.937897e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(347,0.0002240981);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(349,0.0002063608);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(351,8.863598e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(457,0.0001409373);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(459,0.000117898);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(461,8.785864e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(463,0.0001155314);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(465,0.0001848338);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(467,0.0002046036);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(469,0.0001191098);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(471,0.000267358);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(473,0.0001686681);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(475,0.0001855385);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(577,2.6558e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(579,5.423802e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(581,5.839657e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(583,0.0001497003);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(585,8.420019e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(587,0.0001999218);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(589,0.0001810893);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(591,6.157156e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(593,0.000144737);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(595,0.0001168561);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(597,0.0001807772);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(599,0.0001244182);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(697,2.490144e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(703,0.000118835);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(705,0.0001118837);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(709,0.0001813711);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(711,0.0001122661);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(713,0.00014649);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(715,5.58247e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(717,0.0001478894);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(719,0.0001577895);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(721,0.0001764829);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(723,0.0001698315);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(829,8.485075e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(831,3.114483e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(833,0.0002328151);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(835,8.446005e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(837,8.493456e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(839,0.0002425037);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(841,0.0002056284);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(843,0.0003409328);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(845,0.0001443713);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(847,0.0002445754);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(949,2.645236e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(953,2.759996e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(955,8.660168e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(957,3.159031e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(959,2.809941e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(961,9.743064e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(963,0.0001520079);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(965,0.0001841223);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(967,8.862074e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(969,0.0001515523);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(971,8.469417e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1077,2.804695e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1079,2.770836e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1083,0.0001119584);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1085,8.67016e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1087,0.0001452821);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1089,8.826312e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1091,9.164962e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1093,0.000179105);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1095,0.0002407039);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1205,3.136725e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1207,0.0001154601);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1209,8.9517e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1211,5.809341e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1213,0.0002968707);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1215,0.0001572808);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1217,0.0001128975);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1219,0.0001232909);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1329,5.77511e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1331,2.892619e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1333,5.620217e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1335,2.801096e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1337,3.507892e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1339,0.0001197368);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1341,0.0002132763);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1343,2.820964e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1453,2.767089e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1457,5.60766e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1459,2.847426e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1461,8.472243e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1463,0.0001417261);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1465,0.0002032277);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1467,0.0002868607);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1581,2.821337e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1583,0.0001172249);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1585,5.826869e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1587,5.674835e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1589,6.528731e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1591,0.0001455854);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1705,2.821307e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1707,5.748985e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1709,3.001465e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1711,8.439813e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1713,6.194153e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1715,0.0001245201);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1835,5.628204e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1837,5.644675e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1839,0.0001150652);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1955,2.79872e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1959,5.626858e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1961,8.418247e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(1963,8.460863e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2083,5.675761e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinContent(2087,2.808289e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(77,2.813967e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(79,2.600187e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(85,3.080871e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(87,5.222004e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(89,6.406845e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(91,2.984783e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(93,8.503383e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(95,5.748474e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(97,6.040002e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(99,6.811779e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(101,9.150175e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(103,7.364651e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(199,2.682363e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(201,3.127349e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(203,4.489316e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(205,2.647353e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(207,2.700981e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(209,5.160929e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(211,4.169515e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(213,7.782668e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(215,5.162778e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(217,5.475205e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(219,6.018779e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(221,6.315813e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(223,6.607916e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(225,7.641587e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(227,6.104247e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(323,2.70127e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(327,5.540791e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(329,4.721469e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(333,3.893327e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(335,5.160103e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(337,6.358677e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(339,6.225223e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(341,3.989208e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(343,5.827782e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(345,5.178383e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(347,8.502044e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(349,7.825787e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(351,5.125843e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(457,6.310926e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(459,5.903419e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(461,5.080888e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(463,5.776972e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(465,7.561958e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(467,7.745692e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(469,5.986718e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(471,8.942554e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(473,6.886546e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(475,7.58208e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(577,2.655843e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(579,3.835333e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(581,4.136536e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(583,6.706753e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(585,4.861547e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(587,7.5642e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(589,7.412135e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(591,4.361444e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(593,6.490267e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(595,5.851247e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(597,7.399357e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(599,6.233042e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(697,2.490182e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(703,5.949412e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(705,5.602254e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(709,7.432521e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(711,5.613686e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(713,6.562913e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(715,3.947535e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(717,6.625613e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(719,7.074559e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(721,7.234379e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(723,6.934052e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(829,4.906933e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(831,3.114535e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(833,8.2461e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(835,4.876552e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(837,4.90395e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(839,8.604543e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(841,7.780141e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(843,0.0001030981);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(845,6.464703e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(847,8.694406e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(949,2.645278e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(953,2.760042e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(955,5.008194e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(957,3.159084e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(959,2.809988e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(961,5.658651e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(963,6.827926e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(965,7.52864e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(967,5.124962e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(969,6.807457e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(971,4.890069e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1077,2.804743e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1079,2.770883e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1083,5.598297e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1085,5.005981e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1087,6.505494e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1089,5.10428e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1091,5.300132e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1093,7.320312e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1095,8.545478e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1205,3.136777e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1207,5.773407e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1209,5.168545e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1211,4.107968e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1213,9.431943e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1215,7.062764e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1217,5.645257e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1219,6.192576e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1329,4.083762e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1331,2.892669e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1333,3.974228e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1335,2.801143e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1337,3.507951e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1339,5.995498e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1341,8.092111e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1343,2.821012e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1453,2.767135e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1457,3.965348e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1459,2.847475e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1461,4.891701e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1463,6.338725e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1465,7.682223e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1467,9.604272e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1581,2.821385e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1583,5.861659e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1585,4.120363e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1587,4.012852e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1589,4.62466e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1591,6.528315e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1705,2.821355e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1707,4.065287e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1709,3.001519e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1711,4.872975e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1713,4.396136e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1715,6.238147e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1835,3.979876e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1837,3.991523e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1839,5.761563e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1955,2.798767e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1959,3.978924e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1961,4.860523e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(1963,4.88513e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2083,4.013506e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetBinError(2087,2.808336e-05);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetEntries(540.656);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1250HT1500_200MHTinf->Draw("colz");
   c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf->Modified();
   c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf->cd();
   c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf->SetSelected(c_AccEffMap_T2qq_8NJetinf_1250HT1500_200MHTinf);
}
/*
Topology ~q ~q ; ~q ->q+LSP

mSquark(GeV) mLSP(GeV) AccXEff
   300    50   2.68232e-05
   300   100   2.70123e-05
   350     0   2.81392e-05
   350    50    3.1273e-05
   350   250   2.49014e-05
   400     0   2.60015e-05
   400    50   7.77536e-05
   400   100   0.000110238
   450    50   2.64731e-05
   450   100   6.67695e-05
   450   200    2.6558e-05
   450   350   2.64524e-05
   500    50   2.70094e-05
   500   200    5.4238e-05
   500   250   0.000118835
   550     0   3.08082e-05
   550    50   8.92535e-05
   550   100   5.50581e-05
   550   150   0.000140937
   550   200   5.83966e-05
   550   250   0.000111884
   550   300   8.48507e-05
   550   350      2.76e-05
   550   400    2.8047e-05
   600     0   8.99128e-05
   600    50   5.88621e-05
   600   100   8.92284e-05
   600   150   0.000117898
   600   200     0.0001497
   600   300   3.11448e-05
   600   350   8.66017e-05
   600   400   2.77084e-05
   650     0   0.000143079
   650    50   0.000205121
   650   100   0.000142004
   650   150   8.78586e-05
   650   200   8.42002e-05
   650   250   0.000181371
   650   300   0.000232815
   650   350   3.15903e-05
   650   450   3.13672e-05
   650   500   5.77511e-05
   650   550   2.76709e-05
   700     0   2.98473e-05
   700    50   8.94171e-05
   700   100   0.000139189
   700   150   0.000115531
   700   200   0.000199922
   700   250   0.000112266
   700   300   8.44601e-05
   700   350   2.80994e-05
   700   400   0.000111958
   700   450    0.00011546
   700   500   2.89262e-05
   750     0   0.000239241
   750    50   9.42722e-05
   750   100    5.6414e-05
   750   150   0.000184834
   750   200   0.000181089
   750   250    0.00014649
   750   300   8.49346e-05
   750   350   9.74306e-05
   750   400   8.67016e-05
   750   450    8.9517e-05
   750   500   5.62022e-05
   750   550   5.60766e-05
   750   600   2.82134e-05
   750   650   2.82131e-05
   800     0   0.000114804
   800    50   0.000120202
   800   100   0.000116388
   800   150   0.000204604
   800   200   6.15716e-05
   800   250   5.58247e-05
   800   300   0.000242504
   800   350   0.000152008
   800   400   0.000145282
   800   450   5.80934e-05
   800   500    2.8011e-05
   800   550   2.84743e-05
   800   600   0.000117225
   800   650   5.74898e-05
   800   750   2.79872e-05
   850     0    0.00012017
   850    50   0.000125951
   850   100    8.9379e-05
   850   150    0.00011911
   850   200   0.000144737
   850   250   0.000147889
   850   300   0.000205628
   850   350   0.000184122
   850   400   8.82631e-05
   850   450   0.000296871
   850   500   3.50789e-05
   850   550   8.47224e-05
   850   600   5.82687e-05
   850   650   3.00147e-05
   900     0   0.000151648
   900    50   0.000147494
   900   100   0.000224098
   900   150   0.000267358
   900   200   0.000116856
   900   250    0.00015779
   900   300   0.000340933
   900   350   8.86207e-05
   900   400   9.16496e-05
   900   450   0.000157281
   900   500   0.000119737
   900   550   0.000141726
   900   600   5.67484e-05
   900   650   8.43981e-05
   900   700    5.6282e-05
   900   750   5.62686e-05
   900   800   5.67576e-05
   950     0    0.00027367
   950    50   0.000186695
   950   100   0.000206361
   950   150   0.000168668
   950   200   0.000180777
   950   250   0.000176483
   950   300   0.000144371
   950   350   0.000151552
   950   400   0.000179105
   950   450   0.000112897
   950   500   0.000213276
   950   550   0.000203228
   950   600   6.52873e-05
   950   650   6.19415e-05
   950   700   5.64467e-05
   950   750   8.41825e-05
  1000     0   0.000164229
  1000    50   0.000121532
  1000   100    8.8636e-05
  1000   150   0.000185538
  1000   200   0.000124418
  1000   250   0.000169832
  1000   300   0.000244575
  1000   350   8.46942e-05
  1000   400   0.000240704
  1000   450   0.000123291
  1000   500   2.82096e-05
  1000   550   0.000286861
  1000   600   0.000145585
  1000   650    0.00012452
  1000   700   0.000115065
  1000   750   8.46086e-05
  1000   800   2.80829e-05
*/
