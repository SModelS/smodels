#include <map>
#include "debug.h"
#include <string>
using namespace std;
std::map<std::string,bool> lines;
std::map<std::string,std::string> cur_table_line;
