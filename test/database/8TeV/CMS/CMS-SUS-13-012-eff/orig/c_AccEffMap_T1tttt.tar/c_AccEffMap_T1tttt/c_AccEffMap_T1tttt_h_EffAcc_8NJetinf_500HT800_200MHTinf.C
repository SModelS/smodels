{
//=========Macro generated from canvas: c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf/c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf
//=========  (Sat Feb 22 16:31:36 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf = new TCanvas("c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf", "c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf",105,264,500,500);
   c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf->SetFillColor(0);
   c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf->SetLogz();
   c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_500HT800_200MHTinf = new TH2D("h_EffAcc_8NJetinf_500HT800_200MHTinf","h_EffAcc_8NJetinf_500HT800_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(79,0.0001017945);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(81,0.0003610168);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(83,0.001074326);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(85,0.002401229);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(87,0.003344216);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(89,0.005079332);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(91,0.004720639);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(93,0.00442961);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(95,0.003931026);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(97,0.00331092);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(99,0.002636943);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(101,0.002137875);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(103,0.00169991);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(105,0.001304848);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(107,0.000960048);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(109,0.0008353091);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(111,0.0006370835);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(113,0.0005466817);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(115,0.0004133901);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(117,0.0002704093);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(119,0.0002306899);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(141,0.0001192623);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(143,0.0005255413);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(145,0.001133085);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(147,0.002669285);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(149,0.003928847);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(151,0.004474455);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(153,0.004762123);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(155,0.00434271);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(156,0.004363681);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(158,0.003675076);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(160,0.0030708);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(162,0.00223535);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(164,0.001950976);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(166,0.001533772);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(168,0.001035165);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(169,0.00116251);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(171,0.0008883616);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(173,0.0005877699);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(175,0.0005207498);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(177,0.000343606);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(179,0.0003663961);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(181,0.0002856686);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(265,8.664358e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(267,0.000207643);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(269,0.000893486);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(271,0.002193693);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(273,0.003697711);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(275,0.005116101);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(277,0.005835708);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(279,0.005352779);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(280,0.004783372);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(282,0.004627609);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(284,0.00348235);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(286,0.002776796);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(288,0.002023113);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(290,0.00165523);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(292,0.001229114);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(293,0.001144172);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(295,0.0008539889);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(297,0.0007939005);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(299,0.0006532913);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(301,0.0003474726);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(303,0.0003608988);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(305,0.0002517123);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(389,4.866135e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(391,0.000134052);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(393,0.0003353688);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(395,0.00126474);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(397,0.003477683);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(399,0.005587806);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(401,0.005298902);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(403,0.005919257);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(404,0.005011154);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(406,0.004745231);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(408,0.003820593);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(410,0.003172495);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(412,0.002500829);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(414,0.001827948);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(416,0.001596095);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(417,0.001312778);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(419,0.001049267);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(421,0.0008096599);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(423,0.0006794161);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(425,0.0005276051);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(427,0.0005580743);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(429,0.0003005703);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(513,6.572412e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(515,8.121047e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(517,0.0002051723);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(519,0.0004593942);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(521,0.001968333);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(523,0.003933083);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(525,0.006243533);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(527,0.006643055);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(528,0.006102031);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(530,0.005666824);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(532,0.004858749);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(534,0.003493262);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(536,0.003025215);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(538,0.002357703);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(540,0.001707025);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(541,0.001683382);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(543,0.001131073);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(545,0.0009212225);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(547,0.0007931816);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(549,0.0006075318);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(551,0.0004383246);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(553,0.0003639341);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(639,7.52379e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(641,0.000185555);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(643,0.0003271678);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(645,0.0006678995);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(647,0.002301376);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(649,0.004485275);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(651,0.00602151);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(652,0.00705706);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(654,0.00648827);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(656,0.005729588);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(658,0.004335931);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(660,0.003437441);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(662,0.003187955);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(664,0.002162672);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(665,0.002147921);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(667,0.001539675);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(669,0.001105571);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(671,0.0008200237);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(673,0.0005901087);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(675,0.0004688628);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(677,0.0004453243);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(765,0.0001024469);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(767,0.0001327446);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(769,0.0004142394);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(771,0.0008498709);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(773,0.00325239);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(775,0.005501371);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(776,0.006535018);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(778,0.00720363);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(780,0.006205674);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(782,0.006123848);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(784,0.00434297);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(786,0.003575231);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(788,0.00246384);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(789,0.002382983);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(791,0.001614943);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(793,0.001640214);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(795,0.001027476);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(797,0.0006529095);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(799,0.0006986904);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(801,0.0004971788);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(891,6.691897e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(893,0.000202274);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(895,0.0005093545);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(897,0.0009305688);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(899,0.00307961);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(900,0.004690924);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(902,0.006308199);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(904,0.007519436);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(906,0.006979806);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(908,0.005431808);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(910,0.004847011);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(912,0.003384555);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(913,0.002998722);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(915,0.002184468);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(917,0.001697872);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(919,0.001380145);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(921,0.0008961531);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(923,0.000682423);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(925,0.0005418014);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1017,0.0001047275);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1019,0.0002599011);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1021,0.0006018794);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1023,0.00132657);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1024,0.002296357);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1026,0.004663145);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1028,0.006781105);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1030,0.007430874);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1032,0.006765436);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1034,0.005454441);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1036,0.004466953);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1037,0.003858486);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1039,0.002815788);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1041,0.002126953);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1043,0.001470632);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1045,0.001313571);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1047,0.001044369);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1049,0.0008140995);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1143,0.0001388288);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1145,0.0002140292);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1147,0.0006368477);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1148,0.0004627688);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1150,0.002468921);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1152,0.005439409);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1154,0.00715185);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1156,0.007573813);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1158,0.007006226);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1160,0.005588502);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1161,0.005008856);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1163,0.003803746);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1165,0.002828356);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1167,0.002253868);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1169,0.00156891);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1171,0.001124574);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1173,0.0009983404);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1269,0.0001075926);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1271,0.0002529293);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1272,0.0003475053);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1274,0.0006029157);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1276,0.002795373);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1278,0.005670592);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1280,0.007609863);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1282,0.007339668);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1284,0.007147256);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1285,0.00635058);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1287,0.004830108);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1289,0.003235232);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1291,0.003014679);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1293,0.002172823);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1295,0.001562379);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1297,0.0009387678);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1395,0.0001267437);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1396,0.0002366768);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1398,0.0004033328);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1400,0.0007078386);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1402,0.002746421);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1404,0.005617833);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1406,0.007064836);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1408,0.007899719);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1409,0.007270849);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1410,0.006655388);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1411,0.006021553);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1412,0.005284362);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1413,0.004864889);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1414,0.004182622);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1415,0.003664958);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1416,0.002811015);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1417,0.002686723);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1418,0.002232352);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1419,0.002000594);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1420,0.001703055);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1421,0.001602581);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1471,0.007922003);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1472,0.007333051);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1473,0.006572714);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1474,0.006157474);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1475,0.005628801);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1476,0.00446762);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1477,0.003961676);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1478,0.003950072);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1479,0.002775834);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1480,0.002442791);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1481,0.002300221);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1482,0.002128981);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1483,0.001807654);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1520,0.0001208995);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1522,0.0001899894);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1524,0.0005295743);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1526,0.0006723101);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1528,0.003077773);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1530,0.006011547);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1532,0.007334577);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1533,0.007436428);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1534,0.007751558);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1535,0.007507015);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1536,0.006944635);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1537,0.006036304);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1538,0.005596887);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1539,0.005042737);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1540,0.004154254);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1541,0.00343611);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1542,0.002913141);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1543,0.002653531);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1544,0.00239213);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1545,0.001903305);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1595,0.007565202);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1596,0.007927162);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1597,0.007988243);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1598,0.006900767);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1599,0.006944927);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1600,0.006102811);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1601,0.005745831);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1602,0.005114023);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1603,0.004083533);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1604,0.003346456);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1605,0.002697755);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1606,0.002662877);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1607,0.002242414);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1646,0.0001231969);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1648,0.00024162);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1650,0.000517888);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1652,0.0008223814);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1654,0.003140965);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1656,0.00596095);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1657,0.00731316);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1658,0.008096704);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1659,0.007906142);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1660,0.007417984);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1661,0.007833131);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1662,0.006838407);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1663,0.006193699);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1664,0.005182859);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1665,0.004888383);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1666,0.004137713);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1667,0.003209354);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1668,0.003062818);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1669,0.002470525);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1719,0.0060094);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1720,0.00687621);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1721,0.007901496);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1722,0.008110133);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1723,0.00792766);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1724,0.007476496);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1725,0.006723256);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1726,0.006475269);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1727,0.005179862);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1728,0.004920287);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1729,0.004072613);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1730,0.003309372);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1731,0.003182141);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1772,0.0001085639);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1774,0.0002730856);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1776,0.0005218353);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1778,0.0008873911);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1780,0.003354129);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1781,0.004601256);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1782,0.005705839);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1783,0.006984485);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1784,0.007954803);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1785,0.008243863);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1786,0.007827461);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1787,0.007402697);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1788,0.00701188);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1789,0.00621962);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1790,0.005162778);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1791,0.004698523);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1792,0.004029405);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1793,0.0036727);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1843,0.003170812);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1844,0.004521051);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1845,0.005873458);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1846,0.00692305);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1847,0.007756643);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1848,0.008125293);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1849,0.008092837);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1850,0.006620826);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1851,0.006981802);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1852,0.005786787);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1853,0.005386486);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1854,0.004508733);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1855,0.004167154);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1898,7.196793e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1900,0.0002790604);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1902,0.000604027);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1904,0.0010106);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1905,0.001716402);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1906,0.00338728);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1907,0.00457108);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1908,0.006542987);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1909,0.007499397);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1910,0.00774105);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1911,0.007501199);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1912,0.008374533);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1913,0.007644727);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1914,0.006354852);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1915,0.00605616);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1916,0.005233114);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1917,0.004586785);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1967,0.0009216526);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1968,0.002013778);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1969,0.003333541);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1970,0.004569316);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1971,0.006127273);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1972,0.00697543);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1973,0.007697363);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1974,0.0079886);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1975,0.007987787);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1976,0.007744436);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1977,0.007128015);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1978,0.006042243);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(1979,0.005129317);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2024,6.338658e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2026,0.0002547673);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2028,0.0006567265);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2029,0.0008708713);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2030,0.0009441074);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2031,0.00172485);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2032,0.003127906);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2033,0.004735471);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2034,0.006526534);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2035,0.007142935);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2036,0.008218065);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2037,0.007699108);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2038,0.00773459);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2039,0.007857951);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2040,0.006967857);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2041,0.005764163);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2091,0.0004995632);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2092,0.000939324);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2093,0.00104171);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2094,0.0020576);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2095,0.00334979);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2096,0.005088368);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2097,0.005604562);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2098,0.007104116);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2099,0.008643983);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2100,0.008416129);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2101,0.00810897);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2102,0.007484001);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2103,0.006697373);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2150,9.153479e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2152,0.0002324797);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2153,0.0003725504);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2154,0.0005669568);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2155,0.0009281794);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2156,0.0009749818);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2157,0.001940673);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2158,0.003371609);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2159,0.00456339);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2160,0.006154832);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2161,0.007529054);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2162,0.008140008);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2163,0.008545929);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2164,0.008353464);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2165,0.007690476);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2215,0.0002604903);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2216,0.0005604908);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2217,0.0004876493);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2218,0.001128699);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2219,0.0008291661);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2220,0.001951288);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2221,0.003284331);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2222,0.004888367);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2223,0.006414655);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2224,0.007467579);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2225,0.008078089);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2226,0.008465962);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2227,0.00799038);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2276,8.38336e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2277,0.0001424741);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2278,0.0002406232);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2279,0.0003313378);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2280,0.0006316032);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2281,0.0009628614);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2282,0.001088837);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2283,0.001843849);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2284,0.003619002);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2285,0.004866958);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2286,0.006479623);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2287,0.007440178);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2288,0.008284543);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2289,0.008609634);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2339,9.697351e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2340,9.950831e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2341,0.0002367501);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2342,0.0003615337);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2343,0.0006052458);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2344,0.001014423);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2345,0.001000388);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2346,0.002109415);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2347,0.003471865);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2348,0.004930327);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2349,0.006432925);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2350,0.006907902);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2351,0.007841895);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2402,2.542105e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2403,0.0001536062);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2404,0.0002025836);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2405,0.0003463428);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2406,0.0005447216);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2407,0.0008977165);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2408,0.0008317766);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2409,0.002043862);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2410,0.003324585);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2411,0.004931586);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2412,0.006345342);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2413,0.00750489);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2465,8.091756e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2466,0.0001455204);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2467,0.0002607319);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2468,0.0004030442);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2469,0.0005293836);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2470,0.0006624361);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2471,0.001211684);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2472,0.002066747);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2473,0.003519917);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2474,0.005027991);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2475,0.005968929);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2528,5.891771e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2529,0.0002456002);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2530,0.0002024728);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2531,0.0004394644);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2532,0.0005931143);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2533,0.001013228);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2534,0.001169966);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2535,0.002088055);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2536,0.003280191);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2537,0.004661461);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2591,9.728458e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2592,0.0001567624);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2593,0.0002490185);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2594,0.0004095677);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2595,0.0004714255);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2596,0.0009438613);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2597,0.00108702);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2598,0.001947162);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2599,0.003478802);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2655,0.0001245374);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2657,0.0003686142);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2659,0.0008966239);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2661,0.001813972);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2781,0.0001789038);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2783,0.0003834391);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2785,0.0009582392);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2907,0.0001525543);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(2909,0.0003894406);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinContent(3033,0.0001507982);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(79,2.941925e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(81,5.51931e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(83,9.715429e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(85,0.0001462296);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(87,0.0001732153);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(89,0.0002140583);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(91,0.0002057281);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(93,0.0001981154);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(95,0.0001864074);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(97,0.0001700159);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(99,0.0001505687);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(101,0.0001907898);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(103,0.0001197543);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(105,0.0001039258);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(107,8.847968e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(109,8.197784e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(111,7.12637e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(113,6.537801e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(115,5.631302e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(117,4.512015e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(119,4.145733e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(141,3.19582e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(143,6.741663e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(145,9.930308e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(147,0.0001542551);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(149,0.0001872917);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(151,0.00019999);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(153,0.0002067464);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(155,0.0001971539);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(156,0.000196902);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(158,0.0001793458);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(160,0.0001633613);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(162,0.000138591);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(164,0.0001282945);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(166,0.0001126299);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(168,9.228958e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(169,9.732337e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(171,8.47652e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(173,6.837473e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(175,6.366049e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(177,5.125925e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(179,5.243016e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(181,4.6348e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(265,2.625076e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(267,4.168467e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(269,8.788284e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(271,0.0001399521);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(273,0.0001819219);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(275,0.0002141382);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(277,0.0002287203);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(279,0.0002183895);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(280,0.0002060822);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(282,0.0002012666);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(284,0.0001741038);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(286,0.0001543448);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(288,0.0001308235);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(290,0.000117497);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(292,0.0001007826);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(293,9.68021e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(295,8.264043e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(297,7.944095e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(299,7.134383e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(301,5.181921e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(303,5.214353e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(305,4.319898e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(389,1.996142e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(391,3.265365e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(393,5.318749e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(395,0.0001046672);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(397,0.0001758155);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(399,0.0002236862);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(401,0.000217488);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(403,0.000229878);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(404,0.0002107356);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(406,0.0002195654);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(408,0.0001818008);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(410,0.0001650338);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(412,0.0001451363);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(414,0.000123696);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(416,0.000114451);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(417,0.0001039127);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(419,9.1757e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(421,8.02341e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(423,7.287879e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(425,6.358796e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(427,6.493546e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(429,4.753845e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(513,2.193688e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(515,2.577706e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(517,4.034977e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(519,6.163867e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(521,0.0001313941);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(523,0.0001864717);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(525,0.0002358486);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(527,0.0002431216);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(528,0.0002320803);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(530,0.0002230433);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(532,0.0002057588);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(534,0.0001729248);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(536,0.0001600034);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(538,0.0001401193);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(540,0.0001187882);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(541,0.0001171746);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(543,9.535505e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(545,8.525488e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(547,7.860952e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(549,6.838991e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(551,5.758835e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(553,5.202992e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(639,2.384491e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(641,3.798993e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(643,5.131619e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(645,7.495255e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(647,0.0001413171);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(649,0.0001993713);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(651,0.0002310173);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(652,0.0002494227);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(654,0.0002380647);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(656,0.0002228427);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(658,0.0001925616);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(660,0.0001705797);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(662,0.0001632587);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(664,0.000133072);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(665,0.0001323926);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(667,0.0001112462);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(669,9.352841e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(671,8.008685e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(673,6.730858e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(675,5.958418e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(677,5.754208e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(765,2.852731e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(767,3.227228e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(769,5.766635e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(771,8.444275e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(773,0.0001679379);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(775,0.0002198055);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(776,0.0002395479);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(778,0.0002511752);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(780,0.0002320143);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(782,0.0002286347);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(784,0.0001913624);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(786,0.000172239);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(788,0.0001424733);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(789,0.000139495);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(791,0.000113522);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(793,0.0001138915);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(795,8.953652e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(797,7.086853e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(799,7.289043e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(801,6.078527e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(891,2.232395e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(893,3.97928e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(895,6.442294e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(897,8.787831e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(899,0.0001624893);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(900,0.0002017952);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(902,0.0002339193);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(904,0.0002548154);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(906,0.0002443621);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(908,0.0002146208);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(910,0.0002010047);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(912,0.0001670889);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(913,0.0001568317);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(915,0.0001322037);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(917,0.0001159438);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(919,0.0001038446);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(921,8.293841e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(923,7.1984e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(925,6.34542e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1017,2.801718e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1019,4.46603e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1021,6.930448e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1023,0.0001043076);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1024,0.000138549);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1026,0.0001998406);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1028,0.0002410651);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1030,0.0002522173);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1032,0.0002394084);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1034,0.0002138269);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1036,0.0001917425);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1037,0.0001776594);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1039,0.0001503592);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1041,0.0001301377);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1043,0.0001073721);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1045,0.0001002798);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1047,8.898173e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1049,7.803042e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1143,3.279056e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1145,4.054984e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1147,7.058263e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1148,5.942043e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1150,0.0001433612);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1152,0.0002146077);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1154,0.0002459399);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1156,0.0002526508);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1158,0.0002419494);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1160,0.0002148791);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1161,0.0002024504);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1163,0.0001753086);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1165,0.0001499824);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1167,0.000132794);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1169,0.0001099658);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1171,9.220614e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1173,8.633239e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1269,2.883516e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1271,4.413757e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1272,5.194446e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1274,6.805334e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1276,0.0001518443);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1278,0.0002176805);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1280,0.0002527068);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1282,0.0002471632);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1284,0.0002426393);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1285,0.0002272471);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1287,0.0001969485);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1289,0.0001601476);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1291,0.0001535477);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1293,0.0001293535);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1295,0.0001089712);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1297,8.369541e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1395,3.079581e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1396,4.19206e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1398,5.554022e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1400,7.36601e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1402,0.0001495471);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1404,0.0002155289);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1406,0.0002414908);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1408,0.0002547112);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1409,0.0002445255);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1410,0.00023626);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1411,0.0002741206);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1412,0.00021106);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1413,0.0002010559);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1414,0.0001918079);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1415,0.0001698142);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1416,0.0001503325);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1417,0.0001444919);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1418,0.0001306335);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1419,0.0001230931);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1420,0.0001199673);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1421,0.0001155082);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1471,0.0002554749);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1472,0.0002484647);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1473,0.0002485208);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1474,0.0002256875);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1475,0.0002161112);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1476,0.0002156127);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1477,0.0001758729);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1478,0.0002110693);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1479,0.000147608);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1480,0.0001365833);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1481,0.0001624993);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1482,0.0001267571);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1483,0.0001163746);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1520,3.027917e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1522,3.806578e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1524,6.395547e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1526,7.109648e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1528,0.0001571245);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1530,0.0002215784);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1532,0.0002442156);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1533,0.000245443);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1534,0.0002543014);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1535,0.0002459615);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1536,0.0002487577);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1537,0.0002932636);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1538,0.0002281122);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1539,0.0001999636);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1540,0.0002236053);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1541,0.0001678584);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1542,0.0001513461);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1543,0.0001651509);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1544,0.0001343592);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1545,0.0001193461);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1595,0.0002475678);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1596,0.0002539977);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1597,0.0003244633);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1598,0.0002350792);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1599,0.0002367004);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1600,0.0002265696);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1601,0.0002225798);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1602,0.0002013801);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1603,0.0001812751);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1604,0.000159915);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1605,0.0002117298);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1606,0.0001421784);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1607,0.0001298953);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1646,2.991427e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1648,4.216581e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1650,6.253704e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1652,7.761816e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1654,0.0001579187);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1656,0.0002187181);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1657,0.0002424564);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1658,0.0002727108);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1659,0.0003263251);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1660,0.0002602608);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1661,0.0002704241);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1662,0.0003944208);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1663,0.0002205867);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1664,0.0002066708);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1665,0.0002164759);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1666,0.0001777475);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1667,0.0002163576);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1668,0.0001521159);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1669,0.0001358251);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1719,0.0002207803);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1720,0.0002620839);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1721,0.000261052);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1722,0.0002707991);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1723,0.0002517725);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1724,0.000251186);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1725,0.0002292537);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1726,0.0002240357);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1727,0.0002012295);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1728,0.0001949375);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1729,0.0001767123);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1730,0.0001581022);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1731,0.0001793789);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1772,2.807293e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1774,4.438145e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1776,6.212473e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1778,8.027623e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1780,0.0001612147);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1781,0.0001908094);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1782,0.0002276304);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1783,0.0002395304);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1784,0.0002783405);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1785,0.0002635819);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1786,0.0002728536);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1787,0.0002411224);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1788,0.0002402437);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1789,0.0002288622);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1790,0.0001996273);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1791,0.0001886196);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1792,0.0001761253);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1793,0.0001690951);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1843,0.0001574478);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1844,0.0002254544);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1845,0.0002147969);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1846,0.0002333639);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1847,0.0002508173);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1848,0.00025361);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1849,0.0002513475);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1850,0.0003340564);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1851,0.0002782331);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1852,0.0002112011);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1853,0.0002069334);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1854,0.000188207);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1855,0.0002137868);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1898,2.282683e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1900,4.480286e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1902,6.614009e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1904,8.539101e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1905,0.0001233994);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1906,0.0001634714);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1907,0.0002102352);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1908,0.0002437836);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1909,0.0002461384);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1910,0.0002456679);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1911,0.0002417308);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1912,0.0003232527);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1913,0.0002534751);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1914,0.0002283143);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1915,0.0002148885);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1916,0.0002001501);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1917,0.0001923421);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1967,8.586748e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1968,0.0001237458);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1969,0.0001687482);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1970,0.000189064);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1971,0.0002185544);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1972,0.0002328296);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1973,0.000288726);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1974,0.0002795305);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1975,0.0002486722);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1976,0.0002692458);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1977,0.0002338392);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1978,0.0002132109);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(1979,0.0002097339);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2024,2.115664e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2026,4.254595e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2028,6.909806e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2029,7.949796e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2030,8.215687e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2031,0.0001341018);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2032,0.0001540397);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2033,0.0002453155);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2034,0.0002327243);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2035,0.0002511863);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2036,0.0002509226);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2037,0.0002669382);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2038,0.0002495181);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2039,0.0002670974);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2040,0.0002682828);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2041,0.000212491);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2091,5.944203e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2092,9.239976e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2093,8.597472e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2094,0.000122825);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2095,0.0001618424);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2096,0.0002051112);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2097,0.0002083406);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2098,0.0002368131);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2099,0.000264867);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2100,0.0002534897);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2101,0.0002756357);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2102,0.0002421236);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2103,0.0002303919);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2150,2.545894e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2152,4.055778e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2153,5.182402e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2154,9.482789e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2155,8.845684e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2156,8.265145e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2157,0.0001374455);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2158,0.0002145819);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2159,0.0001874543);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2160,0.00021664);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2161,0.0002421208);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2162,0.0002494001);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2163,0.0002536412);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2164,0.0003344562);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2165,0.0002468844);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2215,5.699655e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2216,7.650951e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2217,6.069608e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2218,9.862092e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2219,7.591309e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2220,0.0001327481);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2221,0.0001557187);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2222,0.000191194);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2223,0.0002262018);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2224,0.0002668518);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2225,0.0002460585);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2226,0.000275828);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2227,0.0002478116);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2276,2.427172e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2277,3.113453e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2278,4.075269e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2279,4.952869e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2280,7.679127e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2281,8.291621e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2282,8.692801e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2283,0.0001223159);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2284,0.0001680761);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2285,0.0002098228);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2286,0.0002393827);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2287,0.0002548749);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2288,0.0002640154);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2289,0.0002529331);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2339,2.595722e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2340,2.874407e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2341,4.569263e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2342,5.730181e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2343,6.82791e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2344,8.484141e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2345,8.605446e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2346,0.0001229386);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2347,0.0001610231);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2348,0.0001960788);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2349,0.0002573457);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2350,0.0003955924);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2351,0.0002410665);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2402,1.467708e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2403,3.443191e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2404,5.42966e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2405,5.116414e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2406,6.107264e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2407,7.871678e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2408,7.919315e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2409,0.0001253732);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2410,0.0001669727);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2411,0.0002304546);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2412,0.0002248406);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2413,0.0002578354);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2465,2.339215e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2466,3.180029e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2467,4.695628e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2468,5.261216e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2469,6.00829e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2470,9.594225e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2471,0.000128884);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2472,0.0001225046);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2473,0.0001598536);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2474,0.0001954187);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2475,0.0002178282);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2528,2.085995e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2529,4.161885e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2530,3.708189e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2531,5.936584e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2532,6.916326e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2533,8.331798e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2534,9.307764e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2535,0.0001227111);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2536,0.0001532716);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2537,0.0002049825);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2591,2.938686e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2592,3.206086e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2593,4.219381e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2594,5.212985e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2595,6.155412e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2596,8.947328e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2597,8.73018e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2598,0.0001586428);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2599,0.000163456);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2655,2.863545e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2657,4.938746e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2659,7.687086e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2661,0.0001110258);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2781,3.385974e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2783,4.960657e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2785,7.985297e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2907,3.119819e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(2909,4.956833e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetBinError(3033,3.084729e-05);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetEntries(197549.3);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_500HT800_200MHTinf->Draw("colz");
   c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf->Modified();
   c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf->cd();
   c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf->SetSelected(c_AccEffMap_T1tttt_8NJetinf_500HT800_200MHTinf);
}
/*
   400     0   0.000101794
   400    25   0.000119262
   400    75   8.66436e-05
   400   125   4.86613e-05
   400   175   6.57241e-05
   450     0   0.000361017
   450    25   0.000525541
   450    75   0.000207643
   450   125   0.000134052
   450   175   8.12105e-05
   450   225   7.52379e-05
   500     0    0.00107433
   500    25    0.00113309
   500    75   0.000893486
   500   125   0.000335369
   500   175   0.000205172
   500   225   0.000185555
   500   275   0.000102447
   550     0    0.00240123
   550    25    0.00266929
   550    75    0.00219369
   550   125    0.00126474
   550   175   0.000459394
   550   225   0.000327168
   550   275   0.000132745
   550   325    6.6919e-05
   600     0    0.00334422
   600    25    0.00392885
   600    75    0.00369771
   600   125    0.00347768
   600   175    0.00196833
   600   225   0.000667899
   600   275   0.000414239
   600   325   0.000202274
   600   375   0.000104728
   650     0    0.00507933
   650    25    0.00447446
   650    75     0.0051161
   650   125    0.00558781
   650   175    0.00393308
   650   225    0.00230138
   650   275   0.000849871
   650   325   0.000509355
   650   375   0.000259901
   650   425   0.000138829
   700     0    0.00472064
   700    25    0.00476212
   700    75    0.00583571
   700   125     0.0052989
   700   175    0.00624353
   700   225    0.00448528
   700   275    0.00325239
   700   325   0.000930569
   700   375   0.000601879
   700   425   0.000214029
   700   475   0.000107593
   750     0    0.00442961
   750    25    0.00434271
   750    75    0.00535278
   750   125    0.00591926
   750   175    0.00664305
   750   225    0.00602151
   750   275    0.00550137
   750   325    0.00307961
   750   375    0.00132657
   750   425   0.000636848
   750   475   0.000252929
   750   525   0.000126744
   775    25    0.00436368
   775    75    0.00478337
   775   125    0.00501115
   775   175    0.00610203
   775   225    0.00705706
   775   275    0.00653502
   775   325    0.00469092
   775   375    0.00229636
   775   425   0.000462769
   775   475   0.000347505
   775   525   0.000236677
   775   575     0.0001209
   800     0    0.00393103
   825    25    0.00367508
   825    75    0.00462761
   825   125    0.00474523
   825   175    0.00566682
   825   225    0.00648827
   825   275    0.00720363
   825   325     0.0063082
   825   375    0.00466314
   825   425    0.00246892
   825   475   0.000602916
   825   525   0.000403333
   825   575   0.000189989
   825   625   0.000123197
   850     0    0.00331092
   875    25     0.0030708
   875    75    0.00348235
   875   125    0.00382059
   875   175    0.00485875
   875   225    0.00572959
   875   275    0.00620567
   875   325    0.00751944
   875   375    0.00678111
   875   425    0.00543941
   875   475    0.00279537
   875   525   0.000707839
   875   575   0.000529574
   875   625    0.00024162
   875   675   0.000108564
   900     0    0.00263694
   925    25    0.00223535
   925    75     0.0027768
   925   125     0.0031725
   925   175    0.00349326
   925   225    0.00433593
   925   275    0.00612385
   925   325    0.00697981
   925   375    0.00743087
   925   425    0.00715185
   925   475    0.00567059
   925   525    0.00274642
   925   575    0.00067231
   925   625   0.000517888
   925   675   0.000273086
   925   725   7.19679e-05
   950     0    0.00213787
   975    25    0.00195098
   975    75    0.00202311
   975   125    0.00250083
   975   175    0.00302522
   975   225    0.00343744
   975   275    0.00434297
   975   325    0.00543181
   975   375    0.00676544
   975   425    0.00757381
   975   475    0.00760986
   975   525    0.00561783
   975   575    0.00307777
   975   625   0.000822381
   975   675   0.000521835
   975   725    0.00027906
   975   775   6.33866e-05
  1000     0    0.00169991
  1025    25    0.00153377
  1025    75    0.00165523
  1025   125    0.00182795
  1025   175     0.0023577
  1025   225    0.00318795
  1025   275    0.00357523
  1025   325    0.00484701
  1025   375    0.00545444
  1025   425    0.00700623
  1025   475    0.00733967
  1025   525    0.00706484
  1025   575    0.00601155
  1025   625    0.00314097
  1025   675   0.000887391
  1025   725   0.000604027
  1025   775   0.000254767
  1025   825   9.15348e-05
  1050     0    0.00130485
  1075    25    0.00103516
  1075    75    0.00122911
  1075   125    0.00159609
  1075   175    0.00170702
  1075   225    0.00216267
  1075   275    0.00246384
  1075   325    0.00338456
  1075   375    0.00446695
  1075   425     0.0055885
  1075   475    0.00714726
  1075   525    0.00789972
  1075   575    0.00733458
  1075   625    0.00596095
  1075   675    0.00335413
  1075   725     0.0010106
  1075   775   0.000656726
  1075   825    0.00023248
  1075   875   8.38336e-05
  1100     0   0.000960048
  1100    25    0.00116251
  1100    75    0.00114417
  1100   125    0.00131278
  1100   175    0.00168338
  1100   225    0.00214792
  1100   275    0.00238298
  1100   325    0.00299872
  1100   375    0.00385849
  1100   425    0.00500886
  1100   475    0.00635058
  1100   525    0.00727085
  1100   550      0.007922
  1100   575    0.00743643
  1100   600     0.0075652
  1100   625    0.00731316
  1100   650     0.0060094
  1100   675    0.00460126
  1100   700    0.00317081
  1100   725     0.0017164
  1100   750   0.000921653
  1100   775   0.000870871
  1100   800   0.000499563
  1100   825    0.00037255
  1100   850    0.00026049
  1100   875   0.000142474
  1100   900   9.69735e-05
  1125   525    0.00665539
  1125   550    0.00733305
  1125   575    0.00775156
  1125   600    0.00792716
  1125   625     0.0080967
  1125   650    0.00687621
  1125   675    0.00570584
  1125   700    0.00452105
  1125   725    0.00338728
  1125   750    0.00201378
  1125   775   0.000944107
  1125   800   0.000939324
  1125   825   0.000566957
  1125   850   0.000560491
  1125   875   0.000240623
  1125   900   9.95083e-05
  1125   925    2.5421e-05
  1150     0   0.000835309
  1150    25   0.000888362
  1150    75   0.000853989
  1150   125    0.00104927
  1150   175    0.00113107
  1150   225    0.00153967
  1150   275    0.00161494
  1150   325    0.00218447
  1150   375    0.00281579
  1150   425    0.00380375
  1150   475    0.00483011
  1150   525    0.00602155
  1150   550    0.00657271
  1150   575    0.00750702
  1150   600    0.00798824
  1150   625    0.00790614
  1150   650     0.0079015
  1150   675    0.00698448
  1150   700    0.00587346
  1150   725    0.00457108
  1150   750    0.00333354
  1150   775    0.00172485
  1150   800    0.00104171
  1150   825   0.000928179
  1150   850   0.000487649
  1150   875   0.000331338
  1150   900    0.00023675
  1150   925   0.000153606
  1150   950   8.09176e-05
  1175   525    0.00528436
  1175   550    0.00615747
  1175   575    0.00694464
  1175   600    0.00690077
  1175   625    0.00741798
  1175   650    0.00811013
  1175   675     0.0079548
  1175   700    0.00692305
  1175   725    0.00654299
  1175   750    0.00456932
  1175   775    0.00312791
  1175   800     0.0020576
  1175   825   0.000974982
  1175   850     0.0011287
  1175   875   0.000631603
  1175   900   0.000361534
  1175   925   0.000202584
  1175   950    0.00014552
  1175   975   5.89177e-05
  1200     0   0.000637083
  1200    25    0.00058777
  1200    75     0.0007939
  1200   125    0.00080966
  1200   175   0.000921223
  1200   225    0.00110557
  1200   275    0.00164021
  1200   325    0.00169787
  1200   375    0.00212695
  1200   425    0.00282836
  1200   475    0.00323523
  1200   525    0.00486489
  1200   550     0.0056288
  1200   575     0.0060363
  1200   600    0.00694493
  1200   625    0.00783313
  1200   650    0.00792766
  1200   675    0.00824386
  1200   700    0.00775664
  1200   725     0.0074994
  1200   750    0.00612727
  1200   775    0.00473547
  1200   800    0.00334979
  1200   825    0.00194067
  1200   850   0.000829166
  1200   875   0.000962861
  1200   900   0.000605246
  1200   925   0.000346343
  1200   950   0.000260732
  1200   975     0.0002456
  1200  1000   9.72846e-05
  1225   525    0.00418262
  1225   550    0.00446762
  1225   575    0.00559689
  1225   600    0.00610281
  1225   625    0.00683841
  1225   650     0.0074765
  1225   675    0.00782746
  1225   700    0.00812529
  1225   725    0.00774105
  1225   750    0.00697543
  1225   775    0.00652653
  1225   800    0.00508837
  1225   825    0.00337161
  1225   850    0.00195129
  1225   875    0.00108884
  1225   900    0.00101442
  1225   925   0.000544722
  1225   950   0.000403044
  1225   975   0.000202473
  1225  1000   0.000156762
  1250     0   0.000546682
  1250    25    0.00052075
  1250    75   0.000653291
  1250   125   0.000679416
  1250   175   0.000793182
  1250   225   0.000820024
  1250   275    0.00102748
  1250   325    0.00138015
  1250   375    0.00147063
  1250   425    0.00225387
  1250   475    0.00301468
  1250   525    0.00366496
  1250   550    0.00396168
  1250   575    0.00504274
  1250   600    0.00574583
  1250   625     0.0061937
  1250   650    0.00672326
  1250   675     0.0074027
  1250   700    0.00809284
  1250   725     0.0075012
  1250   750    0.00769736
  1250   775    0.00714293
  1250   800    0.00560456
  1250   825    0.00456339
  1250   850    0.00328433
  1250   875    0.00184385
  1250   900    0.00100039
  1250   925   0.000897717
  1250   950   0.000529384
  1250   975   0.000439464
  1250  1000   0.000249019
  1250  1025   0.000124537
  1275   525    0.00281101
  1275   550    0.00395007
  1275   575    0.00415425
  1275   600    0.00511402
  1275   625    0.00518286
  1275   650    0.00647527
  1275   675    0.00701188
  1275   700    0.00662083
  1275   725    0.00837453
  1275   750     0.0079886
  1275   775    0.00821806
  1275   800    0.00710412
  1275   825    0.00615483
  1275   850    0.00488837
  1275   875      0.003619
  1275   900    0.00210942
  1275   925   0.000831777
  1275   950   0.000662436
  1275   975   0.000593114
  1275  1000   0.000409568
  1300     0    0.00041339
  1300    25   0.000343606
  1300    75   0.000347473
  1300   125   0.000527605
  1300   175   0.000607532
  1300   225   0.000590109
  1300   275   0.000652909
  1300   325   0.000896153
  1300   375    0.00131357
  1300   425    0.00156891
  1300   475    0.00217282
  1300   525    0.00268672
  1300   550    0.00277583
  1300   575    0.00343611
  1300   600    0.00408353
  1300   625    0.00488838
  1300   650    0.00517986
  1300   675    0.00621962
  1300   700     0.0069818
  1300   725    0.00764473
  1300   750    0.00798779
  1300   775    0.00769911
  1300   800    0.00864398
  1300   825    0.00752905
  1300   850    0.00641466
  1300   875    0.00486696
  1300   900    0.00347186
  1300   925    0.00204386
  1300   950    0.00121168
  1300   975    0.00101323
  1300  1000   0.000471426
  1300  1025   0.000368614
  1300  1075   0.000178904
  1325   525    0.00223235
  1325   550    0.00244279
  1325   575    0.00291314
  1325   600    0.00334646
  1325   625    0.00413771
  1325   650    0.00492029
  1325   675    0.00516278
  1325   700    0.00578679
  1325   725    0.00635485
  1325   750    0.00774444
  1325   775    0.00773459
  1325   800    0.00841613
  1325   825    0.00814001
  1325   850    0.00746758
  1325   875    0.00647962
  1325   900    0.00493033
  1325   925    0.00332458
  1325   950    0.00206675
  1325   975    0.00116997
  1325  1000   0.000943861
  1350     0   0.000270409
  1350    25   0.000366396
  1350    75   0.000360899
  1350   125   0.000558074
  1350   175   0.000438325
  1350   225   0.000468863
  1350   275    0.00069869
  1350   325   0.000682423
  1350   375    0.00104437
  1350   425    0.00112457
  1350   475    0.00156238
  1350   525    0.00200059
  1350   550    0.00230022
  1350   575    0.00265353
  1350   600    0.00269775
  1350   625    0.00320935
  1350   650    0.00407261
  1350   675    0.00469852
  1350   700    0.00538649
  1350   725    0.00605616
  1350   750    0.00712801
  1350   775    0.00785795
  1350   800    0.00810897
  1350   825    0.00854593
  1350   850    0.00807809
  1350   875    0.00744018
  1350   900    0.00643293
  1350   925    0.00493159
  1350   950    0.00351992
  1350   975    0.00208805
  1350  1000    0.00108702
  1350  1025   0.000896624
  1350  1075   0.000383439
  1350  1125   0.000152554
  1375   525    0.00170306
  1375   550    0.00212898
  1375   575    0.00239213
  1375   600    0.00266288
  1375   625    0.00306282
  1375   650    0.00330937
  1375   675    0.00402941
  1375   700    0.00450873
  1375   725    0.00523311
  1375   750    0.00604224
  1375   775    0.00696786
  1375   800      0.007484
  1375   825    0.00835346
  1375   850    0.00846596
  1375   875    0.00828454
  1375   900     0.0069079
  1375   925    0.00634534
  1375   950    0.00502799
  1375   975    0.00328019
  1375  1000    0.00194716
  1400     0    0.00023069
  1400    25   0.000285669
  1400    75   0.000251712
  1400   125    0.00030057
  1400   175   0.000363934
  1400   225   0.000445324
  1400   275   0.000497179
  1400   325   0.000541801
  1400   375     0.0008141
  1400   425    0.00099834
  1400   475   0.000938768
  1400   525    0.00160258
  1400   550    0.00180765
  1400   575     0.0019033
  1400   600    0.00224241
  1400   625    0.00247052
  1400   650    0.00318214
  1400   675     0.0036727
  1400   700    0.00416715
  1400   725    0.00458679
  1400   750    0.00512932
  1400   775    0.00576416
  1400   800    0.00669737
  1400   825    0.00769048
  1400   850    0.00799038
  1400   875    0.00860963
  1400   900     0.0078419
  1400   925    0.00750489
  1400   950    0.00596893
  1400   975    0.00466146
  1400  1000     0.0034788
  1400  1025    0.00181397
  1400  1075   0.000958239
  1400  1125   0.000389441
  1400  1175   0.000150798
*/
