{
//=========Macro generated from canvas: c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf/c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf
//=========  (Sat Feb 22 16:28:33 2014) by ROOT version5.32/00
   TCanvas *c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf = new TCanvas("c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf", "c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf",115,312,500,500);
   c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf->Range(0,0,1,1);
   c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf->SetFillColor(0);
   c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf->SetBorderMode(0);
   c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf->SetBorderSize(2);
   c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf->SetLogz();
   c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf->SetFrameBorderMode(0);
   
   TH2D *h_EffAcc_8NJetinf_1000HT1250_200MHTinf = new TH2D("h_EffAcc_8NJetinf_1000HT1250_200MHTinf","h_EffAcc_8NJetinf_1000HT1250_200MHTinf",60,0,1500,60,0,1500);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(75,5.390593e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(77,2.501266e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(81,0.0001127237);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(83,2.791785e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(85,9.071304e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(87,0.0002628221);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(89,0.0001203959);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(91,0.0001231201);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(93,0.0002058178);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(95,5.566244e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(97,9.189455e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(99,8.993107e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(101,0.0001548397);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(199,2.384288e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(201,3.127301e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(203,2.915759e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(205,5.625535e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(207,0.0001131017);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(209,8.925353e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(211,0.0001488866);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(213,6.257942e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(215,0.0001229485);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(217,0.0001341566);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(219,9.834686e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(221,0.0001624583);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(223,0.0001931475);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(225,3.262625e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(227,0.0001840348);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(329,2.67078e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(331,8.103098e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(333,5.849925e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(335,0.0001481191);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(337,8.658758e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(339,0.0001148305);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(341,8.814689e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(343,2.821516e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(345,2.804046e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(347,0.0001658679);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(349,0.0001538962);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(351,0.0001843628);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(449,2.496598e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(451,2.911062e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(453,8.274351e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(455,2.687368e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(457,5.843742e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(459,0.0001000347);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(461,0.0001511169);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(463,0.0001227521);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(465,0.0001918751);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(467,5.997001e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(469,0.000122613);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(471,0.0002005185);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(473,9.487583e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(475,6.826416e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(575,2.597626e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(579,8.135704e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(581,0.000109923);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(583,8.910734e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(585,9.297104e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(587,5.61184e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(589,3.164668e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(591,8.692455e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(593,0.0001813572);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(595,9.206848e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(597,0.0001193481);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(599,8.761846e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(699,2.933804e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(701,5.285508e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(705,2.712333e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(707,0.0001173622);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(709,9.068555e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(711,9.121623e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(713,0.0001203311);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(715,0.0001814303);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(717,2.816941e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(719,0.000241944);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(721,0.0001588346);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(723,8.845393e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(825,5.272254e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(829,5.430448e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(831,8.305289e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(833,5.907249e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(835,3.167252e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(837,0.0001238629);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(839,9.591562e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(841,6.313154e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(843,0.0002155119);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(845,0.0002993063);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(847,0.0001196484);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(951,2.70811e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(953,2.759996e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(955,5.542508e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(959,2.809941e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(961,0.0001274093);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(963,9.36793e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(965,7.081626e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(967,0.0002534553);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(969,0.0002044193);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(971,8.82231e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1075,3.20927e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1077,5.60939e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1079,3.117191e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1081,8.337777e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1083,0.0001469454);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1085,0.000191466);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1087,0.0002019776);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1089,6.354945e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1091,9.164962e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1093,9.138011e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1095,8.784814e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1199,2.706268e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1203,2.755367e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1205,2.7882e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1207,6.133818e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1209,9.697675e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1211,9.077095e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1213,0.0001236961);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1215,0.000212064);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1217,0.0001728743);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1219,0.0001127231);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1325,2.751992e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1327,2.763299e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1329,5.77511e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1331,8.677856e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1333,0.0001194296);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1335,8.403288e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1337,8.76973e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1339,0.0001596491);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1341,8.675645e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1343,0.0002115723);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1451,2.779892e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1455,8.413171e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1457,8.761969e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1459,8.542278e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1461,9.531273e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1463,6.200518e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1465,0.0001868969);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1467,0.0001190743);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1577,5.612489e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1579,2.874627e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1585,8.740304e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1587,8.86693e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1589,0.0002150641);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1591,0.0001192748);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1703,2.798979e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1705,2.821307e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1707,8.623477e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1711,9.494789e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1713,5.663226e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1715,6.313696e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1835,9.145832e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1837,0.0001128935);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1839,0.000207466);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1957,8.457285e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1959,5.626858e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1961,8.418247e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(1963,0.000176268);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2081,5.619684e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2083,2.837881e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2085,2.812099e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2087,0.000175518);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2211,8.374523e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinContent(2335,0.0001152583);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(75,3.811837e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(77,2.501304e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(81,5.665723e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(83,2.791832e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(85,5.250614e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(87,8.777205e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(89,6.037247e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(91,6.16492e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(93,7.798832e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(95,3.93606e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(97,5.313647e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(99,5.210371e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(101,6.955136e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(199,2.384322e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(201,3.127349e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(203,2.915805e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(205,3.984857e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(207,5.672437e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(209,5.183712e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(211,6.68771e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(213,4.452412e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(215,6.156329e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(217,6.735194e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(219,5.701675e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(221,7.295283e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(223,7.908135e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(225,3.262682e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(227,7.552622e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(329,2.670823e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(331,4.678555e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(333,4.14381e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(335,6.64194e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(337,5.007379e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(339,5.749815e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(341,5.097558e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(343,2.821564e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(345,2.804094e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(347,7.445282e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(349,6.907864e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(351,7.571752e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(449,2.496636e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(451,2.911108e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(453,4.785066e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(455,2.687412e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(457,4.139429e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(459,5.783164e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(461,6.769679e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(463,6.148641e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(465,7.867285e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(467,4.247994e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(469,6.153541e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(471,8.213376e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(473,5.477936e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(475,4.828754e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(575,2.597667e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(579,4.697382e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(581,5.496513e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(583,5.153105e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(585,5.381317e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(587,3.968304e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(589,3.164722e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(591,5.018854e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(593,7.43195e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(595,5.347207e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(597,5.998697e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(599,5.066997e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(699,2.93385e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(701,3.737538e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(705,2.712378e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(707,5.898877e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(709,5.243736e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(711,5.274423e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(713,6.033993e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(715,7.4513e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(717,2.816989e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(719,8.582965e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(721,7.12142e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(723,5.115315e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(825,3.728166e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(829,3.840033e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(831,4.795301e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(833,4.184416e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(835,3.167306e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(837,6.201145e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(839,5.551762e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(841,4.480597e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(843,8.172777e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(845,9.482858e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(847,5.993164e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(951,2.708154e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(953,2.760042e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(955,3.919276e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(959,2.809988e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(961,6.403902e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(963,5.422313e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(965,5.007637e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(967,8.984757e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(969,7.738716e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(971,5.101965e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1075,3.209322e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1077,3.966572e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1079,3.117243e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1081,4.81406e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1083,6.583317e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1085,7.840999e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1087,7.641992e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1089,4.52143e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1091,5.300132e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1093,5.284546e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1095,5.08028e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1199,2.706313e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1203,2.755412e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1205,2.788247e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1207,4.344912e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1209,5.632288e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1211,5.249316e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1213,6.212931e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1215,8.060619e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1217,7.065624e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1219,5.636536e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1325,2.752038e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1327,2.763345e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1329,4.083762e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1331,5.010425e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1333,5.982207e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1335,4.851886e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1337,5.071556e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1339,7.166112e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1341,5.009147e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1343,8.010946e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1451,2.779938e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1455,4.857593e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1457,5.067068e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1459,4.93214e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1461,5.503164e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1463,4.400654e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1465,7.667063e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1467,5.96232e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1577,3.968764e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1579,2.874677e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1585,5.046482e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1587,5.127771e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1589,8.129709e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1591,5.995014e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1703,2.799026e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1705,2.821355e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1707,4.979025e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1711,5.504609e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1713,4.004642e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1715,4.492081e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1835,5.288422e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1837,5.645058e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1839,7.861752e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1957,4.883065e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1959,3.978924e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1961,4.860523e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(1963,7.208345e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2081,3.973851e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2083,2.837929e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2085,2.812147e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2087,7.194822e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2211,4.835276e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetBinError(2335,5.771233e-05);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetEntries(525.0149);

   Int_t ci;   // for color index setting
   ci = TColor::GetColor("#000099");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->SetLineColor(ci);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitle("M_{Mother} (GeV)");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetXaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitle("M_{LSP} (GeV)");
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleOffset(1.5);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetYaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetLabelFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetLabelSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetTitleSize(0.035);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->GetZaxis()->SetTitleFont(42);
   h_EffAcc_8NJetinf_1000HT1250_200MHTinf->Draw("colz");
   c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf->Modified();
   c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf->cd();
   c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf->SetSelected(c_AccEffMap_T2qq_8NJetinf_1000HT1250_200MHTinf);
}
/*
Topology ~q ~q ; ~q ->q+LSP

mSquark(GeV) mLSP(GeV) AccXEff
   300     0   5.39059e-05
   300    50   2.38429e-05
   350     0   2.50127e-05
   350    50    3.1273e-05
   350   150    2.4966e-05
   400    50   2.91576e-05
   400   150   2.91106e-05
   400   200   2.59763e-05
   400   250    2.9338e-05
   450     0   0.000112724
   450    50   5.62553e-05
   450   100   2.67078e-05
   450   150   8.27435e-05
   450   250   5.28551e-05
   450   300   5.27225e-05
   500     0   2.79179e-05
   500    50   0.000113102
   500   100    8.1031e-05
   500   150   2.68737e-05
   500   200    8.1357e-05
   500   350   2.70811e-05
   500   400   3.20927e-05
   500   450   2.70627e-05
   550     0    9.0713e-05
   550    50   8.92535e-05
   550   100   5.84993e-05
   550   150   5.84374e-05
   550   200   0.000109923
   550   250   2.71233e-05
   550   300   5.43045e-05
   550   350      2.76e-05
   550   400   5.60939e-05
   550   500   2.75199e-05
   600     0   0.000262822
   600    50   0.000148887
   600   100   0.000148119
   600   150   0.000100035
   600   200   8.91073e-05
   600   250   0.000117362
   600   300   8.30529e-05
   600   350   5.54251e-05
   600   400   3.11719e-05
   600   450   2.75537e-05
   600   500    2.7633e-05
   600   550   2.77989e-05
   650     0   0.000120396
   650    50   6.25794e-05
   650   100   8.65876e-05
   650   150   0.000151117
   650   200    9.2971e-05
   650   250   9.06855e-05
   650   300   5.90725e-05
   650   400   8.33778e-05
   650   450    2.7882e-05
   650   500   5.77511e-05
   650   600   5.61249e-05
   700     0    0.00012312
   700    50   0.000122949
   700   100   0.000114831
   700   150   0.000122752
   700   200   5.61184e-05
   700   250   9.12162e-05
   700   300   3.16725e-05
   700   350   2.80994e-05
   700   400   0.000146945
   700   450   6.13382e-05
   700   500   8.67786e-05
   700   550   8.41317e-05
   700   600   2.87463e-05
   700   650   2.79898e-05
   750     0   0.000205818
   750    50   0.000134157
   750   100   8.81469e-05
   750   150   0.000191875
   750   200   3.16467e-05
   750   250   0.000120331
   750   300   0.000123863
   750   350   0.000127409
   750   400   0.000191466
   750   450   9.69767e-05
   750   500    0.00011943
   750   550   8.76197e-05
   750   650   2.82131e-05
   800     0   5.56624e-05
   800    50   9.83469e-05
   800   100   2.82152e-05
   800   150     5.997e-05
   800   200   8.69246e-05
   800   250    0.00018143
   800   300   9.59156e-05
   800   350   9.36793e-05
   800   400   0.000201978
   800   450    9.0771e-05
   800   500   8.40329e-05
   800   550   8.54228e-05
   800   650   8.62348e-05
   850     0   9.18945e-05
   850    50   0.000162458
   850   100   2.80405e-05
   850   150   0.000122613
   850   200   0.000181357
   850   250   2.81694e-05
   850   300   6.31315e-05
   850   350   7.08163e-05
   850   400   6.35494e-05
   850   450   0.000123696
   850   500   8.76973e-05
   850   550   9.53127e-05
   850   600    8.7403e-05
   850   750   8.45729e-05
   850   800   5.61968e-05
   900     0   8.99311e-05
   900    50   0.000193147
   900   100   0.000165868
   900   150   0.000200519
   900   200   9.20685e-05
   900   250   0.000241944
   900   300   0.000215512
   900   350   0.000253455
   900   400   9.16496e-05
   900   450   0.000212064
   900   500   0.000159649
   900   550   6.20052e-05
   900   600   8.86693e-05
   900   650   9.49479e-05
   900   700   9.14583e-05
   900   750   5.62686e-05
   900   800   2.83788e-05
   950     0    0.00015484
   950    50   3.26262e-05
   950   100   0.000153896
   950   150   9.48758e-05
   950   200   0.000119348
   950   250   0.000158835
   950   300   0.000299306
   950   350   0.000204419
   950   400   9.13801e-05
   950   450   0.000172874
   950   500   8.67564e-05
   950   550   0.000186897
   950   600   0.000215064
   950   650   5.66323e-05
   950   700   0.000112893
   950   750   8.41825e-05
   950   800    2.8121e-05
  1000    50   0.000184035
  1000   100   0.000184363
  1000   150   6.82642e-05
  1000   200   8.76185e-05
  1000   250   8.84539e-05
  1000   300   0.000119648
  1000   350   8.82231e-05
  1000   400   8.78481e-05
  1000   450   0.000112723
  1000   500   0.000211572
  1000   550   0.000119074
  1000   600   0.000119275
  1000   650    6.3137e-05
  1000   700   0.000207466
  1000   750   0.000176268
  1000   800   0.000175518
  1000   850   8.37452e-05
  1000   900   0.000115258
*/
